# MyControl Centre — Enhancement Suggestions

Living backlog of product ideas beyond [FEATURES.md](./FEATURES.md). Use this file to capture **why** a feature matters and track delivery separately from core shipped features.

**Legend:** ✅ Implemented · 🚧 In progress · 📋 Suggested · ❌ Declined

**When implementing a suggestion:**

1. Update **Status** and **Version** in the table below.
2. Move or mirror the row in [FEATURES.md](./FEATURES.md) if it becomes a shipped feature.
3. Add an entry to [RELEASE_NOTES.md](./RELEASE_NOTES.md).
4. Update [MycontrolCentre.md](./MycontrolCentre.md) if schema or architecture changes.

**Product north star:** approved automation for Proxmox fleets with proof — onboard hosts safely, run vetted commands on chosen targets, log every connection and action.

---

## Priority tiers (roadmap hint)

| Tier | Focus | Examples |
|------|--------|----------|
| **Near term** | Polish current workflows | Saved run profiles, dry-run preview, scheduled health checks |
| **Medium term** | Proxmox identity | API inventory, dashboard metrics, guest-aware templates |
| **Medium term** | Safety at scale | Approval workflow, per-role allowlists, change reason |
| **Longer term** | Platform | OIDC, API tokens, jump hosts, policy engine |

---

## Operations & day-to-day usability

Improvements that make daily homelab and small-fleet operations faster and less error-prone.

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Maintenance windows | ✅ | 0.3.0 | Mark servers in maintenance; block operator runs; admin override on Commands page |
| Saved run profiles | ✅ | 0.3.0 | Named presets: servers + command chain + remediation; one-click queue |
| Run comparison view | ✅ | 0.3.0 | Batch compare tab: per-server success/fail, duration, exit code, stderr snippet |
| Live / streaming output | ✅ | 0.3.1 | SSE live output on Commands page during RUNNING runs |
| Dry-run / preview mode | ✅ | 0.3.0 | Preview exact shell per server before queueing; shows maintenance blocks |
| Rollback / follow-up commands | ✅ | 0.3.0 | Optional failure remediation templates (e.g. `dpkg --configure -a`) auto-queued on FAILED |

---

## Proxmox-specific value (big differentiator)

Features that go beyond generic SSH automation and justify using MyControl Centre for Proxmox rather than a plain shell script + SSH loop.

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Read-only Proxmox API layer | ✅ | 0.3.0 | VM/CT counts, node status, version — dashboard + cached summary per server |
| Inventory sync | ✅ | 0.3.0 | Import VMs/containers from Proxmox API; guest list on Servers → Operations |
| Guest-aware commands | ✅ | 0.3.0 | Templates with `{{vmid}}` variable; built-in `qm status` / `pct status` / restart |
| Cluster health view | ✅ | 0.3.0 | Quorum and node counts in proxmoxSummary; cluster status template |
| Backup / snapshot awareness | ✅ | 0.6.0 | Blocks destructive commands when vzdump/ZFS snapshot is stale |
| Guest picker in Commands UI | ✅ | 0.5.0 | Select VM/CT from synced inventory for {{vmid}} templates |
| Cluster health page | ✅ | 0.5.0 | Dedicated Proxmox fleet view with quorum and guest counts |
| Platform tags (Proxmox/Debian/Docker/Arch) | ✅ | 0.5.0 | Manual + auto-detect; filter commands by platform |
| Categorized command library | ✅ | 0.5.0 | Nested APT, Proxmox, Docker, Arch groups |
| Proxmox maintenance library | ✅ | 0.3.0 | Built-in templates: `pveversion -v`, cluster resources, `zfs list`, `ceph status` |

---

## Safety, governance & trust

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Command approval workflow | 📋 | — | Operator proposes run; admin approves with visible server + command diff |
| Per-role command allowlists | 📋 | — | Fine-grained: operators limited to approved templates; admins retain custom |
| Change tickets / reason field | ✅ | 0.4.0 | Required on batch / multi-command runs; stored in audit + run history |
| Secrets injection without storage | 📋 | — | Template placeholders (`{{API_KEY}}`) filled at run from env/vault — not stored in SQLite |
| Break-glass session | 📋 | — | Time-limited elevation with mandatory audit reason and auto-expiry |
| Policy engine | 📋 | — | Rules e.g. no apt upgrade on `production` tag without approval; cluster-wide concurrency caps |

---

## Visibility, alerting & reporting

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Scheduled health checks + alerts | ✅ | 0.4.0 | Periodic SSH probes; webhook, ntfy, Gotify notifications |
| Fleet dashboard | ✅ | 0.4.0 | Offline servers, failed runs, SSH error rate, quorum issues |
| Audit & log export | 📋 | — | CSV/JSON export; SIEM webhook (also listed in FEATURES.md) |
| Compliance report | 📋 | — | “Who ran apt upgrade on which hosts in 30 days” — export for change review |
| Anomaly hints | 📋 | — | Flag first-time custom on prod, new IP, spike in failed SSH connections |

---

## Server & network ergonomics

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Server groups & dynamic targets | ✅ | 0.8.0 | Static lists + tag rules; regex/subnet/ONLINE filters still 📋 |
| Jump host / bastion | 📋 | — | SSH via bastion to isolated management VLANs |
| Bulk import / export | 📋 | — | CSV import; export config without private keys |
| Credential rotation helper | 📋 | — | Roll automation keys on all hosts and update console in one flow |
| Host drift detection | 📋 | — | Light drift vs last successful probe — not full Ansible |

---

## Command & automation depth

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Scheduled / recurring runs | ✅ | 0.6.0 | Weekly UTC schedule per saved run profile |
| Command parameters / variables | ✅ | 0.3.0 | `{{vmid}}` and other template variables |
| Conditional steps | 📋 | — | UI for stop-on-failure vs continue beyond `set -e` chains |
| Playbook-lite | 📋 | — | Wait/retry steps (e.g. wait for port 8006 after `pveproxy` restart) |
| Ansible / playbook support | 📋 | — | Also in FEATURES.md — larger scope |

---

## Platform & integration

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| API tokens / service accounts | 📋 | — | CI/CD triggers approved profiles with scoped permissions |
| Notifications channel settings | 📋 | — | Central webhook/SMTP config + test notification |
| Multi-console / scale tier | 📋 | — | Optional PostgreSQL + Redis for larger teams |
| HA for the console | 📋 | — | Redundant app + shared DB behind load balancer |
| OIDC / LDAP login | 📋 | — | Enterprise auth alongside local users |
| Mobile approve & alert view | 📋 | — | Minimal UI: fleet status, approve pending runs, ack alerts |

---

## Developer & quality

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Integration tests | 📋 | — | API routes with test DB |
| E2E tests (Playwright) | 📋 | — | Login → server CRUD → run command |
| CI pipeline | ✅ | 0.6.0 | GitHub Actions: lint, test, build |
| Plugin hook for commands | 📋 | — | Register template types or post-run hooks without forking core |

---

## Changelog (suggestions file)

| Date | Change |
|------|--------|
| 2026-07-22 | Initial backlog: Operations & day-to-day usability; Proxmox-specific value; plus supporting categories |
