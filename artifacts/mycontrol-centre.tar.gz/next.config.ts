import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  serverExternalPackages: ["ssh2"],
  experimental: {
    /** Lowers peak memory during `next dev` (Next.js 15+). */
    webpackMemoryOptimizations: true,
  },
};

export default nextConfig;
