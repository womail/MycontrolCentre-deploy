# MyControl Centre — Project Documentation

## Overview

MyControl Centre is a secure automation platform for managing Proxmox servers via SSH. It provides user management, server inventory, remote command execution, interactive SSH console, SFTP file management, and a full audit trail.

### App routes (main sections)

| Area | URL | Section |
|------|-----|---------|
| **Servers** | `/servers` | Fleet (default) |
| | `/servers/setup` | SSH setup & add server |
| | `/servers/groups` | Server groups |
| | `/servers/approvals` | Pending enrollment |
| | `/servers/{id}/console` | SSH terminal + file manager |
| **Commands** | `/commands` | Run commands (default) |
| | `/commands/docker` | Docker operations |
| | `/commands/profiles` | Saved run profiles |
| | `/commands/batches` | Batch compare |
| | `/commands/manage` | Manage templates (admin) |
| **Logs** | `/logs` | Audit log (default) |
| | `/logs/remote` | SSH connection log |
| | `/logs/api` | API request log |

Helpers: `src/lib/navigation/sections.ts` (`parse*Section`, `*SectionHref`). Legacy `#pending-enrollment` redirects to `/servers/approvals`.

## Server console (SSH & files)

Operators and admins open **Servers → terminal icon → `/servers/{id}/console`**:

| Tab | Capability |
|-----|------------|
| **SSH terminal** | Live interactive shell (xterm.js). **Multiple server tabs** via “Add server”; font **+/−**; terminal fills the viewport. |
| **Files** | SFTP browser with **drag-to-resize columns** (widths saved in browser). |

- **Roles:** ADMIN and OPERATOR only (VIEWER cannot access).
- **Maintenance:** Operators are blocked when the server is in maintenance (admins can still connect).
- **Limits:** Upload 50 MB, download 100 MB per file via the UI.
- **API:** `POST/GET /api/servers/[id]/files`, upload/download routes, `POST /api/servers/[id]/terminal/session` + SSE stream.

File mutations are recorded in **AuditLog** (`SERVER_FILE_*` actions).

## Deployment

**Default:** Local native install with SQLite — only Node.js required.

| Mode | Command | Dependencies |
|------|---------|--------------|
| Local (recommended) | `./scripts/start.sh local` | Node.js 20+ only |
| Docker (optional) | `./scripts/start.sh docker` | Docker |

SQLite database file: `.data/mycontrol.db`

Previously used PostgreSQL + Redis; replaced in v0.2.0 with SQLite + embedded queue for simpler single-machine deployment.

### Proxmox LXC (native)

Deploy scripts live in the **public** repo [MycontrolCentre-deploy](https://github.com/womail/MycontrolCentre-deploy) (the application repo can stay private).

```bash
bash -c "$(curl -fsSL https://raw.githubusercontent.com/womail/MycontrolCentre-deploy/main/proxmox-create-lxc.sh)"
```

Advanced wizard:

```bash
mode=advanced bash -c "$(curl -fsSL https://raw.githubusercontent.com/womail/MycontrolCentre-deploy/main/proxmox-create-lxc.sh)"
```

| Item | Location |
|------|----------|
| Public CT script | `MycontrolCentre-deploy/proxmox-create-lxc.sh` |
| Install script | `MycontrolCentre-deploy/community-scripts/install/` |
| App install path | `/opt/mycontrol-centre` |

The LXC install **downloads a public source tarball** from [MycontrolCentre-deploy](https://github.com/womail/MycontrolCentre-deploy) (`artifacts/mycontrol-centre.tar.gz`). The application repo can stay private.

On each push to `main`, CI builds that tarball and publishes it to the deploy repo (requires `DEPLOY_REPO_TOKEN` secret — fine-grained PAT with **Contents: Read and write** on `MycontrolCentre-deploy`).

Overrides:

- **Git clone instead of tarball:** `MCC_USE_GIT=1 MCC_GIT_URL='https://x-access-token:TOKEN@github.com/womail/MycontrolCentre.git' bash -c "$(curl -fsSL ...)"`
- **Local checkout on Proxmox host:** `proxmox-lxc-deploy.sh --source-dir /path/to/MycontrolCentre`

Login after first deploy: **admin / admin**.

## Deployment (Docker)

Single-container **Docker Compose** deployment: Next.js UI + API + embedded command worker, SQLite on a named volume.

| Item | Purpose |
|------|---------|
| `Dockerfile` | Multi-stage build (Next.js `standalone` output) |
| `docker-compose.yml` | Port publish, secrets, `mcc_data` volume |
| `docker-entrypoint.sh` | Schema push, optional seed, start `server.js` |
| `.env.docker.example` | Template for container env (copy to `.env`) |

### Quick start

```bash
cp .env.docker.example .env
# Edit APP_URL to your LAN URL (Proxmox hosts must reach it, not localhost-only).

./scripts/start.sh docker
# Or: docker compose up -d --build
```

`./scripts/start.sh docker` creates `.env` if missing and generates `SESSION_SECRET` / `ENCRYPTION_KEY` when placeholders are still set.

Default login after seed: **admin / admin** (change password on first login).

### Operations

| Task | Command |
|------|---------|
| Follow logs | `docker compose logs -f app` |
| Restart | `docker compose restart app` |
| Stop | `./scripts/start.sh stop docker` or `docker compose down` |
| Rebuild | `./scripts/docker-build.sh --no-cache` (auto-retries with `sudo` if needed), then `sudo docker compose up -d --force-recreate` |
| Upsert built-in commands (templates) | `sudo docker compose exec app npm run db:seed` (uses bundled seed in the image) |
| Check deploy | `curl -s http://127.0.0.1:3000/api/health` on the Docker host — expect current `buildRef` and `"sshKeygen":"/usr/bin/ssh-keygen"` |
| Shell | `docker compose exec app sh` |

### Data and paths

- SQLite file inside the container: `/app/.data/mycontrol.db`
- Compose volume: `mcc_data` → `/app/.data` (persists upgrades and restarts)
- Entrypoint runs as **root** only to `chown` the data dir, then runs the app as user `nextjs`.

### Environment (container)

Use the same variables as native install; in Docker set:

- `DATABASE_URL=file:/app/.data/mycontrol.db` (default in compose)
- `APP_URL` — public URL clients and Proxmox use (e.g. `http://10.0.0.5:3000`)
- Do **not** set `NODE_ENV` in `.env` (image uses `production`)

Health check: `GET /api/health` (used by Docker `HEALTHCHECK`). Response includes `version`, `buildRef`, `buildTime`, and `sshKeygen`. Authenticated **About** details: `GET /api/about` (also under **Settings** and **Admin → System**).

### Production notes

- Set strong `SESSION_SECRET` and `ENCRYPTION_KEY` in `.env` before first deploy.
- Put a reverse proxy (TLS) in front if exposed beyond LAN.
- The Docker image includes **`openssh-keygen`**; the SSH wizard runs **`ssh-keygen -t ed25519`** (OpenSSH private key format). If the binary is missing, the app falls back to an equivalent in-process generator.
- For low memory, prefer this image over `next dev` (see Admin → System profile / `npm run memory:report`).

Native install remains the default; Docker is optional.

See **[SECURITY.md](./SECURITY.md)** for OWASP alignment, SBOM generation (`npm run sbom`), and hardening guidance.

## Environment variables

| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | SQLite path, e.g. `file:../.data/mycontrol.db` |
| `RUN_EMBEDDED_WORKER` | Run command queue inside app process (default `true`) |
| `SESSION_SECRET` | Session signing secret (32+ chars) |
| `ENCRYPTION_KEY` | Base64 32-byte key for credential encryption |
| `SECRETS_VAULT_PASSWORD` | Strong password to unlock **Admin → Vault** (view decrypted SSH keys/passwords; 15‑min session cookie). Credentials remain encrypted in SQLite via `ENCRYPTION_KEY`. Still works alone as break-glass unlock. Admins with MFA enrolled may also unlock with account password + TOTP or security key. |
| `APP_URL` | Public URL for the application |
| `MAX_CONCURRENT_SSH` | Default max parallel SSH sessions (overridable in UI) |
| `SESSION_MAX_AGE_HOURS` | Session lifetime (default 24) |
| `AUDIT_LOG_RETENTION_DAYS` | Audit log retention (default 365) |
| `API_LOG_RETENTION_DAYS` | API request log retention (default 14) |
| `RUN_SEED` | Docker entrypoint: run idempotent seed (default `true`) |
| `MCC_PORT` | Host port for compose publish (default 3000) |

Generate secrets:

```bash
openssl rand -base64 32   # SESSION_SECRET
openssl rand -base64 32   # ENCRYPTION_KEY
```

## Database schema

### User

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| username | String | Unique login name |
| passwordHash | String | bcrypt hash |
| role | UserRole | ADMIN, OPERATOR, VIEWER |
| mustChangePassword | Boolean | Force password change on login |
| isActive | Boolean | Account enabled |
| createdAt | DateTime | Created timestamp |
| updatedAt | DateTime | Updated timestamp |

### UserMfa

| Column | Type | Description |
|--------|------|-------------|
| userId | String (PK, FK → User) | One row per user |
| totpEnabled | Boolean | Authenticator app active |
| encryptedTotpSecret | String? | AES-encrypted TOTP secret |
| updatedAt | DateTime | Updated timestamp |

### WebAuthnCredential

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| userId | String | FK → User |
| credentialId | String | WebAuthn credential id (unique) |
| publicKey | String | Base64url COSE public key |
| counter | BigInt | Signature counter |
| deviceName | String? | User label |
| createdAt | DateTime | Registered at |
| lastUsedAt | DateTime? | Last successful auth |

### VaultAccessLog

Tracks when vault secrets are viewed (unlock session load) or copied.

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| userId | String | FK → User (admin) |
| entryType | VaultEntryType | SERVER or SETUP_KEY |
| entryId | String | Server or setup key id |
| entryLabel | String? | Display name / fingerprint |
| action | VaultAccessAction | VIEW or COPY |
| ipAddress | String? | Client IP |
| userAgent | String? | Browser user-agent |
| clientLabel | String? | Short label from browser (platform + UA snippet) |
| clientNode | String? | Admin workstation node (X-MCC-Client-Node or reverse DNS on IP) |
| createdAt | DateTime | Event time |

### Session

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| tokenHash | String | SHA-256 hash of session token |
| userId | String | FK → User |
| ipAddress | String? | Client IP |
| userAgent | String? | Client user agent |
| expiresAt | DateTime | Session expiry |
| createdAt | DateTime | Created timestamp |

### Server

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| name | String | Display name |
| hostname | String | IP or hostname |
| port | Int | SSH port (default 22) |
| sshUser | String | SSH username |
| authType | SshAuthType | KEY, PASSWORD, KEY_AND_PASSWORD |
| encryptedPrivateKey | String? | AES-256-GCM encrypted PEM key |
| encryptedPassword | String? | AES-256-GCM encrypted password/passphrase |
| knownHostKey | String? | Base64 host key for verification |
| acceptNewHostKey | Boolean | Trust host key on first connect |
| tags | Json | Array of tag strings (stored as JSON) |
| manualPlatforms | Json | Admin-selected platform tags |
| detectedPlatforms | Json | Detected capabilities (proxmox, docker, …) |
| detectedOsId | String? | `/etc/os-release` ID (ubuntu, debian, arch, alpine, …) |
| detectedOsLabel | String? | `PRETTY_NAME` from os-release |
| detectedOsFamily | String? | Grouped family: `debian`, `arch`, `alpine`, `unknown` |
| osDetectedAt | DateTime? | Last OS detection (health check) |
| healthStatus | HealthStatus | UNKNOWN, ONLINE, OFFLINE |
| lastHealthCheck | DateTime? | Last health probe time |
| healthMessage | String? | Last health check output/error |
| isActive | Boolean | Server enabled |
| inMaintenance | Boolean | Blocks operator command runs |
| maintenanceNote | String? | Reason shown when blocked |
| maintenanceUntil | DateTime? | Auto-expire maintenance after this time |
| proxmoxApiPort | Int | Proxmox API port (default 8006) |
| proxmoxTokenId | String? | e.g. `root@pam!mycontrol` |
| encryptedProxmoxToken | String? | AES-256-GCM encrypted API token secret |
| proxmoxNodeName | String? | Node name for API calls |
| proxmoxVersion | String? | Last synced PVE version |
| proxmoxSummary | Json? | Cached cluster metrics (VM/CT counts, quorum, etc.) |
| lastProxmoxSync | DateTime? | Last Proxmox inventory sync |
| lastBackupAt | DateTime? | Last vzdump or ZFS snapshot timestamp (Proxmox hosts) |
| lastBackupSource | String? | `vzdump` or `zfs` |
| pendingPackageUpdates | Int? | Cached apt upgrade count (Debian/Proxmox hosts) |
| lastPackageUpdatesCheck | DateTime? | Last apt check via SSH |
| createdAt | DateTime | Created timestamp |
| updatedAt | DateTime | Updated timestamp |

### ServerEnrollmentRequest

Remote hosts submit enrollment via `POST /api/enrollment/register` (Bearer enrollment token). Admins approve to create a `Server` row.

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| status | EnrollmentStatus | PENDING, APPROVED, REJECTED |
| name | String | Suggested display name |
| hostname | String | IP or hostname from host script |
| port | Int | SSH port |
| sshUser | String | Automation user |
| publicKey | String | OpenSSH public key line |
| publicKeyFingerprint | String? | SHA-256 fingerprint |
| knownHostKey | String? | Host SSH key (optional) |
| hostKeyType | String? | ed25519 / rsa |
| metadata | Json? | OS/kernel from host |
| requestIp | String? | Client IP of register call |
| createdAt | DateTime | Submitted at |
| reviewedAt | DateTime? | Admin decision time |
| reviewedById | String? | FK → User |
| rejectReason | String? | Optional reject note |
| serverId | String? | FK → Server when approved |

### SetupSshKey

Encrypted private key from the SSH setup wizard, keyed by public-key fingerprint for enrollment approve without paste.

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| createdById | String | FK → User |
| publicKey | String | OpenSSH public key line |
| publicKeyFingerprint | String | SHA-256 (base64) of key material |
| encryptedPrivateKey | String | AES-256-GCM encrypted PEM |
| createdAt | DateTime | Created timestamp |
| expiresAt | DateTime | Auto-expire (30 days) |

App setting `enrollment_token` (via `app_settings`) secures the register endpoint. Generated wizard keys are stored encrypted in `SetupSshKey` (30-day TTL) for one-click approve. `CommandRun.server` uses `onDelete: Cascade` so deleting a server removes its command history. SSH host verification accepts a single base64 key or a JSON array when the server offers RSA or ed25519.

### ServerGroup

Named targets for batch commands: fixed server lists or tag-based dynamic membership (resolved at run time).

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| name | String | Unique group name |
| description | String? | Optional description |
| kind | ServerGroupKind | `STATIC` or `TAG` |
| serverIds | Json | Server IDs when `STATIC` |
| matchTags | Json | Tag strings when `TAG` |
| matchAnyTag | Boolean | Match any tag (true) or all tags (false) |
| createdAt | DateTime | Created timestamp |
| updatedAt | DateTime | Updated timestamp |

API: `GET/POST /api/server-groups`, `GET/PATCH/DELETE /api/server-groups/[id]`, `GET /api/server-groups/[id]/members` (admin CRUD; members readable by authenticated users).

### SavedRunProfile

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| name | String | Unique profile name |
| description | String? | Optional description |
| serverIds | Json | Array of server IDs (empty when linked to a group) |
| serverGroupId | String? | FK → ServerGroup; when set, targets resolve dynamically |
| templateIds | Json | Ordered command template IDs |
| workingDir | String? | Default working directory |
| listPath | String? | Default list path |
| customCommand | String? | Custom command override |
| failureTemplateIds | Json | Remediation templates queued on failure |
| createdById | String | FK → User |
| createdAt | DateTime | Created timestamp |
| updatedAt | DateTime | Updated timestamp |

### ProfileSchedule

Weekly UTC schedule for a saved run profile (one schedule per profile).

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| profileId | String | FK → SavedRunProfile (unique) |
| enabled | Boolean | Schedule active |
| dayOfWeek | Int | 0=Sunday … 6=Saturday (UTC) |
| hourUtc | Int | Hour 0–23 UTC |
| minuteUtc | Int | Minute 0–59 UTC |
| changeReason | String? | Default change reason for scheduled runs |
| lastRunAt | DateTime? | Last successful trigger |
| lastBatchId | String? | Batch ID from last run |
| createdAt | DateTime | Created timestamp |
| updatedAt | DateTime | Updated timestamp |

### ProxmoxGuest

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| serverId | String | FK → Server |
| guestType | ProxmoxGuestType | QEMU or LXC |
| vmid | Int | Proxmox VM/CT ID |
| name | String | Guest name |
| status | String? | running, stopped, etc. |
| cpu | String? | CPU usage snapshot |
| mem | Int? | Memory used (bytes) |
| maxmem | Int? | Max memory (bytes) |
| disk | Int? | Disk used (bytes) |
| maxdisk | Int? | Max disk (bytes) |
| syncedAt | DateTime | Last sync timestamp |

Unique constraint: `(serverId, vmid)`

### ServerAlertState

Tracks alert cooldown timestamps per server (avoids notification spam).

| Column | Type | Description |
|--------|------|-------------|
| serverId | String | PK, FK → Server |
| lastOfflineAlertAt | DateTime? | Last offline alert sent |
| lastOnlineAlertAt | DateTime? | Last recovery alert sent |
| updatedAt | DateTime | Updated timestamp |

### CommandTemplate

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| name | String | Template name |
| type | String | Built-in: CD, LS, APT_UPDATE, APT_UPGRADE; CUSTOM or any other label runs commandText |
| description | String | Human-readable description |
| commandText | String? | Shell command for CUSTOM templates |
| defaultWorkingDir | String? | Default directory for CD/LS/CUSTOM |
| defaultListPath | String? | Default path for LS |
| sortOrder | Int | Display/run ordering |
| adminOnly | Boolean | Restrict to admin role |
| requiresFreshBackup | Boolean | Require recent vzdump/ZFS backup on Proxmox hosts |
| isBuiltIn | Boolean | System-provided template |
| isActive | Boolean | Template enabled |
| createdAt | DateTime | Created timestamp |
| updatedAt | DateTime | Updated timestamp |

### CommandRun

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| batchId | String? | Groups multi-server runs |
| userId | String | FK → User |
| serverId | String | FK → Server |
| templateId | String? | FK → CommandTemplate (single-template runs) |
| commandType | String | Template type executed (or CUSTOM for multi-step runs) |
| label | String? | Human-readable label (e.g. chained commands) |
| commandText | String | Full shell command sent |
| workingDir | String? | Working directory context |
| failureTemplateIds | Json? | Remediation templates queued if run fails |
| changeReason | String? | Operator justification for batch / multi-command runs |
| status | CommandRunStatus | PENDING, RUNNING, SUCCESS, FAILED, CANCELLED |
| exitCode | Int? | Remote exit code |
| stdout | String | Standard output (max 500KB) |
| stderr | String | Standard error (max 500KB) |
| startedAt | DateTime? | Execution start |
| completedAt | DateTime? | Execution end |
| durationMs | Int? | Duration in milliseconds |
| createdAt | DateTime | Queued timestamp |

### AuditLog

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| userId | String? | FK → User (nullable for failed logins) |
| action | AuditAction | Action type (includes SERVER_FILE_* for SFTP file manager) |
| resourceType | String? | e.g. server, user, command |
| resourceId | String? | Related resource ID |
| details | Json? | Structured metadata (secrets redacted) |
| ipAddress | String? | Client IP |
| userAgent | String? | Client user agent |
| createdAt | DateTime | Event timestamp |

### AppSetting

| Column | Type | Description |
|--------|------|-------------|
| key | String | Setting key (PK) |
| value | String | Setting value |
| updatedAt | DateTime | Last updated |

Known keys: `max_concurrent_ssh`, `audit_retention_days`, `console_public_url`, `ui_appearance` (JSON), `alert_settings` (JSON).

### RemoteConnectionLog

Outbound SSH connections from MyControl Centre to managed servers.

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| serverId | String? | FK → Server |
| serverName | String? | Denormalized server name |
| hostname | String | Target host |
| port | Int | SSH port |
| sshUser | String | SSH username |
| purpose | RemoteConnectionPurpose | HEALTH_CHECK, COMMAND, HOST_KEY_CAPTURE |
| userId | String? | FK → User who triggered the connection |
| commandRunId | String? | FK → CommandRun when purpose is COMMAND |
| outcome | ConnectionOutcome | SUCCESS or FAILED |
| durationMs | Int? | Connection/command duration |
| exitCode | Int? | Remote exit code (success path) |
| errorMessage | String? | Error text (failure path) |
| createdAt | DateTime | Event timestamp |

### ApiRequestLog

Inbound HTTP requests to `/api/*` routes.

| Column | Type | Description |
|--------|------|-------------|
| id | String (cuid) | Primary key |
| method | String | HTTP method |
| path | String | Request path |
| query | String? | Query string (without `?`) |
| statusCode | Int | Response status |
| durationMs | Int | Handler duration |
| userId | String? | FK → User if authenticated |
| ipAddress | String? | Client IP |
| userAgent | String? | Client user agent |
| createdAt | DateTime | Event timestamp |

Connection logs use the same retention as audit logs (`AUDIT_LOG_RETENTION_DAYS`).

## Scheduled health checks & alerts

Since v0.4.0, the embedded background worker probes active servers on an interval and sends notifications when status changes.

| Endpoint | Description |
|----------|-------------|
| `GET /api/settings/alerts` | Read alert settings (admin) |
| `PATCH /api/settings/alerts` | Update alert settings (admin) |
| `POST /api/settings/alerts/test` | Send test notification (admin) |

Alert channels: **webhook**, **ntfy**, **Gotify**. Settings include health-check interval, recovery alerts, cooldown, and maintenance suppression.

## Scheduled profile runs

Since v0.6.0, saved run profiles can run on a weekly UTC schedule from the embedded worker.

| Endpoint | Description |
|----------|-------------|
| `GET /api/commands/profiles/[id]/schedule` | Read profile schedule |
| `PUT /api/commands/profiles/[id]/schedule` | Enable/configure weekly UTC slot |

Schedules run as the profile creator (must be active ADMIN or OPERATOR). Use **Commands → Profiles → Schedule** to set day, hour, minute (UTC), and optional change reason.

## Backup awareness

Since v0.6.0, templates with `requiresFreshBackup` block execution on Proxmox hosts when the last vzdump or ZFS snapshot is older than the configured threshold (default **168 hours**).

- Probed during scheduled health checks → `Server.lastBackupAt`, `lastBackupSource`
- Shown in dry-run preview; blocked at execute unless admin enables **Override stale backup guard**
- Configure threshold in **Settings → System → Backup freshness threshold**

## Docker host operations

Since v0.7.0, **Commands → Docker** provides:

| Feature | Description |
|---------|-------------|
| Install Docker Engine (Ubuntu) | Official apt repository install ([Docker docs](https://docs.docker.com/engine/install/ubuntu/)) |
| Install Portainer CE | Official `portainer/portainer-ce:lts` container ([Portainer docs](https://docs.portainer.io/start/install-ce/server/docker/linux)) |
| Compose deploy | SFTP upload of `docker-compose.yml` + optional `.env`, then `docker compose up -d` |

| Endpoint | Description |
|----------|-------------|
| `POST /api/servers/[id]/docker/compose` | Push compose stack to a Docker host (operator/admin) |

Built-in command templates are seeded for Docker Engine and Portainer installs; compose deploy uses a dedicated API with larger file limits (512KB compose, 64KB env).

## Live command output (SSE)

Since v0.3.1, command runs stream stdout/stderr to the UI while status is `PENDING` or `RUNNING`.

| Endpoint | Description |
|----------|-------------|
| `GET /api/commands/runs/[id]/stream` | Server-Sent Events stream (session auth required) |

Event types (JSON in `data:` field):

- `{ "type": "stdout", "data": "..." }`
- `{ "type": "stderr", "data": "..." }`
- `{ "type": "status", "status": "RUNNING" \| "SUCCESS" \| "FAILED", "exitCode": 0, "durationMs": 1234 }`

The embedded worker publishes chunks through an in-process event bus (`src/lib/commands/run-stream.ts`). Stream state lives on `globalThis.__mcc` so dev hot reload does not orphan buffers. Replay buffers are capped (merged stdout/stderr chunks, ~48k chars per run). Output is also flushed to SQLite every 2 seconds and on completion so polling/history remain available if the browser disconnects.

`GET /api/commands/runs` (list/history) returns **snippets only** (`stdoutSnippet` / `stderrSnippet`); use `GET /api/commands/runs/[id]` for full captured output.

**Memory:** Admin → System profile shows heap, live stream buffers, and background timer count. **Admin → Generate report** (or `GET /api/admin/memory-diagnostics?format=text`) dumps V8 heap spaces and runtime assessment. Offline: `npm run memory:report`. High-frequency GET polls skip API request logging. **`next dev` commonly uses 1–2 GB RSS**; use `./scripts/start.sh prod` for normal memory (~150–400 MB). Restart the Node process after long dev sessions.

**Note:** Live streaming requires `RUN_EMBEDDED_WORKER=true` (default) so the API process that serves SSE is the same process executing SSH.

## Migrations

Initial schema is applied via:

```bash
npx prisma db push
npm run db:seed
```

Seed and CLI options live in `prisma.config.ts` (replaces deprecated `package.json#prisma`).

For production, use `prisma migrate dev` to create versioned migrations.

## SSH setup guide

### Automated setup (recommended)

Use the **Automated Proxmox host setup** wizard on the **Servers** page (admin only):

1. **Generate key** — MyControl Centre runs **`ssh-keygen -t ed25519`** (via `POST /api/setup/ssh-key`). Copy the private key (shown once); it uses standard **OpenSSH** PEM (`BEGIN OPENSSH PRIVATE KEY`).
2. **Run on each Proxmox host** — the wizard gives two one-liners (as **root**, or with **sudo** if you are not root). Both overwrite `/tmp/mcc-proxmox-setup.sh`, run the script, then remove it.

**As root:**

```bash
rm -f /tmp/mcc-proxmox-setup.sh && curl -fsSL --connect-timeout 30 --noproxy '*' 'http://YOUR_CONSOLE:3000/api/setup/proxmox-host.sh' -o /tmp/mcc-proxmox-setup.sh && bash /tmp/mcc-proxmox-setup.sh --pubkey 'ssh-ed25519 AAAA... mycontrol-centre' && rm -f /tmp/mcc-proxmox-setup.sh
```

**With sudo (non-root SSH session):**

```bash
rm -f /tmp/mcc-proxmox-setup.sh && curl -fsSL --connect-timeout 30 --noproxy '*' 'http://YOUR_CONSOLE:3000/api/setup/proxmox-host.sh' -o /tmp/mcc-proxmox-setup.sh && sudo bash /tmp/mcc-proxmox-setup.sh --pubkey 'ssh-ed25519 AAAA... mycontrol-centre' && rm -f /tmp/mcc-proxmox-setup.sh
```

Set **Console URL** in the wizard (or Settings) to an address Proxmox can reach — e.g. `http://10.1.3.230:3000`, not `localhost`.

### Network troubleshooting

Ping only proves ICMP works. The setup script is fetched over **HTTP on TCP port 3000**.

1. **On the console host**, confirm the app listens on all interfaces:
   ```bash
   ss -tlnp | grep 3000    # should show 0.0.0.0:3000
   ./scripts/start.sh status
   ```
2. **From the Proxmox shell**, test connectivity (use `-v` — `curl -fsSL` is silent on failure):
   ```bash
   curl -v --connect-timeout 10 --noproxy '*' http://YOUR_CONSOLE:3000/api/health
   ```
   Expected: `{"ok":true,"service":"mycontrol-centre",...}`
3. **If curl hangs or times out**, open port 3000 on the console host firewall, e.g.:
   ```bash
   sudo ufw allow 3000/tcp
   ```
4. **If Proxmox has `http_proxy` set**, use `--noproxy '*'` (included in wizard commands).

3. **Paste host output** — the script prints connection values and JSON; the wizard pre-fills the Add Server form.
4. **Save & health check** — verify connectivity from the server list.

The bootstrap script (`scripts/proxmox-host-setup.sh`, also served at `/api/setup/proxmox-host.sh`) automatically:

- Creates user `mcc-auto` (or `--user NAME`)
- Installs your public key in `authorized_keys`
- Grants scoped passwordless `sudo` for `apt-get` / `apt`
- Prints hostname, IP, SSH port, and host key for the console

**Manual script** (copy to host):

```bash
scp scripts/proxmox-host-setup.sh root@PROXMOX:/root/
ssh root@PROXMOX './proxmox-host-setup.sh --pubkey "ssh-ed25519 AAAA..."'
```

Set `APP_URL` in `.env` to the URL Proxmox hosts can reach (not `localhost` if hosts are remote).

### Option 1: Key-based auth (manual)

1. Generate a dedicated key pair on the MyControl Centre host:

```bash
ssh-keygen -t ed25519 -f ~/.ssh/mcc-automation -C "mycontrol-centre"
```

2. On each Proxmox host, create a dedicated user:

```bash
id mcc-auto &>/dev/null || \
  { getent group mcc-auto &>/dev/null && useradd -m -s /bin/bash -g mcc-auto mcc-auto || useradd -m -s /bin/bash mcc-auto; }
mkdir -p /home/mcc-auto/.ssh && chmod 700 /home/mcc-auto/.ssh
echo "YOUR_PUBLIC_KEY" >> /home/mcc-auto/.ssh/authorized_keys
chmod 600 /home/mcc-auto/.ssh/authorized_keys
chown -R mcc-auto:mcc-auto /home/mcc-auto/.ssh
```

3. For apt commands, grant scoped sudo:

```bash
echo 'mcc-auto ALL=(ALL) NOPASSWD: /usr/bin/apt-get, /usr/bin/apt, /usr/bin/docker, /usr/bin/systemctl, /usr/bin/install, /usr/bin/curl, /usr/bin/tee, /usr/bin/chmod, /usr/bin/usermod, /usr/bin/bash, /bin/bash, /usr/bin/journalctl' > /etc/sudoers.d/mcc-auto
chmod 440 /etc/sudoers.d/mcc-auto
```

Built-in apt templates use `sudo apt-get` automatically for the `mcc-auto` user. Docker install scripts and other privileged operations run non-interactively via `sudo -n` (passwordless) or `sudo -S` when the server's SSH password is stored (KEY_AND_PASSWORD auth).

4. Capture the host key for strict verification:

```bash
ssh-keyscan -t ed25519 YOUR_PROXMOX_IP | awk '{print $3}'
```

Add the base64 key to the server record, or enable "accept on first connect" temporarily.

### Option 2: Password auth

Supported but not recommended. Passwords are encrypted at rest but are inherently weaker than keys. Use only on isolated lab networks.

### Option 3: Key with passphrase

Select **Key + passphrase** auth type. The private key PEM and passphrase are both stored encrypted.

## Command non-interactivity

Built-in apt commands include:

- `DEBIAN_FRONTEND=noninteractive`
- `NEEDRESTART_MODE=a`
- `apt-get -y -qq`
- Dpkg force-confdef/confold for upgrades

Commands run without PTY allocation to prevent interactive prompts.

## Default admin user

Seeded on first run:

- **Username:** admin
- **Password:** admin
- **mustChangePassword:** true

Change immediately after first login.

## Appearance settings (admin)

Under **Settings → Appearance**, admins can customize the global UI for all users:

| Option | Values |
|--------|--------|
| Style preset | Classic, Graphite, Ocean, Evergreen, Burgundy, Amber Ops (surfaces + accent bundle) |
| Colors | Primary, sidebar, success, warning, danger (hex) |
| Button size | Extra small, small, medium, large |
| Button shape | Sharp, square, rounded, pill, bevel, soft, outline, notched, glow |
| Font family | System, sans-serif, monospace, serif |
| Base font size | 12px / 14px / 16px / 18px |

Settings persist in `AppSetting.ui_appearance`. The login page loads them via public `GET /api/settings/appearance`.

## Feature tracking & releases

- **[FEATURES.md](./FEATURES.md)** — living list of implemented vs planned features
- **[suggestions.md](./suggestions.md)** — enhancement backlog (Operations, Proxmox API, governance, etc.); update status when implementing
- **[RELEASE_NOTES.md](./RELEASE_NOTES.md)** — version changelog (update on each release)

When shipping a feature: update both files and bump the version in `package.json`.

## Running & testing

```bash
chmod +x scripts/setup.sh scripts/start.sh

./scripts/setup.sh              # first-time setup
./scripts/start.sh local        # start (no Docker)
./scripts/start.sh test         # unit tests
./scripts/start.sh status       # check processes
./scripts/start.sh stop         # stop app
```

Unit tests use Vitest (`npm test`). Coverage targets core `src/lib/` modules: crypto, auth, commands, SSH helpers, rate limiting.

## Roadmap

See [FEATURES.md](./FEATURES.md) for the full planned feature list. Highlights:

- TOTP 2FA
- Proxmox API integration
- ~~Scheduled command runs~~ (v0.6.0 — weekly profile schedules)
- ~~Backup / snapshot awareness~~ (v0.6.0)
- ~~GitHub Actions CI~~ (v0.6.0)
- ~~Server groups~~ (v0.8.0 — static + tag groups, profile-linked dynamic targets)
- Integration & E2E tests (v0.2.0)
