// 32-byte key for unit tests only
process.env.ENCRYPTION_KEY = Buffer.alloc(32, 7).toString("base64");
process.env.SESSION_MAX_AGE_HOURS = "24";
