import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { SESSION_COOKIE } from "@/lib/auth/constants";
import { applySecurityHeaders, secureNextResponse } from "@/lib/security/headers";

const publicPaths = [
  "/login",
  "/api/auth/login",
  "/api/auth/mfa/verify",
  "/api/auth/mfa/webauthn/login/options",
  "/api/health",
  "/api/setup/proxmox-host.sh",
  "/api/setup/proxmox-host-cleanup.sh",
  "/api/enrollment/register",
];

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (
    publicPaths.some((p) => pathname.startsWith(p)) ||
    (pathname === "/api/settings/appearance" && request.method === "GET") ||
    pathname.startsWith("/_next") ||
    pathname.startsWith("/favicon")
  ) {
    return secureNextResponse(request);
  }

  const hasSession = request.cookies.has(SESSION_COOKIE);

  if (pathname === "/change-password") {
    if (!hasSession) {
      return applySecurityHeaders(NextResponse.redirect(new URL("/login", request.url)));
    }
    return secureNextResponse(request);
  }

  if (!hasSession && !pathname.startsWith("/api/auth/login")) {
    if (pathname.startsWith("/api/")) {
      return applySecurityHeaders(
        NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
      );
    }
    return applySecurityHeaders(NextResponse.redirect(new URL("/login", request.url)));
  }

  return secureNextResponse(request);
}

export const config = {
  matcher: ["/((?!_next/static|_next/image).*)"],
};
