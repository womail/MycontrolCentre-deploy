"use client";

import { useEffect, useRef, useState } from "react";
import { appendCapped, MAX_CAPTURED_OUTPUT_CHARS } from "@/lib/memory/output-cap";
import { formatDuration } from "@/lib/utils";
import { Radio } from "lucide-react";

interface CommandRunView {
  id: string;
  batchId: string | null;
  commandType: string;
  label: string | null;
  changeReason: string | null;
  commandText: string;
  status: string;
  exitCode: number | null;
  stdout: string;
  stderr: string;
  durationMs: number | null;
  server: { name: string };
}

export function LiveRunOutput({
  run,
  onUpdated,
}: {
  run: CommandRunView;
  onUpdated?: () => void;
}) {
  const [liveStdout, setLiveStdout] = useState(run.stdout);
  const [liveStderr, setLiveStderr] = useState(run.stderr);
  const [liveStatus, setLiveStatus] = useState(run.status);
  const [liveExitCode, setLiveExitCode] = useState(run.exitCode);
  const [liveDurationMs, setLiveDurationMs] = useState(run.durationMs);
  const [streaming, setStreaming] = useState(false);
  const outputRef = useRef<HTMLPreElement>(null);

  useEffect(() => {
    setLiveStdout(run.stdout);
    setLiveStderr(run.stderr);
    setLiveStatus(run.status);
    setLiveExitCode(run.exitCode);
    setLiveDurationMs(run.durationMs);
  }, [run]);

  useEffect(() => {
    if (run.status !== "PENDING" && run.status !== "RUNNING") {
      setStreaming(false);
      return;
    }

    setStreaming(true);
    const source = new EventSource(`/api/commands/runs/${run.id}/stream`);

    source.onmessage = (message) => {
      const event = JSON.parse(message.data) as {
        type: string;
        data?: string;
        status?: string;
        exitCode?: number | null;
        durationMs?: number | null;
      };

      if (event.type === "stdout" && event.data !== undefined) {
        const chunk = event.data;
        setLiveStdout((prev) => appendCapped(prev, chunk, MAX_CAPTURED_OUTPUT_CHARS));
      } else if (event.type === "stderr" && event.data !== undefined) {
        const chunk = event.data;
        setLiveStderr((prev) => appendCapped(prev, chunk, MAX_CAPTURED_OUTPUT_CHARS));
      } else if (event.type === "status" && event.status) {
        setLiveStatus(event.status);
        if (event.exitCode !== undefined) setLiveExitCode(event.exitCode);
        if (event.durationMs !== undefined) setLiveDurationMs(event.durationMs);
        if (
          event.status === "SUCCESS" ||
          event.status === "FAILED" ||
          event.status === "CANCELLED"
        ) {
          source.close();
          setStreaming(false);
          onUpdated?.();
        }
      }
    };

    source.onerror = () => {
      source.close();
      setStreaming(false);
    };

    return () => {
      source.close();
      setStreaming(false);
    };
  }, [run.id, run.status, onUpdated]);

  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [liveStdout, liveStderr]);

  return (
    <div className="space-y-3">
      <div className="text-sm space-y-1">
        <div className="flex flex-wrap items-center gap-2">
          <strong>{run.server.name}</strong>
          <span>· {run.label ?? run.commandType}</span>
          {streaming && (
            <span className="badge badge-warning inline-flex items-center gap-1">
              <Radio className="w-3 h-3" />
              Live
            </span>
          )}
        </div>
        <div style={{ color: "var(--muted)" }}>
          {liveStatus} · exit {liveExitCode ?? "—"} · {formatDuration(liveDurationMs)}
        </div>
        {run.changeReason && (
          <div className="text-xs" style={{ color: "var(--muted)" }}>
            Change reason: {run.changeReason}
          </div>
        )}
        <code className="text-xs block break-all">{run.commandText}</code>
      </div>

      {(liveStdout || liveStatus === "RUNNING" || liveStatus === "PENDING") && (
        <div>
          <div className="text-xs font-medium mb-1">stdout</div>
          <pre ref={outputRef} className="output max-h-96 overflow-y-auto">
            {liveStdout || (streaming ? "Waiting for output..." : "")}
          </pre>
        </div>
      )}

      {liveStderr && (
        <div>
          <div className="text-xs font-medium mb-1">stderr</div>
          <pre className="output max-h-48 overflow-y-auto">{liveStderr}</pre>
        </div>
      )}
    </div>
  );
}
