"use client";

import { useEffect, useState } from "react";
import { formatDate } from "@/lib/utils";

interface AboutInfo {
  service: string;
  version: string;
  buildRef: string;
  buildTime: string | null;
  sshKeygen: string | null;
  timestamp?: string;
}

export function AboutBuildInfo({ title = "About" }: { title?: string }) {
  const [info, setInfo] = useState<AboutInfo | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/about");
        if (!res.ok) {
          setError("Could not load build information.");
          return;
        }
        setInfo(await res.json());
      } catch {
        setError("Could not load build information.");
      }
    }
    void load();
  }, []);

  return (
    <div className="card p-6 space-y-3">
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="text-sm" style={{ color: "var(--muted)" }}>
        MyControl Centre console build running on this host.
      </p>
      {error && (
        <p className="text-sm" style={{ color: "var(--danger)" }}>
          {error}
        </p>
      )}
      {info && (
        <dl className="grid sm:grid-cols-2 gap-x-4 gap-y-2 text-sm">
          <div>
            <dt style={{ color: "var(--muted)" }}>Version</dt>
            <dd className="font-medium font-mono">{info.version}</dd>
          </div>
          <div>
            <dt style={{ color: "var(--muted)" }}>Build</dt>
            <dd className="font-medium font-mono">{info.buildRef}</dd>
          </div>
          <div>
            <dt style={{ color: "var(--muted)" }}>Built</dt>
            <dd className="font-medium">
              {info.buildTime ? formatDate(info.buildTime) : "—"}
            </dd>
          </div>
          <div>
            <dt style={{ color: "var(--muted)" }}>SSH key tool</dt>
            <dd className="font-medium font-mono text-xs">
              {info.sshKeygen ?? "In-process fallback"}
            </dd>
          </div>
        </dl>
      )}
    </div>
  );
}
