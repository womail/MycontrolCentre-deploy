"use client";

import { ArrowUpDown } from "lucide-react";
import type { SortDir } from "@/lib/logs/sort-logs";
import { ResizableColumnHeader } from "@/components/resizable-column-header";

export function ResizableSortableTh({
  label,
  active,
  dir,
  onSort,
  width,
  minWidth = 64,
  onResize,
}: {
  label: string;
  active: boolean;
  dir: SortDir;
  onSort: () => void;
  width: number;
  minWidth?: number;
  onResize: (width: number) => void;
}) {
  return (
    <ResizableColumnHeader width={width} minWidth={minWidth} onResize={onResize}>
      <button
        type="button"
        className="inline-flex items-center gap-1 font-medium hover:opacity-80 max-w-full truncate"
        onClick={onSort}
      >
        {label}
        <ArrowUpDown className="w-3 h-3 opacity-60 shrink-0" />
        {active && <span className="text-[10px] opacity-70">{dir === "asc" ? "↑" : "↓"}</span>}
      </button>
    </ResizableColumnHeader>
  );
}
