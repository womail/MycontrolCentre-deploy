"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

type EnrollmentPendingContextValue = {
  pendingCount: number;
  refreshPendingCount: () => Promise<void>;
};

const EnrollmentPendingContext = createContext<EnrollmentPendingContextValue>({
  pendingCount: 0,
  refreshPendingCount: async () => {},
});

import { useVisibleInterval } from "@/lib/hooks/use-visible-interval";

const POLL_MS = 12_000;

export function EnrollmentPendingProvider({
  children,
  isAdmin,
}: {
  children: ReactNode;
  isAdmin: boolean;
}) {
  const [pendingCount, setPendingCount] = useState(0);

  const refreshPendingCount = useCallback(async () => {
    if (!isAdmin) {
      setPendingCount(0);
      return;
    }
    try {
      const res = await fetch("/api/enrollment/pending-count", { cache: "no-store" });
      if (!res.ok) return;
      const data = (await res.json()) as { count?: number };
      setPendingCount(typeof data.count === "number" ? data.count : 0);
    } catch {
      /* ignore */
    }
  }, [isAdmin]);

  useEffect(() => {
    refreshPendingCount();
  }, [refreshPendingCount]);

  useVisibleInterval(() => {
    void refreshPendingCount();
  }, POLL_MS, isAdmin);

  const value = useMemo(
    () => ({ pendingCount, refreshPendingCount }),
    [pendingCount, refreshPendingCount],
  );

  return (
    <EnrollmentPendingContext.Provider value={value}>
      {children}
    </EnrollmentPendingContext.Provider>
  );
}

export function useEnrollmentPending() {
  return useContext(EnrollmentPendingContext);
}
