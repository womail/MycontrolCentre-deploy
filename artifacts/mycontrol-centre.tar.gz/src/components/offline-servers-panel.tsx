"use client";

import Link from "next/link";
import { formatDate } from "@/lib/utils";
import { ServerHealthAdvice } from "@/components/server-health-advice";

export interface OfflineServerItem {
  id: string;
  name: string;
  hostname: string;
  port: number;
  sshUser: string;
  authType: string;
  healthStatus: string;
  healthMessage: string | null;
  inMaintenance: boolean;
  lastHealthCheck: string | null;
}

export function OfflineServersPanel({ servers }: { servers: OfflineServerItem[] }) {
  if (servers.length === 0) return null;

  return (
    <section className="card p-6 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="font-semibold text-lg">Offline servers</h2>
        <Link href="/servers" className="text-sm" style={{ color: "var(--primary)" }}>
          Manage
        </Link>
      </div>
      <ul className="space-y-4">
        {servers.map((server) => (
          <li key={server.id} className="text-sm border-b pb-4 last:border-0" style={{ borderColor: "var(--card-border)" }}>
            <div className="font-medium">
              {server.name}{" "}
              {server.inMaintenance && <span className="badge badge-warning ml-1">Maintenance</span>}
            </div>
            <div style={{ color: "var(--muted)" }}>
              {server.hostname}
              {server.lastHealthCheck ? ` · checked ${formatDate(server.lastHealthCheck)}` : ""}
            </div>
            <ServerHealthAdvice
              name={server.name}
              hostname={server.hostname}
              port={server.port}
              sshUser={server.sshUser}
              authType={server.authType}
              healthStatus={server.healthStatus}
              healthMessage={server.healthMessage}
              inMaintenance={server.inMaintenance}
            />
          </li>
        ))}
      </ul>
    </section>
  );
}
