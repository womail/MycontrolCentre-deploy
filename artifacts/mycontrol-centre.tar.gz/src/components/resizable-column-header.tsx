"use client";

import { useCallback, useRef } from "react";

export function ResizableColumnHeader({
  width,
  minWidth = 48,
  onResize,
  children,
  className,
}: {
  width: number;
  minWidth?: number;
  onResize: (width: number) => void;
  children: React.ReactNode;
  className?: string;
}) {
  const startX = useRef(0);
  const startWidth = useRef(width);

  const onMouseDown = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      startX.current = e.clientX;
      startWidth.current = width;

      function onMove(ev: MouseEvent) {
        const next = Math.max(minWidth, startWidth.current + (ev.clientX - startX.current));
        onResize(next);
      }

      function onUp() {
        document.removeEventListener("mousemove", onMove);
        document.removeEventListener("mouseup", onUp);
      }

      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onUp);
    },
    [minWidth, onResize, width],
  );

  return (
    <th
      className={className}
      style={{ width, minWidth, maxWidth: width, position: "relative" }}
    >
      <div className="truncate pr-2">{children}</div>
      <div
        role="separator"
        aria-orientation="vertical"
        aria-label="Resize column"
        onMouseDown={onMouseDown}
        className="absolute top-0 right-0 h-full w-1.5 cursor-col-resize hover:bg-[var(--primary)]/40"
      />
    </th>
  );
}
