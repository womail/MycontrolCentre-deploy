"use client";

import {
  getServerHealthAdvice,
  type ServerHealthContext,
} from "@/lib/servers/health-advice";
import { CopyCommandBlock } from "@/components/copy-command-block";
import { AlertTriangle } from "lucide-react";

export function ServerHealthAdvice(props: ServerHealthContext & { healthStatus: string }) {
  if (props.healthStatus === "ONLINE" && !props.inMaintenance) return null;

  const advice = getServerHealthAdvice(props);
  if (!advice) return null;

  return (
    <div
      className="mt-2 p-3 rounded-lg text-sm space-y-2"
      style={{
        background: "color-mix(in srgb, var(--danger) 8%, transparent)",
        border: "1px solid color-mix(in srgb, var(--danger) 25%, transparent)",
      }}
    >
      <div className="flex gap-2 font-medium">
        <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: "var(--danger)" }} />
        <span>{advice.title}</span>
      </div>
      <p style={{ color: "var(--muted)" }}>{advice.summary}</p>
      {advice.steps.length > 0 && (
        <ol className="list-decimal pl-5 space-y-1 text-xs">
          {advice.steps.map((step) => (
            <li key={step}>{step}</li>
          ))}
        </ol>
      )}
      {advice.commands.map((c) => (
        <CopyCommandBlock key={c.label} title={c.label} command={c.command} />
      ))}
    </div>
  );
}
