"use client";

import { useEffect, useRef, useState } from "react";
import { Terminal } from "@xterm/xterm";
import { FitAddon } from "@xterm/addon-fit";
import { Radio } from "lucide-react";
import "@xterm/xterm/css/xterm.css";
import { clampShellGeometry } from "@/lib/ssh/shell-geometry";

export function ServerSshTerminal({
  serverId,
  fontSize = 14,
  isActive = true,
}: {
  serverId: string;
  fontSize?: number;
  isActive?: boolean;
}) {
  const [status, setStatus] = useState<"connecting" | "live" | "closed" | "error">("connecting");
  const [error, setError] = useState("");
  const containerRef = useRef<HTMLDivElement>(null);
  const sessionIdRef = useRef<string | null>(null);
  const termRef = useRef<Terminal | null>(null);
  const fitRef = useRef<FitAddon | null>(null);
  const resizeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const serverIdRef = useRef(serverId);

  useEffect(() => {
    serverIdRef.current = serverId;
  }, [serverId]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const term = new Terminal({
      cursorBlink: true,
      fontSize,
      lineHeight: 1.2,
      fontFamily:
        'ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace',
      theme: {
        background: "#0c0c0c",
        foreground: "#e2e8f0",
        cursor: "#e2e8f0",
        selectionBackground: "#334155",
      },
      scrollback: 5000,
      convertEol: false,
    });
    const fitAddon = new FitAddon();
    term.loadAddon(fitAddon);
    term.open(container);
    fitAddon.fit();

    termRef.current = term;
    fitRef.current = fitAddon;

    let source: EventSource | null = null;
    let active = true;

    function sendInput(data: string) {
      const sessionId = sessionIdRef.current;
      if (!sessionId) return;
      const sid = serverIdRef.current;
      void fetch(`/api/servers/${sid}/terminal/session/${sessionId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "input", data }),
      }).catch(() => undefined);
    }

    function pushResize() {
      const sessionId = sessionIdRef.current;
      const fit = fitRef.current;
      const sid = serverIdRef.current;
      if (!sessionId || !fit) return;
      fit.fit();
      const { cols, rows } = clampShellGeometry(term.cols, term.rows);
      void fetch(`/api/servers/${sid}/terminal/session/${sessionId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "resize", cols, rows }),
      }).catch(() => undefined);
    }

    function scheduleResize() {
      if (resizeTimerRef.current) clearTimeout(resizeTimerRef.current);
      resizeTimerRef.current = setTimeout(() => {
        resizeTimerRef.current = null;
        pushResize();
      }, 120);
    }

    const onDataDispose = term.onData((data) => {
      sendInput(data);
    });

    const resizeObserver = new ResizeObserver(() => {
      fitAddon.fit();
      scheduleResize();
    });
    resizeObserver.observe(container);

    async function closeSession(sessionId: string) {
      const sid = serverIdRef.current;
      await fetch(`/api/servers/${sid}/terminal/session/${sessionId}`, {
        method: "DELETE",
      }).catch(() => undefined);
    }

    async function start() {
      setStatus("connecting");
      setError("");
      term.reset();
      term.writeln("Opening SSH session…");

      fitAddon.fit();
      const { cols, rows } = clampShellGeometry(term.cols, term.rows);
      const sid = serverIdRef.current;

      const res = await fetch(`/api/servers/${sid}/terminal/session`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cols, rows }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        sessionId?: string;
        error?: string;
      };

      if (!active) {
        if (res.ok && data.sessionId) {
          void closeSession(data.sessionId);
        }
        return;
      }

      if (!res.ok) {
        setStatus("error");
        setError(data.error ?? `Could not start SSH (${res.status})`);
        term.writeln(`\r\n\x1b[31m${data.error ?? "Connection failed"}\x1b[0m`);
        return;
      }

      if (!data.sessionId) {
        setStatus("error");
        setError(data.error ?? "Server did not return a session id");
        return;
      }

      sessionIdRef.current = data.sessionId;
      term.reset();

      source = new EventSource(
        `/api/servers/${sid}/terminal/session/${data.sessionId}/stream`,
      );

      source.onmessage = (message) => {
        if (!active) return;
        const event = JSON.parse(message.data) as {
          type: string;
          data?: string;
          message?: string;
        };
        if (event.type === "ready") {
          setStatus("live");
          pushResize();
        } else if (event.type === "output" && event.data !== undefined) {
          term.write(event.data);
          setStatus("live");
        } else if (event.type === "closed") {
          setStatus("closed");
          setError(event.message ?? "Session closed");
          term.writeln(`\r\n\x1b[33m${event.message ?? "Session closed"}\x1b[0m`);
          source?.close();
        }
      };

      source.onerror = () => {
        if (!active) return;
        setStatus("error");
        setError("Live stream disconnected");
        term.writeln("\r\n\x1b[31mLive stream disconnected\x1b[0m");
        source?.close();
      };

      term.focus();
    }

    void start();

    return () => {
      active = false;
      onDataDispose.dispose();
      resizeObserver.disconnect();
      if (resizeTimerRef.current) clearTimeout(resizeTimerRef.current);
      source?.close();
      const sessionId = sessionIdRef.current;
      sessionIdRef.current = null;
      if (sessionId) {
        void closeSession(sessionId);
      }
      term.dispose();
      termRef.current = null;
      fitRef.current = null;
    };
    // fontSize changes are handled in a dedicated effect; do not reopen SSH sessions.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [serverId]);

  useEffect(() => {
    const term = termRef.current;
    const fit = fitRef.current;
    if (!term || !fit) return;
    term.options.fontSize = fontSize;
    fit.fit();
    if (sessionIdRef.current) {
      const { cols, rows } = clampShellGeometry(term.cols, term.rows);
      void fetch(
        `/api/servers/${serverIdRef.current}/terminal/session/${sessionIdRef.current}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "resize", cols, rows }),
        },
      ).catch(() => undefined);
    }
  }, [fontSize]);

  useEffect(() => {
    if (!isActive) return;
    const term = termRef.current;
    const fit = fitRef.current;
    if (!term || !fit) return;
    requestAnimationFrame(() => {
      fit.fit();
      term.focus();
      if (sessionIdRef.current) {
        const { cols, rows } = clampShellGeometry(term.cols, term.rows);
        void fetch(
          `/api/servers/${serverIdRef.current}/terminal/session/${sessionIdRef.current}`,
          {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "resize", cols, rows }),
          },
        ).catch(() => undefined);
      }
    });
  }, [isActive]);

  return (
    <div className="flex flex-col flex-1 min-h-0 h-full gap-2">
      <div className="flex flex-wrap items-center gap-2 text-sm shrink-0">
        {status === "live" && (
          <span className="badge badge-warning inline-flex items-center gap-1">
            <Radio className="w-3 h-3" />
            Live SSH
          </span>
        )}
        {status === "connecting" && (
          <span className="text-sm" style={{ color: "var(--muted)" }}>
            Connecting…
          </span>
        )}
        {status === "closed" && (
          <span className="text-sm" style={{ color: "var(--muted)" }}>
            Session ended
          </span>
        )}
        {error && status !== "live" && (
          <span className="text-sm" style={{ color: "var(--danger)" }}>
            {error}
          </span>
        )}
      </div>
      <div
        className="rounded-lg border overflow-hidden flex-1 min-h-0 flex flex-col"
        style={{
          borderColor: "var(--card-border)",
          background: "#0c0c0c",
        }}
      >
        <div ref={containerRef} className="w-full flex-1 min-h-0 p-1" />
      </div>
    </div>
  );
}
