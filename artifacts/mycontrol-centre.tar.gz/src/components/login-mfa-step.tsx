"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { startAuthentication } from "@simplewebauthn/browser";

export function LoginMfaStep({
  mfaToken,
  methods,
  onBack,
}: {
  mfaToken: string;
  methods: { totp: boolean; webauthn: boolean };
  onBack: () => void;
}) {
  const [totpCode, setTotpCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function submitTotp(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await fetch("/api/auth/mfa/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ mfaToken, totpCode }),
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) {
      setError(data.error ?? "Verification failed");
      return;
    }
    if (data.user?.mustChangePassword) router.push("/change-password");
    else router.push("/dashboard");
    router.refresh();
  }

  async function handleSecurityKey() {
    setLoading(true);
    setError("");
    try {
      const optRes = await fetch("/api/auth/mfa/webauthn/login/options", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mfaToken }),
      });
      const options = await optRes.json();
      if (!optRes.ok) throw new Error(options.error ?? "Options failed");
      const assertion = await startAuthentication({ optionsJSON: options });
      const verRes = await fetch("/api/auth/mfa/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ mfaToken, webauthnResponse: assertion }),
      });
      const data = await verRes.json();
      if (!verRes.ok) throw new Error(data.error ?? "Verification failed");
      if (data.user?.mustChangePassword) router.push("/change-password");
      else router.push("/dashboard");
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Security key failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-4">
      <p className="text-sm" style={{ color: "var(--muted)" }}>
        Second factor required for this account.
      </p>
      {methods.totp && (
        <form onSubmit={submitTotp} className="space-y-3">
          <input
            className="input font-mono text-center tracking-widest"
            placeholder="000000"
            value={totpCode}
            onChange={(e) => setTotpCode(e.target.value)}
            autoComplete="one-time-code"
            maxLength={8}
          />
          <button type="submit" className="btn btn-primary w-full" disabled={loading}>
            Verify code
          </button>
        </form>
      )}
      {methods.webauthn && (
        <button
          type="button"
          className="btn btn-secondary w-full"
          disabled={loading}
          onClick={() => void handleSecurityKey()}
        >
          Use security key
        </button>
      )}
      <button type="button" className="text-sm w-full" style={{ color: "var(--muted)" }} onClick={onBack}>
        Back to password
      </button>
      {error && (
        <p className="text-sm" style={{ color: "var(--danger)" }}>
          {error}
        </p>
      )}
    </div>
  );
}
