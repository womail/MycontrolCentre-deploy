"use client";

import { useEffect, useState } from "react";
import { Calendar, Play, Save, Trash2 } from "lucide-react";
import type { CommandTemplate, ServerOption } from "./command-manager";
import { SelectableList } from "./command-manager";
import { requiresChangeReason } from "@/lib/commands/change-reason";
import { ProfileGroupSelect, ServerGroupPicker } from "@/components/server-group-picker";
import type { ServerGroupSummary } from "@/components/server-groups-panel";
import { useVisibleInterval } from "@/lib/hooks/use-visible-interval";

interface RunProfile {
  id: string;
  name: string;
  description: string | null;
  serverIds: string[];
  templateIds: string[];
  workingDir: string | null;
  listPath: string | null;
  customCommand: string | null;
  failureTemplateIds: string[];
  serverGroupId?: string | null;
  serverGroup?: { id: string; name: string; kind: string } | null;
  schedule?: ProfileSchedule | null;
}

interface ProfileSchedule {
  enabled: boolean;
  dayOfWeek: number;
  hourUtc: number;
  minuteUtc: number;
  changeReason: string | null;
  lastRunAt: string | null;
  lastBatchId: string | null;
}

const WEEKDAYS = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

interface BatchSummary {
  batchId: string;
  label: string;
  createdAt: string;
  user: string;
  serverCount: number;
  successCount: number;
  failedCount: number;
  runs: Array<{
    id: string;
    server: { name: string; hostname: string };
    status: string;
    exitCode: number | null;
    durationMs: number | null;
    stderrSnippet: string;
    label: string | null;
  }>;
}

export function SavedRunProfilesPanel({
  templates,
  servers,
  serverGroups = [],
  onRan,
}: {
  templates: CommandTemplate[];
  servers: ServerOption[];
  serverGroups?: ServerGroupSummary[];
  onRan: (result?: { runs?: Array<{ id: string }> }) => void;
}) {
  const [profiles, setProfiles] = useState<RunProfile[]>([]);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [selectedServers, setSelectedServers] = useState<string[]>([]);
  const [profileGroupId, setProfileGroupId] = useState<string | null>(null);
  const [selectedCommands, setSelectedCommands] = useState<string[]>([]);
  const [failureCommands, setFailureCommands] = useState<string[]>([]);
  const [listExpandSignal, setListExpandSignal] = useState(0);
  const [serversListOpen, setServersListOpen] = useState(false);
  const [commandsListOpen, setCommandsListOpen] = useState(false);
  const [failureListOpen, setFailureListOpen] = useState(false);
  const [changeReason, setChangeReason] = useState("");
  const [error, setError] = useState("");

  async function loadProfiles() {
    const res = await fetch("/api/commands/profiles");
    if (res.ok) {
      const data = await res.json();
      setProfiles(
        data.profiles.map((profile: RunProfile & { serverIds: unknown; templateIds: unknown; failureTemplateIds: unknown }) => ({
          ...profile,
          serverIds: Array.isArray(profile.serverIds) ? profile.serverIds : [],
          templateIds: Array.isArray(profile.templateIds) ? profile.templateIds : [],
          failureTemplateIds: Array.isArray(profile.failureTemplateIds)
            ? profile.failureTemplateIds
            : [],
        })),
      );
    }
  }

  useEffect(() => {
    loadProfiles();
  }, []);

  function toggle(list: string[], id: string) {
    return list.includes(id) ? list.filter((item) => item !== id) : [...list, id];
  }

  async function saveProfile() {
    if (!name.trim()) {
      setError("Profile name is required");
      return;
    }
    if (!profileGroupId && selectedServers.length === 0) {
      setError("Select servers or a server group");
      return;
    }
    setError("");
    const res = await fetch("/api/commands/profiles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: name.trim(),
        description: description.trim() || undefined,
        serverIds: profileGroupId ? [] : selectedServers,
        serverGroupId: profileGroupId,
        templateIds: selectedCommands,
        failureTemplateIds: failureCommands,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Failed to save profile");
      return;
    }
    setName("");
    setDescription("");
    await loadProfiles();
  }

  async function runProfile(id: string) {
    const profile = profiles.find((entry) => entry.id === id);
    let serverCount = profile?.serverIds.length ?? 0;
    if (profile?.serverGroupId) {
      const membersRes = await fetch(`/api/server-groups/${profile.serverGroupId}/members`);
      if (membersRes.ok) {
        const members = await membersRes.json();
        serverCount = Array.isArray(members.serverIds) ? members.serverIds.length : 0;
      } else {
        serverCount = 2;
      }
    }
    const needsReason = profile
      ? requiresChangeReason(serverCount, profile.templateIds.length)
      : false;
    if (needsReason && !changeReason.trim()) {
      setError("Change reason is required for this profile");
      return;
    }

    const res = await fetch(`/api/commands/profiles/${id}/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        changeReason: needsReason ? changeReason.trim() : undefined,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Failed to run profile");
      return;
    }
    onRan({ runs: data.runs });
  }

  async function saveSchedule(profileId: string, schedule: Partial<ProfileSchedule> & { enabled: boolean }) {
    const res = await fetch(`/api/commands/profiles/${profileId}/schedule`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(schedule),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Failed to save schedule");
      return false;
    }
    await loadProfiles();
    return true;
  }

  async function deleteProfile(id: string) {
    if (!confirm("Delete this run profile?")) return;
    await fetch(`/api/commands/profiles/${id}`, { method: "DELETE" });
    await loadProfiles();
  }

  return (
    <div className="card p-6 space-y-4">
      <h2 className="font-semibold">Saved run profiles</h2>
      <p className="text-sm" style={{ color: "var(--muted)" }}>
        Store common server + command combinations for one-click or scheduled execution.
      </p>

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Profile name</label>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Description</label>
          <input className="input" value={description} onChange={(e) => setDescription(e.target.value)} />
        </div>
      </div>

      <ProfileGroupSelect
        groups={serverGroups}
        value={profileGroupId}
        onChange={(id) => {
          setProfileGroupId(id);
          if (id) setSelectedServers([]);
        }}
      />

      <ServerGroupPicker
        groups={serverGroups}
        disabled={Boolean(profileGroupId)}
        onApply={(ids, mode) =>
          setSelectedServers((prev) =>
            mode === "replace" ? ids : [...new Set([...prev, ...ids])],
          )
        }
      />

      <div className="flex flex-wrap gap-3 text-xs" style={{ color: "var(--muted)" }}>
        <button
          type="button"
          className="underline"
          onClick={() => {
            setServersListOpen(true);
            setCommandsListOpen(true);
            setFailureListOpen(true);
            setListExpandSignal((n) => n + 1);
          }}
        >
          Expand all lists
        </button>
        <button
          type="button"
          className="underline"
          onClick={() => {
            setServersListOpen(false);
            setCommandsListOpen(false);
            setFailureListOpen(false);
          }}
        >
          Collapse all lists
        </button>
      </div>

      <div className="grid lg:grid-cols-3 gap-4 text-sm">
        <SelectableList
          title={profileGroupId ? "Servers (group linked)" : "Servers"}
          items={servers.map((server) => ({ id: server.id }))}
          selectedIds={selectedServers}
          expandSignal={listExpandSignal}
          expanded={serversListOpen}
          onExpandedChange={setServersListOpen}
          onToggle={(id) => {
            if (profileGroupId) return;
            setSelectedServers((prev) => toggle(prev, id));
          }}
          onSelectAll={() =>
            setSelectedServers(
              selectedServers.length === servers.length ? [] : servers.map((s) => s.id),
            )
          }
          renderLabel={(item) => servers.find((s) => s.id === item.id)?.name ?? item.id}
        />
        <SelectableList
          title="Commands"
          items={templates.map((t) => ({ id: t.id }))}
          selectedIds={selectedCommands}
          expandSignal={listExpandSignal}
          expanded={commandsListOpen}
          onExpandedChange={setCommandsListOpen}
          onToggle={(id) => setSelectedCommands((prev) => toggle(prev, id))}
          onSelectAll={() =>
            setSelectedCommands(
              selectedCommands.length === templates.length ? [] : templates.map((t) => t.id),
            )
          }
          renderLabel={(item) => templates.find((t) => t.id === item.id)?.name ?? item.id}
        />
        <SelectableList
          title="On failure (optional)"
          items={templates.map((t) => ({ id: t.id }))}
          selectedIds={failureCommands}
          expandSignal={listExpandSignal}
          expanded={failureListOpen}
          onExpandedChange={setFailureListOpen}
          onToggle={(id) => setFailureCommands((prev) => toggle(prev, id))}
          onSelectAll={() => setFailureCommands([])}
          renderLabel={(item) => templates.find((t) => t.id === item.id)?.name ?? item.id}
        />
      </div>

      {error && <p style={{ color: "var(--danger)" }}>{error}</p>}

      <div>
        <label className="block text-sm font-medium mb-1">Default change reason (for batch profiles)</label>
        <input
          className="input"
          value={changeReason}
          onChange={(e) => setChangeReason(e.target.value)}
          placeholder="Used when running multi-server profiles"
          maxLength={500}
        />
      </div>

      <button type="button" className="btn btn-secondary" onClick={saveProfile}>
        <Save className="w-4 h-4" />
        Save profile
      </button>

      <div className="space-y-2">
        {profiles.map((profile) => (
          <ProfileRow
            key={profile.id}
            profile={profile}
            changeReason={changeReason}
            onRun={() => runProfile(profile.id)}
            onDelete={() => deleteProfile(profile.id)}
            onSaveSchedule={(schedule) => saveSchedule(profile.id, schedule)}
            setError={setError}
          />
        ))}
      </div>
    </div>
  );
}

export function BatchComparisonPanel() {
  const [batches, setBatches] = useState<BatchSummary[]>([]);

  async function load() {
    const res = await fetch("/api/commands/batches?limit=15");
    if (res.ok) setBatches((await res.json()).batches);
  }

  useEffect(() => {
    load();
  }, []);

  useVisibleInterval(load, 15_000);

  return (
    <div className="card p-6 space-y-4">
      <h2 className="font-semibold">Batch run comparison</h2>
      {batches.length === 0 ? (
        <p className="text-sm" style={{ color: "var(--muted)" }}>
          No multi-server batch runs yet.
        </p>
      ) : (
        batches.map((batch) => (
          <div key={batch.batchId} className="space-y-2">
            <div className="flex flex-wrap justify-between gap-2 text-sm">
              <strong>{batch.label}</strong>
              <span style={{ color: "var(--muted)" }}>
                {batch.successCount}/{batch.serverCount} success · {batch.failedCount} failed
              </span>
            </div>
            <div className="table-wrap border rounded-lg" style={{ borderColor: "var(--card-border)" }}>
              <table>
                <thead>
                  <tr>
                    <th>Server</th>
                    <th>Status</th>
                    <th>Exit</th>
                    <th>Duration</th>
                    <th>Error snippet</th>
                  </tr>
                </thead>
                <tbody>
                  {batch.runs.map((run) => (
                    <tr key={run.id}>
                      <td>{run.server.name}</td>
                      <td>{run.status}</td>
                      <td>{run.exitCode ?? "—"}</td>
                      <td>{run.durationMs != null ? `${run.durationMs} ms` : "—"}</td>
                      <td className="text-xs font-mono max-w-xs truncate">{run.stderrSnippet || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

function ProfileRow({
  profile,
  changeReason,
  onRun,
  onDelete,
  onSaveSchedule,
  setError,
}: {
  profile: RunProfile;
  changeReason: string;
  onRun: () => void;
  onDelete: () => void;
  onSaveSchedule: (schedule: Partial<ProfileSchedule> & { enabled: boolean }) => Promise<boolean>;
  setError: (message: string) => void;
}) {
  const schedule = profile.schedule;
  const [showSchedule, setShowSchedule] = useState(false);
  const [enabled, setEnabled] = useState(schedule?.enabled ?? false);
  const [dayOfWeek, setDayOfWeek] = useState(schedule?.dayOfWeek ?? 0);
  const [hourUtc, setHourUtc] = useState(schedule?.hourUtc ?? 3);
  const [minuteUtc, setMinuteUtc] = useState(schedule?.minuteUtc ?? 0);
  const [scheduleReason, setScheduleReason] = useState(schedule?.changeReason ?? changeReason);

  useEffect(() => {
    setEnabled(schedule?.enabled ?? false);
    setDayOfWeek(schedule?.dayOfWeek ?? 0);
    setHourUtc(schedule?.hourUtc ?? 3);
    setMinuteUtc(schedule?.minuteUtc ?? 0);
    setScheduleReason(schedule?.changeReason ?? changeReason);
  }, [schedule, changeReason]);

  async function applySchedule() {
    setError("");
    const ok = await onSaveSchedule({
      enabled,
      dayOfWeek,
      hourUtc,
      minuteUtc,
      changeReason: scheduleReason.trim() || undefined,
    });
    if (ok) setShowSchedule(false);
  }

  return (
    <div
      className="p-3 rounded-lg border space-y-3"
      style={{ borderColor: "var(--card-border)" }}
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="font-medium">{profile.name}</div>
          <div className="text-xs" style={{ color: "var(--muted)" }}>
            {profile.serverGroup
              ? `Group: ${profile.serverGroup.name} (${profile.serverGroup.kind})`
              : `${profile.serverIds.length} servers`}{" "}
            · {profile.templateIds.length} commands
            {profile.failureTemplateIds.length > 0 &&
              ` · ${profile.failureTemplateIds.length} remediation`}
            {schedule?.enabled && (
              <span className="inline-flex items-center gap-1">
                · <Calendar className="w-3 h-3" /> Weekly {WEEKDAYS[schedule.dayOfWeek]}{" "}
                {String(schedule.hourUtc).padStart(2, "0")}:{String(schedule.minuteUtc).padStart(2, "0")} UTC
              </span>
            )}
          </div>
          {schedule?.lastRunAt && (
            <div className="text-xs" style={{ color: "var(--muted)" }}>
              Last scheduled run: {new Date(schedule.lastRunAt).toLocaleString()}
            </div>
          )}
        </div>
        <div className="flex gap-2">
          <button type="button" className="btn btn-secondary py-1 px-2 text-sm" onClick={() => setShowSchedule((v) => !v)}>
            <Calendar className="w-4 h-4" />
            Schedule
          </button>
          <button type="button" className="btn btn-primary py-1 px-2 text-sm" onClick={onRun}>
            <Play className="w-4 h-4" />
            Run
          </button>
          <button type="button" className="btn btn-secondary py-1 px-2 text-sm" onClick={onDelete}>
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {showSchedule && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 text-sm border-t pt-3" style={{ borderColor: "var(--card-border)" }}>
          <label className="flex items-center gap-2 sm:col-span-2 lg:col-span-4">
            <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
            Enable weekly schedule (UTC)
          </label>
          <div>
            <label className="block text-xs font-medium mb-1">Day</label>
            <select className="input" value={dayOfWeek} onChange={(e) => setDayOfWeek(Number(e.target.value))}>
              {WEEKDAYS.map((day, index) => (
                <option key={day} value={index}>
                  {day}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Hour (UTC)</label>
            <input className="input" type="number" min={0} max={23} value={hourUtc} onChange={(e) => setHourUtc(Number(e.target.value))} />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Minute</label>
            <input className="input" type="number" min={0} max={59} value={minuteUtc} onChange={(e) => setMinuteUtc(Number(e.target.value))} />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-medium mb-1">Change reason for scheduled runs</label>
            <input className="input" value={scheduleReason} onChange={(e) => setScheduleReason(e.target.value)} maxLength={500} />
          </div>
          <div className="sm:col-span-2 lg:col-span-4">
            <button type="button" className="btn btn-primary py-1 px-2 text-sm" onClick={applySchedule}>
              Save schedule
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
