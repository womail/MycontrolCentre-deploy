"use client";

import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { cn } from "@/lib/utils";

export function CopyCommandBlock({
  command,
  title,
  description,
  prominent,
  className,
}: {
  command: string;
  title?: string;
  description?: string;
  /** Primary copy button before the command (install / cleanup one-liners). */
  prominent?: boolean;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    await navigator.clipboard.writeText(command);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  if (prominent) {
    return (
      <div className={cn("space-y-2", className)}>
        {title && <p className="text-sm font-medium">{title}</p>}
        {description && (
          <p className="text-xs" style={{ color: "var(--muted)" }}>
            {description}
          </p>
        )}
        <div className="flex flex-col sm:flex-row gap-2 sm:items-start">
          <button
            type="button"
            onClick={copy}
            className="btn btn-primary shrink-0 w-full sm:w-auto order-first"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? "Copied" : "Copy command"}
          </button>
          <pre className="output text-xs whitespace-pre-wrap break-all flex-1 min-w-0 order-last sm:order-none">
            {command}
          </pre>
        </div>
      </div>
    );
  }

  return (
    <div className={cn("space-y-1", className)}>
      {(title || description) && (
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            {title && <span className="text-xs font-medium">{title}</span>}
            {description && (
              <p className="text-xs" style={{ color: "var(--muted)" }}>
                {description}
              </p>
            )}
          </div>
          <button type="button" onClick={copy} className="btn btn-secondary text-xs py-1 px-2 shrink-0">
            {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
            {copied ? "Copied" : "Copy"}
          </button>
        </div>
      )}
      <pre className="output text-xs whitespace-pre-wrap break-all">{command}</pre>
    </div>
  );
}
