"use client";

import { useState } from "react";
import { Container, Download, Upload } from "lucide-react";
import type { CommandTemplate, ServerOption } from "./command-manager";

const DOCKER_ENGINE_TEMPLATE = "Install Docker Engine (Ubuntu)";
const PORTAINER_TEMPLATE = "Install Portainer CE";
const PORTAINER_LEGACY_TEMPLATE = "Install Portainer CE (+ HTTP 9000)";

export function DockerOperationsPanel({
  servers,
  templates,
  canRun,
  onRan,
}: {
  servers: ServerOption[];
  templates: CommandTemplate[];
  canRun: boolean;
  onRan: (result?: { runs?: Array<{ id: string }> }) => void;
}) {
  const [serverId, setServerId] = useState("");
  const [remoteDir, setRemoteDir] = useState("/opt/stacks/app");
  const [composeYaml, setComposeYaml] = useState("");
  const [envFile, setEnvFile] = useState("");
  const [projectName, setProjectName] = useState("");
  const [pull, setPull] = useState(true);
  const [changeReason, setChangeReason] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const dockerEngineTemplate = templates.find((t) => t.name === DOCKER_ENGINE_TEMPLATE);
  const portainerTemplate = templates.find((t) => t.name === PORTAINER_TEMPLATE);
  const portainerLegacyTemplate = templates.find((t) => t.name === PORTAINER_LEGACY_TEMPLATE);

  async function runTemplate(template: CommandTemplate) {
    if (!serverId) {
      setError("Select a target server first");
      return;
    }
    setBusy(template.name);
    setError("");
    setSuccess("");
    const res = await fetch("/api/commands", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        serverIds: [serverId],
        templateIds: [template.id],
        changeReason: changeReason.trim() || undefined,
      }),
    });
    const data = await res.json();
    setBusy(null);
    if (!res.ok) {
      setError(data.error ?? "Failed to queue install");
      return;
    }
    setSuccess(`Queued: ${template.name}`);
    onRan({ runs: data.runs });
  }

  async function deployCompose() {
    if (!serverId) {
      setError("Select a target server first");
      return;
    }
    if (!composeYaml.trim()) {
      setError("docker-compose.yml content is required");
      return;
    }
    setBusy("compose");
    setError("");
    setSuccess("");
    const res = await fetch(`/api/servers/${serverId}/docker/compose`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        remoteDir,
        composeYaml,
        envFile: envFile.trim() || undefined,
        pull,
        detach: true,
        projectName: projectName.trim() || undefined,
        changeReason: changeReason.trim() || undefined,
      }),
    });
    const data = await res.json();
    setBusy(null);
    if (!res.ok) {
      setError(data.error ?? "Compose deploy failed");
      return;
    }
    setSuccess(`Deployed to ${data.remoteDir} (run ${data.runId})`);
    onRan({ runs: [{ id: data.runId }] });
  }

  function loadComposeFile(file: File) {
    void file.text().then(setComposeYaml);
  }

  function loadEnvFile(file: File) {
    void file.text().then(setEnvFile);
  }

  if (!canRun) {
    return (
      <div className="card p-6">
        Docker operations require operator or admin role.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="card p-6 space-y-4">
        <div>
          <h2 className="font-semibold flex items-center gap-2">
            <Container className="w-5 h-5" />
            Docker host setup
          </h2>
          <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
            Install Docker Engine and Portainer CE using official procedures, then push compose stacks over SSH.
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Target server</label>
          <select
            className="input"
            value={serverId}
            onChange={(e) => setServerId(e.target.value)}
          >
            <option value="">Select server…</option>
            {servers.map((server) => (
              <option key={server.id} value={server.id}>
                {server.name} ({server.hostname})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Change reason (optional)</label>
          <input
            className="input"
            value={changeReason}
            onChange={(e) => setChangeReason(e.target.value)}
            placeholder="e.g. Initial Docker host provisioning"
            maxLength={500}
          />
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="rounded-lg border p-4 space-y-3" style={{ borderColor: "var(--card-border)" }}>
            <h3 className="font-medium text-sm">Install Docker Engine (Ubuntu)</h3>
            <p className="text-xs" style={{ color: "var(--muted)" }}>
              Apt repository install per{" "}
              <a
                href="https://docs.docker.com/engine/install/ubuntu/"
                target="_blank"
                rel="noreferrer"
                className="underline"
              >
                Docker docs
              </a>
              . Requires Ubuntu, passwordless sudo (re-run host setup) or SSH password stored on the server.
            </p>
            <button
              type="button"
              className="btn btn-primary text-sm"
              disabled={!dockerEngineTemplate || busy !== null}
              onClick={() => dockerEngineTemplate && void runTemplate(dockerEngineTemplate)}
            >
              <Download className="w-4 h-4" />
              {busy === DOCKER_ENGINE_TEMPLATE ? "Queuing…" : "Install Docker Engine"}
            </button>
          </div>

          <div className="rounded-lg border p-4 space-y-3" style={{ borderColor: "var(--card-border)" }}>
            <h3 className="font-medium text-sm">Install Portainer CE</h3>
            <p className="text-xs" style={{ color: "var(--muted)" }}>
              Runs official{" "}
              <code className="font-mono">portainer/portainer-ce:lts</code> container per{" "}
              <a
                href="https://docs.portainer.io/start/install-ce/server/docker/linux"
                target="_blank"
                rel="noreferrer"
                className="underline"
              >
                Portainer docs
              </a>
              . UI on port 9443.
            </p>
            <button
              type="button"
              className="btn btn-primary text-sm"
              disabled={!portainerTemplate || busy !== null}
              onClick={() => portainerTemplate && void runTemplate(portainerTemplate)}
            >
              <Download className="w-4 h-4" />
              {busy === PORTAINER_TEMPLATE ? "Queuing…" : "Install Portainer CE"}
            </button>
            <button
              type="button"
              className="btn btn-secondary text-sm"
              disabled={!portainerLegacyTemplate || busy !== null}
              onClick={() => portainerLegacyTemplate && void runTemplate(portainerLegacyTemplate)}
            >
              {busy === PORTAINER_LEGACY_TEMPLATE ? "Queuing…" : "Install with HTTP :9000"}
            </button>
          </div>
        </div>
      </div>

      <div className="card p-6 space-y-4">
        <div>
          <h2 className="font-semibold flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Deploy docker-compose stack
          </h2>
          <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
            Uploads <code className="font-mono">docker-compose.yml</code> and optional{" "}
            <code className="font-mono">.env</code> via SFTP, then runs{" "}
            <code className="font-mono">docker compose up -d</code> on the host.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Remote directory</label>
            <input
              className="input font-mono text-sm"
              value={remoteDir}
              onChange={(e) => setRemoteDir(e.target.value)}
              placeholder="/opt/stacks/myapp"
            />
            <p className="text-xs mt-1" style={{ color: "var(--muted)" }}>
              Must be writable by the SSH user (often under /home or use sudo-managed /opt/stacks).
            </p>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Compose project name (optional)</label>
            <input
              className="input font-mono text-sm"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              placeholder="myapp"
            />
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-sm font-medium">docker-compose.yml</label>
              <label className="btn btn-secondary py-1 px-2 text-xs cursor-pointer">
                Upload file
                <input
                  type="file"
                  accept=".yml,.yaml,text/yaml,text/plain"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) loadComposeFile(file);
                  }}
                />
              </label>
            </div>
            <textarea
              className="input font-mono text-xs min-h-48"
              value={composeYaml}
              onChange={(e) => setComposeYaml(e.target.value)}
              placeholder={"services:\n  web:\n    image: nginx:alpine\n    ports:\n      - '8080:80'"}
            />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-sm font-medium">.env (optional)</label>
              <label className="btn btn-secondary py-1 px-2 text-xs cursor-pointer">
                Upload file
                <input
                  type="file"
                  accept=".env,text/plain"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) loadEnvFile(file);
                  }}
                />
              </label>
            </div>
            <textarea
              className="input font-mono text-xs min-h-48"
              value={envFile}
              onChange={(e) => setEnvFile(e.target.value)}
              placeholder={"IMAGE_TAG=latest\nSECRET=changeme"}
            />
          </div>
        </div>

        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={pull} onChange={(e) => setPull(e.target.checked)} />
          Run <code className="font-mono text-xs">docker compose pull</code> before up
        </label>

        <button
          type="button"
          className="btn btn-primary"
          disabled={busy !== null}
          onClick={() => void deployCompose()}
        >
          <Upload className="w-4 h-4" />
          {busy === "compose" ? "Deploying…" : "Push files and deploy"}
        </button>
      </div>

      {error && <p style={{ color: "var(--danger)" }}>{error}</p>}
      {success && <p style={{ color: "var(--success)" }}>{success}</p>}
    </div>
  );
}
