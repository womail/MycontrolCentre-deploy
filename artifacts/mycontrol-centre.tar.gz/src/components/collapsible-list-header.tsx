"use client";

import { ChevronDown, ChevronRight } from "lucide-react";

export function CollapsibleListHeader({
  title,
  count,
  selectedCount,
  expanded,
  onToggle,
  selectAllLabel,
  onSelectAll,
}: {
  title: string;
  count?: number;
  selectedCount?: number;
  expanded: boolean;
  onToggle: () => void;
  selectAllLabel?: string;
  onSelectAll?: () => void;
}) {
  return (
    <div className="flex items-center justify-between mb-2 gap-2">
      <button
        type="button"
        className="flex items-center gap-2 text-sm font-medium min-w-0 text-left"
        onClick={onToggle}
        aria-expanded={expanded}
      >
        {expanded ? (
          <ChevronDown className="w-4 h-4 shrink-0 opacity-70" />
        ) : (
          <ChevronRight className="w-4 h-4 shrink-0 opacity-70" />
        )}
        <span className="truncate">
          {title}
          {count != null && count > 0 && ` (${count})`}
          {selectedCount != null && selectedCount > 0 && (
            <span style={{ color: "var(--muted)" }}> · {selectedCount} selected</span>
          )}
        </span>
      </button>
      {expanded && onSelectAll && selectAllLabel && (
        <button type="button" className="text-xs underline shrink-0" onClick={onSelectAll}>
          {selectAllLabel}
        </button>
      )}
    </div>
  );
}
