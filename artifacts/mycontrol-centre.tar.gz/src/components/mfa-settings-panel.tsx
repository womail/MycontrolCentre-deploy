"use client";

import { useCallback, useEffect, useState } from "react";
import { startRegistration } from "@simplewebauthn/browser";
import { Copy, Check } from "lucide-react";
import QRCode from "react-qr-code";

interface MfaStatus {
  totpEnabled: boolean;
  webAuthnCount: number;
  credentials: Array<{
    id: string;
    deviceName: string | null;
    createdAt: string;
    lastUsedAt: string | null;
  }>;
}

export function MfaSettingsPanel() {
  const [status, setStatus] = useState<MfaStatus | null>(null);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [totpSetup, setTotpSetup] = useState<{ secret: string; otpauthUrl: string } | null>(null);
  const [confirmCode, setConfirmCode] = useState("");
  const [disablePassword, setDisablePassword] = useState("");
  const [disableCode, setDisableCode] = useState("");
  const [deviceName, setDeviceName] = useState("Security key");
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    const res = await fetch("/api/auth/mfa/status");
    if (res.ok) setStatus(await res.json());
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function startTotp() {
    setError("");
    const res = await fetch("/api/auth/mfa/totp/setup", { method: "POST" });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Setup failed");
      return;
    }
    setTotpSetup(data);
  }

  async function confirmTotp(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const res = await fetch("/api/auth/mfa/totp/confirm", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: confirmCode }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Confirm failed");
      return;
    }
    setTotpSetup(null);
    setConfirmCode("");
    setMessage("Authenticator app enabled.");
    await load();
  }

  async function disableTotp(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const res = await fetch("/api/auth/mfa/totp", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: disablePassword, code: disableCode }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Disable failed");
      return;
    }
    setDisablePassword("");
    setDisableCode("");
    setMessage("Authenticator disabled.");
    await load();
  }

  async function registerKey() {
    setError("");
    try {
      const optRes = await fetch("/api/auth/mfa/webauthn/register/options", { method: "POST" });
      const options = await optRes.json();
      if (!optRes.ok) throw new Error(options.error ?? "Options failed");
      const attestation = await startRegistration({ optionsJSON: options });
      const verRes = await fetch("/api/auth/mfa/webauthn/register/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ response: attestation, deviceName }),
      });
      const data = await verRes.json();
      if (!verRes.ok) throw new Error(data.error ?? "Register failed");
      setMessage("Security key registered.");
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Registration failed");
    }
  }

  async function removeKey(id: string) {
    const password = prompt("Enter your password to remove this security key:");
    if (!password) return;
    const res = await fetch(`/api/auth/mfa/webauthn/${id}`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Remove failed");
      return;
    }
    setMessage("Security key removed.");
    await load();
  }

  async function copySecret(text: string) {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  if (!status) return <p className="text-sm" style={{ color: "var(--muted)" }}>Loading…</p>;

  return (
    <div className="card p-6 space-y-6">
      <div>
        <h2 className="text-lg font-semibold">Two-factor authentication</h2>
        <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
          Optional per-account TOTP and security keys. When enabled, sign-in and vault unlock (without
          the shared vault password) require your password plus TOTP or a key.
        </p>
      </div>

      {message && (
        <p className="text-sm" style={{ color: "var(--success)" }}>
          {message}
        </p>
      )}
      {error && (
        <p className="text-sm" style={{ color: "var(--danger)" }}>
          {error}
        </p>
      )}

      <section className="space-y-3">
        <h3 className="font-medium">Authenticator app (TOTP)</h3>
        {status.totpEnabled ? (
          <form onSubmit={disableTotp} className="space-y-2 max-w-md">
            <p className="text-sm badge badge-success inline-block">Enabled</p>
            <input
              type="password"
              className="input"
              placeholder="Your password"
              value={disablePassword}
              onChange={(e) => setDisablePassword(e.target.value)}
              autoComplete="current-password"
            />
            <input
              className="input font-mono"
              placeholder="Current 6-digit code"
              value={disableCode}
              onChange={(e) => setDisableCode(e.target.value)}
            />
            <button type="submit" className="btn btn-danger text-sm">
              Disable TOTP
            </button>
          </form>
        ) : totpSetup ? (
          <form onSubmit={confirmTotp} className="space-y-3 max-w-lg">
            <p className="text-sm">Scan with your authenticator app, or enter the secret manually.</p>
            <div
              className="inline-block p-4 rounded-lg bg-white"
              aria-label="TOTP QR code"
            >
              <QRCode value={totpSetup.otpauthUrl} size={200} level="M" />
            </div>
            <div className="flex gap-2 items-center">
              <code className="output text-xs flex-1 break-all">{totpSetup.secret}</code>
              <button type="button" className="btn btn-secondary text-xs" onClick={() => copySecret(totpSetup.secret)}>
                {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              </button>
            </div>
            <p className="text-xs break-all" style={{ color: "var(--muted)" }}>
              {totpSetup.otpauthUrl}
            </p>
            <input
              className="input font-mono max-w-xs"
              placeholder="6-digit code"
              value={confirmCode}
              onChange={(e) => setConfirmCode(e.target.value)}
              required
            />
            <div className="flex gap-2">
              <button type="submit" className="btn btn-primary text-sm">
                Confirm and enable
              </button>
              <button type="button" className="btn btn-secondary text-sm" onClick={() => setTotpSetup(null)}>
                Cancel
              </button>
            </div>
          </form>
        ) : (
          <button type="button" className="btn btn-primary text-sm" onClick={() => void startTotp()}>
            Set up authenticator app
          </button>
        )}
      </section>

      <section className="space-y-3">
        <h3 className="font-medium">Security keys (WebAuthn)</h3>
        <div className="flex flex-wrap gap-2 items-end max-w-md">
          <div className="flex-1 min-w-[140px]">
            <label className="text-xs font-medium">Label</label>
            <input className="input text-sm" value={deviceName} onChange={(e) => setDeviceName(e.target.value)} />
          </div>
          <button type="button" className="btn btn-secondary text-sm" onClick={() => void registerKey()}>
            Register key
          </button>
        </div>
        {status.credentials.length > 0 && (
          <ul className="text-sm space-y-2">
            {status.credentials.map((c) => (
              <li key={c.id} className="flex justify-between gap-2 items-center border rounded p-2" style={{ borderColor: "var(--card-border)" }}>
                <span>{c.deviceName ?? "Security key"}</span>
                <button type="button" className="btn btn-danger text-xs py-1 px-2" onClick={() => void removeKey(c.id)}>
                  Remove
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
