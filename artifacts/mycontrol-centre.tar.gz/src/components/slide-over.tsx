"use client";

import { useEffect } from "react";
import { X } from "lucide-react";

export function SlideOver({
  open,
  title,
  description,
  onClose,
  children,
  width = "max-w-lg",
}: {
  open: boolean;
  title: string;
  description?: string;
  onClose: () => void;
  children: React.ReactNode;
  width?: string;
}) {
  useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <button
        type="button"
        className="absolute inset-0 bg-black/50"
        aria-label="Close panel"
        onClick={onClose}
      />
      <div
        className={`relative flex flex-col w-full ${width} max-h-full shadow-xl`}
        style={{ background: "var(--card)", borderLeft: "1px solid var(--card-border)" }}
        role="dialog"
        aria-modal="true"
        aria-labelledby="slide-over-title"
      >
        <header
          className="flex items-start justify-between gap-3 p-4 border-b shrink-0"
          style={{ borderColor: "var(--card-border)" }}
        >
          <div className="min-w-0">
            <h2 id="slide-over-title" className="font-semibold text-lg">
              {title}
            </h2>
            {description && (
              <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
                {description}
              </p>
            )}
          </div>
          <button type="button" className="btn btn-secondary p-2 shrink-0" onClick={onClose} aria-label="Close">
            <X className="w-4 h-4" />
          </button>
        </header>
        <div className="flex-1 overflow-y-auto p-4">{children}</div>
      </div>
    </div>
  );
}
