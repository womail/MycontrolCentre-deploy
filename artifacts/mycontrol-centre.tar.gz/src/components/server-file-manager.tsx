"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Archive,
  ArchiveRestore,
  FilePlus,
  FolderPlus,
  Pencil,
  RefreshCw,
  Trash2,
  Upload,
  Download,
  Folder,
  File,
  ChevronRight,
  Home,
} from "lucide-react";
import { formatDate } from "@/lib/utils";
import { ResizableColumnHeader } from "@/components/resizable-column-header";

const COL_STORAGE_KEY = "mcc_file_manager_col_widths";

type ColWidths = { select: number; name: number; size: number; modified: number };

const DEFAULT_COL_WIDTHS: ColWidths = {
  select: 44,
  name: 360,
  size: 100,
  modified: 168,
};

function readColWidths(): ColWidths {
  if (typeof window === "undefined") return DEFAULT_COL_WIDTHS;
  try {
    const raw = window.localStorage.getItem(COL_STORAGE_KEY);
    if (!raw) return DEFAULT_COL_WIDTHS;
    const parsed = JSON.parse(raw) as Partial<ColWidths>;
    return {
      select: parsed.select ?? DEFAULT_COL_WIDTHS.select,
      name: Math.max(120, parsed.name ?? DEFAULT_COL_WIDTHS.name),
      size: Math.max(64, parsed.size ?? DEFAULT_COL_WIDTHS.size),
      modified: Math.max(96, parsed.modified ?? DEFAULT_COL_WIDTHS.modified),
    };
  } catch {
    return DEFAULT_COL_WIDTHS;
  }
}

function storeColWidths(widths: ColWidths) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(COL_STORAGE_KEY, JSON.stringify(widths));
}

interface RemoteFileEntry {
  name: string;
  path: string;
  size: number;
  modifyTime: number;
  isDirectory: boolean;
  isSymlink: boolean;
}

function formatBytes(size: number): string {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

export function ServerFileManager({
  serverId,
  fillHeight = false,
}: {
  serverId: string;
  fillHeight?: boolean;
}) {
  const [path, setPath] = useState("/");
  const [entries, setEntries] = useState<RemoteFileEntry[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [colWidths, setColWidths] = useState<ColWidths>(DEFAULT_COL_WIDTHS);
  const uploadRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setColWidths(readColWidths());
  }, []);

  function resizeColumn(key: keyof ColWidths, width: number) {
    setColWidths((prev) => {
      const next = { ...prev, [key]: width };
      storeColWidths(next);
      return next;
    });
  }

  const load = useCallback(async (dir: string) => {
    setLoading(true);
    setError("");
    const res = await fetch(`/api/servers/${serverId}/files?path=${encodeURIComponent(dir)}`);
    const data = await res.json().catch(() => ({}));
    setLoading(false);
    if (!res.ok) {
      setEntries([]);
      setError(data.error ?? `List failed (${res.status})`);
      return;
    }
    setPath(data.path as string);
    setEntries(data.entries as RemoteFileEntry[]);
    setSelected(new Set());
  }, [serverId]);

  useEffect(() => {
    async function init() {
      const homeRes = await fetch(`/api/servers/${serverId}/files`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "resolveHome" }),
      });
      const homeData = await homeRes.json().catch(() => ({}));
      const start = homeRes.ok && homeData.path ? (homeData.path as string) : "/";
      await load(start);
    }
    void init();
  }, [serverId, load]);

  async function postAction(body: Record<string, unknown>) {
    setBusy(true);
    setError("");
    const res = await fetch(`/api/servers/${serverId}/files`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setError(data.error ?? "Operation failed");
      return null;
    }
    return data;
  }

  function toggleSelect(entryPath: string, multi: boolean) {
    setSelected((prev) => {
      const next = multi ? new Set(prev) : new Set<string>();
      if (next.has(entryPath)) next.delete(entryPath);
      else next.add(entryPath);
      return next;
    });
  }

  function openEntry(entry: RemoteFileEntry) {
    if (entry.isDirectory) {
      void load(entry.path);
    }
  }

  const breadcrumbs = path === "/" ? ["/"] : ["/", ...path.split("/").filter(Boolean)];

  function navigateToBreadcrumb(index: number) {
    if (index === 0) {
      void load("/");
      return;
    }
    const parts = breadcrumbs.slice(1, index + 1);
    void load(`/${parts.join("/")}`);
  }

  async function mkdirPrompt() {
    const name = prompt("New folder name");
    if (!name?.trim()) return;
    const result = await postAction({ action: "mkdir", parentPath: path, name: name.trim() });
    if (result) await load(path);
  }

  async function createFilePrompt() {
    const name = prompt("New file name");
    if (!name?.trim()) return;
    const result = await postAction({
      action: "createFile",
      parentPath: path,
      name: name.trim(),
      content: "",
    });
    if (result) await load(path);
  }

  async function renamePrompt() {
    const one = selected.size === 1 ? [...selected][0] : null;
    if (!one) {
      setError("Select exactly one item to rename");
      return;
    }
    const currentName = one.split("/").pop() ?? "";
    const newName = prompt("New name", currentName);
    if (!newName?.trim() || newName.trim() === currentName) return;
    const result = await postAction({ action: "rename", path: one, newName: newName.trim() });
    if (result) await load(path);
  }

  async function deleteSelected() {
    if (selected.size === 0) {
      setError("Select one or more items to delete");
      return;
    }
    const paths = [...selected];
    const hasDir = entries.some((e) => paths.includes(e.path) && e.isDirectory);
    const recursive =
      hasDir &&
      confirm(
        "Delete includes folders. Delete folder contents recursively? Cancel = only empty folders.",
      );
    if (!confirm(`Delete ${paths.length} item(s)?`)) return;

    setBusy(true);
    setError("");
    for (const p of paths) {
      const res = await fetch(`/api/servers/${serverId}/files`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "delete", path: p, recursive }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data.error ?? "Delete failed");
        setBusy(false);
        await load(path);
        return;
      }
    }
    setBusy(false);
    await load(path);
  }

  async function downloadSelected() {
    const paths = [...selected];
    if (paths.length === 0) {
      setError("Select file(s) to download");
      return;
    }
    for (const p of paths) {
      const entry = entries.find((e) => e.path === p);
      if (entry?.isDirectory) continue;
      window.open(
        `/api/servers/${serverId}/files/download?path=${encodeURIComponent(p)}`,
        "_blank",
      );
    }
  }

  async function uploadFiles(fileList: FileList | null) {
    if (!fileList?.length) return;
    setBusy(true);
    setError("");
    for (const file of Array.from(fileList)) {
      const form = new FormData();
      form.set("parentPath", path);
      form.set("fileName", file.name);
      form.set("file", file);
      const res = await fetch(`/api/servers/${serverId}/files/upload`, {
        method: "POST",
        body: form,
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data.error ?? `Upload failed for ${file.name}`);
        setBusy(false);
        return;
      }
    }
    setBusy(false);
    await load(path);
  }

  async function compressSelected() {
    const paths = [...selected];
    if (paths.length === 0) {
      setError("Select items to compress");
      return;
    }
    const defaultName = `archive-${Date.now()}.tar.gz`;
    const archiveName = prompt("Archive file name (in current folder)", defaultName);
    if (!archiveName?.trim()) return;
    const archivePath = path === "/" ? `/${archiveName.trim()}` : `${path}/${archiveName.trim()}`;
    const result = await postAction({ action: "compress", paths, archivePath });
    if (result) await load(path);
  }

  async function decompressSelected() {
    const paths = [...selected].filter((p) => {
      const name = p.split("/").pop()?.toLowerCase() ?? "";
      return (
        name.endsWith(".tar.gz") ||
        name.endsWith(".tgz") ||
        name.endsWith(".tar") ||
        name.endsWith(".zip") ||
        name.endsWith(".gz")
      );
    });
    if (paths.length !== 1) {
      setError("Select exactly one archive (.tar.gz, .tgz, .tar, .zip, .gz)");
      return;
    }
    const result = await postAction({
      action: "decompress",
      archivePath: paths[0],
      destDir: path,
    });
    if (result) await load(path);
  }

  return (
    <div className={fillHeight ? "flex flex-col flex-1 min-h-0 h-full gap-3" : "space-y-3"}>
      <div className="flex flex-wrap gap-2">
        <button type="button" className="btn btn-secondary py-1 px-2" onClick={() => load(path)} disabled={loading || busy}>
          <RefreshCw className="w-4 h-4" />
        </button>
        <button type="button" className="btn btn-secondary py-1 px-2" onClick={mkdirPrompt} disabled={busy}>
          <FolderPlus className="w-4 h-4" />
          Folder
        </button>
        <button type="button" className="btn btn-secondary py-1 px-2" onClick={createFilePrompt} disabled={busy}>
          <FilePlus className="w-4 h-4" />
          File
        </button>
        <button type="button" className="btn btn-secondary py-1 px-2" onClick={() => uploadRef.current?.click()} disabled={busy}>
          <Upload className="w-4 h-4" />
          Upload
        </button>
        <button type="button" className="btn btn-secondary py-1 px-2" onClick={downloadSelected} disabled={busy}>
          <Download className="w-4 h-4" />
          Download
        </button>
        <button type="button" className="btn btn-secondary py-1 px-2" onClick={renamePrompt} disabled={busy}>
          <Pencil className="w-4 h-4" />
          Rename
        </button>
        <button type="button" className="btn btn-secondary py-1 px-2" onClick={compressSelected} disabled={busy}>
          <Archive className="w-4 h-4" />
          Compress
        </button>
        <button type="button" className="btn btn-secondary py-1 px-2" onClick={decompressSelected} disabled={busy}>
          <ArchiveRestore className="w-4 h-4" />
          Extract
        </button>
        <button type="button" className="btn btn-secondary py-1 px-2" onClick={deleteSelected} disabled={busy}>
          <Trash2 className="w-4 h-4" style={{ color: "var(--danger)" }} />
          Delete
        </button>
        <input
          ref={uploadRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => {
            void uploadFiles(e.target.files);
            e.target.value = "";
          }}
        />
      </div>

      <nav className="flex flex-wrap items-center gap-1 text-sm" aria-label="Path">
        <button type="button" className="btn btn-secondary py-0.5 px-1.5" onClick={() => load("/")} title="Root">
          <Home className="w-4 h-4" />
        </button>
        {breadcrumbs.map((part, index) => (
          <span key={`${part}-${index}`} className="inline-flex items-center gap-1">
            {index > 0 && <ChevronRight className="w-3 h-3" style={{ color: "var(--muted)" }} />}
            <button
              type="button"
              className="hover:underline"
              style={{ color: index === breadcrumbs.length - 1 ? "var(--foreground)" : "var(--primary)" }}
              onClick={() => navigateToBreadcrumb(index)}
            >
              {part}
            </button>
          </span>
        ))}
      </nav>

      {error && (
        <p className="text-sm" style={{ color: "var(--danger)" }}>
          {error}
        </p>
      )}

      <div
        className={
          fillHeight
            ? "table-wrap border rounded-lg flex-1 min-h-0 overflow-auto"
            : "table-wrap border rounded-lg"
        }
        style={{ borderColor: "var(--card-border)" }}
      >
        <table className="w-full" style={{ tableLayout: "fixed" }}>
          <thead>
            <tr>
              <th style={{ width: colWidths.select, minWidth: colWidths.select }} />
              <ResizableColumnHeader
                width={colWidths.name}
                minWidth={120}
                onResize={(w) => resizeColumn("name", w)}
              >
                Name
              </ResizableColumnHeader>
              <ResizableColumnHeader
                width={colWidths.size}
                minWidth={64}
                onResize={(w) => resizeColumn("size", w)}
              >
                Size
              </ResizableColumnHeader>
              <ResizableColumnHeader
                width={colWidths.modified}
                minWidth={96}
                onResize={(w) => resizeColumn("modified", w)}
              >
                Modified
              </ResizableColumnHeader>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={4} style={{ color: "var(--muted)" }}>
                  Loading…
                </td>
              </tr>
            ) : entries.length === 0 ? (
              <tr>
                <td colSpan={4} style={{ color: "var(--muted)" }}>
                  Empty directory
                </td>
              </tr>
            ) : (
              entries.map((entry) => (
                <tr
                  key={entry.path}
                  className="cursor-pointer hover:opacity-90"
                  onClick={(e) => {
                    if (e.shiftKey) toggleSelect(entry.path, true);
                    else if (e.ctrlKey || e.metaKey) toggleSelect(entry.path, true);
                    else {
                      setSelected(new Set([entry.path]));
                      if (entry.isDirectory) openEntry(entry);
                    }
                  }}
                >
                  <td>
                    <input
                      type="checkbox"
                      checked={selected.has(entry.path)}
                      onChange={() => toggleSelect(entry.path, true)}
                      onClick={(e) => e.stopPropagation()}
                    />
                  </td>
                  <td className="font-medium truncate" style={{ maxWidth: colWidths.name }}>
                    <span className="inline-flex items-center gap-2">
                      {entry.isDirectory ? (
                        <Folder className="w-4 h-4 shrink-0" style={{ color: "var(--warning)" }} />
                      ) : (
                        <File className="w-4 h-4 shrink-0" style={{ color: "var(--muted)" }} />
                      )}
                      {entry.name}
                      {entry.isSymlink && (
                        <span className="text-xs" style={{ color: "var(--muted)" }}>
                          (link)
                        </span>
                      )}
                    </span>
                  </td>
                  <td>{entry.isDirectory ? "—" : formatBytes(entry.size)}</td>
                  <td className="text-sm" style={{ color: "var(--muted)" }}>
                    {entry.modifyTime ? formatDate(new Date(entry.modifyTime).toISOString()) : "—"}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      <p className="text-xs" style={{ color: "var(--muted)" }}>
        Click a folder to open. Ctrl/Cmd+click or checkbox to multi-select. Upload/download limits: 50 MB /
        100 MB per file.
      </p>
    </div>
  );
}
