"use client";

import { useState } from "react";
import type { ServerGroupSummary } from "./server-groups-panel";

export function ServerGroupPicker({
  groups,
  onApply,
  disabled,
}: {
  groups: ServerGroupSummary[];
  onApply: (serverIds: string[], mode: "replace" | "add") => void;
  disabled?: boolean;
}) {
  const [groupId, setGroupId] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  if (groups.length === 0) return null;

  async function apply(mode: "replace" | "add") {
    if (!groupId) {
      setError("Choose a group");
      return;
    }
    setLoading(true);
    setError("");
    const res = await fetch(`/api/server-groups/${groupId}/members`);
    const data = await res.json();
    setLoading(false);
    if (!res.ok) {
      setError(data.error ?? "Failed to resolve group");
      return;
    }
    const ids = Array.isArray(data.serverIds) ? data.serverIds : [];
    if (ids.length === 0) {
      setError("Group has no active members");
      return;
    }
    onApply(ids, mode);
  }

  return (
    <div className="flex flex-wrap items-end gap-2 text-sm">
      <div className="min-w-[12rem] flex-1">
        <label className="block text-xs font-medium mb-1" style={{ color: "var(--muted)" }}>
          Apply server group
        </label>
        <select
          className="input"
          value={groupId}
          disabled={disabled || loading}
          onChange={(e) => {
            setGroupId(e.target.value);
            setError("");
          }}
        >
          <option value="">Select group…</option>
          {groups.map((group) => (
            <option key={group.id} value={group.id}>
              {group.name} ({group.memberCount}) · {group.kind === "TAG" ? "tags" : "static"}
            </option>
          ))}
        </select>
      </div>
      <button
        type="button"
        className="btn btn-secondary"
        disabled={disabled || loading || !groupId}
        onClick={() => apply("replace")}
      >
        Use group
      </button>
      <button
        type="button"
        className="btn btn-ghost"
        disabled={disabled || loading || !groupId}
        onClick={() => apply("add")}
      >
        Add to selection
      </button>
      {error && (
        <p className="w-full text-xs" style={{ color: "var(--danger)" }}>
          {error}
        </p>
      )}
    </div>
  );
}

export function ProfileGroupSelect({
  groups,
  value,
  onChange,
}: {
  groups: ServerGroupSummary[];
  value: string | null;
  onChange: (groupId: string | null) => void;
}) {
  if (groups.length === 0) return null;

  return (
    <div>
      <label className="block text-sm font-medium mb-1">Server group (optional)</label>
      <select
        className="input"
        value={value ?? ""}
        onChange={(e) => onChange(e.target.value || null)}
      >
        <option value="">Manual server selection</option>
        {groups.map((group) => (
          <option key={group.id} value={group.id}>
            {group.name} — {group.memberCount} server(s), {group.kind === "TAG" ? "dynamic tags" : "static"}
          </option>
        ))}
      </select>
      <p className="text-xs mt-1" style={{ color: "var(--muted)" }}>
        When set, targets resolve from the group at run time (including scheduled runs).
      </p>
    </div>
  );
}
