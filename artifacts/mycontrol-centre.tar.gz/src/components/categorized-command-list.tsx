"use client";

import { useEffect, useMemo, useState } from "react";
import { groupTemplatesByCategory } from "@/lib/commands/categories";
import { CollapsibleListHeader } from "@/components/collapsible-list-header";
import type { CommandTemplate } from "./command-manager";

export function CategorizedCommandList({
  title,
  templates,
  selectedIds,
  onToggle,
  onSelectAll,
  emptyMessage = "No commands match the selected servers.",
  expandSignal = 0,
  expanded: controlledExpanded,
  onExpandedChange,
}: {
  title: string;
  templates: CommandTemplate[];
  selectedIds: string[];
  onToggle: (id: string) => void;
  onSelectAll: () => void;
  emptyMessage?: string;
  expandSignal?: number;
  expanded?: boolean;
  onExpandedChange?: (expanded: boolean) => void;
}) {
  const [internalExpanded, setInternalExpanded] = useState(selectedIds.length > 0);
  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>({});

  const expanded = controlledExpanded ?? internalExpanded;
  const setExpanded = (value: boolean) => {
    onExpandedChange?.(value);
    if (controlledExpanded === undefined) setInternalExpanded(value);
  };

  const groups = useMemo(() => groupTemplatesByCategory(templates), [templates]);

  useEffect(() => {
    setOpenCategories((prev) => {
      const next = { ...prev };
      for (const group of groups) {
        if (next[group.category] === undefined) next[group.category] = false;
      }
      return next;
    });
  }, [groups]);

  useEffect(() => {
    if (expandSignal <= 0) return;
    setExpanded(true);
    setOpenCategories((prev) => {
      const next = { ...prev };
      for (const group of groups) {
        const hasSelected = group.templates.some((t) => selectedIds.includes(t.id));
        if (hasSelected) next[group.category] = true;
      }
      return next;
    });
    // setExpanded is intentionally omitted (stable enough for expandSignal handling).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expandSignal, groups, selectedIds]);

  const allSelected = templates.length > 0 && selectedIds.length === templates.length;

  function expandAllCategories() {
    const next: Record<string, boolean> = {};
    for (const group of groups) next[group.category] = true;
    setOpenCategories(next);
  }

  function collapseAllCategories() {
    const next: Record<string, boolean> = {};
    for (const group of groups) next[group.category] = false;
    setOpenCategories(next);
  }

  return (
    <div>
      <CollapsibleListHeader
        title={title}
        count={templates.length}
        selectedCount={selectedIds.length}
        expanded={expanded}
        onToggle={() => setExpanded(!expanded)}
        selectAllLabel={allSelected ? "Clear all" : "Select all"}
        onSelectAll={templates.length > 1 ? onSelectAll : undefined}
      />

      {expanded && templates.length > 0 && groups.length > 1 && (
        <div className="flex gap-3 mb-2 text-xs">
          <button type="button" className="underline" onClick={expandAllCategories}>
            Expand categories
          </button>
          <button type="button" className="underline" onClick={collapseAllCategories}>
            Collapse categories
          </button>
        </div>
      )}

      {!expanded ? null : templates.length === 0 ? (
        <p
          className="text-sm p-3 rounded-lg border"
          style={{ color: "var(--muted)", borderColor: "var(--card-border)" }}
        >
          {emptyMessage}
        </p>
      ) : (
        <div className="space-y-2 max-h-72 overflow-y-auto">
          {groups.map((group) => (
            <div
              key={group.category}
              className="rounded-lg border"
              style={{ borderColor: "var(--card-border)" }}
            >
              <button
                type="button"
                className="w-full flex items-center justify-between px-3 py-2 text-sm font-medium"
                onClick={() =>
                  setOpenCategories((prev) => ({
                    ...prev,
                    [group.category]: !prev[group.category],
                  }))
                }
              >
                <span>
                  {group.label} ({group.templates.length})
                </span>
                <span>{openCategories[group.category] ? "−" : "+"}</span>
              </button>
              {openCategories[group.category] && (
                <div className="divide-y" style={{ borderColor: "var(--card-border)" }}>
                  {group.templates.map((template) => {
                    const checked = selectedIds.includes(template.id);
                    const order = selectedIds.indexOf(template.id);
                    return (
                      <label
                        key={template.id}
                        className="flex items-start gap-3 px-3 py-2 cursor-pointer hover:bg-black/5 dark:hover:bg-white/5"
                      >
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => onToggle(template.id)}
                          className="mt-1"
                        />
                        <span className="min-w-0 flex-1">
                          <span className="flex items-center gap-2">
                            <span className="font-medium text-sm">{template.name}</span>
                            {checked && order >= 0 && (
                              <span className="badge badge-muted text-xs">{order + 1}</span>
                            )}
                          </span>
                          {template.description && (
                            <span className="block text-xs mt-0.5" style={{ color: "var(--muted)" }}>
                              {template.description}
                            </span>
                          )}
                          {template.platforms && !template.platforms.includes("all") && (
                            <span className="block text-xs mt-1" style={{ color: "var(--muted)" }}>
                              {template.platforms.join(", ")}
                            </span>
                          )}
                        </span>
                      </label>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
