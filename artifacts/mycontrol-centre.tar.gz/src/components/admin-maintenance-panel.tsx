"use client";

import { useState } from "react";
import { Trash2 } from "lucide-react";

export function AdminMaintenancePanel() {
  const [loading, setLoading] = useState<string | null>(null);
  const [message, setMessage] = useState("");

  async function run(body: Record<string, boolean>, label: string) {
    if (!confirm(`Clear ${label}? This cannot be undone.`)) return;
    setLoading(label);
    setMessage("");
    try {
      const res = await fetch("/api/admin/cleanup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Cleanup failed");
      const parts: string[] = [];
      if (data.failedRuns) parts.push(`${data.failedRuns} failed run(s)`);
      if (data.sshFailures) parts.push(`${data.sshFailures} SSH failure log(s)`);
      if (data.auditLogs) parts.push(`${data.auditLogs} audit log(s)`);
      if (data.remoteLogs) parts.push(`${data.remoteLogs} remote SSH log(s)`);
      if (data.apiLogs) parts.push(`${data.apiLogs} API log(s)`);
      setMessage(`Removed ${parts.join(", ")}.`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Cleanup failed");
    } finally {
      setLoading(null);
    }
  }

  const busy = loading !== null;

  return (
    <div className="card p-6 space-y-4">
      <div>
        <h2 className="text-lg font-semibold">Maintenance &amp; log cleanup</h2>
        <p className="text-sm" style={{ color: "var(--muted)" }}>
          Reset dashboard counters and wipe stored log tables. Does not delete servers or successful command output.
        </p>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-medium">Command history</h3>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            className="btn btn-secondary text-sm"
            disabled={busy}
            onClick={() => run({ failedRuns: true }, "all failed command runs")}
          >
            <Trash2 className="w-4 h-4" />
            Clear failed runs
          </button>
          <button
            type="button"
            className="btn btn-secondary text-sm"
            disabled={busy}
            onClick={() =>
              run({ failedRuns: true, sshFailures: true }, "failed runs and SSH failure logs")
            }
          >
            Clear failed runs + SSH failures
          </button>
        </div>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-medium">Connection logs</h3>
        <button
          type="button"
          className="btn btn-secondary text-sm"
          disabled={busy}
          onClick={() => run({ sshFailures: true }, "SSH failure connection logs")}
        >
          <Trash2 className="w-4 h-4" />
          Clear SSH failure logs
        </button>
      </div>

      <div className="space-y-2">
        <h3 className="text-sm font-medium">Log tables (full wipe)</h3>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            className="btn btn-danger py-1 px-3 text-sm"
            disabled={busy}
            onClick={() => run({ auditLogs: true }, "all audit log entries")}
          >
            Wipe audit logs
          </button>
          <button
            type="button"
            className="btn btn-danger py-1 px-3 text-sm"
            disabled={busy}
            onClick={() => run({ remoteLogs: true }, "all remote SSH logs")}
          >
            Wipe remote SSH logs
          </button>
          <button
            type="button"
            className="btn btn-danger py-1 px-3 text-sm"
            disabled={busy}
            onClick={() => run({ apiLogs: true }, "all API request logs")}
          >
            Wipe API logs
          </button>
        </div>
      </div>

      {message && (
        <p className="text-sm" role="status">
          {message}
        </p>
      )}
    </div>
  );
}
