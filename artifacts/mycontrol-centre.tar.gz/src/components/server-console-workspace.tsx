"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  Activity,
  Files,
  Minus,
  Plus,
  Terminal,
  X,
  ChevronDown,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { ServerSshTerminal } from "@/components/server-ssh-terminal";
import { ServerFileManager } from "@/components/server-file-manager";
import {
  clampTerminalFontSize,
  readStoredTerminalFontSize,
  storeTerminalFontSize,
  TERMINAL_FONT_MAX,
  TERMINAL_FONT_MIN,
  TERMINAL_FONT_DEFAULT,
} from "@/lib/console/terminal-font-size";

type SessionMode = "terminal" | "files";

export type ConsoleSession = {
  key: string;
  serverId: string;
  serverName: string;
  hostname: string;
  mode: SessionMode;
};

interface ServerOption {
  id: string;
  name: string;
  hostname: string;
  port: number;
}

function newSessionKey() {
  return crypto.randomUUID();
}

export function ServerConsoleWorkspace({
  initialServerId,
  userRole,
}: {
  initialServerId: string;
  userRole: string;
}) {
  const [servers, setServers] = useState<ServerOption[]>([]);
  const [sessions, setSessions] = useState<ConsoleSession[]>([]);
  const [activeKey, setActiveKey] = useState<string | null>(null);
  const [fontSize, setFontSize] = useState(TERMINAL_FONT_DEFAULT);
  const [addOpen, setAddOpen] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState("");

  const activeSession = sessions.find((s) => s.key === activeKey) ?? null;

  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    async function init() {
      const res = await fetch("/api/servers");
      if (!res.ok) return;
      const data = await res.json();
      const list = (data.servers ?? []) as ServerOption[];
      setServers(list);

      if (!initialized && initialServerId) {
        const initial = list.find((s) => s.id === initialServerId);
        if (initial) {
          const key = newSessionKey();
          setSessions([
            {
              key,
              serverId: initial.id,
              serverName: initial.name,
              hostname: `${initial.hostname}:${initial.port}`,
              mode: "terminal",
            },
          ]);
          setActiveKey(key);
        }
        setInitialized(true);
      }
    }
    void init();
  }, [initialServerId, initialized]);

  useEffect(() => {
    setFontSize(readStoredTerminalFontSize());
  }, []);

  const openServerIds = useMemo(() => new Set(sessions.map((s) => s.serverId)), [sessions]);

  const addableServers = useMemo(
    () => servers.filter((s) => !openServerIds.has(s.id)),
    [openServerIds, servers],
  );

  function addSession(server: ServerOption) {
    const key = newSessionKey();
    setSessions((prev) => [
      ...prev,
      {
        key,
        serverId: server.id,
        serverName: server.name,
        hostname: `${server.hostname}:${server.port}`,
        mode: "terminal",
      },
    ]);
    setActiveKey(key);
    setAddOpen(false);
  }

  function closeSession(key: string) {
    setSessions((prev) => {
      const next = prev.filter((s) => s.key !== key);
      if (activeKey === key) {
        setActiveKey(next[next.length - 1]?.key ?? null);
      }
      return next;
    });
  }

  function setSessionMode(key: string, mode: SessionMode) {
    setSessions((prev) => prev.map((s) => (s.key === key ? { ...s, mode } : s)));
  }

  function changeFontSize(delta: number) {
    setFontSize((prev) => {
      const next = clampTerminalFontSize(prev + delta);
      storeTerminalFontSize(next);
      return next;
    });
  }

  async function testActiveConnection() {
    if (!activeSession) return;
    setTesting(true);
    setTestResult("");
    const res = await fetch(`/api/servers/${activeSession.serverId}/health`, { method: "POST" });
    const data = await res.json().catch(() => ({}));
    setTesting(false);
    if (data.online) {
      setTestResult(data.stdout?.trim() || "Connection OK");
    } else {
      setTestResult(data.error ?? "Connection failed");
    }
  }

  const canAdd = userRole !== "VIEWER" && (addableServers.length > 0 || servers.length > 0);

  return (
    <div className="flex flex-col min-h-[calc(100vh-5rem)] max-h-[calc(100vh-5rem)] -my-2">
      <div className="flex flex-wrap items-center justify-between gap-3 shrink-0 pb-3">
        <div className="min-w-0">
          <Link
            href="/servers"
            className="text-sm hover:underline"
            style={{ color: "var(--muted)" }}
          >
            ← Servers
          </Link>
          <h1 className="text-xl font-bold truncate">
            {activeSession ? activeSession.serverName : "Remote console"}
          </h1>
          {activeSession && (
            <p className="text-sm truncate" style={{ color: "var(--muted)" }}>
              {activeSession.hostname}
            </p>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div
            className="flex items-center gap-1 rounded-lg border px-1"
            style={{ borderColor: "var(--card-border)" }}
            title="Terminal font size"
          >
            <button
              type="button"
              className="btn btn-secondary p-1.5"
              disabled={fontSize <= TERMINAL_FONT_MIN}
              onClick={() => changeFontSize(-1)}
              aria-label="Decrease font size"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="text-sm tabular-nums w-8 text-center">{fontSize}</span>
            <button
              type="button"
              className="btn btn-secondary p-1.5"
              disabled={fontSize >= TERMINAL_FONT_MAX}
              onClick={() => changeFontSize(1)}
              aria-label="Increase font size"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
          {activeSession && (
            <button
              type="button"
              className="btn btn-secondary"
              onClick={testActiveConnection}
              disabled={testing}
            >
              <Activity className="w-4 h-4" />
              {testing ? "Testing…" : "Test SSH"}
            </button>
          )}
        </div>
      </div>

      {testResult && (
        <pre
          className="shrink-0 text-xs font-mono mb-2 p-2 rounded border max-h-24 overflow-auto whitespace-pre-wrap"
          style={{ borderColor: "var(--card-border)", color: "var(--muted)" }}
        >
          {testResult}
        </pre>
      )}

      <div
        className="flex flex-wrap items-end gap-1 shrink-0 border-b pb-0"
        style={{ borderColor: "var(--card-border)" }}
      >
        {sessions.map((session) => (
          <div
            key={session.key}
            className={cn(
              "flex items-center gap-1 rounded-t-lg border border-b-0 px-2 py-1.5 text-sm max-w-[14rem]",
              activeKey === session.key ? "font-medium" : "opacity-70",
            )}
            style={{
              borderColor: "var(--card-border)",
              background: activeKey === session.key ? "var(--card)" : "transparent",
            }}
          >
            <button
              type="button"
              className="truncate text-left flex-1 min-w-0"
              onClick={() => setActiveKey(session.key)}
              title={`${session.serverName} (${session.hostname})`}
            >
              <Terminal className="w-3 h-3 inline mr-1 opacity-60" />
              {session.serverName}
            </button>
            <button
              type="button"
              className="p-0.5 rounded hover:bg-black/10 shrink-0"
              onClick={() => closeSession(session.key)}
              aria-label={`Close ${session.serverName}`}
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}

        <div className="relative mb-1">
          <button
            type="button"
            className="btn btn-secondary py-1 px-2 text-sm"
            disabled={!canAdd}
            onClick={() => setAddOpen((o) => !o)}
          >
            <Plus className="w-4 h-4" />
            Add server
            <ChevronDown className="w-3 h-3" />
          </button>
          {addOpen && (
            <>
              <button
                type="button"
                className="fixed inset-0 z-40 cursor-default"
                aria-label="Close menu"
                onClick={() => setAddOpen(false)}
              />
              <div
                className="absolute left-0 top-full mt-1 z-50 min-w-[16rem] max-h-64 overflow-y-auto rounded-lg border shadow-lg py-1"
                style={{ background: "var(--card)", borderColor: "var(--card-border)" }}
              >
                {addableServers.length === 0 ? (
                  <p className="px-3 py-2 text-sm" style={{ color: "var(--muted)" }}>
                    {servers.length === 0 ? "Loading servers…" : "All servers already have a tab."}
                  </p>
                ) : (
                  addableServers.map((server) => (
                    <button
                      key={server.id}
                      type="button"
                      className="w-full text-left px-3 py-2 text-sm hover:bg-black/5 dark:hover:bg-white/5"
                      onClick={() => addSession(server)}
                    >
                      <div className="font-medium">{server.name}</div>
                      <div className="text-xs" style={{ color: "var(--muted)" }}>
                        {server.hostname}:{server.port}
                      </div>
                    </button>
                  ))
                )}
              </div>
            </>
          )}
        </div>
      </div>

      {activeSession && (
        <div className="flex gap-2 shrink-0 py-2">
          {(
            [
              { id: "terminal" as const, label: "SSH", icon: Terminal },
              { id: "files" as const, label: "Files", icon: Files },
            ] as const
          ).map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              className={cn(
                "btn py-1 px-2 text-sm",
                activeSession.mode === id ? "btn-primary" : "btn-secondary",
              )}
              onClick={() => setSessionMode(activeSession.key, id)}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>
      )}

      <div
        className="card flex-1 min-h-0 flex flex-col overflow-hidden p-2 sm:p-3"
        style={{ borderTopLeftRadius: activeSession ? 0 : undefined }}
      >
        {sessions.length === 0 ? (
          <p className="text-sm p-4" style={{ color: "var(--muted)" }}>
            Loading…
          </p>
        ) : (
          <div className="relative flex-1 min-h-0">
            {sessions.map((session) => (
              <div
                key={session.key}
                className={cn(
                  "absolute inset-0 flex flex-col min-h-0",
                  activeKey !== session.key && "invisible pointer-events-none",
                )}
              >
                <div
                  className={cn(
                    "flex flex-col flex-1 min-h-0",
                    session.mode !== "terminal" && "hidden",
                  )}
                >
                  <ServerSshTerminal
                    serverId={session.serverId}
                    fontSize={fontSize}
                    isActive={activeKey === session.key && session.mode === "terminal"}
                  />
                </div>
                <div
                  className={cn(
                    "flex flex-col flex-1 min-h-0",
                    session.mode !== "files" && "hidden",
                  )}
                >
                  <ServerFileManager
                    serverId={session.serverId}
                    fillHeight={activeKey === session.key && session.mode === "files"}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
