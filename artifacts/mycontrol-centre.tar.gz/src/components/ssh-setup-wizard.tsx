"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Check,
  Copy,
  Key,
  Terminal,
  ChevronRight,
  AlertTriangle,
} from "lucide-react";
import { parseProxmoxHostOutput } from "@/lib/setup/parse-host-output";
import { CopyCommandBlock } from "@/components/copy-command-block";
import { buildRemoteCleanupCommand } from "@/lib/setup/remote-cleanup";

interface GeneratedKey {
  publicKey: string;
  privateKey: string;
  fingerprint: string;
  installCommand: string;
  installCommandSudo?: string;
  scriptUrl: string;
  consoleUrl?: string;
  sshUser: string;
}

type Step = 1 | 2 | 3 | 4;

function CopyButton({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  async function copy() {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }
  return (
    <button type="button" onClick={copy} className="btn btn-secondary text-xs py-1 px-2 shrink-0" title={label ?? "Copy"}>
      {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
      {copied ? "Copied" : "Copy"}
    </button>
  );
}

function CodeBlock({ children, copyText, prominent }: { children: string; copyText?: string; prominent?: boolean }) {
  return (
    <CopyCommandBlock
      command={copyText ?? children}
      prominent={prominent}
    />
  );
}

export function SshSetupWizard({
  onUseKey,
  onUseHostInfo,
  onKeysGenerated,
  enrollmentReceived,
}: {
  onUseKey?: (privateKey: string) => void;
  onUseHostInfo?: (info: {
    name?: string;
    hostname?: string;
    port?: number;
    sshUser?: string;
    knownHostKey?: string;
  }) => void;
  onKeysGenerated?: (keys: { publicKey: string; privateKey: string }) => void;
  enrollmentReceived?: boolean;
}) {
  const [step, setStep] = useState<Step>(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [keys, setKeys] = useState<GeneratedKey | null>(null);
  const [hostOutput, setHostOutput] = useState("");
  const [savedPrivateKey, setSavedPrivateKey] = useState(false);
  const [consoleUrl, setConsoleUrl] = useState("");
  const [updatingCommand, setUpdatingCommand] = useState(false);

  useEffect(() => {
    async function loadConsoleUrl() {
      const fromWindow =
        typeof window !== "undefined" ? window.location.origin : "";
      try {
        const res = await fetch("/api/settings");
        if (res.ok) {
          const data = await res.json();
          setConsoleUrl(data.consolePublicUrl || fromWindow);
          return;
        }
      } catch {
        /* fallback */
      }
      setConsoleUrl(fromWindow);
    }
    loadConsoleUrl();
  }, []);

  const generateKeys = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/setup/ssh-key", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ consoleUrl: consoleUrl.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed to generate key");
      setKeys(data);
      onKeysGenerated?.({ publicKey: data.publicKey, privateKey: data.privateKey });
      if (data.consoleUrl) setConsoleUrl(data.consoleUrl);
      setStep(2);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed");
    } finally {
      setLoading(false);
    }
  }, [consoleUrl, onKeysGenerated]);

  async function refreshInstallCommand() {
    if (!keys?.publicKey || !consoleUrl.trim()) return;
    setUpdatingCommand(true);
    setError("");
    try {
      const res = await fetch("/api/setup/install-command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          consoleUrl: consoleUrl.trim(),
          publicKey: keys.publicKey,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed to update command");
      setKeys((prev) =>
        prev
          ? {
              ...prev,
              installCommand: data.installCommand,
              installCommandSudo: data.installCommandSudo,
              scriptUrl: data.scriptUrl,
              consoleUrl: data.consoleUrl,
            }
          : prev,
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed");
    } finally {
      setUpdatingCommand(false);
    }
  }

  function parseHostOutput(text: string): boolean {
    const parsed = parseProxmoxHostOutput(text);
    if (!parsed) {
      setError(
        "Could not find Name or Hostname / IP in the pasted output. Include the 'copy these values' section or the JSON block.",
      );
      return false;
    }

    onUseHostInfo?.({
      name: parsed.name,
      hostname: parsed.hostname,
      port: parsed.port,
      sshUser: parsed.sshUser,
      knownHostKey: parsed.knownHostKey,
    });
    setError("");
    return true;
  }

  const steps = [
    { n: 1, label: "Generate key" },
    { n: 2, label: "Run on host" },
    { n: 3, label: "Paste output" },
    { n: 4, label: "Add server" },
  ];

  return (
    <div className="card p-6 space-y-6">
      <div>
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Terminal className="w-5 h-5" style={{ color: "var(--primary)" }} />
          Automated Proxmox host setup
        </h2>
        <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
          Generate an SSH key, then run the <strong>full install command</strong> on each Proxmox
          host as root (SSH or Proxmox shell). Opening the script URL in a browser only shows the
          script — it does not configure the host.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {steps.map((s) => (
          <div
            key={s.n}
            className="flex items-center gap-1 text-xs"
            style={{ color: step >= s.n ? "var(--foreground)" : "var(--muted)" }}
          >
            <span
              className="w-6 h-6 rounded-full flex items-center justify-center font-medium"
              style={{
                background:
                  step === s.n
                    ? "var(--primary)"
                    : step > s.n
                      ? "color-mix(in srgb, var(--success) 25%, transparent)"
                      : "color-mix(in srgb, var(--muted) 20%, transparent)",
                color: step === s.n ? "white" : "inherit",
              }}
            >
              {step > s.n ? <Check className="w-3 h-3" /> : s.n}
            </span>
            {s.label}
            {s.n < 4 && <ChevronRight className="w-3 h-3 opacity-40" />}
          </div>
        ))}
      </div>

      {error && (
        <p className="text-sm flex items-center gap-2" style={{ color: "var(--danger)" }}>
          <AlertTriangle className="w-4 h-4" />
          {error}
        </p>
      )}

      {step === 1 && (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">
              Console URL (reachable from Proxmox hosts)
            </label>
            <input
              className="input font-mono text-sm"
              value={consoleUrl}
              onChange={(e) => setConsoleUrl(e.target.value)}
              placeholder="http://10.1.3.230:3000"
            />
            <p className="text-xs mt-1" style={{ color: "var(--muted)" }}>
              IP or hostname Proxmox uses to download the setup script — not{" "}
              <code>localhost</code> unless Proxmox runs on the same machine. Saved in Settings.
            </p>
            <p className="text-xs mt-2 p-2 rounded-lg" style={{ background: "color-mix(in srgb, var(--muted) 12%, transparent)" }}>
              <strong>Can Proxmox reach this URL?</strong> From the Proxmox shell, run:{" "}
              <code className="text-xs">
                curl -v --connect-timeout 10 --noproxy &apos;*&apos; {consoleUrl.trim() || "http://YOUR_IP:3000"}/api/health
              </code>
              . Ping only tests ICMP — you need TCP port 3000 open on the console host (firewall).
              <code className="block mt-1">curl -fsSL</code> is silent on failure; use{" "}
              <code>-v</code> while debugging.
            </p>
          </div>
          <p className="text-sm" style={{ color: "var(--muted)" }}>
            MyControl Centre will create a dedicated <strong>ed25519</strong> key pair. The{" "}
            <strong>private key</strong> stays in the console (encrypted at rest). The{" "}
            <strong>public key</strong> is installed on each Proxmox host by the setup script.
          </p>
          <button
            type="button"
            className="btn btn-primary"
            onClick={generateKeys}
            disabled={loading || !consoleUrl.trim()}
          >
            <Key className="w-4 h-4" />
            {loading ? "Generating..." : "Generate SSH key pair"}
          </button>
        </div>
      )}

      {step === 2 && keys && (
        <div className="space-y-4">
          {enrollmentReceived && (
            <div
              className="p-3 rounded-lg text-sm"
              style={{
                background: "color-mix(in srgb, var(--success) 12%, transparent)",
                border: "1px solid color-mix(in srgb, var(--success) 35%, transparent)",
              }}
            >
              <strong>Host enrolled.</strong> Use <strong>Pending enrollment</strong> above to approve
              and activate — you do not need step 3 unless enrollment failed.
            </div>
          )}
          <div
            className="p-3 rounded-lg text-sm flex gap-2"
            style={{
              background: "color-mix(in srgb, var(--warning) 12%, transparent)",
              border: "1px solid color-mix(in srgb, var(--warning) 30%, transparent)",
            }}
          >
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: "var(--warning)" }} />
            <div>
              <strong>Save your private key now.</strong> It is shown once. You will paste it when
              adding the server. Fingerprint: <code>{keys.fingerprint}</code>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-sm font-medium">Private key (for Add Server form)</label>
              <CopyButton text={keys.privateKey} label="Copy private key" />
            </div>
            <CodeBlock copyText={keys.privateKey}>{keys.privateKey}</CodeBlock>
            <label className="flex items-center gap-2 mt-2 text-sm">
              <input
                type="checkbox"
                checked={savedPrivateKey}
                onChange={(e) => setSavedPrivateKey(e.target.checked)}
              />
              I have copied the private key to a safe place
            </label>
          </div>

          <div>
            <div className="flex flex-wrap items-end gap-2 mb-2">
              <div className="flex-1 min-w-[200px]">
                <label className="block text-sm font-medium mb-1">Console URL</label>
                <input
                  className="input font-mono text-sm"
                  value={consoleUrl}
                  onChange={(e) => setConsoleUrl(e.target.value)}
                />
              </div>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={refreshInstallCommand}
                disabled={updatingCommand}
              >
                {updatingCommand ? "Updating..." : "Update command"}
              </button>
            </div>
            <CopyCommandBlock
              prominent
              title="Run on each Proxmox host as root"
              description="Copy the full one-liner, paste into the Proxmox shell or SSH session, then press Enter."
              command={keys.installCommand}
            />
            <CopyCommandBlock
              prominent
              title="Or run with sudo (non-root SSH login)"
              description="Same script: overwrites /tmp/mcc-proxmox-setup.sh, runs with sudo, then removes the file."
              command={keys.installCommandSudo ?? keys.installCommand.replace("bash /tmp", "sudo bash /tmp")}
            />
            <details className="text-xs" style={{ color: "var(--muted)" }}>
              <summary className="cursor-pointer font-medium" style={{ color: "var(--foreground)" }}>
                Remove automation from a host (production cleanup)
              </summary>
              <div className="mt-2">
                <CopyCommandBlock
                  prominent
                  command={buildRemoteCleanupCommand(consoleUrl.trim(), {
                    publicKey: keys.publicKey,
                  })}
                />
              </div>
            </details>
            <p className="text-xs mt-2" style={{ color: "var(--muted)" }}>
              Each command removes any old <code>/tmp/mcc-proxmox-setup.sh</code>, downloads a fresh copy,
              runs <code>--pubkey</code> with your key, then deletes the script. When enrollment is enabled,
              the script also posts host details to the console — approve the request under{" "}
              <strong>Pending enrollment</strong> and paste this private key to activate the server
              (you can skip manual paste in step 3). Script URL:{" "}
              <a href={keys.scriptUrl} className="underline" target="_blank" rel="noreferrer">
                {keys.scriptUrl}?raw=1
              </a>
            </p>
          </div>

          <div className="flex gap-2">
            <button
              type="button"
              className="btn btn-primary"
              disabled={!savedPrivateKey}
              onClick={() => setStep(3)}
            >
              Next — I ran the command on the host
            </button>
            <button type="button" className="btn btn-secondary" onClick={() => setStep(1)}>
              Regenerate key
            </button>
          </div>
        </div>
      )}

      {step === 3 && keys && (
        <div className="space-y-4">
          <p className="text-sm" style={{ color: "var(--muted)" }}>
            Paste the output from the host script (the section starting with &quot;MyControl Centre
            — copy these values&quot;). Optional — you can also fill the form manually.
          </p>
          <textarea
            className="input font-mono text-xs min-h-40"
            placeholder="Paste host script output here..."
            value={hostOutput}
            onChange={(e) => setHostOutput(e.target.value)}
          />
          <div className="flex gap-2">
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => {
                if (!parseHostOutput(hostOutput)) return;
                onUseKey?.(keys.privateKey);
                setStep(4);
              }}
            >
              Parse & continue
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => {
                onUseKey?.(keys.privateKey);
                setStep(4);
              }}
            >
              Skip — fill form manually
            </button>
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="space-y-3">
          <p className="text-sm flex items-center gap-2" style={{ color: "var(--success)" }}>
            <Check className="w-4 h-4" />
            Ready to add the server — scroll to <strong>Add server</strong> below. Values from the
            host output are pre-filled when you clicked Parse.
          </p>
          <ul className="text-sm list-disc pl-5 space-y-1" style={{ color: "var(--muted)" }}>
            <li>Auth type: <strong>SSH key</strong></li>
            <li>SSH user: <strong>mcc-auto</strong> (unless you changed it)</li>
            <li>After saving, click the health-check button to verify connectivity</li>
            <li>For apt commands, the host script configures sudo — templates use apt-get directly on Debian/Proxmox when running as a user with sudo, or use root (not recommended)</li>
          </ul>
          <button type="button" className="btn btn-secondary" onClick={() => setStep(1)}>
            Start over
          </button>
        </div>
      )}

      <details className="text-sm" style={{ color: "var(--muted)" }}>
        <summary className="cursor-pointer font-medium" style={{ color: "var(--foreground)" }}>
          Manual setup (without automation)
        </summary>
        <div className="mt-3 space-y-2">
          <p>On the Proxmox host as root:</p>
          <CodeBlock>{`# Create automation user (use -g if group mcc-auto already exists from a prior run)
id mcc-auto &>/dev/null || \\
  { getent group mcc-auto &>/dev/null && useradd -m -s /bin/bash -g mcc-auto mcc-auto || useradd -m -s /bin/bash mcc-auto; }
mkdir -p /home/mcc-auto/.ssh && chmod 700 /home/mcc-auto/.ssh

# Add your public key (one line from ssh-keygen .pub file)
echo 'PASTE_PUBLIC_KEY_HERE' >> /home/mcc-auto/.ssh/authorized_keys
chmod 600 /home/mcc-auto/.ssh/authorized_keys
chown -R mcc-auto:mcc-auto /home/mcc-auto/.ssh

# Scoped sudo for MyControl automation (apt, docker install, systemctl)
echo 'mcc-auto ALL=(ALL) NOPASSWD: /usr/bin/apt-get, /usr/bin/apt, /usr/bin/docker, /usr/bin/systemctl, /usr/bin/install, /usr/bin/curl, /usr/bin/tee, /usr/bin/chmod, /usr/bin/usermod, /usr/bin/bash, /bin/bash, /usr/bin/journalctl' > /etc/sudoers.d/mcc-auto
chmod 440 /etc/sudoers.d/mcc-auto

# From MyControl Centre machine — get host key for strict verification:
ssh-keyscan -t ed25519 PROXMOX_IP | awk '{print $3}'`}</CodeBlock>
          <p>
            Download the full script:{" "}
            <a href="/api/setup/proxmox-host.sh" className="underline">
              proxmox-host-setup.sh
            </a>
          </p>
        </div>
      </details>
    </div>
  );
}
