"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import {
  applyAppearanceToDocument,
  clearAppearanceOverrides,
  mergeAppearance,
  type AppearanceSettings,
} from "@/lib/settings/appearance";

type AppearanceContextValue = {
  appearance: Required<AppearanceSettings>;
  refresh: () => Promise<void>;
};

const AppearanceContext = createContext<AppearanceContextValue | null>(null);

export function AppearanceProvider({ children }: { children: React.ReactNode }) {
  const [appearance, setAppearance] = useState(() => mergeAppearance());

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/settings/appearance");
      if (!res.ok) return;
      const data = (await res.json()) as { appearance: AppearanceSettings };
      const merged = mergeAppearance(data.appearance);
      setAppearance(merged);
      applyAppearanceToDocument(merged);
    } catch {
      /* use defaults */
    }
  }, []);

  useEffect(() => {
    refresh();

    const onUpdate = () => {
      void refresh();
    };
    window.addEventListener("mcc-appearance-updated", onUpdate);
    const onTheme = () => applyAppearanceToDocument(appearance);
    window.addEventListener("mcc-theme-changed", onTheme);
    return () => {
      window.removeEventListener("mcc-appearance-updated", onUpdate);
      window.removeEventListener("mcc-theme-changed", onTheme);
    };
  }, [refresh, appearance]);

  useEffect(() => {
    applyAppearanceToDocument(appearance);
    return () => clearAppearanceOverrides();
  }, [appearance]);

  return (
    <AppearanceContext.Provider value={{ appearance, refresh }}>
      {children}
    </AppearanceContext.Provider>
  );
}

export function useAppearance() {
  const ctx = useContext(AppearanceContext);
  if (!ctx) {
    throw new Error("useAppearance must be used within AppearanceProvider");
  }
  return ctx;
}

export function notifyAppearanceUpdated() {
  window.dispatchEvent(new CustomEvent("mcc-appearance-updated"));
}
