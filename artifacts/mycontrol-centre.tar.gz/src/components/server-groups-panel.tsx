"use client";

import { useCallback, useEffect, useState } from "react";
import { Layers, Trash2 } from "lucide-react";

export interface ServerGroupSummary {
  id: string;
  name: string;
  description: string | null;
  kind: "STATIC" | "TAG";
  serverIds: string[];
  matchTags: string[];
  matchAnyTag: boolean;
  memberCount: number;
}

interface ServerRow {
  id: string;
  name: string;
}

export function ServerGroupsPanel({
  servers,
  onChanged,
}: {
  servers: ServerRow[];
  onChanged?: () => void;
}) {
  const [groups, setGroups] = useState<ServerGroupSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [kind, setKind] = useState<"STATIC" | "TAG">("STATIC");
  const [selectedServerIds, setSelectedServerIds] = useState<string[]>([]);
  const [matchTags, setMatchTags] = useState("");
  const [matchAnyTag, setMatchAnyTag] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    const res = await fetch("/api/server-groups");
    if (res.ok) {
      setError("");
      setGroups((await res.json()).groups);
    } else {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Failed to load server groups");
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function toggleServer(id: string) {
    setSelectedServerIds((prev) =>
      prev.includes(id) ? prev.filter((entry) => entry !== id) : [...prev, id],
    );
  }

  async function createGroup(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      setError("Group name is required");
      return;
    }
    setSaving(true);
    setError("");
    const body =
      kind === "STATIC"
        ? {
            name: name.trim(),
            description: description.trim() || undefined,
            kind: "STATIC" as const,
            serverIds: selectedServerIds,
          }
        : {
            name: name.trim(),
            description: description.trim() || undefined,
            kind: "TAG" as const,
            matchTags: matchTags
              .split(",")
              .map((tag) => tag.trim())
              .filter(Boolean),
            matchAnyTag,
          };

    const res = await fetch("/api/server-groups", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    setSaving(false);
    if (!res.ok) {
      setError(data.error ?? "Failed to create group");
      return;
    }
    setName("");
    setDescription("");
    setSelectedServerIds([]);
    setMatchTags("");
    await load();
    onChanged?.();
  }

  async function deleteGroup(id: string) {
    if (!confirm("Delete this server group? Linked run profiles will keep working but lose the group reference.")) {
      return;
    }
    const res = await fetch(`/api/server-groups/${id}`, { method: "DELETE" });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Delete failed");
      return;
    }
    await load();
    onChanged?.();
  }

  return (
    <div className="card p-6 space-y-4">
      <div className="flex items-center gap-2">
        <Layers className="w-5 h-5" style={{ color: "var(--muted)" }} />
        <h2 className="font-semibold text-lg">Server groups</h2>
      </div>
      <p className="text-sm" style={{ color: "var(--muted)" }}>
        Named static lists or tag rules for batch command targeting. Tag groups resolve to active servers at run time.
      </p>

      {error && (
        <p className="text-sm" style={{ color: "var(--danger)" }}>
          {error}
        </p>
      )}

      <form onSubmit={createGroup} className="space-y-4 border-t pt-4" style={{ borderColor: "var(--border)" }}>
        <h3 className="text-sm font-medium">New group</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Name</label>
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Description</label>
            <input className="input" value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
        </div>
        <div className="flex flex-wrap gap-4 text-sm">
          <label className="flex items-center gap-2">
            <input
              type="radio"
              name="groupKind"
              checked={kind === "STATIC"}
              onChange={() => setKind("STATIC")}
            />
            Static (pick servers)
          </label>
          <label className="flex items-center gap-2">
            <input
              type="radio"
              name="groupKind"
              checked={kind === "TAG"}
              onChange={() => setKind("TAG")}
            />
            Tag rule (dynamic)
          </label>
        </div>

        {kind === "STATIC" ? (
          <div className="max-h-48 overflow-y-auto border rounded p-2 space-y-1 text-sm" style={{ borderColor: "var(--border)" }}>
            {servers.length === 0 ? (
              <p style={{ color: "var(--muted)" }}>Add servers first.</p>
            ) : (
              servers.map((server) => (
                <label key={server.id} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={selectedServerIds.includes(server.id)}
                    onChange={() => toggleServer(server.id)}
                  />
                  {server.name}
                </label>
              ))
            )}
          </div>
        ) : (
          <div className="space-y-2">
            <div>
              <label className="block text-sm font-medium mb-1">Match tags (comma-separated)</label>
              <input
                className="input"
                value={matchTags}
                onChange={(e) => setMatchTags(e.target.value)}
                placeholder="prod, proxmox"
              />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={matchAnyTag} onChange={(e) => setMatchAnyTag(e.target.checked)} />
              Match any tag (uncheck for all tags required)
            </label>
          </div>
        )}

        <button type="submit" className="btn btn-primary" disabled={saving}>
          {saving ? "Saving…" : "Create group"}
        </button>
      </form>

      <div className="border-t pt-4" style={{ borderColor: "var(--border)" }}>
        <h3 className="text-sm font-medium mb-2">Existing groups</h3>
        {loading ? (
          <p className="text-sm" style={{ color: "var(--muted)" }}>
            Loading…
          </p>
        ) : groups.length === 0 ? (
          <p className="text-sm" style={{ color: "var(--muted)" }}>
            No groups yet.
          </p>
        ) : (
          <ul className="space-y-2 text-sm">
            {groups.map((group) => (
              <li
                key={group.id}
                className="flex flex-wrap items-start justify-between gap-2 border rounded p-3"
                style={{ borderColor: "var(--border)" }}
              >
                <div>
                  <p className="font-medium">{group.name}</p>
                  {group.description && (
                    <p style={{ color: "var(--muted)" }}>{group.description}</p>
                  )}
                  <p style={{ color: "var(--muted)" }}>
                    {group.kind === "STATIC"
                      ? `${group.memberCount} active server(s) · static list`
                      : `${group.memberCount} active server(s) · tags: ${group.matchTags.join(", ")} (${group.matchAnyTag ? "any" : "all"})`}
                  </p>
                </div>
                <button
                  type="button"
                  className="btn btn-ghost text-sm"
                  onClick={() => deleteGroup(group.id)}
                  title="Delete group"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
