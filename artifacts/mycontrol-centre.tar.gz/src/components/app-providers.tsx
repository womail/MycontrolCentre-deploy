"use client";

import { EnrollmentPendingProvider } from "@/components/enrollment-pending-provider";

export function AppProviders({
  children,
  isAdmin,
}: {
  children: React.ReactNode;
  isAdmin: boolean;
}) {
  return <EnrollmentPendingProvider isAdmin={isAdmin}>{children}</EnrollmentPendingProvider>;
}
