"use client";

import { useEffect, useState } from "react";
import { Bell, Plus, Trash2 } from "lucide-react";

type AlertChannelType = "webhook" | "ntfy" | "gotify";

interface AlertChannel {
  id: string;
  type: AlertChannelType;
  enabled: boolean;
  url?: string;
  topic?: string;
  token?: string;
}

interface AlertSettings {
  enabled: boolean;
  healthCheckEnabled: boolean;
  healthCheckIntervalMinutes: number;
  alertOnRecovery: boolean;
  alertCooldownMinutes: number;
  skipAlertsInMaintenance: boolean;
  channels: AlertChannel[];
}

const emptyChannel = (): AlertChannel => ({
  id: crypto.randomUUID(),
  type: "webhook",
  enabled: true,
  url: "",
});

export function AlertsSettingsPanel() {
  const [alerts, setAlerts] = useState<AlertSettings | null>(null);
  const [saved, setSaved] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState("");
  const [error, setError] = useState("");

  async function load() {
    const res = await fetch("/api/settings/alerts");
    if (res.ok) {
      setAlerts((await res.json()).alerts);
    }
  }

  useEffect(() => {
    load();
  }, []);

  function updateChannel(index: number, patch: Partial<AlertChannel>) {
    if (!alerts) return;
    setAlerts({
      ...alerts,
      channels: alerts.channels.map((channel, idx) =>
        idx === index ? { ...channel, ...patch } : channel,
      ),
    });
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!alerts) return;
    setError("");
    const res = await fetch("/api/settings/alerts", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(alerts),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Failed to save alerts");
      return;
    }
    setAlerts(data.alerts);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  async function testAlert() {
    setTesting(true);
    setTestResult("");
    setError("");
    const res = await fetch("/api/settings/alerts/test", { method: "POST" });
    const data = await res.json();
    setTesting(false);
    if (!res.ok) {
      setError(data.error ?? "Test alert failed");
      return;
    }
    const failed = (data.results as Array<{ ok: boolean; error?: string }>).filter(
      (result) => !result.ok,
    );
    setTestResult(
      failed.length > 0
        ? `Sent with ${failed.length} channel failure(s)`
        : "Test alert sent successfully",
    );
  }

  if (!alerts) {
    return (
      <div className="card p-6 text-sm" style={{ color: "var(--muted)" }}>
        Loading alert settings...
      </div>
    );
  }

  return (
    <form onSubmit={save} className="card p-6 space-y-5">
      <div>
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Bell className="w-5 h-5" />
          Alerts &amp; health checks
        </h2>
        <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
          Periodic SSH health probes and notifications when servers go offline or recover.
        </p>
      </div>

      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={alerts.enabled}
          onChange={(e) => setAlerts({ ...alerts, enabled: e.target.checked })}
        />
        Enable alert notifications
      </label>

      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={alerts.healthCheckEnabled}
          onChange={(e) => setAlerts({ ...alerts, healthCheckEnabled: e.target.checked })}
        />
        Run scheduled health checks
      </label>

      <div className="grid sm:grid-cols-2 gap-4">
        <Field
          label="Health check interval (minutes)"
          type="number"
          min={1}
          max={1440}
          value={String(alerts.healthCheckIntervalMinutes)}
          onChange={(value) =>
            setAlerts({
              ...alerts,
              healthCheckIntervalMinutes: parseInt(value, 10) || 5,
            })
          }
        />
        <Field
          label="Alert cooldown (minutes)"
          type="number"
          min={5}
          max={1440}
          value={String(alerts.alertCooldownMinutes)}
          onChange={(value) =>
            setAlerts({
              ...alerts,
              alertCooldownMinutes: parseInt(value, 10) || 30,
            })
          }
        />
      </div>

      <div className="flex flex-wrap gap-4 text-sm">
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={alerts.alertOnRecovery}
            onChange={(e) => setAlerts({ ...alerts, alertOnRecovery: e.target.checked })}
          />
          Alert when servers recover
        </label>
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={alerts.skipAlertsInMaintenance}
            onChange={(e) =>
              setAlerts({ ...alerts, skipAlertsInMaintenance: e.target.checked })
            }
          />
          Suppress alerts for servers in maintenance
        </label>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-medium">Notification channels</h3>
          <button
            type="button"
            className="btn btn-secondary py-1 px-2 text-sm"
            onClick={() =>
              setAlerts({ ...alerts, channels: [...alerts.channels, emptyChannel()] })
            }
          >
            <Plus className="w-4 h-4" />
            Add channel
          </button>
        </div>

        {alerts.channels.length === 0 ? (
          <p className="text-sm" style={{ color: "var(--muted)" }}>
            No channels configured. Add a webhook, ntfy, or Gotify channel.
          </p>
        ) : (
          alerts.channels.map((channel, index) => (
            <div
              key={channel.id}
              className="p-4 rounded-lg border space-y-3"
              style={{ borderColor: "var(--card-border)" }}
            >
              <div className="flex flex-wrap gap-3 items-center justify-between">
                <select
                  className="input w-auto"
                  value={channel.type}
                  onChange={(e) =>
                    updateChannel(index, { type: e.target.value as AlertChannelType })
                  }
                >
                  <option value="webhook">Webhook</option>
                  <option value="ntfy">ntfy</option>
                  <option value="gotify">Gotify</option>
                </select>
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={channel.enabled}
                    onChange={(e) => updateChannel(index, { enabled: e.target.checked })}
                  />
                  Enabled
                </label>
                <button
                  type="button"
                  className="btn btn-secondary py-1 px-2"
                  onClick={() =>
                    setAlerts({
                      ...alerts,
                      channels: alerts.channels.filter((_, idx) => idx !== index),
                    })
                  }
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {channel.type === "webhook" && (
                <Field
                  label="Webhook URL"
                  value={channel.url ?? ""}
                  onChange={(value) => updateChannel(index, { url: value })}
                  placeholder="https://hooks.example.com/..."
                />
              )}

              {channel.type === "ntfy" && (
                <div className="grid sm:grid-cols-2 gap-3">
                  <Field
                    label="Server URL"
                    value={channel.url ?? "https://ntfy.sh"}
                    onChange={(value) => updateChannel(index, { url: value })}
                  />
                  <Field
                    label="Topic"
                    value={channel.topic ?? ""}
                    onChange={(value) => updateChannel(index, { topic: value })}
                  />
                  <Field
                    label="Access token (optional)"
                    type="password"
                    value={channel.token ?? ""}
                    onChange={(value) => updateChannel(index, { token: value })}
                  />
                </div>
              )}

              {channel.type === "gotify" && (
                <div className="grid sm:grid-cols-2 gap-3">
                  <Field
                    label="Gotify server URL"
                    value={channel.url ?? ""}
                    onChange={(value) => updateChannel(index, { url: value })}
                    placeholder="https://gotify.example.com"
                  />
                  <Field
                    label="App token"
                    type="password"
                    value={channel.token ?? ""}
                    onChange={(value) => updateChannel(index, { token: value })}
                  />
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {error && <p style={{ color: "var(--danger)" }}>{error}</p>}
      {testResult && <p style={{ color: "var(--success)" }}>{testResult}</p>}

      <div className="flex flex-wrap gap-2 items-center">
        <button type="submit" className="btn btn-primary">
          Save alert settings
        </button>
        <button
          type="button"
          className="btn btn-secondary"
          onClick={testAlert}
          disabled={testing}
        >
          {testing ? "Sending..." : "Send test alert"}
        </button>
        {saved && (
          <span className="text-sm" style={{ color: "var(--success)" }}>
            Saved
          </span>
        )}
      </div>
    </form>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  min,
  max,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  placeholder?: string;
  min?: number;
  max?: number;
}) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1">{label}</label>
      <input
        className="input"
        type={type}
        value={value}
        min={min}
        max={max}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}
