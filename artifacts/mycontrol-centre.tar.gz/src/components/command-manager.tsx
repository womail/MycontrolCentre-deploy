"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Play, Save, Trash2, Wrench, Eye } from "lucide-react";
import { extractTemplateVariables } from "@/lib/commands/variables";
import { commandTypeUsesShellText, SUGGESTED_COMMAND_TYPES } from "@/lib/commands/command-types";
import { requiresChangeReason } from "@/lib/commands/change-reason";
import { CategorizedCommandList } from "@/components/categorized-command-list";
import { GuestPicker } from "@/components/guest-picker";
import { filterTemplatesForServers } from "@/lib/commands/platform-filter";
import { PLATFORM_LABELS, COMMAND_CATEGORIES, SERVER_PLATFORMS, type ServerPlatform } from "@/lib/servers/platforms";
import { ServerGroupPicker } from "@/components/server-group-picker";
import type { ServerGroupSummary } from "@/components/server-groups-panel";
import { CollapsibleListHeader } from "@/components/collapsible-list-header";
import { SlideOver } from "@/components/slide-over";

export interface CommandTemplate {
  id: string;
  name: string;
  type: string;
  description: string;
  commandText: string | null;
  defaultWorkingDir: string | null;
  defaultListPath: string | null;
  sortOrder: number;
  adminOnly: boolean;
  isBuiltIn: boolean;
  isActive: boolean;
  category?: string;
  platforms?: string[];
}

export interface ServerOption {
  id: string;
  name: string;
  hostname: string;
  healthStatus: string;
  inMaintenance?: boolean;
  maintenanceNote?: string | null;
  platforms?: ServerPlatform[];
}

interface TestResult {
  ok: boolean;
  label?: string;
  commandText?: string;
  exitCode?: number;
  stdout?: string;
  stderr?: string;
  error?: string;
  durationMs?: number;
}

const COMMAND_TYPE_HINTS: Record<string, string> = {
  CD: "Change directory — uses working directory path at run time",
  LS: "List directory — uses list path at run time",
  APT_UPDATE: "Runs apt-get update (Debian/Proxmox)",
  APT_UPGRADE: "Runs apt-get upgrade (Debian/Proxmox)",
  CUSTOM: "Arbitrary shell command — requires command text",
};

const PLATFORM_PICKER_OPTIONS = ["all", ...SERVER_PLATFORMS] as const;

const emptyDraft = (): CommandTemplate => ({
  id: "",
  name: "",
  type: "CUSTOM",
  description: "",
  commandText: "",
  defaultWorkingDir: "",
  defaultListPath: "",
  sortOrder: 100,
  adminOnly: true,
  isBuiltIn: false,
  isActive: true,
  category: "general",
  platforms: ["all"],
});

export function CommandTemplateManager({
  templates,
  servers,
  onChanged,
}: {
  templates: CommandTemplate[];
  servers: ServerOption[];
  onChanged: () => void;
}) {
  const [draft, setDraft] = useState<CommandTemplate>(emptyDraft());
  const [editingId, setEditingId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testServerId, setTestServerId] = useState("");
  const [testWorkingDir, setTestWorkingDir] = useState("");
  const [testListPath, setTestListPath] = useState("");
  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [editorOpen, setEditorOpen] = useState(false);

  useEffect(() => {
    if (!testServerId && servers[0]) setTestServerId(servers[0].id);
  }, [servers, testServerId]);

  function startCreate() {
    setEditingId(null);
    setDraft(emptyDraft());
    setError("");
    setTestResult(null);
    setEditorOpen(true);
  }

  function startEdit(template: CommandTemplate) {
    setEditingId(template.id);
    setDraft({ ...template });
    setError("");
    setTestResult(null);
    setEditorOpen(true);
  }

  async function saveTemplate(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");

    const payload = {
      name: draft.name,
      type: draft.type,
      description: draft.description,
      commandText: draft.commandText || undefined,
      defaultWorkingDir: draft.defaultWorkingDir || undefined,
      defaultListPath: draft.defaultListPath || undefined,
      sortOrder: draft.sortOrder,
      adminOnly: draft.adminOnly,
      isActive: draft.isActive,
      category: draft.category?.trim() || "general",
      platforms: draft.platforms?.length ? draft.platforms : ["all"],
    };

    const res = await fetch(
      editingId ? `/api/commands/templates/${editingId}` : "/api/commands/templates",
      {
        method: editingId ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      },
    );
    const data = await res.json();
    setSaving(false);

    if (!res.ok) {
      setError(data.error ?? "Failed to save command");
      return;
    }

    if (editingId) {
      setDraft({ ...data.template });
      setEditingId(data.template.id);
    } else {
      startEdit(data.template);
    }
    onChanged();
  }

  async function deleteTemplate(id: string) {
    if (!confirm("Delete this command template?")) return;
    const res = await fetch(`/api/commands/templates/${id}`, { method: "DELETE" });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Failed to delete");
      return;
    }
    if (editingId === id) startCreate();
    onChanged();
  }

  async function testTemplate() {
    if (!testServerId) {
      setError("Select a server to test against");
      return;
    }
    setTesting(true);
    setError("");
    setTestResult(null);

    const res = await fetch("/api/commands/test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        serverId: testServerId,
        draft: {
          name: draft.name || "Draft command",
          type: draft.type,
          description: draft.description || "Draft",
          commandText: draft.commandText || undefined,
          defaultWorkingDir: draft.defaultWorkingDir || undefined,
          defaultListPath: draft.defaultListPath || undefined,
          adminOnly: draft.adminOnly,
        },
        workingDir: testWorkingDir || draft.defaultWorkingDir || undefined,
        listPath: testListPath || draft.defaultListPath || undefined,
        customCommand: draft.commandText || undefined,
      }),
    });
    const data = await res.json();
    setTesting(false);
    if (!res.ok) {
      setError(data.error ?? "Test failed");
      return;
    }
    setTestResult(data);
  }

  const sortedTemplates = useMemo(
    () => [...templates].sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name)),
    [templates],
  );

  return (
    <div className="space-y-4">
      <div className="card p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h2 className="font-semibold">Command library</h2>
            <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
              Built-in and custom templates. Click Edit to change type, text, and options in a side panel.
            </p>
          </div>
          <button type="button" className="btn btn-secondary text-sm" onClick={startCreate}>
            New command
          </button>
        </div>
        <div className="max-h-[32rem] overflow-y-auto border rounded-lg" style={{ borderColor: "var(--card-border)" }}>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Type</th>
                <th>Status</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {sortedTemplates.map((template) => (
                <tr key={template.id}>
                  <td>
                    <div className="font-medium">{template.name}</div>
                    <div className="text-xs" style={{ color: "var(--muted)" }}>
                      {template.description}
                    </div>
                  </td>
                  <td className="text-xs font-mono">{template.type}</td>
                  <td>
                    <span className={`badge ${template.isActive ? "badge-success" : "badge-muted"}`}>
                      {template.isActive ? "Active" : "Inactive"}
                    </span>
                  </td>
                  <td className="text-right">
                    <button
                      type="button"
                      className="btn btn-secondary py-1 px-2 text-xs"
                      onClick={() => startEdit(template)}
                    >
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <SlideOver
        open={editorOpen}
        title={editingId ? "Edit command" : "Create command"}
        description="Command type controls how the template is built and what fields are required at run time."
        onClose={() => setEditorOpen(false)}
        width="max-w-xl"
      >
        <form onSubmit={saveTemplate} className="space-y-4">
        <h2 className="font-semibold flex items-center gap-2 sr-only">
          <Wrench className="w-4 h-4" />
          {editingId ? "Edit command" : "Create command"}
        </h2>

        <div className="grid sm:grid-cols-2 gap-4">
          <FormField label="Name" value={draft.name} onChange={(v) => setDraft({ ...draft, name: v })} required />
          <div>
            <label className="block text-sm font-medium mb-1">Type</label>
            <input
              list="mcc-command-types"
              className="input font-mono text-sm"
              value={draft.type}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  type: e.target.value.trim() || "CUSTOM",
                })
              }
              placeholder="CUSTOM or your own type name"
              required
            />
            <datalist id="mcc-command-types">
              {SUGGESTED_COMMAND_TYPES.map((type) => (
                <option key={type} value={type} />
              ))}
            </datalist>
            <p className="text-xs mt-1" style={{ color: "var(--muted)" }}>
              {COMMAND_TYPE_HINTS[draft.type] ??
                (commandTypeUsesShellText(draft.type)
                  ? "Custom type — runs command text below on the host (shown in run history as this type)."
                  : "Built-in runner — command text is optional.")}
              {draft.isBuiltIn && (
                <>
                  {" "}
                  Built-in template — name stays fixed for seeded commands.
                </>
              )}
            </p>
          </div>
        </div>

        <FormField
          label="Description"
          value={draft.description}
          onChange={(v) => setDraft({ ...draft, description: v })}
          required
        />

        {commandTypeUsesShellText(draft.type) && (
          <div>
            <label className="block text-sm font-medium mb-1">Command text</label>
            <input
              className="input font-mono text-sm"
              value={draft.commandText ?? ""}
              onChange={(e) => setDraft({ ...draft, commandText: e.target.value })}
              placeholder="sudo systemctl status ssh"
              required
            />
          </div>
        )}

        <div className="grid sm:grid-cols-2 gap-4">
          <FormField
            label="Default working directory"
            value={draft.defaultWorkingDir ?? ""}
            onChange={(v) => setDraft({ ...draft, defaultWorkingDir: v })}
            placeholder="/opt"
          />
          <FormField
            label="Default list path"
            value={draft.defaultListPath ?? ""}
            onChange={(v) => setDraft({ ...draft, defaultListPath: v })}
            placeholder="/var/log"
          />
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Category (Run tab grouping)</label>
            <input
              list="mcc-command-categories"
              className="input text-sm"
              value={draft.category ?? "general"}
              onChange={(e) => setDraft({ ...draft, category: e.target.value.trim() || "general" })}
            />
            <datalist id="mcc-command-categories">
              {COMMAND_CATEGORIES.map((category) => (
                <option key={category} value={category} />
              ))}
            </datalist>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Platforms</label>
            <p className="text-xs mb-2" style={{ color: "var(--muted)" }}>
              Command appears when every selected server matches one of these (use <strong>all</strong> for any host).
            </p>
            <div className="flex flex-wrap gap-2">
              {PLATFORM_PICKER_OPTIONS.map((platform) => {
                const selected = (draft.platforms ?? ["all"]).includes(platform);
                return (
                  <label key={platform} className="flex items-center gap-1.5 text-xs border rounded px-2 py-1">
                    <input
                      type="checkbox"
                      checked={selected}
                      onChange={() => {
                        setDraft((prev) => {
                          let next = prev.platforms ?? ["all"];
                          if (platform === "all") {
                            return { ...prev, platforms: ["all"] };
                          }
                          next = next.filter((p) => p !== "all");
                          if (next.includes(platform)) {
                            next = next.filter((p) => p !== platform);
                          } else {
                            next = [...next, platform];
                          }
                          if (next.length === 0) next = ["all"];
                          return { ...prev, platforms: next };
                        });
                      }}
                    />
                    {platform === "all" ? "All platforms" : PLATFORM_LABELS[platform as ServerPlatform] ?? platform}
                  </label>
                );
              })}
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-3 gap-4">
          <FormField
            label="Sort order"
            type="number"
            value={String(draft.sortOrder)}
            onChange={(v) => setDraft({ ...draft, sortOrder: parseInt(v, 10) || 0 })}
          />
          <label className="flex items-center gap-2 text-sm mt-6">
            <input
              type="checkbox"
              checked={draft.adminOnly}
              onChange={(e) => setDraft({ ...draft, adminOnly: e.target.checked })}
            />
            Admin only
          </label>
          <label className="flex items-center gap-2 text-sm mt-6">
            <input
              type="checkbox"
              checked={draft.isActive}
              onChange={(e) => setDraft({ ...draft, isActive: e.target.checked })}
            />
            Active
          </label>
        </div>

        <div className="p-4 rounded-lg space-y-3" style={{ border: "1px solid var(--card-border)" }}>
          <p className="text-sm font-medium">Test in editor</p>
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium mb-1">Test server</label>
              <select
                className="input"
                value={testServerId}
                onChange={(e) => setTestServerId(e.target.value)}
              >
                {servers.map((server) => (
                  <option key={server.id} value={server.id}>
                    {server.name} ({server.hostname})
                  </option>
                ))}
              </select>
            </div>
            <FormField
              label="Override working dir"
              value={testWorkingDir}
              onChange={setTestWorkingDir}
              placeholder="Optional"
            />
            <FormField
              label="Override list path"
              value={testListPath}
              onChange={setTestListPath}
              placeholder="Optional"
            />
          </div>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={testTemplate}
            disabled={testing || !draft.description}
          >
            {testing ? "Testing..." : "Test command"}
          </button>
          {testResult && (
            <div className="space-y-2 text-sm">
              <div style={{ color: testResult.ok ? "var(--success)" : "var(--danger)" }}>
                {testResult.ok ? "Test succeeded" : "Test failed"} · exit {testResult.exitCode ?? "—"}
              </div>
              {testResult.commandText && (
                <code className="text-xs block break-all">{testResult.commandText}</code>
              )}
              {testResult.stdout && <pre className="output">{testResult.stdout}</pre>}
              {(testResult.stderr || testResult.error) && (
                <pre className="output">{testResult.stderr || testResult.error}</pre>
              )}
            </div>
          )}
        </div>

        {error && <p style={{ color: "var(--danger)" }}>{error}</p>}

        <div className="flex flex-wrap gap-2">
          <button type="submit" className="btn btn-primary" disabled={saving}>
            <Save className="w-4 h-4" />
            {saving ? "Saving..." : "Save command"}
          </button>
          {editingId && !draft.isBuiltIn && (
            <button
              type="button"
              className="btn btn-danger"
              onClick={() => deleteTemplate(editingId)}
            >
              <Trash2 className="w-4 h-4" />
              Delete
            </button>
          )}
        </div>
        </form>
      </SlideOver>
    </div>
  );
}

function FormField({
  label,
  value,
  onChange,
  required,
  type = "text",
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
  type?: string;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1">{label}</label>
      <input
        className="input"
        type={type}
        value={value}
        required={required}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}

export function SelectableList({
  title,
  items,
  selectedIds,
  onToggle,
  onSelectAll,
  renderLabel,
  renderMeta,
  defaultExpanded = false,
  expandSignal = 0,
  expanded: controlledExpanded,
  onExpandedChange,
}: {
  title: string;
  items: { id: string }[];
  selectedIds: string[];
  onToggle: (id: string) => void;
  onSelectAll: () => void;
  renderLabel: (item: { id: string }) => string;
  renderMeta?: (item: { id: string }) => string | undefined;
  defaultExpanded?: boolean;
  expandSignal?: number;
  expanded?: boolean;
  onExpandedChange?: (expanded: boolean) => void;
}) {
  const [internalExpanded, setInternalExpanded] = useState(
    defaultExpanded || selectedIds.length > 0,
  );
  const expanded = controlledExpanded ?? internalExpanded;
  const setExpanded = (value: boolean) => {
    onExpandedChange?.(value);
    if (controlledExpanded === undefined) setInternalExpanded(value);
  };

  useEffect(() => {
    if (expandSignal > 0) setExpanded(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expandSignal]);

  useEffect(() => {
    if (selectedIds.length > 0 && expandSignal > 0) setExpanded(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedIds.length, expandSignal]);

  const allSelected = items.length > 0 && selectedIds.length === items.length;
  const selectedCount = selectedIds.length;

  return (
    <div>
      <CollapsibleListHeader
        title={title}
        count={items.length}
        selectedCount={selectedCount}
        expanded={expanded}
        onToggle={() => setExpanded(!expanded)}
        selectAllLabel={allSelected ? "Clear all" : "Select all"}
        onSelectAll={items.length > 1 ? onSelectAll : undefined}
      />
      {expanded && (
        <div
          className="max-h-56 overflow-y-auto rounded-lg border divide-y"
          style={{ borderColor: "var(--card-border)" }}
        >
          {items.length === 0 ? (
            <p className="p-3 text-sm" style={{ color: "var(--muted)" }}>
              Nothing available.
            </p>
          ) : (
            items.map((item) => {
              const checked = selectedIds.includes(item.id);
              const order = selectedIds.indexOf(item.id);
              return (
                <label
                  key={item.id}
                  className="flex items-start gap-3 p-3 cursor-pointer hover:bg-black/5 dark:hover:bg-white/5"
                >
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => onToggle(item.id)}
                    className="mt-1"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="font-medium text-sm">{renderLabel(item)}</div>
                    {renderMeta?.(item) && (
                      <div className="text-xs" style={{ color: "var(--muted)" }}>
                        {renderMeta(item)}
                      </div>
                    )}
                  </div>
                  {checked && order >= 0 && (
                    <span className="badge badge-muted shrink-0">#{order + 1}</span>
                  )}
                </label>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}

export function CommandRunPanel({
  templates,
  servers,
  serverGroups = [],
  canRun,
  isAdmin,
  onRan,
  initialServerIds,
  initialTemplateIds,
}: {
  templates: CommandTemplate[];
  servers: ServerOption[];
  serverGroups?: ServerGroupSummary[];
  canRun: boolean;
  isAdmin?: boolean;
  onRan: (result?: { runs?: Array<{ id: string }> }) => void;
  initialServerIds?: string[];
  initialTemplateIds?: string[];
}) {
  const [selectedServers, setSelectedServers] = useState<string[]>([]);
  const [selectedCommands, setSelectedCommands] = useState<string[]>([]);
  const [workingDir, setWorkingDir] = useState("");
  const [listPath, setListPath] = useState("");
  const [customCommand, setCustomCommand] = useState("");
  const [failureCommands, setFailureCommands] = useState<string[]>([]);
  const [variables, setVariables] = useState<Record<string, string>>({});
  const [forceMaintenance, setForceMaintenance] = useState(false);
  const [forceStaleBackup, setForceStaleBackup] = useState(false);
  const [preview, setPreview] = useState<{
    label: string;
    commandText: string;
    previews: Array<{
      serverName: string;
      hostname: string;
      blocked: boolean;
      blockReason?: string;
      backupWarning?: string;
      backupBlocked?: boolean;
      commandText: string;
    }>;
    blockedServers: Array<{ serverName: string; blockReason?: string; backupWarning?: string }>;
  } | null>(null);
  const [running, setRunning] = useState(false);
  const [previewing, setPreviewing] = useState(false);
  const [changeReason, setChangeReason] = useState("");
  const [error, setError] = useState("");
  const appliedRunPresetKey = useRef<string | null>(null);
  const [listExpandSignal, setListExpandSignal] = useState(0);
  const [runPicker, setRunPicker] = useState<"servers" | "commands" | "failure" | null>(null);

  useEffect(() => {
    if (!initialServerIds?.length && !initialTemplateIds?.length) return;
    const key = `${initialServerIds?.join(",") ?? ""}:${initialTemplateIds?.join(",") ?? ""}`;
    if (appliedRunPresetKey.current === key) return;

    const validServers = (initialServerIds ?? []).filter((id) => servers.some((s) => s.id === id));
    const validTemplates = (initialTemplateIds ?? []).filter((id) =>
      templates.some((t) => t.id === id),
    );
    if (!validServers.length || !validTemplates.length) return;

    appliedRunPresetKey.current = key;
    setSelectedServers(validServers);
    setSelectedCommands(validTemplates);
    setRunPicker("commands");
    setListExpandSignal((n) => n + 1);
    setPreview(null);
    setError("");
    requestAnimationFrame(() => {
      document.getElementById("command-run-panel")?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }, [initialServerIds, initialTemplateIds, servers, templates]);

  const needsChangeReason = requiresChangeReason(
    selectedServers.length,
    selectedCommands.length,
  );

  const activeTemplates = useMemo(
    () =>
      [...templates]
        .filter((template) => template.isActive)
        .sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name)),
    [templates],
  );

  const selectedServerRecords = useMemo(
    () => servers.filter((server) => selectedServers.includes(server.id)),
    [servers, selectedServers],
  );

  const visibleTemplates = useMemo(
    () => filterTemplatesForServers(activeTemplates, selectedServerRecords),
    [activeTemplates, selectedServerRecords],
  );

  const guestPickerServerId =
    selectedServers.length === 1 &&
    selectedServerRecords[0]?.platforms?.includes("proxmox")
      ? selectedServers[0]
      : null;

  const selectedTemplateRecords = selectedCommands
    .map((id) => activeTemplates.find((template) => template.id === id))
    .filter(Boolean) as CommandTemplate[];

  const needsWorkingDir = selectedTemplateRecords.some((template) => template.type === "CD");
  const needsListPath = selectedTemplateRecords.some(
    (template) => template.type === "LS" && !template.defaultListPath,
  );
  const needsCustom = selectedTemplateRecords.some(
    (template) => commandTypeUsesShellText(template.type) && !template.commandText,
  );

  const requiredVariables = useMemo(() => {
    const keys = new Set<string>();
    for (const template of selectedTemplateRecords) {
      for (const key of extractTemplateVariables(template.commandText)) keys.add(key);
      for (const key of extractTemplateVariables(template.defaultWorkingDir)) keys.add(key);
      for (const key of extractTemplateVariables(template.defaultListPath)) keys.add(key);
    }
    return [...keys];
  }, [selectedTemplateRecords]);

  function toggleSelected(list: string[], id: string): string[] {
    return list.includes(id) ? list.filter((item) => item !== id) : [...list, id];
  }

  async function dryRun() {
    if (selectedServers.length === 0 || selectedCommands.length === 0) {
      setError("Select servers and commands to preview");
      return;
    }
    setPreviewing(true);
    setError("");
    const res = await fetch("/api/commands/preview", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        serverIds: selectedServers,
        templateIds: selectedCommands,
        workingDir: workingDir || undefined,
        listPath: listPath || undefined,
        customCommand: customCommand || undefined,
        failureTemplateIds: failureCommands.length ? failureCommands : undefined,
        variables: Object.keys(variables).length ? variables : undefined,
        forceMaintenance: isAdmin && forceMaintenance ? true : undefined,
        forceStaleBackup: isAdmin && forceStaleBackup ? true : undefined,
      }),
    });
    const data = await res.json();
    setPreviewing(false);
    if (!res.ok) {
      setError(data.error ?? "Preview failed");
      return;
    }
    setPreview(data);
  }

  async function execute() {
    if (selectedServers.length === 0) {
      setError("Select at least one server");
      return;
    }
    if (selectedCommands.length === 0) {
      setError("Select at least one command");
      return;
    }
    setError("");
    setRunning(true);

    const res = await fetch("/api/commands", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        serverIds: selectedServers,
        templateIds: selectedCommands,
        workingDir: workingDir || undefined,
        listPath: listPath || undefined,
        customCommand: customCommand || undefined,
        failureTemplateIds: failureCommands.length ? failureCommands : undefined,
        variables: Object.keys(variables).length ? variables : undefined,
        forceMaintenance: isAdmin && forceMaintenance ? true : undefined,
        forceStaleBackup: isAdmin && forceStaleBackup ? true : undefined,
        changeReason: needsChangeReason ? changeReason.trim() : undefined,
      }),
    });
    const data = await res.json();
    setRunning(false);

    if (!res.ok) {
      setError(data.error ?? "Failed to queue commands");
      return;
    }
    onRan({ runs: data.runs });
  }

  if (!canRun) {
    return (
      <div className="card p-6">
        You have read-only access. Command execution requires operator or admin role.
      </div>
    );
  }

  return (
    <div id="command-run-panel" className="card p-6 space-y-5">
      <div>
        <h2 className="font-semibold text-lg">Execute commands</h2>
        <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
          Choose hosts, then the command sequence to run on each host. Optional remediation runs only on
          hosts where a primary command fails.
        </p>
      </div>

      <ServerGroupPicker
        groups={serverGroups}
        onApply={(ids, mode) =>
          setSelectedServers((prev) =>
            mode === "replace" ? ids : [...new Set([...prev, ...ids])],
          )
        }
      />

      <div className="grid md:grid-cols-3 gap-4">
        <RunSelectionCard
          step={1}
          title="Target servers"
          count={selectedServers.length}
          total={servers.length}
          summary={
            selectedServers.length === 0
              ? "No servers selected"
              : selectedServerRecords
                  .slice(0, 3)
                  .map((s) => s.name)
                  .join(", ") + (selectedServers.length > 3 ? "…" : "")
          }
          hint="Commands run on every selected host (in parallel batches)."
          onOpen={() => {
            setListExpandSignal((n) => n + 1);
            setRunPicker("servers");
          }}
        />
        <RunSelectionCard
          step={2}
          title="Command sequence"
          count={selectedCommands.length}
          total={visibleTemplates.length}
          summary={
            selectedTemplateRecords.length === 0
              ? "No commands selected"
              : selectedTemplateRecords.map((t) => t.name).join(" → ")
          }
          hint="Runs in this order on each server before moving to the next host."
          onOpen={() => {
            setListExpandSignal((n) => n + 1);
            setRunPicker("commands");
          }}
        />
        <RunSelectionCard
          step={3}
          title="On failure (optional)"
          count={failureCommands.length}
          total={visibleTemplates.length}
          summary={
            failureCommands.length === 0
              ? "None — failures stop the sequence on that host"
              : failureCommands
                  .map((id) => activeTemplates.find((t) => t.id === id)?.name ?? id)
                  .join(" → ")
          }
          hint="Extra commands on a host only if a primary step fails (e.g. dpkg configure)."
          onOpen={() => {
            setListExpandSignal((n) => n + 1);
            setRunPicker("failure");
          }}
          optional
        />
      </div>

      <SlideOver
        open={runPicker === "servers"}
        title="Target servers"
        description="Select one or more hosts. Maintenance and health status are shown for each row."
        onClose={() => setRunPicker(null)}
        width="max-w-md"
      >
        <SelectableList
          title="Servers"
          items={servers}
          selectedIds={selectedServers}
          defaultExpanded
          expandSignal={listExpandSignal}
          onToggle={(id) => setSelectedServers((prev) => toggleSelected(prev, id))}
          onSelectAll={() =>
            setSelectedServers(
              selectedServers.length === servers.length ? [] : servers.map((server) => server.id),
            )
          }
          renderLabel={(item) => servers.find((server) => server.id === item.id)?.name ?? item.id}
          renderMeta={(item) => {
            const server = servers.find((entry) => entry.id === item.id);
            if (!server) return undefined;
            const maintenance = server.inMaintenance ? " · MAINTENANCE" : "";
            const platformLabel = server.platforms?.length
              ? ` · ${server.platforms.map((p) => PLATFORM_LABELS[p] ?? p).join(", ")}`
              : "";
            return `${server.hostname} · ${server.healthStatus}${platformLabel}${maintenance}`;
          }}
        />
        <div className="mt-4 flex justify-end">
          <button type="button" className="btn btn-primary" onClick={() => setRunPicker(null)}>
            Done
          </button>
        </div>
      </SlideOver>

      <SlideOver
        open={runPicker === "commands"}
        title="Command sequence"
        description={
          selectedServers.length === 0
            ? "Select servers first — the list is filtered by platform (Proxmox, Debian, Docker, etc.)."
            : `Showing commands compatible with ${selectedServerRecords.length} selected host(s). Order matters.`
        }
        onClose={() => setRunPicker(null)}
        width="max-w-lg"
      >
        <CategorizedCommandList
          title="Primary commands"
          templates={visibleTemplates}
          selectedIds={selectedCommands}
          expandSignal={listExpandSignal}
          onToggle={(id) => setSelectedCommands((prev) => toggleSelected(prev, id))}
          onSelectAll={() =>
            setSelectedCommands(
              selectedCommands.length === visibleTemplates.length
                ? []
                : visibleTemplates.map((template) => template.id),
            )
          }
          emptyMessage={
            selectedServers.length === 0
              ? "Select servers to see compatible commands."
              : "No commands match the selected server platforms."
          }
        />
        <div className="mt-4 flex justify-end">
          <button type="button" className="btn btn-primary" onClick={() => setRunPicker(null)}>
            Done
          </button>
        </div>
      </SlideOver>

      <SlideOver
        open={runPicker === "failure"}
        title="On failure — remediation"
        description="If a primary command exits non-zero on a host, these commands run on that host (in order) before the run is marked failed. Leave empty to stop immediately on error."
        onClose={() => setRunPicker(null)}
        width="max-w-lg"
      >
        <div
          className="rounded-lg p-3 text-sm mb-4"
          style={{ background: "var(--muted-bg, rgba(127,127,127,0.08))", color: "var(--muted)" }}
        >
          Example: after a failed <strong>APT Upgrade</strong>, run <strong>DPKG Configure</strong> to
          repair interrupted package setup.
        </div>
        <CategorizedCommandList
          title="Remediation commands"
          templates={visibleTemplates}
          selectedIds={failureCommands}
          expandSignal={listExpandSignal}
          onToggle={(id) => setFailureCommands((prev) => toggleSelected(prev, id))}
          onSelectAll={() => setFailureCommands([])}
          emptyMessage="No remediation commands for selected platforms."
        />
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" className="btn btn-secondary" onClick={() => setFailureCommands([])}>
            Clear remediation
          </button>
          <button type="button" className="btn btn-primary" onClick={() => setRunPicker(null)}>
            Done
          </button>
        </div>
      </SlideOver>

      {selectedServers.length > 0 && visibleTemplates.length < activeTemplates.length && (
        <p className="text-sm" style={{ color: "var(--muted)" }}>
          Showing {visibleTemplates.length} of {activeTemplates.length} commands compatible with selected server platforms.
        </p>
      )}

      {selectedTemplateRecords.length > 0 && (
        <p className="text-sm">
          <strong>Run order:</strong>{" "}
          {selectedTemplateRecords.map((template) => template.name).join(" → ")}
        </p>
      )}

      <div className="grid md:grid-cols-3 gap-4">
        {needsWorkingDir && (
          <RunField label="Directory path" value={workingDir} onChange={setWorkingDir} placeholder="/var/log" />
        )}
        {needsListPath && (
          <RunField label="Path to list" value={listPath} onChange={setListPath} placeholder="/var/log" />
        )}
        {needsCustom && (
          <div className="md:col-span-2">
            <RunField
              label="Custom command override"
              value={customCommand}
              onChange={setCustomCommand}
              placeholder="Command text for selected custom template"
            />
          </div>
        )}
      </div>

      {requiredVariables.length > 0 && (
        <div className="grid md:grid-cols-3 gap-4">
          {requiredVariables.map((key) =>
            key === "vmid" && guestPickerServerId ? (
              <GuestPicker
                key={key}
                serverId={guestPickerServerId}
                value={variables[key] ?? ""}
                onChange={(value) => setVariables((prev) => ({ ...prev, [key]: value }))}
              />
            ) : (
              <RunField
                key={key}
                label={`Variable {{${key}}}`}
                value={variables[key] ?? ""}
                onChange={(value) => setVariables((prev) => ({ ...prev, [key]: value }))}
                placeholder={`Value for ${key}`}
              />
            ),
          )}
        </div>
      )}

      {isAdmin && servers.some((server) => server.inMaintenance) && (
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={forceMaintenance}
            onChange={(e) => setForceMaintenance(e.target.checked)}
          />
          Override maintenance windows (admin only)
        </label>
      )}

      {isAdmin && (
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={forceStaleBackup}
            onChange={(e) => setForceStaleBackup(e.target.checked)}
          />
          Override stale backup guard (admin only)
        </label>
      )}

      {needsChangeReason && (
        <div>
          <label className="block text-sm font-medium mb-1">
            Change reason <span style={{ color: "var(--danger)" }}>*</span>
          </label>
          <input
            className="input"
            value={changeReason}
            onChange={(e) => setChangeReason(e.target.value)}
            placeholder="e.g. Weekly patch window — INC-1234"
            maxLength={500}
          />
          <p className="text-xs mt-1" style={{ color: "var(--muted)" }}>
            Required for multi-server or multi-command runs. Stored in audit and run history.
          </p>
        </div>
      )}

      {preview && (
        <div
          className="rounded-lg border p-4 space-y-3 text-sm"
          style={{ borderColor: "var(--card-border)" }}
        >
          <div>
            <strong>Dry-run preview:</strong> {preview.label}
          </div>
          <pre className="output text-xs">{preview.commandText}</pre>
          {preview.blockedServers.length > 0 && (
            <p style={{ color: "var(--warning)" }}>
              Blocked:{" "}
              {preview.blockedServers
                .map((server) =>
                  server.backupWarning
                    ? `${server.serverName} (backup: ${server.backupWarning})`
                    : `${server.serverName}${server.blockReason ? ` (${server.blockReason})` : ""}`,
                )
                .join(", ")}
            </p>
          )}
          <div className="table-wrap border rounded-lg" style={{ borderColor: "var(--card-border)" }}>
            <table>
              <thead>
                <tr>
                  <th>Server</th>
                  <th>Status</th>
                  <th>Command</th>
                </tr>
              </thead>
              <tbody>
                {preview.previews.map((row) => (
                  <tr key={row.serverName}>
                    <td>{row.serverName}</td>
                    <td>
                      {row.blocked
                        ? `Blocked — ${row.blockReason ?? "maintenance"}`
                        : row.backupWarning
                          ? `Warning — ${row.backupWarning}`
                          : "Will run"}
                    </td>
                    <td className="font-mono text-xs">{row.commandText}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {error && <p style={{ color: "var(--danger)" }}>{error}</p>}

      <div className="flex flex-wrap gap-2">
        <button type="button" className="btn btn-secondary" onClick={dryRun} disabled={previewing}>
          <Eye className="w-4 h-4" />
          {previewing ? "Previewing..." : "Preview before run"}
        </button>
        <button type="button" className="btn btn-primary" onClick={execute} disabled={running}>
          <Play className="w-4 h-4" />
          {running ? "Queuing..." : "Run selected commands"}
        </button>
      </div>
    </div>
  );
}

function RunSelectionCard({
  step,
  title,
  count,
  total,
  summary,
  hint,
  onOpen,
  optional,
}: {
  step: number;
  title: string;
  count: number;
  total: number;
  summary: string;
  hint: string;
  onOpen: () => void;
  optional?: boolean;
}) {
  return (
    <div
      className="rounded-lg border p-4 flex flex-col gap-3 min-h-[9rem]"
      style={{ borderColor: "var(--card-border)" }}
    >
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="text-xs font-medium uppercase tracking-wide" style={{ color: "var(--muted)" }}>
            Step {step}
            {optional ? " · Optional" : ""}
          </p>
          <h3 className="font-semibold">{title}</h3>
        </div>
        <span className={`badge ${count > 0 ? "badge-success" : "badge-muted"}`}>
          {count}/{total}
        </span>
      </div>
      <p className="text-sm line-clamp-2 flex-1" title={summary}>
        {summary}
      </p>
      <p className="text-xs" style={{ color: "var(--muted)" }}>
        {hint}
      </p>
      <button type="button" className="btn btn-secondary text-sm w-full" onClick={onOpen}>
        {count > 0 ? "Change selection" : "Choose…"}
      </button>
    </div>
  );
}

function RunField({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1">{label}</label>
      <input
        className="input"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
      />
    </div>
  );
}
