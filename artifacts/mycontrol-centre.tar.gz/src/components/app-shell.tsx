"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard,
  Server,
  Terminal,
  ScrollText,
  Users,
  Settings,
  LogOut,
  Moon,
  Sun,
  Shield,
  Layers,
  Database,
  Activity,
  KeyRound,
  ShieldCheck,
} from "lucide-react";
import { useTheme } from "./theme-provider";
import { cn } from "@/lib/utils";
import { useEnrollmentPending } from "./enrollment-pending-provider";

const mainNav = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/servers", label: "Servers", icon: Server, enrollmentBadge: true },
  { href: "/commands", label: "Commands", icon: Terminal },
  { href: "/cluster", label: "Cluster", icon: Layers },
  { href: "/logs", label: "Logs", icon: ScrollText },
];

const adminNav = [
  { href: "/settings", label: "Settings", icon: Settings },
  { href: "/admin/system", label: "System", icon: Activity },
  { href: "/admin/vault", label: "Vault", icon: KeyRound },
  { href: "/admin/database", label: "Database", icon: Database },
  { href: "/users", label: "Users", icon: Users },
];

export function AppShell({
  children,
  user,
}: {
  children: React.ReactNode;
  user: { username: string; role: string };
}) {
  const pathname = usePathname();
  const router = useRouter();
  const { theme, toggle } = useTheme();
  const { pendingCount } = useEnrollmentPending();
  const isAdmin = user.role === "ADMIN";
  const showEnrollmentBadge = isAdmin && pendingCount > 0;

  async function logout() {
    await fetch("/api/auth/login", { method: "DELETE" });
    router.push("/login");
    router.refresh();
  }

  function NavLink({
    href,
    label,
    icon: Icon,
    showBadge,
  }: {
    href: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    showBadge?: boolean;
  }) {
    const active = pathname.startsWith(href);
    const badge = showBadge ? pendingCount : 0;
    return (
      <Link
        href={href}
        className={cn(
          "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
          active
            ? "bg-white/10 text-white font-medium"
            : "opacity-80 hover:opacity-100 hover:bg-white/5",
        )}
      >
        <span className="relative shrink-0">
          <Icon className="w-4 h-4" />
          {badge > 0 && (
            <span
              className="absolute -top-2 -right-2 min-w-[1.1rem] h-[1.1rem] px-0.5 rounded-full text-[10px] font-bold flex items-center justify-center leading-none"
              style={{ background: "var(--warning)", color: "#1a1a1a" }}
              title={`${badge} pending enrollment request${badge === 1 ? "" : "s"}`}
            >
              {badge > 99 ? "99+" : badge}
            </span>
          )}
        </span>
        {label}
      </Link>
    );
  }

  return (
    <div className="min-h-screen flex w-full">
      <aside
        className="w-64 shrink-0 flex flex-col p-4 gap-6 min-h-screen"
        style={{ background: "var(--sidebar)", color: "var(--sidebar-text)" }}
      >
        <div className="flex items-center gap-2 px-2 pt-2">
          <Shield className="w-7 h-7" style={{ color: "var(--primary)" }} />
          <div>
            <div className="font-bold text-lg leading-tight">MyControl</div>
            <div className="text-xs opacity-70">Centre</div>
          </div>
        </div>

        <nav className="flex flex-col gap-1">
          {mainNav.map((item) => (
            <NavLink
              key={item.href}
              href={item.href}
              label={item.label}
              icon={item.icon}
              showBadge={Boolean(item.enrollmentBadge && showEnrollmentBadge)}
            />
          ))}

          {isAdmin && (
            <>
              <div className="px-3 pt-4 pb-1 text-[10px] uppercase tracking-wider opacity-50">
                Admin
              </div>
              {adminNav.map((item) => (
                <NavLink key={item.href} href={item.href} label={item.label} icon={item.icon} />
              ))}
            </>
          )}
        </nav>

        <div className="mt-auto space-y-2 pt-4 border-t border-white/10">
          <Link
            href="/account/security"
            className={cn(
              "flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
              pathname.startsWith("/account/security")
                ? "bg-white/10 font-medium"
                : "opacity-80 hover:opacity-100 hover:bg-white/5",
            )}
          >
            <ShieldCheck className="w-4 h-4" />
            Security
          </Link>
          <div className="px-3 text-sm">
            <div className="font-medium">{user.username}</div>
            <div className="text-xs opacity-60 capitalize">{user.role.toLowerCase()}</div>
          </div>
          <button
            onClick={toggle}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm hover:bg-white/5"
          >
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            {theme === "dark" ? "Light mode" : "Dark mode"}
          </button>
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm hover:bg-white/5 text-red-300"
          >
            <LogOut className="w-4 h-4" />
            Sign out
          </button>
        </div>
      </aside>

      <main className="flex-1 min-w-0 w-full p-4 md:p-6 lg:p-8 overflow-auto">{children}</main>
    </div>
  );
}
