"use client";

import { ArrowUpDown } from "lucide-react";
import type { SortDir } from "@/lib/logs/sort-logs";

export function SortableTh({
  label,
  active,
  dir,
  onSort,
}: {
  label: string;
  active: boolean;
  dir: SortDir;
  onSort: () => void;
}) {
  return (
    <th>
      <button
        type="button"
        className="inline-flex items-center gap-1 font-medium hover:opacity-80"
        onClick={onSort}
      >
        {label}
        <ArrowUpDown className="w-3 h-3 opacity-60" />
        {active && <span className="text-[10px] opacity-70">{dir === "asc" ? "↑" : "↓"}</span>}
      </button>
    </th>
  );
}
