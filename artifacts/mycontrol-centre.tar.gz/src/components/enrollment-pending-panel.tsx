"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Check, X, Server, RefreshCw } from "lucide-react";
import { formatDate } from "@/lib/utils";
import { useEnrollmentPending } from "@/components/enrollment-pending-provider";

interface EnrollmentRequest {
  id: string;
  status: string;
  name: string;
  hostname: string;
  port: number;
  sshUser: string;
  publicKey: string;
  knownHostKey: string | null;
  metadata: Record<string, unknown> | null;
  requestIp: string | null;
  createdAt: string;
  canUseStoredKey: boolean;
}

const POLL_MS = 4000;

export function EnrollmentPendingPanel({
  onApproved,
  watchPublicKey,
  onPendingDetected,
  alwaysVisible = true,
}: {
  onApproved?: () => void;
  watchPublicKey?: string;
  onPendingDetected?: () => void;
  /** Keep the card visible on Servers when the queue is empty (admin). */
  alwaysVisible?: boolean;
}) {
  const [requests, setRequests] = useState<EnrollmentRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [acting, setActing] = useState<string | null>(null);
  const [approveId, setApproveId] = useState<string | null>(null);
  const [privateKey, setPrivateKey] = useState("");
  const [displayName, setDisplayName] = useState("");
  const notifiedRef = useRef(false);
  const { refreshPendingCount } = useEnrollmentPending();

  const load = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/enrollment/requests?status=PENDING");
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed to load enrollments");
      const list: EnrollmentRequest[] = data.requests ?? [];
      setRequests(list);
      await refreshPendingCount();

      if (watchPublicKey?.trim()) {
        const normalizedWatch = watchPublicKey.trim();
        const match = list.some((r) => r.publicKey.trim() === normalizedWatch);
        if (match && !notifiedRef.current) {
          notifiedRef.current = true;
          onPendingDetected?.();
        }
      }
    } catch (e) {
      if (!silent) {
        setError(e instanceof Error ? e.message : "Failed to load");
        setRequests([]);
      }
    } finally {
      if (!silent) setLoading(false);
    }
  }, [watchPublicKey, onPendingDetected, refreshPendingCount]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    const timer = setInterval(() => load(true), POLL_MS);
    return () => clearInterval(timer);
  }, [load]);

  async function approveRequest(req: EnrollmentRequest, opts?: { privateKey?: string }) {
    setActing(req.id);
    setError("");
    try {
      const res = await fetch(`/api/enrollment/requests/${req.id}/approve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: (approveId === req.id ? displayName : req.name).trim() || req.name,
          privateKey: opts?.privateKey?.trim() || undefined,
          useStoredKey: !opts?.privateKey?.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Approve failed");
      setApproveId(null);
      setPrivateKey("");
      await load(true);
      onApproved?.();
      if (data.health && !data.health.online) {
        setError(
          `Server added but health check failed: ${data.health.error ?? "offline"}. Check host key or SSH access.`,
        );
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Approve failed");
    } finally {
      setActing(null);
    }
  }

  function openManualApprove(req: EnrollmentRequest) {
    setApproveId(req.id);
    setDisplayName(req.name);
    setPrivateKey("");
    setError("");
  }

  async function submitManualApprove() {
    const req = requests.find((r) => r.id === approveId);
    if (!req) return;
    if (!privateKey.trim()) {
      setError("Paste the full private key, or cancel and use one-click approve if the wizard key is still stored.");
      return;
    }
    await approveRequest(req, { privateKey });
  }

  async function reject(id: string) {
    const reason = prompt("Reject reason (optional):") ?? "";
    setActing(id);
    setError("");
    try {
      const res = await fetch(`/api/enrollment/requests/${id}/reject`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason: reason.trim() || undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Reject failed");
      if (approveId === id) setApproveId(null);
      await load(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Reject failed");
    } finally {
      setActing(null);
    }
  }

  const showPanel = alwaysVisible || requests.length > 0 || approveId || loading || Boolean(error);

  if (!showPanel) {
    return null;
  }

  return (
    <div
      id="pending-enrollment"
      className="card p-6 space-y-4 border border-amber-500/40 scroll-mt-6"
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Server className="w-5 h-5" style={{ color: "var(--primary)" }} />
            Pending enrollment
            {requests.length > 0 && (
              <span className="text-xs font-normal px-2 py-0.5 rounded-full bg-amber-500/20">
                {requests.length}
              </span>
            )}
          </h2>
          <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
            Refreshes every few seconds. If you used <strong>Generate SSH key</strong> in the wizard,
            use <strong>Approve &amp; activate</strong> — no paste needed (key kept encrypted in the console for 30 days).
          </p>
        </div>
        <button type="button" className="btn btn-secondary text-sm" onClick={() => load()}>
          <RefreshCw className="w-4 h-4" />
          Refresh
        </button>
      </div>

      {error && (
        <p className="text-sm text-red-500" role="alert">
          {error}
        </p>
      )}

      {approveId && (
        <div className="p-4 rounded-lg space-y-3" style={{ background: "var(--muted-bg)" }}>
          <p className="text-sm font-medium">Activate server (manual key)</p>
          <p className="text-xs" style={{ color: "var(--muted)" }}>
            Only needed if the wizard key was regenerated or expired. Paste the <em>complete</em> private key block.
          </p>
          <label className="block text-xs" style={{ color: "var(--muted)" }}>
            Display name
            <input
              className="input mt-1 w-full"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
            />
          </label>
          <label className="block text-xs" style={{ color: "var(--muted)" }}>
            Private key
            <textarea
              className="input mt-1 w-full font-mono text-xs min-h-[120px]"
              value={privateKey}
              onChange={(e) => setPrivateKey(e.target.value)}
              placeholder="-----BEGIN OPENSSH PRIVATE KEY-----&#10;...&#10;-----END OPENSSH PRIVATE KEY-----"
            />
          </label>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              className="btn btn-primary text-sm"
              disabled={acting === approveId}
              onClick={submitManualApprove}
            >
              <Check className="w-4 h-4" />
              Approve with pasted key
            </button>
            <button
              type="button"
              className="btn btn-secondary text-sm"
              onClick={() => setApproveId(null)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      <ul className="space-y-3">
        {requests.map((req) => (
          <li
            key={req.id}
            className="flex flex-wrap items-start justify-between gap-3 p-4 rounded-lg border"
            style={{ borderColor: "var(--border)" }}
          >
            <div className="min-w-0 space-y-1">
              <p className="font-medium">
                {req.name}{" "}
                <span className="text-sm font-normal" style={{ color: "var(--muted)" }}>
                  {req.sshUser}@{req.hostname}:{req.port}
                </span>
              </p>
              <p className="text-xs" style={{ color: "var(--muted)" }}>
                Requested {formatDate(req.createdAt)}
                {req.requestIp ? ` from ${req.requestIp}` : ""}
              </p>
              {req.metadata && typeof req.metadata === "object" && "os" in req.metadata && (
                <p className="text-xs" style={{ color: "var(--muted)" }}>
                  {String(req.metadata.os)}
                </p>
              )}
              {req.canUseStoredKey && (
                <p className="text-xs" style={{ color: "var(--success)" }}>
                  Matching setup key on console — one-click approve available
                </p>
              )}
            </div>
            <div className="flex flex-wrap gap-2 shrink-0">
              {req.canUseStoredKey ? (
                <button
                  type="button"
                  className="btn btn-primary text-sm py-1"
                  disabled={acting === req.id}
                  onClick={() => approveRequest(req)}
                >
                  Approve &amp; activate
                </button>
              ) : (
                <button
                  type="button"
                  className="btn btn-primary text-sm py-1"
                  disabled={acting === req.id}
                  onClick={() => openManualApprove(req)}
                >
                  Approve…
                </button>
              )}
              <button
                type="button"
                className="btn btn-secondary text-sm py-1"
                disabled={acting === req.id}
                onClick={() => reject(req.id)}
              >
                <X className="w-4 h-4" />
                Reject
              </button>
            </div>
          </li>
        ))}
      </ul>

      {!loading && requests.length === 0 && !approveId && (
        <p className="text-sm py-4 text-center rounded-lg border border-dashed" style={{ color: "var(--muted)", borderColor: "var(--border)" }}>
          No pending requests. Generate an SSH key below, run the install command on the host as root,
          and a request will appear here automatically (badge on <strong>Approvals</strong> in the sidebar).
        </p>
      )}

      {loading && requests.length === 0 && (
        <p className="text-sm" style={{ color: "var(--muted)" }}>
          Checking for pending enrollments…
        </p>
      )}
    </div>
  );
}
