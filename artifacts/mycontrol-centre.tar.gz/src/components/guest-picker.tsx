"use client";

import { useEffect, useState } from "react";

interface GuestOption {
  vmid: number;
  name: string;
  guestType: string;
  status: string | null;
}

export function GuestPicker({
  serverId,
  value,
  onChange,
}: {
  serverId: string | null;
  value: string;
  onChange: (vmid: string) => void;
}) {
  const [guests, setGuests] = useState<GuestOption[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!serverId) {
      setGuests([]);
      return;
    }

    setLoading(true);
    fetch(`/api/servers/${serverId}/proxmox`)
      .then((res) => (res.ok ? res.json() : { guests: [] }))
      .then((data) => setGuests(data.guests ?? []))
      .finally(() => setLoading(false));
  }, [serverId]);

  if (!serverId) return null;

  return (
    <div>
      <label className="block text-sm font-medium mb-1">Guest (VMID)</label>
      {loading ? (
        <p className="text-sm" style={{ color: "var(--muted)" }}>
          Loading inventory...
        </p>
      ) : guests.length === 0 ? (
        <input
          className="input"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Enter VMID (sync Proxmox inventory first)"
        />
      ) : (
        <select
          className="input"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        >
          <option value="">Select guest...</option>
          {guests.map((guest) => (
            <option key={guest.vmid} value={String(guest.vmid)}>
              {guest.vmid} · {guest.name} ({guest.guestType}
              {guest.status ? ` · ${guest.status}` : ""})
            </option>
          ))}
        </select>
      )}
    </div>
  );
}
