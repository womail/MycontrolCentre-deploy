import {
  OS_FAMILY_LABELS,
  osBadgeTitle,
  type OsFamily,
} from "@/lib/servers/os-display";

const FAMILY_BADGE_CLASS: Record<OsFamily, string> = {
  debian: "badge badge-muted",
  arch: "badge badge-muted",
  alpine: "badge badge-muted",
  unknown: "badge badge-muted opacity-60",
};

export function ServerOsBadge({
  detectedOsFamily,
  detectedOsId,
  detectedOsLabel,
}: {
  detectedOsFamily: string | null;
  detectedOsId: string | null;
  detectedOsLabel: string | null;
}) {
  const family = (detectedOsFamily ?? "unknown") as OsFamily;
  const label =
    family in OS_FAMILY_LABELS && family !== "unknown"
      ? OS_FAMILY_LABELS[family]
      : detectedOsId && detectedOsId !== "unknown"
        ? detectedOsId
        : "—";

  return (
    <span
      className={`${FAMILY_BADGE_CLASS[family in OS_FAMILY_LABELS ? family : "unknown"]} text-xs`}
      title={osBadgeTitle({ detectedOsFamily, detectedOsId, detectedOsLabel })}
    >
      {label}
    </span>
  );
}
