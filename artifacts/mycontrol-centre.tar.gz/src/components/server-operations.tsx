"use client";

import { useCallback, useEffect, useState } from "react";
import { RefreshCw, Settings2, Wrench } from "lucide-react";
import { formatDate } from "@/lib/utils";

interface ProxmoxGuest {
  id: string;
  vmid: number;
  name: string;
  guestType: string;
  status: string;
}

interface ServerSettings {
  id: string;
  name: string;
  hostname: string;
  port: number;
  sshUser: string;
  authType: string;
  knownHostKey: string | null;
  acceptNewHostKey: boolean;
  inMaintenance: boolean;
  maintenanceNote: string | null;
  maintenanceUntil: string | null;
  proxmoxApiPort: number;
  proxmoxTokenId: string | null;
  proxmoxNodeName: string | null;
  proxmoxVersion: string | null;
  lastProxmoxSync: string | null;
  proxmoxSummary: Record<string, unknown> | null;
}

export function ServerOperationsPanel({
  serverId,
  isAdmin,
  canSync,
  onChanged,
  onClose,
}: {
  serverId: string;
  isAdmin: boolean;
  canSync: boolean;
  onChanged: () => void;
  onClose: () => void;
}) {
  const [settings, setSettings] = useState<ServerSettings | null>(null);
  const [guests, setGuests] = useState<ProxmoxGuest[]>([]);
  const [hasProxmoxToken, setHasProxmoxToken] = useState(false);
  const [maintenanceNote, setMaintenanceNote] = useState("");
  const [maintenanceUntil, setMaintenanceUntil] = useState("");
  const [proxmoxApiPort, setProxmoxApiPort] = useState("8006");
  const [proxmoxTokenId, setProxmoxTokenId] = useState("");
  const [proxmoxTokenSecret, setProxmoxTokenSecret] = useState("");
  const [proxmoxNodeName, setProxmoxNodeName] = useState("");
  const [sshHostname, setSshHostname] = useState("");
  const [sshPort, setSshPort] = useState("22");
  const [sshUser, setSshUser] = useState("mcc-auto");
  const [sshPrivateKey, setSshPrivateKey] = useState("");
  const [knownHostKey, setKnownHostKey] = useState("");
  const [acceptNewHostKey, setAcceptNewHostKey] = useState(false);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    const [serverRes, proxmoxRes] = await Promise.all([
      fetch(`/api/servers/${serverId}`),
      fetch(`/api/servers/${serverId}/proxmox`),
    ]);
    if (serverRes.ok) {
      const data = await serverRes.json();
      const server = data.server as ServerSettings;
      setSettings(server);
      setMaintenanceNote(server.maintenanceNote ?? "");
      setMaintenanceUntil(
        server.maintenanceUntil ? server.maintenanceUntil.slice(0, 16) : "",
      );
      setProxmoxApiPort(String(server.proxmoxApiPort ?? 8006));
      setProxmoxTokenId(server.proxmoxTokenId ?? "");
      setProxmoxNodeName(server.proxmoxNodeName ?? "");
      setSshHostname(server.hostname ?? "");
      setSshPort(String(server.port ?? 22));
      setSshUser(server.sshUser ?? "mcc-auto");
      setKnownHostKey(server.knownHostKey ?? "");
      setAcceptNewHostKey(Boolean(server.acceptNewHostKey));
      setSshPrivateKey("");
    }
    if (proxmoxRes.ok) {
      const data = await proxmoxRes.json();
      setGuests(data.guests ?? []);
      setHasProxmoxToken(Boolean(data.server?.hasProxmoxToken));
    }
    setLoading(false);
  }, [serverId]);

  useEffect(() => {
    load();
  }, [load]);

  async function saveSettings(patch: Record<string, unknown>) {
    if (!isAdmin) return;
    setSaving(true);
    setError("");
    const res = await fetch(`/api/servers/${serverId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    const data = await res.json();
    setSaving(false);
    if (!res.ok) {
      setError(data.error ?? "Failed to save");
      return;
    }
    await load();
    onChanged();
  }

  async function toggleMaintenance() {
    if (!settings) return;
    await saveSettings({
      inMaintenance: !settings.inMaintenance,
      maintenanceNote: maintenanceNote.trim() || null,
      maintenanceUntil: maintenanceUntil ? new Date(maintenanceUntil).toISOString() : null,
    });
  }

  async function saveSshConnection() {
    const patch: Record<string, unknown> = {
      hostname: sshHostname.trim(),
      port: parseInt(sshPort, 10) || 22,
      sshUser: sshUser.trim() || "mcc-auto",
      knownHostKey: knownHostKey.trim() || null,
      acceptNewHostKey,
    };
    if (sshPrivateKey.trim()) {
      patch.privateKey = sshPrivateKey.trim();
    }
    await saveSettings(patch);
    setSshPrivateKey("");
  }

  async function saveProxmox() {
    await saveSettings({
      proxmoxApiPort: parseInt(proxmoxApiPort, 10) || 8006,
      proxmoxTokenId: proxmoxTokenId.trim() || null,
      proxmoxTokenSecret: proxmoxTokenSecret.trim() || undefined,
      proxmoxNodeName: proxmoxNodeName.trim() || null,
    });
    setProxmoxTokenSecret("");
  }

  async function syncProxmox() {
    setSyncing(true);
    setError("");
    const res = await fetch(`/api/servers/${serverId}/proxmox`, { method: "POST" });
    const data = await res.json();
    setSyncing(false);
    if (!res.ok) {
      setError(data.error ?? "Proxmox sync failed");
      return;
    }
    await load();
    onChanged();
  }

  if (loading || !settings) {
    return (
      <div className="card p-6">
        <p className="text-sm" style={{ color: "var(--muted)" }}>
          Loading server settings...
        </p>
      </div>
    );
  }

  const summary = settings.proxmoxSummary as {
    vmCount?: number;
    lxcCount?: number;
    onlineNodes?: number;
    nodeCount?: number;
    quorum?: boolean;
  } | null;

  const runningGuests = guests.filter((guest) => guest.status === "running").length;

  return (
    <div className="card p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="font-semibold text-lg flex items-center gap-2">
          <Settings2 className="w-5 h-5" />
          {settings.name} — operations
        </h2>
        <button type="button" className="btn btn-secondary py-1 px-2" onClick={onClose}>
          Close
        </button>
      </div>

      {error && <p style={{ color: "var(--danger)" }}>{error}</p>}

      <section className="space-y-3">
        <h3 className="font-medium">SSH connection</h3>
        <p className="text-sm" style={{ color: "var(--muted)" }}>
          Update host, user, or private key if health checks fail with authentication errors. Compare
          OpenSSH fingerprints in <strong>Admin → Vault</strong> with{" "}
          <code>ssh-keygen -lf /home/mcc-auto/.ssh/authorized_keys</code> on the host.
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          <Field label="Hostname / IP" value={sshHostname} onChange={setSshHostname} disabled={!isAdmin} />
          <Field label="Port" value={sshPort} onChange={setSshPort} disabled={!isAdmin} />
          <Field label="SSH user" value={sshUser} onChange={setSshUser} disabled={!isAdmin} />
        </div>
        {isAdmin && (
          <>
            <div>
              <label className="block text-sm font-medium mb-1">
                Private key (PEM — leave blank to keep current)
              </label>
              <textarea
                className="input font-mono text-xs min-h-[120px]"
                value={sshPrivateKey}
                onChange={(e) => setSshPrivateKey(e.target.value)}
                placeholder="-----BEGIN OPENSSH PRIVATE KEY-----"
                spellCheck={false}
              />
            </div>
            <Field
              label="Known host key (base64, optional)"
              value={knownHostKey}
              onChange={setKnownHostKey}
            />
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={acceptNewHostKey}
                onChange={(e) => setAcceptNewHostKey(e.target.checked)}
              />
              Accept new host key on first connect
            </label>
            <button type="button" className="btn btn-primary" onClick={saveSshConnection} disabled={saving}>
              Save SSH settings
            </button>
          </>
        )}
      </section>

      <section className="space-y-3">
        <h3 className="font-medium flex items-center gap-2">
          <Wrench className="w-4 h-4" />
          Maintenance window
        </h3>
        <p className="text-sm" style={{ color: "var(--muted)" }}>
          Servers in maintenance block command runs for operators. Admins can override from the Commands page.
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          <Field
            label="Note"
            value={maintenanceNote}
            onChange={setMaintenanceNote}
            disabled={!isAdmin}
          />
          <Field
            label="Until (optional)"
            type="datetime-local"
            value={maintenanceUntil}
            onChange={setMaintenanceUntil}
            disabled={!isAdmin}
          />
        </div>
        {isAdmin && (
          <button
            type="button"
            className={`btn ${settings.inMaintenance ? "btn-secondary" : "btn-primary"}`}
            onClick={toggleMaintenance}
            disabled={saving}
          >
            {settings.inMaintenance ? "Clear maintenance" : "Enable maintenance"}
          </button>
        )}
        {settings.inMaintenance && (
          <span className="badge badge-warning ml-2">In maintenance</span>
        )}
      </section>

      <section className="space-y-3">
        <h3 className="font-medium">Proxmox API</h3>
        <p className="text-sm" style={{ color: "var(--muted)" }}>
          Read-only API token for inventory sync and dashboard metrics. Token ID format:{" "}
          <code>root@pam!mycontrol</code>
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          <Field
            label="API port"
            value={proxmoxApiPort}
            onChange={setProxmoxApiPort}
            disabled={!isAdmin}
          />
          <Field
            label="Node name (optional)"
            value={proxmoxNodeName}
            onChange={setProxmoxNodeName}
            disabled={!isAdmin}
          />
          <Field
            label="Token ID"
            value={proxmoxTokenId}
            onChange={setProxmoxTokenId}
            disabled={!isAdmin}
          />
          {isAdmin && (
            <Field
              label="Token secret (leave blank to keep existing)"
              type="password"
              value={proxmoxTokenSecret}
              onChange={setProxmoxTokenSecret}
            />
          )}
        </div>
        <div className="flex flex-wrap gap-2 items-center">
          {isAdmin && (
            <button type="button" className="btn btn-secondary" onClick={saveProxmox} disabled={saving}>
              Save Proxmox settings
            </button>
          )}
          {canSync && hasProxmoxToken && (
            <button type="button" className="btn btn-primary" onClick={syncProxmox} disabled={syncing}>
              <RefreshCw className="w-4 h-4" />
              {syncing ? "Syncing..." : "Sync inventory"}
            </button>
          )}
        </div>
        <div className="text-sm" style={{ color: "var(--muted)" }}>
          Version: {settings.proxmoxVersion ?? "—"} · Last sync:{" "}
          {settings.lastProxmoxSync ? formatDate(settings.lastProxmoxSync) : "never"}
          {summary && (
            <>
              {" "}
              · {summary.vmCount ?? 0} VMs · {summary.lxcCount ?? 0} CTs · {runningGuests} running
              {summary.quorum != null && ` · quorum ${summary.quorum ? "OK" : "lost"}`}
            </>
          )}
        </div>
        {guests.length > 0 && (
          <div className="table-wrap border rounded-lg" style={{ borderColor: "var(--card-border)" }}>
            <table>
              <thead>
                <tr>
                  <th>VMID</th>
                  <th>Name</th>
                  <th>Type</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {guests.map((guest) => (
                  <tr key={guest.id}>
                    <td>{guest.vmid}</td>
                    <td>{guest.name}</td>
                    <td>{guest.guestType}</td>
                    <td>{guest.status ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {error && <p style={{ color: "var(--danger)" }}>{error}</p>}
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  disabled,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  disabled?: boolean;
}) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1">{label}</label>
      <input
        className="input"
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
      />
    </div>
  );
}
