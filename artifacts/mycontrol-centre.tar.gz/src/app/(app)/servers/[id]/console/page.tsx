"use client";

import { useCallback, useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { PageContainer } from "@/components/page-container";
import { ServerConsoleWorkspace } from "@/components/server-console-workspace";

export default function ServerConsolePage() {
  const params = useParams();
  const router = useRouter();
  const serverId = params.id as string;

  const [user, setUser] = useState<{ username: string; role: string } | null>(null);

  const load = useCallback(async () => {
    const meRes = await fetch("/api/auth/me");
    if (!meRes.ok) {
      router.push("/login");
      return;
    }
    const me = await meRes.json();
    setUser(me.user);
    if (me.user.role === "VIEWER") {
      router.push("/servers");
    }
  }, [router]);

  useEffect(() => {
    void load();
  }, [load]);

  if (!user) {
    return <div className="p-8">Loading…</div>;
  }

  return (
    <AppShell user={user}>
      <PageContainer className="space-y-0 h-full">
        <ServerConsoleWorkspace initialServerId={serverId} userRole={user.role} />
      </PageContainer>
    </AppShell>
  );
}
