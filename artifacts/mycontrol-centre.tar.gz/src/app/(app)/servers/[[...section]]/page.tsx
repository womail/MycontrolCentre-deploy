"use client";

import { useCallback, useEffect, useMemo, useState, Fragment } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { PageContainer } from "@/components/page-container";
import { formatDate } from "@/lib/utils";
import { compareServers, type ServerSortKey, type SortDir } from "@/lib/servers/sort-servers";
import { SshSetupWizard } from "@/components/ssh-setup-wizard";
import { Plus, Trash2, Activity, Settings2, ArrowUpDown, TerminalSquare } from "lucide-react";
import { ServerOperationsPanel } from "@/components/server-operations";
import { ServerOsBadge } from "@/components/server-os-badge";
import { EnrollmentPendingPanel } from "@/components/enrollment-pending-panel";
import { ServerGroupsPanel } from "@/components/server-groups-panel";
import { ServerHealthAdvice } from "@/components/server-health-advice";
import { cn } from "@/lib/utils";
import { packageUpdatesCommandsHref } from "@/lib/updates/package-update-templates";
import {
  parseServerSection,
  isValidServerSectionPath,
  serverSectionHref,
  sectionPartsFromParams,
  type ServerSection,
} from "@/lib/navigation/sections";

type ServersTab = ServerSection;

const SERVER_TABS: { id: ServersTab; label: string; adminOnly?: boolean }[] = [
  { id: "fleet", label: "Fleet" },
  { id: "setup", label: "Setup & add", adminOnly: true },
  { id: "groups", label: "Groups", adminOnly: true },
  { id: "approvals", label: "Approvals", adminOnly: true },
];

interface ServerRow {
  id: string;
  name: string;
  hostname: string;
  port: number;
  sshUser: string;
  authType: string;
  tags: string[];
  healthStatus: string;
  healthMessage: string | null;
  lastHealthCheck: string | null;
  isActive: boolean;
  inMaintenance: boolean;
  maintenanceNote: string | null;
  platforms: string[];
  detectedPlatforms: string[];
  detectedOsId: string | null;
  detectedOsLabel: string | null;
  detectedOsFamily: string | null;
  osDetectedAt: string | null;
  manualPlatforms: string[];
  proxmoxVersion: string | null;
  lastProxmoxSync: string | null;
  pendingPackageUpdates: number | null;
  lastPackageUpdatesCheck: string | null;
}

interface UserInfo {
  username: string;
  role: string;
}

interface ServerFormDraft {
  name: string;
  hostname: string;
  port: number;
  sshUser: string;
  authType: string;
  privateKey: string;
  password: string;
  knownHostKey: string;
  acceptNewHostKey: boolean;
  tags: string;
  manualPlatforms: string[];
}

const PLATFORM_OPTIONS = [
  { id: "proxmox", label: "Proxmox" },
  { id: "debian", label: "Debian" },
  { id: "ubuntu", label: "Ubuntu" },
  { id: "alpine", label: "Alpine" },
  { id: "docker", label: "Docker" },
  { id: "arch", label: "Arch" },
] as const;

const emptyDraft: ServerFormDraft = {
  name: "",
  hostname: "",
  port: 22,
  sshUser: "mcc-auto",
  authType: "KEY",
  privateKey: "",
  password: "",
  knownHostKey: "",
  acceptNewHostKey: false,
  tags: "",
  manualPlatforms: [],
};

export default function ServersPage() {
  const router = useRouter();
  const routeSection = useParams().section;
  const sectionParts = useMemo(
    () => sectionPartsFromParams(routeSection as string | string[] | undefined),
    [routeSection],
  );
  const pageTab = parseServerSection(sectionParts);

  const [user, setUser] = useState<UserInfo | null>(null);
  const [servers, setServers] = useState<ServerRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formDraft, setFormDraft] = useState<ServerFormDraft>(emptyDraft);
  const [checking, setChecking] = useState<string | null>(null);
  const [settingsServerId, setSettingsServerId] = useState<string | null>(null);
  const [setupPublicKey, setSetupPublicKey] = useState<string | undefined>();
  const [enrollmentReceived, setEnrollmentReceived] = useState(false);

  const [loadError, setLoadError] = useState("");
  const [sortKey, setSortKey] = useState<ServerSortKey>("name");
  const [sortDir, setSortDir] = useState<SortDir>("asc");

  const sortedServers = useMemo(
    () =>
      [...servers].sort((a, b) =>
        compareServers(a, b, sortKey, sortDir),
      ),
    [servers, sortKey, sortDir],
  );

  function toggleSort(key: ServerSortKey) {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  }

  const load = useCallback(async () => {
    const [meRes, serversRes] = await Promise.all([
      fetch("/api/auth/me"),
      fetch("/api/servers"),
    ]);
    if (meRes.ok) setUser((await meRes.json()).user);
    if (serversRes.ok) {
      setLoadError("");
      setServers((await serversRes.json()).servers);
    } else {
      const data = await serversRes.json().catch(() => ({}));
      setServers([]);
      setLoadError(data.error ?? `Failed to load servers (${serversRes.status})`);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (!isValidServerSectionPath(sectionParts)) {
      router.replace("/servers");
    }
  }, [router, sectionParts]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.location.hash === "#pending-enrollment") {
      router.replace("/servers/approvals");
    }
  }, [router]);

  async function healthCheck(id: string) {
    setChecking(id);
    const res = await fetch(`/api/servers/${id}/health`, { method: "POST" });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      alert(data.error ?? `Health check failed (${res.status})`);
    }
    await load();
    setChecking(null);
  }

  async function deleteServer(id: string) {
    if (!confirm("Delete this server? Command history for this server will also be removed.")) return;
    const res = await fetch(`/api/servers/${id}`, { method: "DELETE" });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      alert(data.error ?? `Delete failed (${res.status})`);
      return;
    }
    await load();
  }

  if (!user) return <div className="p-8">Loading...</div>;

  const canRunCommands = user.role === "ADMIN" || user.role === "OPERATOR";

  return (
    <AppShell user={user}>
      <PageContainer>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Servers</h1>
            <p style={{ color: "var(--muted)" }}>SSH targets, enrollment, and groups</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {SERVER_TABS.filter((t) => !t.adminOnly || user.role === "ADMIN").map((t) => (
            <Link
              key={t.id}
              href={serverSectionHref(t.id)}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
                pageTab === t.id ? "btn btn-primary" : "btn btn-secondary",
              )}
            >
              {t.label}
            </Link>
          ))}
        </div>

        {pageTab === "fleet" && (
          <>
            {loadError && (
              <div className="card p-4 text-sm" style={{ color: "var(--danger)" }}>
                {loadError}. Run <code className="font-mono">npm run db:repair</code> and refresh the page.
              </div>
            )}

            <div className="card overflow-hidden">
              <div
                className="px-4 py-3 border-b flex flex-wrap items-center justify-between gap-2"
                style={{ borderColor: "var(--card-border)" }}
              >
                <div>
                  <h2 className="font-semibold">Server fleet</h2>
                  <p className="text-xs" style={{ color: "var(--muted)" }}>
                    {loading ? "Loading…" : `${servers.length} host${servers.length === 1 ? "" : "s"}`}
                  </p>
                </div>
              </div>
              <div className="table-wrap overflow-x-auto max-h-[28rem] overflow-y-auto">
                <table>
                  <thead className="sticky top-0 z-10 bg-[var(--card)]">
                    <tr>
                      <SortHeader label="Name" sortKey="name" active={sortKey} dir={sortDir} onSort={toggleSort} />
                      <SortHeader label="Host" sortKey="host" active={sortKey} dir={sortDir} onSort={toggleSort} />
                      <SortHeader label="Health" sortKey="health" active={sortKey} dir={sortDir} onSort={toggleSort} />
                      <SortHeader label="OS" sortKey="os" active={sortKey} dir={sortDir} onSort={toggleSort} />
                      <SortHeader label="Updates" sortKey="updates" active={sortKey} dir={sortDir} onSort={toggleSort} />
                      <SortHeader label="Last check" sortKey="lastCheck" active={sortKey} dir={sortDir} onSort={toggleSort} />
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading ? (
                      <tr>
                        <td colSpan={7}>Loading...</td>
                      </tr>
                    ) : servers.length === 0 ? (
                      <tr>
                        <td colSpan={7} style={{ color: "var(--muted)" }}>
                          No servers yet.
                          {user.role === "ADMIN" && (
                            <>
                              {" "}
                              Open <strong>Setup & add</strong> to run the wizard or add a host manually.
                            </>
                          )}
                        </td>
                      </tr>
                    ) : (
                      sortedServers.map((s) => (
                        <Fragment key={s.id}>
                        <tr>
                          <td className="font-medium">
                            <div>{s.name}</div>
                            <div className="text-xs font-normal" style={{ color: "var(--muted)" }}>
                              {s.sshUser} · {s.authType}
                              {s.inMaintenance && (
                                <span className="badge badge-warning ml-1">Maintenance</span>
                              )}
                            </div>
                          </td>
                          <td>
                            {s.hostname}:{s.port}
                          </td>
                          <td>
                            <HealthBadge status={s.healthStatus} />
                          </td>
                          <td>
                            <ServerOsBadge
                              detectedOsFamily={s.detectedOsFamily}
                              detectedOsId={s.detectedOsId}
                              detectedOsLabel={s.detectedOsLabel}
                            />
                            {s.platforms.includes("proxmox") && s.proxmoxVersion && (
                              <div className="text-xs mt-0.5" style={{ color: "var(--muted)" }}>
                                PVE {s.proxmoxVersion.split("-")[0]}
                              </div>
                            )}
                          </td>
                          <td>
                            {s.pendingPackageUpdates != null ? (
                              s.pendingPackageUpdates > 0 ? (
                                canRunCommands ? (
                                  <Link
                                    href={packageUpdatesCommandsHref(s.id)}
                                    className="badge badge-warning hover:opacity-90 underline-offset-2 hover:underline"
                                    title={
                                      s.lastPackageUpdatesCheck
                                        ? `Run package update — last checked ${formatDate(s.lastPackageUpdatesCheck)}`
                                        : "Run package update on Commands"
                                    }
                                  >
                                    {s.pendingPackageUpdates}
                                  </Link>
                                ) : (
                                  <span className="badge badge-warning">{s.pendingPackageUpdates}</span>
                                )
                              ) : (
                                <span className="text-xs" style={{ color: "var(--muted)" }}>
                                  0
                                </span>
                              )
                            ) : (
                              <span className="text-xs" style={{ color: "var(--muted)" }}>
                                —
                              </span>
                            )}
                          </td>
                          <td className="text-sm" style={{ color: "var(--muted)" }}>
                            {formatDate(s.lastHealthCheck)}
                          </td>
                          <td>
                            <div className="flex gap-2">
                              {canRunCommands && (
                                <Link
                                  href={`/servers/${s.id}/console`}
                                  className="btn btn-secondary py-1 px-2"
                                  title="SSH terminal & files"
                                >
                                  <TerminalSquare className="w-4 h-4" />
                                </Link>
                              )}
                              <button
                                className="btn btn-secondary py-1 px-2"
                                onClick={() => healthCheck(s.id)}
                                disabled={checking === s.id}
                                title="Health check"
                              >
                                <Activity className="w-4 h-4" />
                              </button>
                              <button
                                className="btn btn-secondary py-1 px-2"
                                onClick={() => setSettingsServerId(s.id)}
                                title="Server settings (SSH, maintenance, Proxmox)"
                              >
                                <Settings2 className="w-4 h-4" />
                              </button>
                              {user.role === "ADMIN" && (
                                <button
                                  className="btn btn-secondary py-1 px-2"
                                  onClick={() => deleteServer(s.id)}
                                  title="Delete"
                                >
                                  <Trash2 className="w-4 h-4" style={{ color: "var(--danger)" }} />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                        {(s.healthStatus !== "ONLINE" || s.inMaintenance) && (
                          <tr key={`${s.id}-advice`}>
                            <td colSpan={7} className="!pt-0">
                              <ServerHealthAdvice
                                name={s.name}
                                hostname={s.hostname}
                                port={s.port}
                                sshUser={s.sshUser}
                                authType={s.authType}
                                healthStatus={s.healthStatus}
                                healthMessage={s.healthMessage}
                                inMaintenance={s.inMaintenance}
                              />
                            </td>
                          </tr>
                        )}
                        </Fragment>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {pageTab === "setup" && user.role === "ADMIN" && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <p className="text-sm" style={{ color: "var(--muted)" }}>
                Generate keys, install the agent on Proxmox, or add a server manually.
              </p>
              <button
                className="btn btn-primary"
                onClick={() => setShowForm(true)}
              >
                <Plus className="w-4 h-4" />
                Add server manually
              </button>
            </div>
            <SshSetupWizard
              enrollmentReceived={enrollmentReceived}
              onKeysGenerated={(k) => {
                setSetupPublicKey(k.publicKey);
                setEnrollmentReceived(false);
              }}
              onUseKey={(privateKey) => {
                setFormDraft((d) => ({ ...d, privateKey, authType: "KEY" }));
                setShowForm(true);
              }}
              onUseHostInfo={(info) => {
                setFormDraft((d) => ({
                  ...d,
                  name: info.name || d.name,
                  hostname: info.hostname || d.hostname,
                  port: info.port ?? d.port,
                  sshUser: info.sshUser || d.sshUser,
                  knownHostKey: info.knownHostKey || d.knownHostKey,
                  acceptNewHostKey: !info.knownHostKey,
                }));
                setShowForm(true);
              }}
            />
          </div>
        )}

        {pageTab === "groups" && user.role === "ADMIN" && (
          <ServerGroupsPanel servers={servers.map((s) => ({ id: s.id, name: s.name }))} />
        )}

        {pageTab === "approvals" && user.role === "ADMIN" && (
          <EnrollmentPendingPanel
            onApproved={load}
            watchPublicKey={setupPublicKey}
            onPendingDetected={() => setEnrollmentReceived(true)}
          />
        )}

        {showForm && user.role === "ADMIN" && (
          <ServerForm
            initial={formDraft}
            onSaved={() => {
              setShowForm(false);
              setFormDraft(emptyDraft);
              load();
            }}
            onCancel={() => {
              setShowForm(false);
              setFormDraft(emptyDraft);
            }}
          />
        )}

        {settingsServerId && (
          <ServerOperationsPanel
            serverId={settingsServerId}
            isAdmin={user.role === "ADMIN"}
            canSync={user.role === "ADMIN" || user.role === "OPERATOR"}
            onChanged={load}
            onClose={() => setSettingsServerId(null)}
          />
        )}

      </PageContainer>
    </AppShell>
  );
}

function SortHeader({
  label,
  sortKey,
  active,
  dir,
  onSort,
}: {
  label: string;
  sortKey: ServerSortKey;
  active: ServerSortKey;
  dir: SortDir;
  onSort: (key: ServerSortKey) => void;
}) {
  const isActive = active === sortKey;
  return (
    <th>
      <button
        type="button"
        className="inline-flex items-center gap-1 font-medium hover:opacity-80"
        onClick={() => onSort(sortKey)}
      >
        {label}
        <ArrowUpDown className="w-3 h-3 opacity-60" />
        {isActive && (
          <span className="text-[10px] opacity-70">{dir === "asc" ? "↑" : "↓"}</span>
        )}
      </button>
    </th>
  );
}

function HealthBadge({ status }: { status: string }) {
  const cls =
    status === "ONLINE"
      ? "badge-success"
      : status === "OFFLINE"
        ? "badge-danger"
        : "badge-muted";
  return <span className={`badge ${cls}`}>{status}</span>;
}

function ServerForm({
  initial,
  onSaved,
  onCancel,
}: {
  initial: ServerFormDraft;
  onSaved: () => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState(initial);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setForm(initial);
  }, [initial]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");

    const res = await fetch("/api/servers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        knownHostKey: form.knownHostKey || null,
        tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean),
        manualPlatforms: form.manualPlatforms,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Failed");
      setSaving(false);
      return;
    }
    onSaved();
  }

  return (
    <form onSubmit={submit} className="card p-6 space-y-4">
      <h2 className="font-semibold text-lg">New server</h2>
      <div className="grid md:grid-cols-2 gap-4">
        <Field label="Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} required />
        <Field label="Hostname / IP" value={form.hostname} onChange={(v) => setForm({ ...form, hostname: v })} required />
        <Field label="Port" type="number" value={String(form.port)} onChange={(v) => setForm({ ...form, port: parseInt(v) || 22 })} />
        <Field label="SSH user" value={form.sshUser} onChange={(v) => setForm({ ...form, sshUser: v })} />
        <div>
          <label className="block text-sm font-medium mb-1">Auth type</label>
          <select
            className="input"
            value={form.authType}
            onChange={(e) => setForm({ ...form, authType: e.target.value })}
          >
            <option value="KEY">SSH key</option>
            <option value="PASSWORD">Password</option>
            <option value="KEY_AND_PASSWORD">Key + passphrase</option>
          </select>
        </div>
        <Field label="Tags (comma-separated)" value={form.tags} onChange={(v) => setForm({ ...form, tags: v })} />
        <div className="md:col-span-2">
          <label className="block text-sm font-medium mb-2">Platforms (manual)</label>
          <div className="flex flex-wrap gap-3">
            {PLATFORM_OPTIONS.map((option) => (
              <label key={option.id} className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={form.manualPlatforms.includes(option.id)}
                  onChange={(e) => {
                    setForm((prev) => ({
                      ...prev,
                      manualPlatforms: e.target.checked
                        ? [...prev.manualPlatforms, option.id]
                        : prev.manualPlatforms.filter((platform) => platform !== option.id),
                    }));
                  }}
                />
                {option.label}
              </label>
            ))}
          </div>
          <p className="text-xs mt-1" style={{ color: "var(--muted)" }}>
            Auto-detection runs on health check (Proxmox, Debian, Docker, Arch).
          </p>
        </div>
        <Field
          label="Known host key (optional)"
          value={form.knownHostKey}
          onChange={(v) => setForm({ ...form, knownHostKey: v, acceptNewHostKey: !v })}
        />
      </div>
      {(form.authType === "KEY" || form.authType === "KEY_AND_PASSWORD") && (
        <div>
          <label className="block text-sm font-medium mb-1">Private key (PEM)</label>
          <textarea
            className="input font-mono text-xs min-h-32"
            value={form.privateKey}
            onChange={(e) => setForm({ ...form, privateKey: e.target.value })}
            placeholder="-----BEGIN OPENSSH PRIVATE KEY-----"
            required
          />
        </div>
      )}
      {(form.authType === "PASSWORD" || form.authType === "KEY_AND_PASSWORD") && (
        <Field
          label={form.authType === "KEY_AND_PASSWORD" ? "Key passphrase" : "SSH password"}
          type="password"
          value={form.password}
          onChange={(v) => setForm({ ...form, password: v })}
        />
      )}
      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={form.acceptNewHostKey}
          onChange={(e) => setForm({ ...form, acceptNewHostKey: e.target.checked })}
        />
        Accept host key on first connect (use only if you do not have the known host key)
      </label>
      {error && <p style={{ color: "var(--danger)" }}>{error}</p>}
      <div className="flex gap-2">
        <button type="submit" className="btn btn-primary" disabled={saving}>
          {saving ? "Saving..." : "Save server"}
        </button>
        <button type="button" className="btn btn-secondary" onClick={onCancel}>
          Cancel
        </button>
      </div>
    </form>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1">{label}</label>
      <input
        className="input"
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
      />
    </div>
  );
}
