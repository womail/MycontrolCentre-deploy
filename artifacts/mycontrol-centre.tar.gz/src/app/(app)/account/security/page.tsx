"use client";

import { useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { PageContainer } from "@/components/page-container";
import { MfaSettingsPanel } from "@/components/mfa-settings-panel";

export default function AccountSecurityPage() {
  const [user, setUser] = useState<{ username: string; role: string } | null>(null);

  useEffect(() => {
    void fetch("/api/auth/me")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => d && setUser(d.user));
  }, []);

  if (!user) return <div className="p-8">Loading...</div>;

  return (
    <AppShell user={user}>
      <PageContainer className="max-w-2xl space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Account security</h1>
          <p style={{ color: "var(--muted)" }}>Two-factor authentication for {user.username}</p>
        </div>
        <MfaSettingsPanel />
      </PageContainer>
    </AppShell>
  );
}
