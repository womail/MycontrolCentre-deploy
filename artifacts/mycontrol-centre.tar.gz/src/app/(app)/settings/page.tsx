"use client";

import { useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { PageContainer } from "@/components/page-container";
import { notifyAppearanceUpdated } from "@/components/appearance-provider";
import { AboutBuildInfo } from "@/components/about-build-info";
import { AlertsSettingsPanel } from "@/components/alerts-settings";
import {
  DEFAULT_APPEARANCE,
  appearanceToCssProperties,
  type AppearanceSettings,
} from "@/lib/settings/appearance";
import {
  THEME_PRESETS,
  appearanceForThemePreset,
} from "@/lib/settings/theme-presets";
import type { CSSProperties } from "react";

type ButtonSize = NonNullable<AppearanceSettings["buttonSize"]>;
type ButtonShape = NonNullable<AppearanceSettings["buttonShape"]>;
type FontFamily = NonNullable<AppearanceSettings["fontFamily"]>;
type FontSize = NonNullable<AppearanceSettings["fontSize"]>;

const emptyAppearance = (): Required<AppearanceSettings> => ({ ...DEFAULT_APPEARANCE });

export default function SettingsPage() {
  const [user, setUser] = useState<{ username: string; role: string } | null>(null);
  const [maxConcurrentSsh, setMaxConcurrentSsh] = useState(5);
  const [auditRetentionDays, setAuditRetentionDays] = useState(365);
  const [backupMaxAgeHours, setBackupMaxAgeHours] = useState(168);
  const [consolePublicUrl, setConsolePublicUrl] = useState("");
  const [appearance, setAppearance] = useState(emptyAppearance);
  const [saved, setSaved] = useState(false);
  const [appearanceSaved, setAppearanceSaved] = useState(false);

  useEffect(() => {
    async function load() {
      const [meRes, settingsRes, appearanceRes] = await Promise.all([
        fetch("/api/auth/me"),
        fetch("/api/settings"),
        fetch("/api/settings/appearance"),
      ]);
      if (meRes.ok) setUser((await meRes.json()).user);
      if (settingsRes.ok) {
        const data = await settingsRes.json();
        setMaxConcurrentSsh(data.maxConcurrentSsh);
        setAuditRetentionDays(data.auditRetentionDays);
        setBackupMaxAgeHours(data.backupMaxAgeHours ?? 168);
        setConsolePublicUrl(
          data.consolePublicUrl ||
            (typeof window !== "undefined" ? window.location.origin : ""),
        );
      }
      if (appearanceRes.ok) {
        const data = await appearanceRes.json();
        setAppearance({ ...DEFAULT_APPEARANCE, ...data.appearance });
      }
    }
    load();
  }, []);

  async function saveSystem(e: React.FormEvent) {
    e.preventDefault();
    await fetch("/api/settings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        maxConcurrentSsh,
        auditRetentionDays,
        consolePublicUrl,
        backupMaxAgeHours,
      }),
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  async function saveAppearance(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/settings/appearance", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(appearance),
    });
    if (res.ok) {
      notifyAppearanceUpdated();
      setAppearanceSaved(true);
      setTimeout(() => setAppearanceSaved(false), 2000);
    }
  }

  function resetAppearance() {
    setAppearance({ ...DEFAULT_APPEARANCE });
  }

  if (!user) return <div className="p-8">Loading...</div>;
  if (user.role !== "ADMIN") {
    return (
      <AppShell user={user}>
        <div className="card p-6">Admin access required.</div>
      </AppShell>
    );
  }

  return (
    <AppShell user={user}>
      <PageContainer className="max-w-4xl">
        <div>
          <h1 className="text-3xl font-bold">Settings</h1>
          <p style={{ color: "var(--muted)" }}>System configuration and appearance</p>
        </div>

        <form onSubmit={saveSystem} className="card p-6 space-y-4">
          <h2 className="text-lg font-semibold">System</h2>
          <div>
            <label className="block text-sm font-medium mb-1">
              Console URL (for Proxmox setup curl)
            </label>
            <input
              className="input font-mono text-sm"
              type="text"
              value={consolePublicUrl}
              onChange={(e) => setConsolePublicUrl(e.target.value)}
              placeholder="http://10.1.3.230:3000"
            />
            <p className="text-xs mt-1" style={{ color: "var(--muted)" }}>
              Address Proxmox hosts use to reach this console.
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">
              Max concurrent SSH sessions
            </label>
            <input
              className="input"
              type="number"
              min={1}
              max={50}
              value={maxConcurrentSsh}
              onChange={(e) => setMaxConcurrentSsh(parseInt(e.target.value) || 5)}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">
              Audit log retention (days)
            </label>
            <input
              className="input"
              type="number"
              min={30}
              max={3650}
              value={auditRetentionDays}
              onChange={(e) => setAuditRetentionDays(parseInt(e.target.value) || 365)}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">
              Backup freshness threshold (hours)
            </label>
            <input
              className="input"
              type="number"
              min={1}
              max={8760}
              value={backupMaxAgeHours}
              onChange={(e) => setBackupMaxAgeHours(parseInt(e.target.value) || 168)}
            />
            <p className="text-xs mt-1" style={{ color: "var(--muted)" }}>
              Destructive commands on Proxmox hosts require a vzdump or ZFS snapshot within this window (default 168h / 7 days).
            </p>
          </div>

          <button type="submit" className="btn btn-primary">
            Save system settings
          </button>
          {saved && (
            <span className="text-sm ml-2" style={{ color: "var(--success)" }}>
              Saved
            </span>
          )}
        </form>

        <AboutBuildInfo />

        <AlertsSettingsPanel />

        <form onSubmit={saveAppearance} className="card p-6 space-y-5">
          <div>
            <h2 className="text-lg font-semibold">Appearance</h2>
            <p className="text-sm mt-1" style={{ color: "var(--muted)" }}>
              Global UI options for all users. Changes apply immediately after saving.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold mb-2">Style preset</h3>
            <p className="text-xs mb-3" style={{ color: "var(--muted)" }}>
              One-click palettes for surfaces, accent, typography, and button shape. You can still fine-tune colors below.
            </p>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {THEME_PRESETS.map((preset) => {
                const active = (appearance.themePreset ?? "classic") === preset.id;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    className="text-left p-3 rounded-lg border transition-colors"
                    style={{
                      borderColor: active ? "var(--primary)" : "var(--card-border)",
                      boxShadow: active ? "0 0 0 1px var(--primary)" : undefined,
                    }}
                    onClick={() =>
                      setAppearance((prev) => ({
                        ...prev,
                        ...appearanceForThemePreset(preset.id),
                      }))
                    }
                  >
                    <div className="flex gap-1 mb-2">
                      {preset.swatch.map((color) => (
                        <span
                          key={color}
                          className="h-4 flex-1 rounded-sm"
                          style={{ background: color }}
                        />
                      ))}
                    </div>
                    <p className="text-sm font-medium">{preset.label}</p>
                    <p className="text-xs" style={{ color: "var(--muted)" }}>
                      {preset.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <ColorField
              label="Primary color"
              value={appearance.primaryColor}
              onChange={(v) => setAppearance((a) => ({ ...a, primaryColor: v }))}
            />
            <ColorField
              label="Sidebar color"
              value={appearance.sidebarColor}
              onChange={(v) => setAppearance((a) => ({ ...a, sidebarColor: v }))}
            />
            <ColorField
              label="Success color"
              value={appearance.successColor}
              onChange={(v) => setAppearance((a) => ({ ...a, successColor: v }))}
            />
            <ColorField
              label="Warning color"
              value={appearance.warningColor}
              onChange={(v) => setAppearance((a) => ({ ...a, warningColor: v }))}
            />
            <ColorField
              label="Danger color"
              value={appearance.dangerColor}
              onChange={(v) => setAppearance((a) => ({ ...a, dangerColor: v }))}
            />
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <SelectField
              label="Button size"
              value={appearance.buttonSize}
              onChange={(v) =>
                setAppearance((a) => ({ ...a, buttonSize: v as ButtonSize }))
              }
              options={[
                { value: "xs", label: "Extra small (compact)" },
                { value: "sm", label: "Small" },
                { value: "md", label: "Medium" },
                { value: "lg", label: "Large" },
              ]}
            />
            <SelectField
              label="Button shape / style"
              value={appearance.buttonShape}
              onChange={(v) =>
                setAppearance((a) => ({ ...a, buttonShape: v as ButtonShape }))
              }
              options={[
                { value: "sharp", label: "Sharp" },
                { value: "square", label: "Square" },
                { value: "rounded", label: "Rounded" },
                { value: "pill", label: "Pill" },
                { value: "bevel", label: "Bevel (raised)" },
                { value: "soft", label: "Soft shadow" },
                { value: "outline", label: "Outline primary" },
                { value: "notched", label: "Notched corners" },
                { value: "glow", label: "Glow" },
              ]}
            />
            <SelectField
              label="Font family"
              value={appearance.fontFamily}
              onChange={(v) =>
                setAppearance((a) => ({ ...a, fontFamily: v as FontFamily }))
              }
              options={[
                { value: "system", label: "System UI" },
                { value: "sans", label: "Sans-serif" },
                { value: "mono", label: "Monospace" },
                { value: "serif", label: "Serif" },
              ]}
            />
            <SelectField
              label="Base font size"
              value={appearance.fontSize}
              onChange={(v) =>
                setAppearance((a) => ({ ...a, fontSize: v as FontSize }))
              }
              options={[
                { value: "xs", label: "Compact (12px)" },
                { value: "sm", label: "Small (14px)" },
                { value: "md", label: "Medium (16px)" },
                { value: "lg", label: "Large (18px)" },
              ]}
            />
          </div>

          <div
            className="p-4 rounded-lg space-y-3"
            style={
              {
                border: "1px solid var(--card-border)",
                background: "color-mix(in srgb, var(--muted) 8%, transparent)",
                ...appearanceToCssProperties(appearance),
              } as CSSProperties
            }
          >
            <p className="text-sm font-medium">Preview</p>
            <div className="flex flex-wrap gap-2">
              <button type="button" className="btn btn-primary">
                Primary
              </button>
              <button type="button" className="btn btn-secondary">
                Secondary
              </button>
              <button type="button" className="btn btn-danger">
                Danger
              </button>
              <span className="badge badge-success">Success</span>
              <span className="badge badge-warning">Warning</span>
            </div>
            <p className="text-sm" style={{ color: "var(--muted)" }}>
              Sample body text — the quick brown fox jumps over the lazy dog.
            </p>
          </div>

          <div className="flex flex-wrap gap-2 items-center">
            <button type="submit" className="btn btn-primary">
              Save appearance
            </button>
            <button type="button" className="btn btn-secondary" onClick={resetAppearance}>
              Reset to defaults
            </button>
            {appearanceSaved && (
              <span className="text-sm" style={{ color: "var(--success)" }}>
                Appearance saved
              </span>
            )}
          </div>
        </form>

        <div className="card p-6 space-y-2 text-sm" style={{ color: "var(--muted)" }}>
          <h2 className="font-semibold text-base" style={{ color: "var(--foreground)" }}>
            Security notes
          </h2>
          <ul className="list-disc pl-5 space-y-1">
            <li>Set strong SESSION_SECRET and ENCRYPTION_KEY in production.</li>
            <li>Deploy behind HTTPS (Caddy/nginx reverse proxy recommended).</li>
            <li>Restrict network access to trusted IPs/VPN where possible.</li>
          </ul>
        </div>
      </PageContainer>
    </AppShell>
  );
}

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1">{label}</label>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-10 w-12 cursor-pointer rounded border border-[var(--card-border)] bg-transparent"
          aria-label={label}
        />
        <input
          className="input font-mono text-sm flex-1"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          pattern="^#[0-9A-Fa-f]{6}$"
          placeholder="#3b82f6"
        />
      </div>
    </div>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1">{label}</label>
      <select
        className="input"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}
