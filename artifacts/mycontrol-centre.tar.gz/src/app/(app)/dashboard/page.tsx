import { getSessionUser } from "@/lib/auth/session";
import { AppShell } from "@/components/app-shell";
import { getFleetDashboardStats } from "@/lib/dashboard/fleet-stats";
import { formatDate } from "@/lib/utils";
import { OfflineServersPanel } from "@/components/offline-servers-panel";
import Link from "next/link";
import { PageContainer } from "@/components/page-container";
import {
  Server,
  Terminal,
  ScrollText,
  Activity,
  AlertTriangle,
  WifiOff,
  Clock,
} from "lucide-react";

export default async function DashboardPage() {
  const user = await getSessionUser();
  if (!user) return null;

  const stats = await getFleetDashboardStats();

  return (
    <AppShell user={user}>
      <PageContainer className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p style={{ color: "var(--muted)" }}>
            Fleet health, recent activity, and items needing attention
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={Server} label="Total servers" value={String(stats.serverCount)} />
          <StatCard icon={Activity} label="Online" value={String(stats.onlineCount)} accent="success" />
          <StatCard
            icon={WifiOff}
            label="Offline"
            value={String(stats.offlineCount)}
            accent={stats.offlineCount > 0 ? "danger" : undefined}
          />
          <StatCard
            icon={ScrollText}
            label="In maintenance"
            value={String(stats.maintenanceCount)}
            accent={stats.maintenanceCount > 0 ? "warning" : undefined}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            icon={Terminal}
            label="Proxmox guests"
            value={stats.proxmoxSyncedCount > 0 ? String(stats.proxmoxGuestCount) : "—"}
            hint={
              stats.proxmoxSyncedCount > 0
                ? `${stats.proxmoxSyncedCount} nodes synced`
                : "Sync from Servers"
            }
          />
          <StatCard
            icon={Clock}
            label="Pending runs"
            value={String(stats.pendingRunCount)}
            accent={stats.pendingRunCount > 0 ? "warning" : undefined}
          />
          <StatCard
            icon={AlertTriangle}
            label="Failed runs (24h)"
            value={String(stats.failedRunCount24h)}
            accent={stats.failedRunCount24h > 0 ? "danger" : undefined}
          />
          <StatCard
            icon={Activity}
            label="SSH failure rate (24h)"
            value={stats.sshFailureRate24h != null ? `${stats.sshFailureRate24h}%` : "—"}
            hint={
              stats.sshFailureRate24h != null ? "From connection logs" : "No SSH activity yet"
            }
            accent={
              stats.sshFailureRate24h != null && stats.sshFailureRate24h >= 20
                ? "danger"
                : undefined
            }
          />
        </div>

        {(stats.offlineServers.length > 0 || stats.quorumIssues.length > 0) && (
          <div className="grid lg:grid-cols-2 gap-6">
            {stats.offlineServers.length > 0 && (
              <OfflineServersPanel
                servers={stats.offlineServers.map((s) => ({
                  ...s,
                  lastHealthCheck: s.lastHealthCheck?.toISOString() ?? null,
                }))}
              />
            )}

            {stats.quorumIssues.length > 0 && (
              <section className="card p-6 space-y-3">
                <h2 className="font-semibold text-lg">Proxmox quorum issues</h2>
                <ul className="space-y-2 text-sm">
                  {stats.quorumIssues.map((server) => (
                    <li key={server.id}>
                      {server.name} — cluster quorum lost
                    </li>
                  ))}
                </ul>
              </section>
            )}
          </div>
        )}

        <div className="grid lg:grid-cols-2 gap-6">
          <section className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-lg">Recent commands</h2>
              <Link href="/commands" className="text-sm" style={{ color: "var(--primary)" }}>
                View all
              </Link>
            </div>
            {stats.recentRuns.length === 0 ? (
              <p className="text-sm" style={{ color: "var(--muted)" }}>
                No commands run yet.
              </p>
            ) : (
              <ul className="space-y-3">
                {stats.recentRuns.map((run) => (
                  <li key={run.id} className="flex items-center justify-between text-sm gap-2">
                    <span>
                      {run.server.name} · {run.label ?? run.commandType}
                    </span>
                    <StatusBadge status={run.status} />
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-lg">Recent failures</h2>
              <Link href="/commands" className="text-sm" style={{ color: "var(--primary)" }}>
                View all
              </Link>
            </div>
            {stats.recentFailedRuns.length === 0 ? (
              <p className="text-sm" style={{ color: "var(--muted)" }}>
                No failed runs recently.
              </p>
            ) : (
              <ul className="space-y-3">
                {stats.recentFailedRuns.map((run) => (
                  <li key={run.id} className="text-sm space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span>
                        {run.server.name} · {run.label ?? run.commandType}
                      </span>
                      <span className="text-xs" style={{ color: "var(--muted)" }}>
                        {formatDate(run.createdAt)}
                      </span>
                    </div>
                    {run.changeReason && (
                      <div className="text-xs" style={{ color: "var(--muted)" }}>
                        Reason: {run.changeReason}
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        <section className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-lg">Recent audit</h2>
            <Link href="/logs" className="text-sm" style={{ color: "var(--primary)" }}>
              View all
            </Link>
          </div>
          <ul className="space-y-3">
            {stats.recentLogs.map((log) => (
              <li key={log.id} className="text-sm">
                <div className="flex justify-between gap-2">
                  <span>{log.action.replace(/_/g, " ")}</span>
                  <span style={{ color: "var(--muted)" }}>{formatDate(log.createdAt)}</span>
                </div>
                <div className="text-xs" style={{ color: "var(--muted)" }}>
                  {log.user?.username ?? "system"}
                </div>
              </li>
            ))}
          </ul>
        </section>
      </PageContainer>
    </AppShell>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  accent,
  hint,
}: {
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
  label: string;
  value: string;
  accent?: "success" | "warning" | "danger";
  hint?: string;
}) {
  const color =
    accent === "success"
      ? "var(--success)"
      : accent === "warning"
        ? "var(--warning)"
        : accent === "danger"
          ? "var(--danger)"
          : "var(--primary)";
  return (
    <div className="card p-5">
      <div className="flex items-center gap-3 mb-2">
        <Icon className="w-5 h-5" style={{ color }} />
        <span className="text-sm" style={{ color: "var(--muted)" }}>
          {label}
        </span>
      </div>
      <div className="text-3xl font-bold">{value}</div>
      {hint && (
        <div className="text-xs mt-1" style={{ color: "var(--muted)" }}>
          {hint}
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    SUCCESS: "badge-success",
    FAILED: "badge-danger",
    RUNNING: "badge-warning",
    PENDING: "badge-muted",
  };
  return <span className={`badge ${map[status] ?? "badge-muted"}`}>{status}</span>;
}
