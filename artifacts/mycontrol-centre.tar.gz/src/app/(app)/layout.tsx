import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth/session";
import { AppProviders } from "@/components/app-providers";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.mustChangePassword) redirect("/change-password");

  return (
    <AppProviders isAdmin={user.role === "ADMIN"}>{children}</AppProviders>
  );
}
