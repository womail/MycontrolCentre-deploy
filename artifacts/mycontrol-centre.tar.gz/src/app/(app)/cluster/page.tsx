"use client";

import { useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { PageContainer } from "@/components/page-container";
import { formatDate } from "@/lib/utils";
import Link from "next/link";
import { RefreshCw } from "lucide-react";

interface ClusterNode {
  id: string;
  name: string;
  hostname: string;
  healthStatus: string;
  inMaintenance: boolean;
  platforms: string[];
  proxmoxVersion: string | null;
  proxmoxNodeName: string | null;
  lastProxmoxSync: string | null;
  guestCount: number;
  summary: {
    vmCount?: number;
    lxcCount?: number;
    onlineNodes?: number;
    nodeCount?: number;
    quorum?: boolean;
  } | null;
}

interface ClusterResponse {
  nodes: ClusterNode[];
  proxmoxNodes: ClusterNode[];
  quorumIssues: ClusterNode[];
  totals: {
    servers: number;
    proxmoxNodes: number;
    guests: number;
    quorumIssues: number;
  };
}

export default function ClusterPage() {
  const [user, setUser] = useState<{ username: string; role: string } | null>(null);
  const [data, setData] = useState<ClusterResponse | null>(null);

  async function load() {
    const [meRes, clusterRes] = await Promise.all([
      fetch("/api/auth/me"),
      fetch("/api/cluster"),
    ]);
    if (meRes.ok) setUser((await meRes.json()).user);
    if (clusterRes.ok) setData(await clusterRes.json());
  }

  useEffect(() => {
    load();
  }, []);

  if (!user) return <div className="p-8">Loading...</div>;

  return (
    <AppShell user={user}>
      <PageContainer>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Cluster</h1>
            <p style={{ color: "var(--muted)" }}>
              Proxmox node health, quorum, and synced guest inventory
            </p>
          </div>
          <button type="button" className="btn btn-secondary" onClick={load}>
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>

        {!data ? (
          <div className="card p-6">Loading cluster data...</div>
        ) : (
          <>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Stat label="Proxmox nodes" value={String(data.totals.proxmoxNodes)} />
              <Stat label="Synced guests" value={String(data.totals.guests)} />
              <Stat
                label="Quorum issues"
                value={String(data.totals.quorumIssues)}
                warn={data.totals.quorumIssues > 0}
              />
              <Stat label="All servers" value={String(data.totals.servers)} />
            </div>

            {data.quorumIssues.length > 0 && (
              <div className="card p-4 text-sm" style={{ borderColor: "var(--warning)" }}>
                <strong>Quorum lost</strong> on:{" "}
                {data.quorumIssues.map((node) => node.name).join(", ")}
              </div>
            )}

            <div className="card table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Node</th>
                    <th>Health</th>
                    <th>Version</th>
                    <th>Guests</th>
                    <th>Cluster</th>
                    <th>Last sync</th>
                  </tr>
                </thead>
                <tbody>
                  {data.proxmoxNodes.length === 0 ? (
                    <tr>
                      <td colSpan={6} style={{ color: "var(--muted)" }}>
                        No Proxmox nodes detected yet. Run a health check or tag servers as Proxmox.
                      </td>
                    </tr>
                  ) : (
                    data.proxmoxNodes.map((node) => (
                      <tr key={node.id}>
                        <td>
                          <div className="font-medium">{node.name}</div>
                          <div className="text-xs" style={{ color: "var(--muted)" }}>
                            {node.hostname}
                          </div>
                        </td>
                        <td>
                          <StatusBadge status={node.healthStatus} />
                          {node.inMaintenance && (
                            <span className="badge badge-warning ml-1">Maint</span>
                          )}
                        </td>
                        <td>{node.proxmoxVersion ?? "—"}</td>
                        <td>{node.guestCount}</td>
                        <td>
                          {node.summary?.quorum == null
                            ? "—"
                            : node.summary.quorum
                              ? "Quorum OK"
                              : "Quorum lost"}
                          {node.summary && (
                            <div className="text-xs" style={{ color: "var(--muted)" }}>
                              {node.summary.vmCount ?? 0} VM · {node.summary.lxcCount ?? 0} CT
                            </div>
                          )}
                        </td>
                        <td className="text-sm" style={{ color: "var(--muted)" }}>
                          {node.lastProxmoxSync ? formatDate(node.lastProxmoxSync) : "never"}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <p className="text-sm" style={{ color: "var(--muted)" }}>
              Sync inventory per server from{" "}
              <Link href="/servers" style={{ color: "var(--primary)" }}>
                Servers → Operations
              </Link>
              .
            </p>
          </>
        )}
      </PageContainer>
    </AppShell>
  );
}

function Stat({ label, value, warn }: { label: string; value: string; warn?: boolean }) {
  return (
    <div className="card p-5">
      <div className="text-sm" style={{ color: "var(--muted)" }}>
        {label}
      </div>
      <div
        className="text-3xl font-bold mt-1"
        style={warn ? { color: "var(--warning)" } : undefined}
      >
        {value}
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const cls =
    status === "ONLINE"
      ? "badge-success"
      : status === "OFFLINE"
        ? "badge-danger"
        : "badge-muted";
  return <span className={`badge ${cls}`}>{status}</span>;
}
