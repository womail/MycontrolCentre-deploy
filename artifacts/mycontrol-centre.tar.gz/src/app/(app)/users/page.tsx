"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { PageContainer } from "@/components/page-container";
import { formatDate } from "@/lib/utils";
import { Plus, Trash2 } from "lucide-react";

interface UserRow {
  id: string;
  username: string;
  role: string;
  isActive: boolean;
  mustChangePassword: boolean;
  totpEnabled: boolean;
  createdAt: string;
}

export default function UsersPage() {
  const [user, setUser] = useState<{ username: string; role: string } | null>(null);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [showForm, setShowForm] = useState(false);

  const load = useCallback(async () => {
    const meRes = await fetch("/api/auth/me");
    if (meRes.ok) {
      const me = (await meRes.json()).user;
      setUser(me);
      if (me.role === "ADMIN") {
        const usersRes = await fetch("/api/users");
        if (usersRes.ok) setUsers((await usersRes.json()).users);
      }
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function deleteUser(id: string) {
    if (!confirm("Delete this user?")) return;
    await fetch(`/api/users/${id}`, { method: "DELETE" });
    load();
  }

  async function resetTotp(id: string, username: string) {
    if (
      !confirm(
        `Reset TOTP for "${username}"? They will sign in with password only until they enroll a new authenticator under Account → Security.`,
      )
    ) {
      return;
    }
    const res = await fetch(`/api/users/${id}/reset-totp`, { method: "POST" });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      alert(data.error ?? "Reset failed");
      return;
    }
    load();
  }

  if (!user) return <div className="p-8">Loading...</div>;
  if (user.role !== "ADMIN") {
    return (
      <AppShell user={user}>
        <div className="card p-6">Admin access required.</div>
      </AppShell>
    );
  }

  return (
    <AppShell user={user}>
      <PageContainer>
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Users</h1>
            <p style={{ color: "var(--muted)" }}>Manage access roles</p>
          </div>
          <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>
            <Plus className="w-4 h-4" />
            Add user
          </button>
        </div>

        {showForm && (
          <UserForm
            onSaved={() => {
              setShowForm(false);
              load();
            }}
            onCancel={() => setShowForm(false)}
          />
        )}

        <div className="card table-wrap">
          <table>
            <thead>
              <tr>
                <th>Username</th>
                <th>Role</th>
                <th>Status</th>
                <th>MFA</th>
                <th>Created</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id}>
                  <td className="font-medium">{u.username}</td>
                  <td className="capitalize">{u.role.toLowerCase()}</td>
                  <td>
                    {u.isActive ? (
                      <span className="badge badge-success">Active</span>
                    ) : (
                      <span className="badge badge-danger">Inactive</span>
                    )}
                    {u.mustChangePassword && (
                      <span className="badge badge-warning ml-1">Must change pwd</span>
                    )}
                  </td>
                  <td>
                    {u.totpEnabled ? (
                      <span className="badge badge-success">TOTP</span>
                    ) : (
                      <span className="text-xs" style={{ color: "var(--muted)" }}>
                        —
                      </span>
                    )}
                  </td>
                  <td className="text-sm" style={{ color: "var(--muted)" }}>
                    {formatDate(u.createdAt)}
                  </td>
                  <td>
                    <div className="flex gap-2 justify-end">
                      {u.totpEnabled && (
                        <button
                          type="button"
                          className="btn btn-secondary py-1 px-2 text-xs"
                          onClick={() => void resetTotp(u.id, u.username)}
                        >
                          Reset TOTP
                        </button>
                      )}
                      <button className="btn btn-secondary py-1 px-2" onClick={() => deleteUser(u.id)}>
                      <Trash2 className="w-4 h-4" style={{ color: "var(--danger)" }} />
                    </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </PageContainer>
    </AppShell>
  );
}

function UserForm({
  onSaved,
  onCancel,
}: {
  onSaved: () => void;
  onCancel: () => void;
}) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("OPERATOR");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const res = await fetch("/api/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password, role }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Failed");
      setSaving(false);
      return;
    }
    onSaved();
  }

  return (
    <form onSubmit={submit} className="card p-6 space-y-4">
      <h2 className="font-semibold">New user</h2>
      <input className="input" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} required />
      <input className="input" type="password" placeholder="Password (min 12 chars)" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={12} />
      <select className="input" value={role} onChange={(e) => setRole(e.target.value)}>
        <option value="ADMIN">Admin</option>
        <option value="OPERATOR">Operator</option>
        <option value="VIEWER">Viewer</option>
      </select>
      {error && <p style={{ color: "var(--danger)" }}>{error}</p>}
      <div className="flex gap-2">
        <button type="submit" className="btn btn-primary" disabled={saving}>Save</button>
        <button type="button" className="btn btn-secondary" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}
