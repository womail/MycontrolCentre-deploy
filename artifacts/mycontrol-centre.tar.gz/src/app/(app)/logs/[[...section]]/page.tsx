"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { Minus, Plus } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { PageContainer } from "@/components/page-container";
import { SlideOver } from "@/components/slide-over";
import { ResizableColumnHeader } from "@/components/resizable-column-header";
import { ResizableSortableTh } from "@/components/resizable-sortable-th";
import { formatDate } from "@/lib/utils";
import { cn } from "@/lib/utils";
import {
  compareApiLogs,
  compareAuditLogs,
  compareRemoteLogs,
  useSortedRows,
} from "@/lib/logs/sort-logs";
import {
  type ApiColWidths,
  type AuditColWidths,
  type RemoteColWidths,
  readApiColWidths,
  readAuditColWidths,
  readRemoteColWidths,
  storeApiColWidths,
  storeAuditColWidths,
  storeRemoteColWidths,
} from "@/lib/logs/log-table-columns";
import {
  clampTerminalFontSize,
  readStoredTerminalFontSize,
  storeTerminalFontSize,
  TERMINAL_FONT_DEFAULT,
  TERMINAL_FONT_MAX,
  TERMINAL_FONT_MIN,
} from "@/lib/console/terminal-font-size";
import {
  parseLogSection,
  isValidLogSectionPath,
  logSectionHref,
  sectionPartsFromParams,
  type LogSection,
} from "@/lib/navigation/sections";

interface AuditEntry {
  id: string;
  action: string;
  resourceType: string | null;
  resourceId: string | null;
  details: Record<string, unknown> | null;
  ipAddress: string | null;
  createdAt: string;
  user: { username: string } | null;
}

interface RemoteConnectionEntry {
  id: string;
  serverName: string | null;
  hostname: string;
  port: number;
  sshUser: string;
  purpose: string;
  outcome: string;
  durationMs: number | null;
  exitCode: number | null;
  errorMessage: string | null;
  createdAt: string;
  user: { username: string } | null;
  server: { id: string; name: string } | null;
}

interface ApiRequestEntry {
  id: string;
  method: string;
  path: string;
  query: string | null;
  statusCode: number;
  durationMs: number;
  ipAddress: string | null;
  createdAt: string;
  user: { username: string } | null;
}

type LogTab = LogSection;

const tabs: { id: LogTab; label: string; description: string }[] = [
  { id: "audit", label: "Audit", description: "Security-relevant user actions" },
  { id: "remote", label: "Remote SSH", description: "Outbound connections to managed servers" },
  { id: "api", label: "API requests", description: "Inbound HTTP requests to the API" },
];

function outcomeBadge(outcome: string) {
  if (outcome === "SUCCESS") return "badge-success";
  if (outcome === "FAILED") return "badge-danger";
  return "badge-muted";
}

function statusBadge(status: number) {
  if (status >= 500) return "badge-danger";
  if (status >= 400) return "badge-warning";
  return "badge-success";
}

function AuditDetailGrid({ entry }: { entry: AuditEntry }) {
  const rows: { label: string; value: string }[] = [
    { label: "ID", value: entry.id },
    { label: "Time", value: formatDate(entry.createdAt) },
    { label: "User", value: entry.user?.username ?? "—" },
    { label: "Action", value: entry.action },
    { label: "Resource type", value: entry.resourceType ?? "—" },
    { label: "Resource ID", value: entry.resourceId ?? "—" },
    { label: "IP address", value: entry.ipAddress ?? "—" },
  ];

  return (
    <>
      <dl className="grid gap-2 sm:grid-cols-[8rem_1fr]">
        {rows.map((row) => (
          <div key={row.label} className="contents">
            <dt className="font-medium" style={{ color: "var(--muted)" }}>
              {row.label}
            </dt>
            <dd className="break-all font-mono text-xs sm:text-sm">{row.value}</dd>
          </div>
        ))}
      </dl>
      <div>
        <p className="font-medium mb-2">Details (JSON)</p>
        <pre
          className="text-xs font-mono p-3 rounded-lg border overflow-x-auto whitespace-pre-wrap break-all max-h-[min(50vh,24rem)] overflow-y-auto"
          style={{ borderColor: "var(--card-border)", background: "var(--background)" }}
        >
          {entry.details ? JSON.stringify(entry.details, null, 2) : "—"}
        </pre>
      </div>
    </>
  );
}

export default function LogsPage() {
  const router = useRouter();
  const routeSection = useParams().section;
  const sectionParts = useMemo(
    () => sectionPartsFromParams(routeSection as string | string[] | undefined),
    [routeSection],
  );
  const tab = parseLogSection(sectionParts);

  const [user, setUser] = useState<{ username: string; role: string } | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditEntry[]>([]);
  const [remoteLogs, setRemoteLogs] = useState<RemoteConnectionEntry[]>([]);
  const [apiLogs, setApiLogs] = useState<ApiRequestEntry[]>([]);
  const [fontSize, setFontSize] = useState(TERMINAL_FONT_DEFAULT);
  const [auditCols, setAuditCols] = useState<AuditColWidths>(() => readAuditColWidths());
  const [remoteCols, setRemoteCols] = useState<RemoteColWidths>(() => readRemoteColWidths());
  const [apiCols, setApiCols] = useState<ApiColWidths>(() => readApiColWidths());
  const [selectedAudit, setSelectedAudit] = useState<AuditEntry | null>(null);

  const auditSort = useSortedRows(auditLogs, "createdAt", compareAuditLogs);
  const remoteSort = useSortedRows(remoteLogs, "createdAt", compareRemoteLogs);
  const apiSort = useSortedRows(apiLogs, "createdAt", compareApiLogs);

  useEffect(() => {
    setFontSize(readStoredTerminalFontSize());
    setAuditCols(readAuditColWidths());
    setRemoteCols(readRemoteColWidths());
    setApiCols(readApiColWidths());
  }, []);

  const loadTab = useCallback(async () => {
    if (tab === "audit") {
      const res = await fetch("/api/audit?limit=200");
      if (res.ok) setAuditLogs((await res.json()).logs);
    } else if (tab === "remote") {
      const res = await fetch("/api/connection-logs/remote?limit=200");
      if (res.ok) setRemoteLogs((await res.json()).logs);
    } else {
      const res = await fetch("/api/connection-logs/api?limit=200");
      if (res.ok) setApiLogs((await res.json()).logs);
    }
  }, [tab]);

  useEffect(() => {
    if (!isValidLogSectionPath(sectionParts)) {
      router.replace("/logs");
    }
  }, [router, sectionParts]);

  useEffect(() => {
    async function loadUser() {
      const meRes = await fetch("/api/auth/me");
      if (meRes.ok) {
        const me = await meRes.json();
        if (me.user.role === "VIEWER") {
          router.push("/dashboard");
          return;
        }
        setUser(me.user);
      }
    }
    loadUser();
  }, [router]);

  useEffect(() => {
    if (user) void loadTab();
  }, [user, loadTab]);

  function changeFontSize(delta: number) {
    setFontSize((prev) => {
      const next = clampTerminalFontSize(prev + delta);
      storeTerminalFontSize(next);
      return next;
    });
  }

  function resizeAudit<K extends keyof AuditColWidths>(key: K, width: number) {
    setAuditCols((prev) => {
      const next = { ...prev, [key]: width };
      storeAuditColWidths(next);
      return next;
    });
  }

  function resizeRemote<K extends keyof RemoteColWidths>(key: K, width: number) {
    setRemoteCols((prev) => {
      const next = { ...prev, [key]: width };
      storeRemoteColWidths(next);
      return next;
    });
  }

  function resizeApi<K extends keyof ApiColWidths>(key: K, width: number) {
    setApiCols((prev) => {
      const next = { ...prev, [key]: width };
      storeApiColWidths(next);
      return next;
    });
  }

  if (!user) return <div className="p-8">Loading...</div>;

  const activeTab = tabs.find((t) => t.id === tab)!;
  const tableFontStyle = { fontSize: `${fontSize}px` };

  return (
    <AppShell user={user}>
      <PageContainer className="flex flex-col min-h-[calc(100vh-5rem)]">
        <div className="flex flex-wrap items-start justify-between gap-4 shrink-0">
          <div>
            <h1 className="text-3xl font-bold">Logs</h1>
            <p style={{ color: "var(--muted)" }}>{activeTab.description}</p>
            {user.role === "ADMIN" && (
              <p className="text-xs mt-2" style={{ color: "var(--muted)" }}>
                To clear audit, remote SSH, or API logs, use Admin → System → Maintenance.
              </p>
            )}
          </div>
          <div
            className="flex items-center gap-1 rounded-lg border px-1 shrink-0"
            style={{ borderColor: "var(--card-border)" }}
            title="Table font size (shared with server console)"
          >
            <button
              type="button"
              className="btn btn-secondary p-1.5"
              disabled={fontSize <= TERMINAL_FONT_MIN}
              onClick={() => changeFontSize(-1)}
              aria-label="Decrease font size"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="text-sm tabular-nums w-8 text-center">{fontSize}</span>
            <button
              type="button"
              className="btn btn-secondary p-1.5"
              disabled={fontSize >= TERMINAL_FONT_MAX}
              onClick={() => changeFontSize(1)}
              aria-label="Increase font size"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 shrink-0">
          {tabs.map((item) => (
            <Link
              key={item.id}
              href={logSectionHref(item.id)}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
                tab === item.id
                  ? "bg-[var(--primary)] text-white"
                  : "bg-[color-mix(in_srgb,var(--muted)_15%,transparent)] hover:bg-[color-mix(in_srgb,var(--muted)_25%,transparent)]",
              )}
            >
              {item.label}
            </Link>
          ))}
        </div>

        {tab === "audit" && (
          <div className="card table-wrap flex-1 min-h-0 max-h-[calc(100vh-13rem)] overflow-auto">
            <table className="w-full" style={{ tableLayout: "fixed", ...tableFontStyle }}>
              <thead className="sticky top-0 z-10 bg-[var(--card)]">
                <tr>
                  <ResizableSortableTh
                    label="Time"
                    active={auditSort.sortKey === "createdAt"}
                    dir={auditSort.sortDir}
                    onSort={() => auditSort.toggleSort("createdAt")}
                    width={auditCols.time}
                    minWidth={120}
                    onResize={(w) => resizeAudit("time", w)}
                  />
                  <ResizableSortableTh
                    label="User"
                    active={auditSort.sortKey === "user"}
                    dir={auditSort.sortDir}
                    onSort={() => auditSort.toggleSort("user")}
                    width={auditCols.user}
                    onResize={(w) => resizeAudit("user", w)}
                  />
                  <ResizableSortableTh
                    label="Action"
                    active={auditSort.sortKey === "action"}
                    dir={auditSort.sortDir}
                    onSort={() => auditSort.toggleSort("action")}
                    width={auditCols.action}
                    onResize={(w) => resizeAudit("action", w)}
                  />
                  <ResizableSortableTh
                    label="Resource"
                    active={auditSort.sortKey === "resourceType"}
                    dir={auditSort.sortDir}
                    onSort={() => auditSort.toggleSort("resourceType")}
                    width={auditCols.resource}
                    onResize={(w) => resizeAudit("resource", w)}
                  />
                  <ResizableSortableTh
                    label="IP"
                    active={auditSort.sortKey === "ipAddress"}
                    dir={auditSort.sortDir}
                    onSort={() => auditSort.toggleSort("ipAddress")}
                    width={auditCols.ip}
                    onResize={(w) => resizeAudit("ip", w)}
                  />
                  <ResizableColumnHeader
                    width={auditCols.details}
                    minWidth={120}
                    onResize={(w) => resizeAudit("details", w)}
                  >
                    Details
                  </ResizableColumnHeader>
                </tr>
              </thead>
              <tbody>
                {auditSort.sorted.map((log) => (
                  <tr
                    key={log.id}
                    className="cursor-pointer hover:bg-[color-mix(in_srgb,var(--muted)_8%,transparent)]"
                    onClick={() => setSelectedAudit(log)}
                  >
                    <td className="whitespace-nowrap truncate">{formatDate(log.createdAt)}</td>
                    <td className="truncate">{log.user?.username ?? "—"}</td>
                    <td>
                      <span className="badge badge-muted">{log.action.replace(/_/g, " ")}</span>
                    </td>
                    <td className="truncate">
                      {log.resourceType ?? "—"}
                      {log.resourceId && (
                        <span className="block text-xs opacity-60 truncate">{log.resourceId}</span>
                      )}
                    </td>
                    <td className="truncate">{log.ipAddress ?? "—"}</td>
                    <td className="font-mono truncate">
                      {log.details ? JSON.stringify(log.details) : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab === "remote" && (
          <div className="card table-wrap flex-1 min-h-0 max-h-[calc(100vh-13rem)] overflow-auto">
            <table className="w-full" style={{ tableLayout: "fixed", ...tableFontStyle }}>
              <thead className="sticky top-0 z-10 bg-[var(--card)]">
                <tr>
                  <ResizableSortableTh
                    label="Time"
                    active={remoteSort.sortKey === "createdAt"}
                    dir={remoteSort.sortDir}
                    onSort={() => remoteSort.toggleSort("createdAt")}
                    width={remoteCols.time}
                    minWidth={120}
                    onResize={(w) => resizeRemote("time", w)}
                  />
                  <ResizableSortableTh
                    label="Server"
                    active={remoteSort.sortKey === "server"}
                    dir={remoteSort.sortDir}
                    onSort={() => remoteSort.toggleSort("server")}
                    width={remoteCols.server}
                    onResize={(w) => resizeRemote("server", w)}
                  />
                  <ResizableSortableTh
                    label="Target"
                    active={remoteSort.sortKey === "hostname"}
                    dir={remoteSort.sortDir}
                    onSort={() => remoteSort.toggleSort("hostname")}
                    width={remoteCols.target}
                    minWidth={140}
                    onResize={(w) => resizeRemote("target", w)}
                  />
                  <ResizableSortableTh
                    label="Purpose"
                    active={remoteSort.sortKey === "purpose"}
                    dir={remoteSort.sortDir}
                    onSort={() => remoteSort.toggleSort("purpose")}
                    width={remoteCols.purpose}
                    onResize={(w) => resizeRemote("purpose", w)}
                  />
                  <ResizableSortableTh
                    label="User"
                    active={remoteSort.sortKey === "user"}
                    dir={remoteSort.sortDir}
                    onSort={() => remoteSort.toggleSort("user")}
                    width={remoteCols.user}
                    onResize={(w) => resizeRemote("user", w)}
                  />
                  <ResizableSortableTh
                    label="Outcome"
                    active={remoteSort.sortKey === "outcome"}
                    dir={remoteSort.sortDir}
                    onSort={() => remoteSort.toggleSort("outcome")}
                    width={remoteCols.outcome}
                    onResize={(w) => resizeRemote("outcome", w)}
                  />
                  <ResizableSortableTh
                    label="Duration"
                    active={remoteSort.sortKey === "durationMs"}
                    dir={remoteSort.sortDir}
                    onSort={() => remoteSort.toggleSort("durationMs")}
                    width={remoteCols.duration}
                    onResize={(w) => resizeRemote("duration", w)}
                  />
                  <ResizableColumnHeader
                    width={remoteCols.details}
                    minWidth={120}
                    onResize={(w) => resizeRemote("details", w)}
                  >
                    Details
                  </ResizableColumnHeader>
                </tr>
              </thead>
              <tbody>
                {remoteSort.sorted.map((log) => (
                  <tr key={log.id}>
                    <td className="whitespace-nowrap truncate">{formatDate(log.createdAt)}</td>
                    <td className="truncate">{log.server?.name ?? log.serverName ?? "—"}</td>
                    <td className="font-mono truncate">
                      {log.sshUser}@{log.hostname}:{log.port}
                    </td>
                    <td>
                      <span className="badge badge-muted">{log.purpose.replace(/_/g, " ")}</span>
                    </td>
                    <td className="truncate">{log.user?.username ?? "—"}</td>
                    <td>
                      <span className={cn("badge", outcomeBadge(log.outcome))}>{log.outcome}</span>
                    </td>
                    <td>{log.durationMs != null ? `${log.durationMs} ms` : "—"}</td>
                    <td className="truncate">
                      {log.outcome === "FAILED"
                        ? log.errorMessage ?? "—"
                        : log.exitCode != null
                          ? `exit ${log.exitCode}`
                          : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab === "api" && (
          <div className="card table-wrap flex-1 min-h-0 max-h-[calc(100vh-13rem)] overflow-auto">
            <table className="w-full" style={{ tableLayout: "fixed", ...tableFontStyle }}>
              <thead className="sticky top-0 z-10 bg-[var(--card)]">
                <tr>
                  <ResizableSortableTh
                    label="Time"
                    active={apiSort.sortKey === "createdAt"}
                    dir={apiSort.sortDir}
                    onSort={() => apiSort.toggleSort("createdAt")}
                    width={apiCols.time}
                    minWidth={120}
                    onResize={(w) => resizeApi("time", w)}
                  />
                  <ResizableSortableTh
                    label="Method"
                    active={apiSort.sortKey === "method"}
                    dir={apiSort.sortDir}
                    onSort={() => apiSort.toggleSort("method")}
                    width={apiCols.method}
                    onResize={(w) => resizeApi("method", w)}
                  />
                  <ResizableSortableTh
                    label="Path"
                    active={apiSort.sortKey === "path"}
                    dir={apiSort.sortDir}
                    onSort={() => apiSort.toggleSort("path")}
                    width={apiCols.path}
                    minWidth={160}
                    onResize={(w) => resizeApi("path", w)}
                  />
                  <ResizableSortableTh
                    label="Status"
                    active={apiSort.sortKey === "statusCode"}
                    dir={apiSort.sortDir}
                    onSort={() => apiSort.toggleSort("statusCode")}
                    width={apiCols.status}
                    onResize={(w) => resizeApi("status", w)}
                  />
                  <ResizableSortableTh
                    label="Duration"
                    active={apiSort.sortKey === "durationMs"}
                    dir={apiSort.sortDir}
                    onSort={() => apiSort.toggleSort("durationMs")}
                    width={apiCols.duration}
                    onResize={(w) => resizeApi("duration", w)}
                  />
                  <ResizableSortableTh
                    label="User"
                    active={apiSort.sortKey === "user"}
                    dir={apiSort.sortDir}
                    onSort={() => apiSort.toggleSort("user")}
                    width={apiCols.user}
                    onResize={(w) => resizeApi("user", w)}
                  />
                  <ResizableSortableTh
                    label="Client IP"
                    active={apiSort.sortKey === "ipAddress"}
                    dir={apiSort.sortDir}
                    onSort={() => apiSort.toggleSort("ipAddress")}
                    width={apiCols.ip}
                    onResize={(w) => resizeApi("ip", w)}
                  />
                </tr>
              </thead>
              <tbody>
                {apiSort.sorted.map((log) => (
                  <tr key={log.id}>
                    <td className="whitespace-nowrap truncate">{formatDate(log.createdAt)}</td>
                    <td>
                      <span className="badge badge-muted">{log.method}</span>
                    </td>
                    <td className="font-mono truncate">
                      {log.path}
                      {log.query && <span className="block text-xs opacity-60 truncate">?{log.query}</span>}
                    </td>
                    <td>
                      <span className={cn("badge", statusBadge(log.statusCode))}>{log.statusCode}</span>
                    </td>
                    <td>{log.durationMs} ms</td>
                    <td className="truncate">{log.user?.username ?? "—"}</td>
                    <td className="truncate">{log.ipAddress ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <p className="text-xs shrink-0" style={{ color: "var(--muted)" }}>
          Drag column edges to resize. Widths are saved per tab in this browser. Click an audit row for
          full details.
        </p>

        <SlideOver
          open={selectedAudit !== null}
          title="Audit entry"
          description={selectedAudit ? formatDate(selectedAudit.createdAt) : undefined}
          onClose={() => setSelectedAudit(null)}
          width="max-w-2xl"
        >
          {selectedAudit && (
            <div className="space-y-4 text-sm">
              <AuditDetailGrid entry={selectedAudit} />
            </div>
          )}
        </SlideOver>
      </PageContainer>
    </AppShell>
  );
}
