"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { PageContainer } from "@/components/page-container";
import { formatDate } from "@/lib/utils";
import { RefreshCw } from "lucide-react";
import type { SystemProfile } from "@/lib/admin/system-profile";
import { AboutBuildInfo } from "@/components/about-build-info";
import { AdminMaintenancePanel } from "@/components/admin-maintenance-panel";

export default function SystemProfilePage() {
  const [user, setUser] = useState<{ username: string; role: string } | null>(null);
  const [profile, setProfile] = useState<SystemProfile | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [diagText, setDiagText] = useState("");
  const [diagLoading, setDiagLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    const [meRes, profileRes] = await Promise.all([
      fetch("/api/auth/me"),
      fetch("/api/admin/system-profile"),
    ]);
    if (meRes.ok) setUser((await meRes.json()).user);
    if (profileRes.ok) {
      setProfile((await profileRes.json()).profile);
    } else {
      const data = await profileRes.json().catch(() => ({}));
      setError(data.error ?? "Failed to load system profile");
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function loadMemoryDiagnostics() {
    setDiagLoading(true);
    setDiagText("");
    try {
      const res = await fetch("/api/admin/memory-diagnostics?format=text");
      if (res.ok) {
        setDiagText(await res.text());
      } else {
        setDiagText("Failed to load diagnostics.");
      }
    } finally {
      setDiagLoading(false);
    }
  }

  if (!user) return <div className="p-8">Loading...</div>;
  if (user.role !== "ADMIN") {
    return (
      <AppShell user={user}>
        <div className="card p-6">Admin access required.</div>
      </AppShell>
    );
  }

  return (
    <AppShell user={user}>
      <PageContainer className="max-w-4xl">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">System profile</h1>
            <p style={{ color: "var(--muted)" }}>
              Runtime health, database size, and load hints for this console instance.
            </p>
          </div>
          <button type="button" className="btn btn-secondary" onClick={load} disabled={loading}>
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>

        {error && (
          <div className="card p-4 text-sm" style={{ color: "var(--danger)" }}>
            {error}
          </div>
        )}

        <AboutBuildInfo title="About this console" />

        <AdminMaintenancePanel />

        {profile && (
          <>
            <p className="text-xs" style={{ color: "var(--muted)" }}>
              Snapshot: {formatDate(profile.generatedAt)}
            </p>

            {profile.hints.length > 0 && (
              <div className="card p-4 space-y-2 border-l-4" style={{ borderColor: "var(--warning)" }}>
                <h2 className="font-semibold text-sm">Performance hints</h2>
                <ul className="text-sm list-disc pl-5 space-y-1">
                  {profile.hints.map((hint) => (
                    <li key={hint}>{hint}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="grid md:grid-cols-2 gap-4">
              <StatCard title="Process">
                <StatRow label="Uptime" value={`${profile.process.uptimeSec}s`} />
                <StatRow label="Node" value={profile.process.nodeVersion} />
                <StatRow label="Platform" value={profile.process.platform} />
                <StatRow label="PID" value={String(profile.process.pid)} />
                <StatRow
                  label="Embedded worker"
                  value={profile.process.embeddedWorker ? "Yes" : "No"}
                />
                <StatRow label="NODE_ENV" value={profile.process.nodeEnv} />
              </StatCard>
              <StatCard title="Memory">
                <StatRow label="RSS" value={`${profile.memory.rssMb} MB`} />
                <StatRow label="Heap used" value={`${profile.memory.heapUsedMb} MB`} />
                <StatRow label="Heap total" value={`${profile.memory.heapTotalMb} MB`} />
                <StatRow label="External" value={`${profile.memory.externalMb} MB`} />
              </StatCard>
              <StatCard title="SQLite">
                <StatRow label="Ping" value={`${profile.database.pingMs} ms`} />
                <StatRow
                  label="File size"
                  value={
                    profile.database.fileSizeMb != null
                      ? `${profile.database.fileSizeMb} MB`
                      : "—"
                  }
                />
                {profile.database.filePath && (
                  <p className="text-xs font-mono mt-2 break-all" style={{ color: "var(--muted)" }}>
                    {profile.database.filePath}
                  </p>
                )}
              </StatCard>
              <StatCard title="Row counts">
                <StatRow label="Servers" value={String(profile.database.counts.servers)} />
                <StatRow label="Command runs" value={String(profile.database.counts.commandRuns)} />
                <StatRow
                  label="Pending / running"
                  value={`${profile.database.counts.commandRunsPending} / ${profile.database.counts.commandRunsRunning}`}
                />
                <StatRow label="Audit logs" value={String(profile.database.counts.auditLogs)} />
                <StatRow
                  label="Remote SSH logs"
                  value={String(profile.database.counts.remoteConnectionLogs)}
                />
                <StatRow label="API logs" value={String(profile.database.counts.apiRequestLogs)} />
              </StatCard>
              <StatCard title="Live run streams">
                <StatRow label="Active buffers" value={String(profile.runtime.activeRunStreams)} />
                <StatRow label="SSE listeners" value={String(profile.runtime.runStreamListeners)} />
                <StatRow
                  label="Buffered events"
                  value={String(profile.runtime.bufferedStreamEvents)}
                />
                <StatRow
                  label="Buffered chars"
                  value={String(profile.runtime.bufferedStreamChars)}
                />
                <StatRow
                  label="Background timers"
                  value={String(profile.runtime.backgroundTimers)}
                />
              </StatCard>
            </div>

            <div className="card p-4 text-sm" style={{ color: "var(--muted)" }}>
              <p>
                If the UI feels slow, check large <strong>API logs</strong> (every page poll writes
                rows), heavy <strong>Commands</strong> auto-refresh, or run{" "}
                <strong>health checks</strong> that trigger apt metadata updates. This release pauses
                background polling when the tab is hidden and refreshes runs separately from static data.
              </p>
            </div>

            <div className="card p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="font-semibold">Memory diagnostics</h2>
                <button
                  type="button"
                  className="btn btn-secondary text-sm"
                  disabled={diagLoading}
                  onClick={() => void loadMemoryDiagnostics()}
                >
                  {diagLoading ? "Collecting…" : "Generate report"}
                </button>
              </div>
              <p className="text-sm" style={{ color: "var(--muted)" }}>
                V8 heap spaces, active handles, MCC stream buffers, and DB output totals. Also run
                offline: <code className="font-mono text-xs">npm run memory:report</code>
              </p>
              {diagText ? (
                <pre
                  className="text-xs overflow-auto max-h-[28rem] p-3 rounded border font-mono"
                  style={{ borderColor: "var(--card-border)", background: "var(--background)" }}
                >
                  {diagText}
                </pre>
              ) : null}
            </div>
          </>
        )}
      </PageContainer>
    </AppShell>
  );
}

function StatCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="card p-4 space-y-2">
      <h2 className="font-semibold">{title}</h2>
      {children}
    </div>
  );
}

function StatRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4 text-sm">
      <span style={{ color: "var(--muted)" }}>{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
