"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { PageContainer } from "@/components/page-container";
import { Database, Download, Upload, Plus, Trash2, Save } from "lucide-react";

interface TableMeta {
  id: string;
  label: string;
  description: string;
  idField: string;
  canCreate: boolean;
  canDelete: boolean;
}

export default function AdminDatabasePage() {
  const [user, setUser] = useState<{ username: string; role: string } | null>(null);
  const [tables, setTables] = useState<TableMeta[]>([]);
  const [activeTable, setActiveTable] = useState<string>("appSetting");
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [meta, setMeta] = useState<TableMeta | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [editor, setEditor] = useState("{}");
  const [error, setError] = useState("");
  const [backupConfigured, setBackupConfigured] = useState(false);
  const [backupPassword, setBackupPassword] = useState("");
  const [restorePassword, setRestorePassword] = useState("");
  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [status, setStatus] = useState("");
  const [restoreNeedsRestart, setRestoreNeedsRestart] = useState(false);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => setUser(d.user));
    fetch("/api/admin/database/tables")
      .then((r) => r.json())
      .then((d) => setTables(d.tables ?? []));
    fetch("/api/admin/database/backup")
      .then((r) => r.json())
      .then((d) => setBackupConfigured(Boolean(d.backupPasswordConfigured)));
  }, []);

  const loadTable = useCallback(async (tableId: string) => {
    setError("");
    const res = await fetch(`/api/admin/database/${tableId}`);
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Failed to load table");
      return;
    }
    setMeta(data.meta);
    setRows(data.rows ?? []);
    setSelectedId(null);
    setEditor("{}");
  }, []);

  useEffect(() => {
    if (user?.role === "ADMIN" && activeTable) loadTable(activeTable);
  }, [user, activeTable, loadTable]);

  function selectRow(row: Record<string, unknown>) {
    const idField = meta?.idField ?? "id";
    const id = String(row[idField] ?? "");
    setSelectedId(id);
    setEditor(JSON.stringify(row, null, 2));
  }

  async function saveRow() {
    if (!meta || !selectedId) return;
    setStatus("");
    try {
      const parsed = JSON.parse(editor) as Record<string, unknown>;
      const res = await fetch(`/api/admin/database/${activeTable}/${encodeURIComponent(selectedId)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Save failed");
      setStatus("Row saved.");
      await loadTable(activeTable);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Save failed");
    }
  }

  async function createRow() {
    if (!meta?.canCreate) return;
    setStatus("");
    try {
      const parsed = JSON.parse(editor) as Record<string, unknown>;
      const res = await fetch(`/api/admin/database/${activeTable}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Create failed");
      setStatus("Row created.");
      await loadTable(activeTable);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Create failed");
    }
  }

  async function deleteRow() {
    if (!meta?.canDelete || !selectedId) return;
    if (!confirm("Delete this row?")) return;
    const res = await fetch(
      `/api/admin/database/${activeTable}/${encodeURIComponent(selectedId)}`,
      { method: "DELETE" },
    );
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Delete failed");
      return;
    }
    setStatus("Row deleted.");
    await loadTable(activeTable);
  }

  async function saveBackupPassword() {
    const res = await fetch("/api/admin/database/backup", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: backupPassword }),
    });
    if (!res.ok) {
      const data = await res.json();
      setError(data.error ?? "Failed to save password");
      return;
    }
    setBackupConfigured(true);
    setBackupPassword("");
    setStatus("Backup encryption password stored (encrypted at rest).");
  }

  async function downloadBackup() {
    setStatus("");
    const res = await fetch("/api/admin/database/backup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(backupPassword ? { password: backupPassword } : {}),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Backup failed");
      return;
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `mycontrol-backup-${Date.now()}.mccdb`;
    a.click();
    URL.revokeObjectURL(url);
    setStatus("Encrypted backup downloaded.");
  }

  async function restoreBackup() {
    if (!restoreFile) {
      setError("Choose a .mccdb backup file");
      return;
    }
    if (!confirm("Replace the live database? Restart the app after restore.")) return;
    const form = new FormData();
    form.set("file", restoreFile);
    form.set("password", restorePassword);
    const res = await fetch("/api/admin/database/restore", { method: "POST", body: form });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Restore failed");
      return;
    }
    setStatus(data.message ?? "Restored.");
    setRestoreNeedsRestart(true);
  }

  if (!user) return <div className="p-8">Loading...</div>;
  if (user.role !== "ADMIN") {
    return (
      <AppShell user={user}>
        <PageContainer>
          <p>Admin only.</p>
        </PageContainer>
      </AppShell>
    );
  }

  return (
    <AppShell user={user}>
      <PageContainer className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Database className="w-8 h-8" style={{ color: "var(--primary)" }} />
            Database admin
          </h1>
          <p style={{ color: "var(--muted)" }}>
            Encrypted backup/restore and CRUD on selected SQLite tables
          </p>
        </div>

        <section className="card p-6 space-y-4">
          <h2 className="font-semibold text-lg">Encrypted backup &amp; restore</h2>
          <p className="text-sm" style={{ color: "var(--muted)" }}>
            Backups use AES-256-GCM with a password you set here (stored encrypted in the database).
            Restore replaces <code className="font-mono">.data/mycontrol.db</code> — restart the app afterward.
          </p>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Backup password (min 8 chars)</label>
              <input
                className="input"
                type="password"
                value={backupPassword}
                onChange={(e) => setBackupPassword(e.target.value)}
                placeholder={backupConfigured ? "•••••••• (configured)" : "Set password"}
              />
              <button type="button" className="btn btn-secondary text-sm" onClick={saveBackupPassword}>
                Save password for backups
              </button>
            </div>
            <div className="flex flex-wrap items-end gap-2">
              <button type="button" className="btn btn-primary text-sm" onClick={downloadBackup}>
                <Download className="w-4 h-4" />
                Download encrypted backup
              </button>
            </div>
          </div>
          <div className="grid md:grid-cols-2 gap-4 pt-2 border-t" style={{ borderColor: "var(--border)" }}>
            <div>
              <label className="text-sm font-medium">Restore file (.mccdb)</label>
              <input
                className="input mt-1"
                type="file"
                accept=".mccdb,application/octet-stream"
                onChange={(e) => setRestoreFile(e.target.files?.[0] ?? null)}
              />
            </div>
            <div>
              <label className="text-sm font-medium">Backup password</label>
              <input
                className="input mt-1"
                type="password"
                value={restorePassword}
                onChange={(e) => setRestorePassword(e.target.value)}
              />
            </div>
            <button type="button" className="btn btn-secondary text-sm md:col-span-2" onClick={restoreBackup}>
              <Upload className="w-4 h-4" />
              Restore database
            </button>
          </div>
        </section>

        {restoreNeedsRestart && (
          <div
            className="p-4 rounded-lg text-sm border"
            style={{
              borderColor: "var(--warning)",
              background: "color-mix(in srgb, var(--warning) 12%, transparent)",
            }}
            role="alert"
          >
            <strong>Restart required.</strong> The SQLite file on disk was replaced. Stop and start
            MyControl Centre (e.g. <code className="font-mono">./scripts/start.sh stop</code> then{" "}
            <code className="font-mono">./scripts/start.sh local</code>) before using the console
            again.
          </div>
        )}

        <section className="grid lg:grid-cols-[220px_1fr] gap-6">
          <div className="card p-3 space-y-1">
            {tables.map((t) => (
              <button
                key={t.id}
                type="button"
                className={`w-full text-left px-3 py-2 rounded-lg text-sm ${
                  activeTable === t.id ? "font-medium" : ""
                }`}
                style={{
                  background:
                    activeTable === t.id
                      ? "color-mix(in srgb, var(--primary) 15%, transparent)"
                      : undefined,
                }}
                onClick={() => setActiveTable(t.id)}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="space-y-4 min-w-0">
            {meta && (
              <p className="text-sm" style={{ color: "var(--muted)" }}>
                {meta.description}
              </p>
            )}
            <div className="card table-wrap max-h-64 overflow-auto">
              <table>
                <thead>
                  <tr>
                    <th>{meta?.idField ?? "id"}</th>
                    <th>Preview</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => {
                    const idField = meta?.idField ?? "id";
                    const id = String(row[idField] ?? "");
                    return (
                      <tr
                        key={id}
                        className="cursor-pointer"
                        onClick={() => selectRow(row)}
                        style={{
                          background:
                            selectedId === id
                              ? "color-mix(in srgb, var(--primary) 8%, transparent)"
                              : undefined,
                        }}
                      >
                        <td className="font-mono text-xs">{id}</td>
                        <td className="text-xs truncate max-w-md">
                          {JSON.stringify(row).slice(0, 120)}…
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="card p-4 space-y-2">
              <div className="flex flex-wrap gap-2">
                {meta?.canCreate && (
                  <button
                    type="button"
                    className="btn btn-secondary text-sm"
                    onClick={() => {
                      setSelectedId(null);
                      setEditor("{}");
                    }}
                  >
                    <Plus className="w-4 h-4" />
                    New JSON
                  </button>
                )}
                {selectedId && (
                  <button type="button" className="btn btn-primary text-sm" onClick={saveRow}>
                    <Save className="w-4 h-4" />
                    Save
                  </button>
                )}
                {!selectedId && meta?.canCreate && (
                  <button type="button" className="btn btn-primary text-sm" onClick={createRow}>
                    <Save className="w-4 h-4" />
                    Create
                  </button>
                )}
                {selectedId && meta?.canDelete && (
                  <button type="button" className="btn btn-secondary text-sm" onClick={deleteRow}>
                    <Trash2 className="w-4 h-4" />
                    Delete
                  </button>
                )}
              </div>
              <textarea
                className="input font-mono text-xs min-h-[240px] w-full"
                value={editor}
                onChange={(e) => setEditor(e.target.value)}
              />
            </div>
          </div>
        </section>

        {error && (
          <p className="text-sm" style={{ color: "var(--danger)" }} role="alert">
            {error}
          </p>
        )}
        {status && (
          <p className="text-sm" style={{ color: "var(--success)" }} role="status">
            {status}
          </p>
        )}
      </PageContainer>
    </AppShell>
  );
}
