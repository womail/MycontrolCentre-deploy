"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { PageContainer } from "@/components/page-container";
import { Lock, Unlock, Copy, Check, Trash2 } from "lucide-react";
import { CopyCommandBlock } from "@/components/copy-command-block";
import { buildRemoteCleanupCommand } from "@/lib/setup/remote-cleanup";
import { startAuthentication } from "@simplewebauthn/browser";
import { formatDate } from "@/lib/utils";
import { vaultClientHeaders, getVaultClientNode, setVaultClientNode, vaultClientLabel } from "@/lib/vault/client-label";

type UnlockMode = "vault" | "account";

interface VaultLastAccess {
  at: string;
  action: "VIEW" | "COPY";
  username: string;
  machine: string;
  clientNode: string;
  targetNode: string | null;
}

interface VaultServerEntry {
  id: string;
  name: string;
  hostname: string;
  port: number;
  sshUser: string;
  authType: string;
  privateKey: string | null;
  password: string | null;
  knownHostKey: string | null;
  derivedPublicKey: string | null;
  storedKeyFingerprint: string | null;
  opensshFingerprint: string | null;
  matchesSetupWizardKey: boolean;
  lastAccess: VaultLastAccess | null;
}

interface SetupKeyHostLink {
  kind: "fleet" | "enrollment_pending" | "enrollment_approved" | "enrollment_rejected";
  label: string;
  hostname: string;
  port: number;
  sshUser: string;
  serverId?: string;
  enrollmentId?: string;
  statusNote?: string;
}

interface VaultSetupKey {
  id: string;
  publicKey: string;
  fingerprint: string;
  privateKey: string;
  createdAt: string;
  expiresAt: string;
  wizardHosts: SetupKeyHostLink[];
  keyPairConsistent: boolean;
  opensshFingerprint: string | null;
  lastAccess: VaultLastAccess | null;
}

export default function AdminVaultPage() {
  const [user, setUser] = useState<{ username: string; role: string } | null>(null);
  const [configured, setConfigured] = useState(true);
  const [unlocked, setUnlocked] = useState(false);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [servers, setServers] = useState<VaultServerEntry[]>([]);
  const [setupKeys, setSetupKeys] = useState<VaultSetupKey[]>([]);
  const [consoleUrl, setConsoleUrl] = useState("");
  const [vaultMessage, setVaultMessage] = useState("");
  const [unlockMode, setUnlockMode] = useState<UnlockMode>("vault");
  const [totpCode, setTotpCode] = useState("");
  const [accountUnlock, setAccountUnlock] = useState({ totp: false, webauthn: false });
  const [clientNodeName, setClientNodeName] = useState("");

  useEffect(() => {
    setClientNodeName(getVaultClientNode());
  }, []);

  const load = useCallback(async () => {
    const vaultHeaders = vaultClientHeaders();
    const [meRes, vaultRes] = await Promise.all([
      fetch("/api/auth/me"),
      fetch("/api/admin/vault", { headers: vaultHeaders }),
    ]);
    if (meRes.ok) setUser((await meRes.json()).user);
    if (vaultRes.ok) {
      const data = await vaultRes.json();
      setConfigured(data.configured !== false);
      setUnlocked(Boolean(data.unlocked));
      setServers(data.entries?.servers ?? []);
      setSetupKeys(data.entries?.setupKeys ?? []);
      if (data.accountUnlock) setAccountUnlock(data.accountUnlock);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    async function loadUrl() {
      const fromWindow = typeof window !== "undefined" ? window.location.origin : "";
      try {
        const res = await fetch("/api/settings");
        if (res.ok) {
          const data = await res.json();
          setConsoleUrl(data.consolePublicUrl || fromWindow);
          return;
        }
      } catch {
        /* fallback */
      }
      setConsoleUrl(fromWindow);
    }
    void loadUrl();
  }, []);

  async function unlock(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await fetch("/api/admin/vault", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        password,
        totpCode: unlockMode === "account" ? totpCode : undefined,
      }),
    });
    setLoading(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Unlock failed");
      return;
    }
    setPassword("");
    setTotpCode("");
    await load();
  }

  async function unlockWithKey() {
    setLoading(true);
    setError("");
    try {
      const optRes = await fetch("/api/admin/vault/webauthn/options", { method: "POST" });
      const options = await optRes.json();
      if (!optRes.ok) throw new Error(options.error ?? "Options failed");
      const assertion = await startAuthentication({ optionsJSON: options });
      const res = await fetch("/api/admin/vault", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          password,
          webauthnResponse: assertion,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Unlock failed");
      setPassword("");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Security key failed");
    } finally {
      setLoading(false);
    }
  }

  async function lock() {
    await fetch("/api/admin/vault", { method: "DELETE" });
    setUnlocked(false);
    setServers([]);
    setSetupKeys([]);
  }

  async function deleteSetupKey(id: string) {
    if (!confirm("Delete this setup key from the database? You cannot recover it from the vault.")) return;
    setVaultMessage("");
    const res = await fetch(`/api/admin/vault/setup-keys/${id}`, { method: "DELETE" });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setVaultMessage(data.error ?? "Delete failed");
      return;
    }
    await load();
  }

  async function purgeSetupKeys(scope: "expired" | "all") {
    const label = scope === "all" ? "all setup wizard keys" : "expired setup keys";
    if (!confirm(`Permanently delete ${label}?`)) return;
    setVaultMessage("");
    const res = await fetch(`/api/admin/vault/setup-keys?scope=${scope}`, { method: "DELETE" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setVaultMessage(data.error ?? "Delete failed");
      return;
    }
    setVaultMessage(`Removed ${data.deleted ?? 0} setup key(s).`);
    await load();
  }

  const appBase = consoleUrl.trim() || (typeof window !== "undefined" ? window.location.origin : "");

  if (!user) return <div className="p-8">Loading...</div>;
  if (user.role !== "ADMIN") {
    return (
      <AppShell user={user}>
        <div className="card p-6">Admin access required.</div>
      </AppShell>
    );
  }

  return (
    <AppShell user={user}>
      <PageContainer className="max-w-4xl space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Secrets vault</h1>
          <p style={{ color: "var(--muted)" }}>
            Credentials are encrypted in the database. Unlock with the shared{" "}
            <code className="text-xs">SECRETS_VAULT_PASSWORD</code>, or with your account password plus
            TOTP / security key if enrolled under Security.
          </p>
        </div>

        {!configured && (
          <div className="card p-6 text-sm" style={{ color: "var(--warning)" }}>
            Set <strong>SECRETS_VAULT_PASSWORD</strong> in the server environment to enable the vault.
          </div>
        )}

        {configured && !unlocked && (
          <form onSubmit={unlock} className="card p-6 space-y-4 max-w-lg">
            <h2 className="font-semibold flex items-center gap-2">
              <Lock className="w-4 h-4" /> Vault locked
            </h2>
            <div className="flex gap-2">
              <button
                type="button"
                className={unlockMode === "vault" ? "btn btn-primary text-sm" : "btn btn-secondary text-sm"}
                onClick={() => setUnlockMode("vault")}
              >
                Vault password
              </button>
              {(accountUnlock.totp || accountUnlock.webauthn) && (
                <button
                  type="button"
                  className={unlockMode === "account" ? "btn btn-primary text-sm" : "btn btn-secondary text-sm"}
                  onClick={() => setUnlockMode("account")}
                >
                  Account + MFA
                </button>
              )}
            </div>
            <input
              type="password"
              className="input"
              placeholder={unlockMode === "vault" ? "SECRETS_VAULT_PASSWORD" : "Your account password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="off"
            />
            {unlockMode === "account" && accountUnlock.totp && (
              <input
                className="input font-mono"
                placeholder="6-digit authenticator code"
                value={totpCode}
                onChange={(e) => setTotpCode(e.target.value)}
                autoComplete="one-time-code"
              />
            )}
            {error && (
              <p className="text-sm" style={{ color: "var(--danger)" }}>
                {error}
              </p>
            )}
            <div className="flex flex-wrap gap-2">
              <button type="submit" className="btn btn-primary" disabled={loading}>
                <Unlock className="w-4 h-4" />
                Unlock
              </button>
              {unlockMode === "account" && accountUnlock.webauthn && (
                <button
                  type="button"
                  className="btn btn-secondary"
                  disabled={loading || !password}
                  onClick={() => void unlockWithKey()}
                >
                  Use security key
                </button>
              )}
            </div>
          </form>
        )}

        {configured && unlocked && (
          <>
            <div className="flex flex-wrap gap-2 items-center">
              <span className="badge badge-success">Unlocked (15 min)</span>
              <button type="button" className="btn btn-secondary text-sm" onClick={() => void lock()}>
                <Lock className="w-4 h-4" />
                Lock now
              </button>
            </div>
            {vaultMessage && (
              <p className="text-sm" style={{ color: "var(--success)" }}>
                {vaultMessage}
              </p>
            )}

            <div className="card p-4 max-w-lg space-y-2">
              <label className="text-sm font-medium">This computer&apos;s node name (optional)</label>
              <p className="text-xs" style={{ color: "var(--muted)" }}>
                Shown in vault access history (e.g. your PC or laptop hostname). Saved in this browser only.
                If empty, the server tries reverse DNS on your IP.
              </p>
              <div className="flex gap-2">
                <input
                  className="input text-sm font-mono flex-1"
                  placeholder="will-laptop"
                  value={clientNodeName}
                  onChange={(e) => setClientNodeName(e.target.value)}
                  onBlur={() => setVaultClientNode(clientNodeName)}
                />
                <button
                  type="button"
                  className="btn btn-secondary text-sm"
                  onClick={() => setVaultClientNode(clientNodeName)}
                >
                  Save
                </button>
              </div>
            </div>

            <section className="card p-6 space-y-4">
              <h2 className="font-semibold">Production cleanup</h2>
              <p className="text-sm" style={{ color: "var(--muted)" }}>
                Before go-live: delete wizard keys stored in the database, then run the remote cleanup on
                each host as <strong>root</strong> to revoke the automation user&apos;s key and sudoers file.
              </p>
              {appBase && setupKeys[0] && (
                <CopyCommandBlock
                  prominent
                  title="Run on the remote host (uses the newest setup public key)"
                  command={buildRemoteCleanupCommand(appBase, {
                    publicKey: setupKeys[0].publicKey,
                    removeUser: false,
                  })}
                />
              )}
              <CopyCommandBlock
                prominent
                title="Full removal on host (delete mcc-auto user — destructive)"
                description="Only after removing the server from Fleet or when decommissioning the host."
                command={
                  appBase && setupKeys[0]
                    ? buildRemoteCleanupCommand(appBase, {
                        publicKey: setupKeys[0].publicKey,
                        removeUser: true,
                      })
                    : `# Generate from a setup key after unlock, or:\ncurl -fsSL '${appBase}/api/setup/proxmox-host-cleanup.sh?raw=1' -o /tmp/mcc-proxmox-cleanup.sh\nsudo bash /tmp/mcc-proxmox-cleanup.sh --pubkey 'YOUR_PUBLIC_KEY' --remove-user`
                }
              />
            </section>

            <section className="card p-6 space-y-4">
              <h2 className="font-semibold">Server connections ({servers.length})</h2>
              {servers.length === 0 ? (
                <p className="text-sm" style={{ color: "var(--muted)" }}>
                  No servers configured.
                </p>
              ) : (
                <ul className="space-y-4">
                  {servers.map((s) => (
                    <li key={s.id} className="border rounded-lg p-4 space-y-2" style={{ borderColor: "var(--card-border)" }}>
                      <div className="font-medium">
                        {s.name}{" "}
                        <span className="text-sm font-normal" style={{ color: "var(--muted)" }}>
                          {s.sshUser}@{s.hostname}:{s.port}
                        </span>
                      </div>
                      <VaultLastAccessLine access={s.lastAccess} />
                      {s.opensshFingerprint && (
                        <div className="space-y-2 text-xs" style={{ color: "var(--muted)" }}>
                          <p className="font-mono">
                            <span className="font-sans font-medium" style={{ color: "var(--foreground)" }}>
                              Login key fingerprint{" "}
                            </span>
                            (same as{" "}
                            <code className="font-mono">ssh-keygen -lf authorized_keys</code> on the host):{" "}
                            {s.opensshFingerprint}
                          </p>
                          <CopyCommandBlock
                            title="On the host — list fingerprints in authorized_keys"
                            command={`sudo ssh-keygen -lf /home/${s.sshUser}/.ssh/authorized_keys 2>/dev/null || echo 'No authorized_keys'`}
                          />
                          <p>
                            Exactly one line in <code className="font-mono">authorized_keys</code> should match the
                            fingerprint above. Extra lines from old wizard runs cause &quot;auth failed&quot; if MCC still
                            holds a different private key.
                          </p>
                        </div>
                      )}
                      {s.derivedPublicKey && (
                        <div className="space-y-1">
                          <p className="text-xs font-mono break-all" style={{ color: "var(--muted)" }}>
                            Stored key (public line for authorized_keys):
                          </p>
                          <CopyCommandBlock
                            title="Copy public line"
                            command={s.derivedPublicKey}
                          />
                        </div>
                      )}
                      {s.storedKeyFingerprint && (
                        <p className="text-xs" style={{ color: "var(--muted)" }}>
                          {s.matchesSetupWizardKey ? (
                            <span className="badge badge-success">Same key as an active wizard entry</span>
                          ) : (
                            <span className="badge badge-muted">
                              Not in wizard storage (normal once servers are enrolled — compare OpenSSH
                              fingerprint to the host)
                            </span>
                          )}
                        </p>
                      )}
                      {s.privateKey && (
                        <SecretBlock
                          label="Private key"
                          value={s.privateKey}
                          entryType="SERVER"
                          entryId={s.id}
                          entryLabel={s.name}
                          onAccessLogged={load}
                        />
                      )}
                      {s.password && (
                        <SecretBlock
                          label="Password"
                          value={s.password}
                          mono
                          entryType="SERVER"
                          entryId={s.id}
                          entryLabel={s.name}
                          onAccessLogged={load}
                        />
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <section className="card p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="font-semibold">Setup wizard keys ({setupKeys.length})</h2>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    className="btn btn-secondary text-xs"
                    onClick={() => void purgeSetupKeys("expired")}
                  >
                    Delete expired
                  </button>
                  <button
                    type="button"
                    className="btn btn-danger text-xs"
                    onClick={() => void purgeSetupKeys("all")}
                  >
                    Delete all
                  </button>
                </div>
              </div>
              <p className="text-xs" style={{ color: "var(--muted)" }}>
                Unused keys from <strong>Setup &amp; add → Generate key</strong> (for enrollment approve).
                Your {servers.length} fleet servers keep their keys under <strong>Server connections</strong> above
                — not here. After approve, wizard rows are removed; that is expected.
              </p>
              {setupKeys.length === 0 ? (
                <p className="text-sm" style={{ color: "var(--muted)" }}>
                  No active setup keys in storage.
                </p>
              ) : (
                <ul className="space-y-4">
                  {setupKeys.map((k) => {
                    const expired = new Date(k.expiresAt).getTime() < Date.now();
                    return (
                    <li key={k.id} className="border rounded-lg p-4 space-y-2" style={{ borderColor: "var(--card-border)" }}>
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="text-xs font-mono space-y-1" style={{ color: "var(--muted)" }}>
                          {k.opensshFingerprint && <div>{k.opensshFingerprint}</div>}
                          <div>MCC id: {k.fingerprint}</div>
                          {expired && <span className="badge badge-muted ml-2">Expired</span>}
                        </div>
                        <button
                          type="button"
                          className="btn btn-danger text-xs py-1 px-2"
                          onClick={() => void deleteSetupKey(k.id)}
                        >
                          <Trash2 className="w-3 h-3" />
                          Delete
                        </button>
                      </div>
                      <VaultLastAccessLine access={k.lastAccess} />
                      {!k.keyPairConsistent && (
                        <p className="text-xs text-amber-600">
                          Warning: stored public line and private key fingerprint do not match — regenerate
                          or delete this wizard key.
                        </p>
                      )}
                      <SetupKeyHostsList hosts={k.wizardHosts} />
                      <p className="text-xs" style={{ color: "var(--muted)" }}>
                        Generated {formatDate(k.createdAt)} · expires {formatDate(k.expiresAt)}
                      </p>
                      {appBase && (
                        <CopyCommandBlock
                          prominent
                          title="Remote cleanup for this key"
                          command={buildRemoteCleanupCommand(appBase, { publicKey: k.publicKey })}
                        />
                      )}
                      <SecretBlock label="Public key" value={k.publicKey} mono entryType="SETUP_KEY" entryId={k.id} entryLabel={k.fingerprint} onAccessLogged={load} />
                      <SecretBlock label="Private key" value={k.privateKey} entryType="SETUP_KEY" entryId={k.id} entryLabel={k.fingerprint} onAccessLogged={load} />
                    </li>
                  );})}
                </ul>
              )}
            </section>
          </>
        )}
      </PageContainer>
    </AppShell>
  );
}

function SetupKeyHostsList({ hosts }: { hosts: SetupKeyHostLink[] }) {
  if (hosts.length === 0) {
    return (
      <p className="text-xs" style={{ color: "var(--muted)" }}>
        No linked hosts yet — run the install command on a machine (or complete enrollment) with this
        public key.
      </p>
    );
  }
  return (
    <div className="text-xs space-y-1">
      <p className="font-medium">Wizard key used on</p>
      <ul className="list-disc pl-4 space-y-1" style={{ color: "var(--muted)" }}>
        {hosts.map((h) => (
          <li key={`${h.kind}-${h.enrollmentId ?? h.serverId ?? h.hostname}`}>
            <strong>{h.label}</strong> — {h.sshUser}@{h.hostname}:{h.port}
            {h.kind === "fleet" && <span className="badge badge-success ml-1">Fleet</span>}
            {h.kind === "enrollment_pending" && (
              <span className="badge badge-warning ml-1">Pending approval</span>
            )}
            {h.kind === "enrollment_approved" && (
              <span className="badge badge-muted ml-1">Enrolled</span>
            )}
            {h.statusNote && <span className="block opacity-90">{h.statusNote}</span>}
          </li>
        ))}
      </ul>
    </div>
  );
}

function VaultLastAccessLine({ access }: { access: VaultLastAccess | null }) {
  if (!access) {
    return (
      <p className="text-xs" style={{ color: "var(--muted)" }}>
        No recorded access yet
      </p>
    );
  }
  const verb = access.action === "COPY" ? "Copied" : "Viewed";
  return (
    <p className="text-xs" style={{ color: "var(--muted)" }}>
      Last used: {verb} by <strong>{access.username}</strong> · {formatDate(access.at)}
      {access.targetNode && (
        <>
          {" "}
          · Server node: <strong>{access.targetNode}</strong>
        </>
      )}
      {" "}
      · From node: <strong>{access.clientNode}</strong>
      <span className="opacity-80"> · {access.machine}</span>
    </p>
  );
}

function SecretBlock({
  label,
  value,
  mono,
  entryType,
  entryId,
  entryLabel,
  onAccessLogged,
}: {
  label: string;
  value: string;
  mono?: boolean;
  entryType: "SERVER" | "SETUP_KEY";
  entryId: string;
  entryLabel: string;
  onAccessLogged?: () => void;
}) {
  const [copied, setCopied] = useState(false);
  async function copy() {
    await navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    void fetch("/api/admin/vault/access", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        entryType,
        entryId,
        entryLabel,
        action: "COPY",
        clientLabel: vaultClientLabel(),
        clientNode: getVaultClientNode() || undefined,
      }),
    }).then(() => onAccessLogged?.());
  }
  return (
    <div>
      <div className="flex items-center justify-between gap-2 mb-1">
        <span className="text-xs font-medium">{label}</span>
        <button type="button" className="btn btn-secondary text-xs py-0.5 px-2" onClick={copy}>
          {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre className={`output text-xs max-h-40 overflow-auto ${mono ? "whitespace-pre-wrap break-all" : ""}`}>
        {value}
      </pre>
    </div>
  );
}
