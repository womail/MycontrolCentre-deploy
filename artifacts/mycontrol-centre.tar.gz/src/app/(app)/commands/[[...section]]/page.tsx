"use client";

import { Suspense, useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams, useParams } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { PageContainer } from "@/components/page-container";
import {
  CommandRunPanel,
  CommandTemplateManager,
  type CommandTemplate,
  type ServerOption,
} from "@/components/command-manager";
import { SavedRunProfilesPanel, BatchComparisonPanel } from "@/components/command-operations";
import { DockerOperationsPanel } from "@/components/docker-operations";
import { LiveRunOutput } from "@/components/live-run-output";
import { formatDate } from "@/lib/utils";
import { RefreshCw } from "lucide-react";
import type { ServerGroupSummary } from "@/components/server-groups-panel";
import { pickPackageUpdateTemplateIds } from "@/lib/updates/package-update-templates";
import { useVisibleInterval } from "@/lib/hooks/use-visible-interval";
import {
  parseCommandSection,
  isValidCommandSectionPath,
  commandSectionHref,
  sectionPartsFromParams,
} from "@/lib/navigation/sections";

interface CommandRunSummary {
  id: string;
  batchId: string | null;
  commandType: string;
  label: string | null;
  changeReason: string | null;
  commandText: string;
  status: string;
  exitCode: number | null;
  durationMs: number | null;
  createdAt: string;
  server: { name: string };
  user: { username: string };
}

interface CommandRunDetail extends CommandRunSummary {
  stdout: string;
  stderr: string;
}


export default function CommandsPage() {
  return (
    <Suspense fallback={<div className="p-8">Loading...</div>}>
      <CommandsPageContent />
    </Suspense>
  );
}

function CommandsPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const routeSection = useParams().section;
  const sectionParts = useMemo(
    () => sectionPartsFromParams(routeSection as string | string[] | undefined),
    [routeSection],
  );
  const tab = parseCommandSection(sectionParts);

  const [user, setUser] = useState<{ username: string; role: string } | null>(null);
  const [servers, setServers] = useState<ServerOption[]>([]);
  const [serverGroups, setServerGroups] = useState<ServerGroupSummary[]>([]);
  const [templates, setTemplates] = useState<CommandTemplate[]>([]);
  const [runs, setRuns] = useState<CommandRunSummary[]>([]);
  const [selectedRun, setSelectedRun] = useState<CommandRunDetail | null>(null);

  const [serversError, setServersError] = useState("");
  const [runPreset, setRunPreset] = useState<{
    serverIds: string[];
    templateIds: string[];
  } | null>(null);
  const [presetMessage, setPresetMessage] = useState("");

  const loadStatic = useCallback(async () => {
    const [meRes, serversRes, templatesRes, groupsRes] = await Promise.all([
      fetch("/api/auth/me"),
      fetch("/api/servers"),
      fetch("/api/commands/templates"),
      fetch("/api/server-groups"),
    ]);
    if (meRes.ok) setUser((await meRes.json()).user);
    if (serversRes.ok) {
      setServersError("");
      const data = await serversRes.json();
      setServers(
        data.servers
          .filter((server: ServerOption & { isActive?: boolean }) => server.isActive !== false)
          .map((server: ServerOption & { inMaintenance?: boolean; maintenanceNote?: string | null; platforms?: string[] }) => ({
            id: server.id,
            name: server.name,
            hostname: server.hostname,
            healthStatus: server.healthStatus,
            inMaintenance: server.inMaintenance,
            maintenanceNote: server.maintenanceNote,
            platforms: server.platforms as ServerOption["platforms"],
          })),
      );
    } else {
      const data = await serversRes.json().catch(() => ({}));
      setServers([]);
      setServersError(data.error ?? `Failed to load servers (${serversRes.status})`);
    }
    if (templatesRes.ok) {
      setTemplates((await templatesRes.json()).templates);
    }
    if (groupsRes.ok) {
      setServerGroups((await groupsRes.json()).groups ?? []);
    } else {
      setServerGroups([]);
    }
  }, []);

  const loadRuns = useCallback(async () => {
    const runsRes = await fetch("/api/commands/runs?limit=30");
    if (runsRes.ok) {
      const nextRuns = (await runsRes.json()).runs as CommandRunSummary[];
      setRuns(nextRuns);
      return nextRuns;
    }
    return [];
  }, []);

  const load = useCallback(async () => {
    await loadStatic();
    return loadRuns();
  }, [loadStatic, loadRuns]);

  const selectRunById = useCallback(async (runId: string) => {
    const res = await fetch(`/api/commands/runs/${runId}`);
    if (res.ok) setSelectedRun((await res.json()).run);
  }, []);

  const handleRan = useCallback(
    async (result?: { runs?: Array<{ id: string }> }) => {
      await load();
      if (result?.runs?.[0]?.id) {
        await selectRunById(result.runs[0].id);
      }
    },
    [load, selectRunById],
  );

  useEffect(() => {
    void load();
  }, [load]);

  useVisibleInterval(() => void loadRuns(), 8000);
  useVisibleInterval(() => void loadStatic(), 60_000);

  useEffect(() => {
    if (!isValidCommandSectionPath(sectionParts)) {
      router.replace("/commands");
    }
  }, [router, sectionParts]);

  useEffect(() => {
    const serverId = searchParams.get("runUpdates");
    if (!serverId) return;
    if (servers.length === 0 || templates.length === 0) return;

    if (tab !== "run") {
      router.replace(`/commands?runUpdates=${encodeURIComponent(serverId)}`, { scroll: false });
      return;
    }

    const server = servers.find((entry) => entry.id === serverId);
    if (!server) {
      setPresetMessage("Server not found or inactive.");
      router.replace("/commands", { scroll: false });
      return;
    }

    const templateIds = pickPackageUpdateTemplateIds(server, templates);
    if (templateIds.length === 0) {
      setPresetMessage("No package update commands match this server's platforms.");
      router.replace("/commands", { scroll: false });
      return;
    }

    setPresetMessage("");
    setRunPreset({ serverIds: [serverId], templateIds });
    router.replace("/commands", { scroll: false });
  }, [searchParams, servers, templates, router, tab]);

  if (!user) return <div className="p-8">Loading...</div>;

  const isAdmin = user.role === "ADMIN";
  const canRun = user.role === "ADMIN" || user.role === "OPERATOR";

  return (
    <AppShell user={user}>
      <PageContainer>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Commands</h1>
            <p style={{ color: "var(--muted)" }}>
              Run command sequences on selected Proxmox hosts
            </p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Link
              href={commandSectionHref("run")}
              className={`btn ${tab === "run" ? "btn-primary" : "btn-secondary"}`}
            >
              Run
            </Link>
            <Link
              href={commandSectionHref("docker")}
              className={`btn ${tab === "docker" ? "btn-primary" : "btn-secondary"}`}
            >
              Docker
            </Link>
            <Link
              href={commandSectionHref("profiles")}
              className={`btn ${tab === "profiles" ? "btn-primary" : "btn-secondary"}`}
            >
              Profiles
            </Link>
            <Link
              href={commandSectionHref("batches")}
              className={`btn ${tab === "batches" ? "btn-primary" : "btn-secondary"}`}
            >
              Batch compare
            </Link>
            {isAdmin && (
              <Link
                href={commandSectionHref("manage")}
                className={`btn ${tab === "manage" ? "btn-primary" : "btn-secondary"}`}
              >
                Manage commands
              </Link>
            )}
          </div>
        </div>

        {tab === "run" ? (
          <>
            {serversError && (
              <div className="card p-4 text-sm" style={{ color: "var(--danger)" }}>
                {serversError}. Try running <code className="font-mono">npm run db:repair</code> and refresh.
              </div>
            )}
            {presetMessage && (
              <div className="card p-4 text-sm" style={{ color: "var(--danger)" }}>
                {presetMessage}
              </div>
            )}
            <CommandRunPanel
            templates={templates.filter((template) => !template.adminOnly || isAdmin)}
            servers={servers}
            serverGroups={serverGroups}
            canRun={canRun}
            isAdmin={isAdmin}
            onRan={handleRan}
            initialServerIds={runPreset?.serverIds}
            initialTemplateIds={runPreset?.templateIds}
          />
          </>
        ) : tab === "docker" && canRun ? (
          <DockerOperationsPanel
            servers={servers}
            templates={templates.filter((template) => template.isActive && (!template.adminOnly || isAdmin))}
            canRun={canRun}
            onRan={handleRan}
          />
        ) : tab === "profiles" && canRun ? (
          <SavedRunProfilesPanel
            templates={templates.filter((template) => template.isActive && (!template.adminOnly || isAdmin))}
            servers={servers}
            serverGroups={serverGroups}
            onRan={handleRan}
          />
        ) : tab === "batches" ? (
          <BatchComparisonPanel />
        ) : (
          isAdmin && (
            <CommandTemplateManager templates={templates} servers={servers} onChanged={load} />
          )
        )}

        <div className="grid lg:grid-cols-2 gap-6">
          <div className="card table-wrap">
            <div
              className="p-4 flex items-center justify-between border-b"
              style={{ borderColor: "var(--card-border)" }}
            >
              <h2 className="font-semibold">Run history</h2>
              <button className="btn btn-secondary py-1 px-2" onClick={load}>
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
            <table>
              <thead>
                <tr>
                  <th>Server</th>
                  <th>Command</th>
                  <th>Reason</th>
                  <th>Status</th>
                  <th>When</th>
                </tr>
              </thead>
              <tbody>
                {runs.map((run) => (
                  <tr
                    key={run.id}
                    className="cursor-pointer hover:bg-black/5 dark:hover:bg-white/5"
                    onClick={() => void selectRunById(run.id)}
                  >
                    <td>{run.server.name}</td>
                    <td>{run.label ?? run.commandType}</td>
                    <td className="text-xs max-w-[10rem] truncate" title={run.changeReason ?? undefined}>
                      {run.changeReason ?? "—"}
                    </td>
                    <td>
                      <StatusBadge status={run.status} />
                    </td>
                    <td className="text-sm" style={{ color: "var(--muted)" }}>
                      {formatDate(run.createdAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="card p-6">
            <h2 className="font-semibold mb-4">Output</h2>
            {!selectedRun ? (
              <p className="text-sm" style={{ color: "var(--muted)" }}>
                Select a run to view output.
              </p>
            ) : (
              <LiveRunOutput
                run={selectedRun}
                onUpdated={async () => {
                  await loadRuns();
                  await selectRunById(selectedRun.id);
                }}
              />
            )}
          </div>
        </div>
      </PageContainer>
    </AppShell>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    SUCCESS: "badge-success",
    FAILED: "badge-danger",
    RUNNING: "badge-warning",
    PENDING: "badge-muted",
  };
  return <span className={`badge ${map[status] ?? "badge-muted"}`}>{status}</span>;
}
