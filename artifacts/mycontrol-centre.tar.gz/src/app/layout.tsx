import type { Metadata } from "next";
import { AppearanceProvider } from "@/components/appearance-provider";
import { ThemeProvider } from "@/components/theme-provider";
import "./globals.css";

export const metadata: Metadata = {
  title: "MyControl Centre",
  description: "Secure remote server management for Proxmox hosts",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body>
        <AppearanceProvider>
          <ThemeProvider>{children}</ThemeProvider>
        </AppearanceProvider>
      </body>
    </html>
  );
}
