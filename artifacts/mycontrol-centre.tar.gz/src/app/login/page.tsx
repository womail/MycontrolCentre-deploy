"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Shield } from "lucide-react";
import { LoginMfaStep } from "@/components/login-mfa-step";

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [mfaToken, setMfaToken] = useState<string | null>(null);
  const [mfaMethods, setMfaMethods] = useState<{ totp: boolean; webauthn: boolean } | null>(null);

  useEffect(() => {
    void fetch("/api/auth/login", { method: "DELETE", credentials: "include" });
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Login failed");
        return;
      }
      if (data.requiresMfa && data.mfaToken) {
        setMfaToken(data.mfaToken);
        setMfaMethods(data.methods ?? { totp: true, webauthn: false });
        return;
      }
      if (data.user.mustChangePassword) {
        router.push("/change-password");
      } else {
        router.push("/dashboard");
      }
      router.refresh();
    } catch {
      setError("Network error");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="card w-full max-w-md p-8 shadow-xl">
        <div className="flex items-center gap-3 mb-8">
          <Shield className="w-10 h-10" style={{ color: "var(--primary)" }} />
          <div>
            <h1 className="text-2xl font-bold">MyControl Centre</h1>
            <p className="text-sm" style={{ color: "var(--muted)" }}>
              Secure server automation
            </p>
          </div>
        </div>

        {mfaToken && mfaMethods ? (
          <LoginMfaStep
            mfaToken={mfaToken}
            methods={mfaMethods}
            onBack={() => {
              setMfaToken(null);
              setMfaMethods(null);
              setError("");
            }}
          />
        ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Username</label>
            <input
              className="input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Password</label>
            <input
              className="input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              required
            />
          </div>
          {error && (
            <p className="text-sm" style={{ color: "var(--danger)" }}>
              {error}
            </p>
          )}
          <button type="submit" className="btn btn-primary w-full" disabled={loading}>
            {loading ? "Signing in..." : "Sign in"}
          </button>
        </form>
        )}
      </div>
    </div>
  );
}
