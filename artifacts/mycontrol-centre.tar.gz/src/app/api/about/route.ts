import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { getBuildInfo } from "@/lib/build-info";

export const GET = withAuth(async () => {
  const info = getBuildInfo();
  return NextResponse.json({
    ...info,
    timestamp: new Date().toISOString(),
  });
});
