import { readFileSync } from "fs";
import { join } from "path";
import { NextRequest, NextResponse } from "next/server";
import { withApiLog } from "@/lib/api-handler";
import { resolveAppUrl } from "@/lib/setup/app-url";

function loadScript(): string {
  const scriptPath = join(process.cwd(), "scripts", "proxmox-host-cleanup.sh");
  return readFileSync(scriptPath, "utf8");
}

function wantsScript(request: NextRequest): boolean {
  const raw = request.nextUrl.searchParams.get("raw");
  if (raw === "1") return true;

  const ua = (request.headers.get("user-agent") ?? "").toLowerCase();
  if (ua.includes("curl") || ua.includes("wget")) return true;

  const accept = request.headers.get("accept") ?? "";
  if (accept.includes("text/html") && !accept.includes("text/plain")) {
    return false;
  }

  return true;
}

function htmlHelp(appUrl: string): string {
  const scriptUrl = `${appUrl}/api/setup/proxmox-host-cleanup.sh`;
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Proxmox host cleanup — MyControl Centre</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 720px; margin: 2rem auto; padding: 0 1rem; line-height: 1.5; }
    code, pre { background: #0f172a; color: #e2e8f0; padding: 0.15rem 0.35rem; border-radius: 4px; }
    pre { padding: 1rem; overflow-x: auto; white-space: pre-wrap; word-break: break-all; }
    .warn { background: #fef3c7; border: 1px solid #f59e0b; padding: 1rem; border-radius: 8px; color: #78350f; }
  </style>
</head>
<body>
  <h1>Remote host cleanup script</h1>
  <div class="warn">
    <strong>Run on the remote host as root</strong> when removing MyControl Centre automation
    (revoke keys, sudoers, optional user delete). Also delete setup keys in Admin → Vault.
  </div>
  <pre>${scriptUrl}?raw=1</pre>
  <p><a href="/admin/vault">Admin → Vault</a> · <a href="/servers">Servers</a></p>
</body>
</html>`;
}

export const GET = withApiLog(async (request: NextRequest) => {
  const appUrl = resolveAppUrl(request);

  if (!wantsScript(request)) {
    return new NextResponse(htmlHelp(appUrl), {
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  }

  try {
    const script = loadScript();
    return new NextResponse(script, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Disposition": 'inline; filename="proxmox-host-cleanup.sh"',
        "Cache-Control": "public, max-age=3600",
      },
    });
  } catch {
    return NextResponse.json({ error: "Cleanup script not found" }, { status: 404 });
  }
});
