import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { buildInstallCommandPair } from "@/lib/setup/ssh-keygen";
import { setConsolePublicUrl } from "@/lib/settings/console-url";
import { getEnrollmentToken } from "@/lib/enrollment/token";
import { z } from "zod";

const schema = z.object({
  consoleUrl: z.string().min(1),
  publicKey: z.string().min(1),
});

/** Rebuild install command when console URL changes (wizard step 2). */
export const POST = withAuth(
  async (req) => {
    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const appUrl = await setConsolePublicUrl(parsed.data.consoleUrl);
    const enrollToken = await getEnrollmentToken();
    const withEnroll = enrollToken
      ? buildInstallCommandPair(appUrl, parsed.data.publicKey.trim(), { enrollToken })
      : null;
    const manual = buildInstallCommandPair(appUrl, parsed.data.publicKey.trim());

    return NextResponse.json({
      consoleUrl: appUrl,
      installCommand: withEnroll?.asRoot ?? manual.asRoot,
      installCommandSudo: withEnroll?.withSudo ?? manual.withSudo,
      installCommandManual: manual.asRoot,
      installCommandManualSudo: manual.withSudo,
      enrollmentEnabled: Boolean(enrollToken),
    });
  },
  { roles: ["ADMIN"] },
);
