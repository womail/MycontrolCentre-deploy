import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import {
  buildInstallCommandPair,
  generateSshKeyPair,
  type GeneratedSshKey,
} from "@/lib/setup/ssh-keygen";
import {
  getConsolePublicUrl,
  setConsolePublicUrl,
} from "@/lib/settings/console-url";
import { ensureEnrollmentToken } from "@/lib/enrollment/token";
import { storeSetupSshKey } from "@/lib/enrollment/setup-key";
import { z } from "zod";

const bodySchema = z.object({
  consoleUrl: z.string().min(1).optional(),
});

function keyResponse(
  appUrl: string,
  keys: GeneratedSshKey,
  enrollToken: string,
  setupKeyId: string,
) {
  const withEnroll = buildInstallCommandPair(appUrl, keys.publicKey, { enrollToken });
  const manual = buildInstallCommandPair(appUrl, keys.publicKey);
  return {
    ...keys,
    installCommand: withEnroll.asRoot,
    installCommandSudo: withEnroll.withSudo,
    installCommandManual: manual.asRoot,
    installCommandManualSudo: manual.withSudo,
    scriptUrl: `${appUrl}/api/setup/proxmox-host.sh`,
    consoleUrl: appUrl,
    sshUser: "mcc-auto",
    authType: "KEY",
    enrollmentEnabled: true,
    setupKeyId,
  };
}

export const POST = withAuth(
  async (req, { user }) => {
    try {
      const body = await req.json().catch(() => ({}));
      const parsed = bodySchema.safeParse(body);

      let appUrl: string;
      if (parsed.success && parsed.data.consoleUrl) {
        appUrl = await setConsolePublicUrl(parsed.data.consoleUrl);
      } else {
        appUrl = await getConsolePublicUrl(req);
      }

      const keys = generateSshKeyPair();
      const enrollToken = await ensureEnrollmentToken();
      const stored = await storeSetupSshKey({
        createdById: user.id,
        publicKey: keys.publicKey,
        privateKey: keys.privateKey,
      });

      await logAudit({
        userId: user.id,
        action: "SETTINGS_UPDATED",
        resourceType: "ssh-setup",
        details: {
          action: "generate_ssh_key",
          fingerprint: keys.fingerprint,
          consoleUrl: appUrl,
        },
        ipAddress: getClientIp(req.headers),
      });

      return NextResponse.json(keyResponse(appUrl, keys, enrollToken, stored.id));
    } catch (error) {
      const message = error instanceof Error ? error.message : "Key generation failed";
      return jsonError(message, 500);
    }
  },
  { roles: ["ADMIN"] },
);
