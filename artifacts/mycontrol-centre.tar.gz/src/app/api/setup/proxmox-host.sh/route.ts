import { readFileSync } from "fs";
import { join } from "path";
import { NextRequest, NextResponse } from "next/server";
import { withApiLog } from "@/lib/api-handler";
import { resolveAppUrl } from "@/lib/setup/app-url";

function loadScript(): string {
  const scriptPath = join(process.cwd(), "scripts", "proxmox-host-setup.sh");
  return readFileSync(scriptPath, "utf8");
}

function wantsScript(request: NextRequest): boolean {
  const raw = request.nextUrl.searchParams.get("raw");
  if (raw === "1") return true;

  const ua = (request.headers.get("user-agent") ?? "").toLowerCase();
  if (ua.includes("curl") || ua.includes("wget")) return true;

  const accept = request.headers.get("accept") ?? "";
  if (accept.includes("text/html") && !accept.includes("text/plain")) {
    return false;
  }

  return true;
}

function htmlHelp(appUrl: string): string {
  const scriptUrl = `${appUrl}/api/setup/proxmox-host.sh`;
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Proxmox host setup — MyControl Centre</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 720px; margin: 2rem auto; padding: 0 1rem; line-height: 1.5; }
    code, pre { background: #0f172a; color: #e2e8f0; padding: 0.15rem 0.35rem; border-radius: 4px; }
    pre { padding: 1rem; overflow-x: auto; white-space: pre-wrap; word-break: break-all; }
    .warn { background: #fef3c7; border: 1px solid #f59e0b; padding: 1rem; border-radius: 8px; color: #78350f; }
    h1 { font-size: 1.5rem; }
  </style>
</head>
<body>
  <h1>Proxmox host setup script</h1>
  <div class="warn">
    <strong>Opening this page does not configure your Proxmox host.</strong>
    You must run the install command <em>on each Proxmox server</em> as <code>root</code>
    (SSH in, or Proxmox shell).
  </div>
  <h2>Steps</h2>
  <ol>
    <li>In MyControl Centre → <strong>Servers</strong>, click <strong>Generate SSH key pair</strong>.</li>
    <li>Copy the full <strong>install command</strong> from step 2 (includes your public key).</li>
    <li>SSH to the Proxmox host and paste that command into the terminal.</li>
    <li>Copy the script output back into the wizard and add the server.</li>
  </ol>
  <h2>Script URL (for curl)</h2>
  <pre>${scriptUrl}</pre>
  <p>Raw script: <a href="${scriptUrl}?raw=1">${scriptUrl}?raw=1</a></p>
  <p>Example shape (replace with your key from the wizard):</p>
  <pre>rm -f /tmp/mcc-proxmox-setup.sh &amp;&amp; curl -fsSL --connect-timeout 30 --noproxy '*' '${scriptUrl}' -o /tmp/mcc-proxmox-setup.sh &amp;&amp; bash /tmp/mcc-proxmox-setup.sh --pubkey 'ssh-ed25519 AAAA... mycontrol-centre' &amp;&amp; rm -f /tmp/mcc-proxmox-setup.sh</pre>
  <p>As a non-root user with sudo:</p>
  <pre>rm -f /tmp/mcc-proxmox-setup.sh &amp;&amp; curl -fsSL --connect-timeout 30 --noproxy '*' '${scriptUrl}' -o /tmp/mcc-proxmox-setup.sh &amp;&amp; sudo bash /tmp/mcc-proxmox-setup.sh --pubkey 'ssh-ed25519 AAAA... mycontrol-centre' &amp;&amp; rm -f /tmp/mcc-proxmox-setup.sh</pre>
  <p><a href="/servers">← Back to Servers</a></p>
</body>
</html>`;
}

export const GET = withApiLog(async (request: NextRequest) => {
  const appUrl = resolveAppUrl(request);

  if (!wantsScript(request)) {
    return new NextResponse(htmlHelp(appUrl), {
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  }

  try {
    const script = loadScript();
    return new NextResponse(script, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Disposition": 'inline; filename="proxmox-host-setup.sh"',
        "Cache-Control": "public, max-age=3600",
      },
    });
  } catch {
    return NextResponse.json({ error: "Setup script not found" }, { status: 404 });
  }
});
