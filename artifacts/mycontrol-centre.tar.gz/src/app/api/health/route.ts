import { NextResponse } from "next/server";
import { withApiLog } from "@/lib/api-handler";
import { getBuildInfo } from "@/lib/build-info";

export const GET = withApiLog(async () => {
  const info = getBuildInfo();
  return NextResponse.json({
    ok: true,
    ...info,
    timestamp: new Date().toISOString(),
  });
});
