import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { prisma } from "@/lib/db";

export const GET = withAuth(async (req) => {
  const url = new URL(req.url);
  const limit = Math.min(parseInt(url.searchParams.get("limit") ?? "20", 10), 100);

  const recentRuns = await prisma.commandRun.findMany({
    where: { batchId: { not: null } },
    orderBy: { createdAt: "desc" },
    take: 500,
    include: {
      server: { select: { id: true, name: true, hostname: true } },
      user: { select: { username: true } },
    },
  });

  const batchMap = new Map<string, typeof recentRuns>();
  for (const run of recentRuns) {
    if (!run.batchId) continue;
    const list = batchMap.get(run.batchId) ?? [];
    list.push(run);
    batchMap.set(run.batchId, list);
  }

  const batches = [...batchMap.entries()]
    .slice(0, limit)
    .map(([batchId, batchRuns]) => {
      const first = batchRuns[0];
      return {
        batchId,
        label: first?.label ?? first?.commandType ?? "Batch run",
        createdAt: first?.createdAt,
        user: first?.user.username,
        serverCount: batchRuns.length,
        successCount: batchRuns.filter((run) => run.status === "SUCCESS").length,
        failedCount: batchRuns.filter((run) => run.status === "FAILED").length,
        runs: batchRuns.map((run) => ({
          id: run.id,
          server: run.server,
          status: run.status,
          exitCode: run.exitCode,
          durationMs: run.durationMs,
          stderrSnippet: run.stderr.slice(0, 200),
          stdoutSnippet: run.stdout.slice(0, 200),
          label: run.label,
          commandType: run.commandType,
          createdAt: run.createdAt,
        })),
      };
    });

  return NextResponse.json({ batches });
});
