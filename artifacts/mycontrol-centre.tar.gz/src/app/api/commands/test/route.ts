import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { buildCommandChain, buildFromTemplate } from "@/lib/commands/builder";
import {
  assertTemplatesAllowed,
  getCommandTemplatesByIds,
  resolveTemplateForDraft,
} from "@/lib/commands/templates";
import { execOnServer } from "@/lib/ssh/client";
import { z } from "zod";

const overrideSchema = z.object({
  workingDir: z.string().optional(),
  listPath: z.string().optional(),
  customCommand: z.string().optional(),
});

const testSchema = z.object({
  serverId: z.string().min(1),
  templateId: z.string().optional(),
  templateIds: z.array(z.string()).optional(),
  draft: z
    .object({
      name: z.string().min(1),
      type: z.enum(["CD", "LS", "APT_UPDATE", "APT_UPGRADE", "CUSTOM"]),
      description: z.string().min(1),
      commandText: z.string().optional(),
      defaultWorkingDir: z.string().optional(),
      defaultListPath: z.string().optional(),
      adminOnly: z.boolean().optional(),
    })
    .optional(),
  workingDir: z.string().optional(),
  listPath: z.string().optional(),
  customCommand: z.string().optional(),
  templateOverrides: z.record(overrideSchema).optional(),
});

export const POST = withAuth(
  async (req, { user }) => {
    const body = await req.json();
    const parsed = testSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const server = await prisma.server.findUnique({
      where: { id: parsed.data.serverId, isActive: true },
    });
    if (!server) return jsonError("Server not found", 404);

    let built;
    try {
      if (parsed.data.draft) {
        const template = resolveTemplateForDraft(parsed.data.draft);
        built = buildFromTemplate(template, {
          workingDir: parsed.data.workingDir,
          listPath: parsed.data.listPath,
          customCommand: parsed.data.customCommand,
        });
      } else if (parsed.data.templateIds?.length) {
        const templates = await getCommandTemplatesByIds(parsed.data.templateIds);
        assertTemplatesAllowed(templates, user.role);
        built = buildCommandChain(templates, parsed.data.templateOverrides);
      } else if (parsed.data.templateId) {
        const templates = await getCommandTemplatesByIds([parsed.data.templateId]);
        assertTemplatesAllowed(templates, user.role);
        built = buildFromTemplate(templates[0], {
          workingDir: parsed.data.workingDir,
          listPath: parsed.data.listPath,
          customCommand: parsed.data.customCommand,
          ...(parsed.data.templateOverrides?.[parsed.data.templateId] ?? {}),
        });
      } else {
        return jsonError("Provide draft, templateId, or templateIds");
      }
    } catch (error) {
      return jsonError(error instanceof Error ? error.message : "Invalid command");
    }

    try {
      const result = await execOnServer(server, built.commandText, {
        timeoutMs: 120000,
        log: {
          purpose: "COMMAND",
          userId: user.id,
        },
      });

      return NextResponse.json({
        ok: result.exitCode === 0,
        label: built.label,
        commandText: built.commandText,
        exitCode: result.exitCode,
        stdout: result.stdout,
        stderr: result.stderr,
        durationMs: result.durationMs,
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Test run failed";
      return NextResponse.json(
        {
          ok: false,
          label: built.label,
          commandText: built.commandText,
          error: message,
        },
        { status: 502 },
      );
    }
  },
  { roles: ["ADMIN"] },
);
