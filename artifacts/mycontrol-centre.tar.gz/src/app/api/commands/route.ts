import { randomUUID } from "crypto";
import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { buildExecutionPlan } from "@/lib/commands/plan-execution";
import { validateChangeReason } from "@/lib/commands/change-reason";
import { enqueueCommandRun, ensureEmbeddedWorker } from "@/lib/queue/command-queue";
import { getClientIp } from "@/lib/rate-limit";
import { z } from "zod";

const overrideSchema = z.object({
  workingDir: z.string().optional(),
  listPath: z.string().optional(),
  customCommand: z.string().optional(),
});

const executeSchema = z.object({
  serverIds: z.array(z.string()).min(1),
  templateIds: z.array(z.string()).min(1),
  workingDir: z.string().optional(),
  listPath: z.string().optional(),
  customCommand: z.string().optional(),
  templateOverrides: z.record(overrideSchema).optional(),
  failureTemplateIds: z.array(z.string()).optional(),
  variables: z.record(z.string()).optional(),
  forceMaintenance: z.boolean().optional(),
  forceStaleBackup: z.boolean().optional(),
  changeReason: z.string().max(500).optional(),
});

export const GET = withAuth(async (req, { user }) => {
  const { listCommandTemplates } = await import("@/lib/commands/templates");
  const templates = await listCommandTemplates({ includeInactive: user.role === "ADMIN" });
  const visible =
    user.role === "ADMIN"
      ? templates
      : templates.filter((template) => !template.adminOnly);

  return NextResponse.json({ templates: visible });
});

export const POST = withAuth(
  async (req, { user }) => {
    if (user.role === "VIEWER") return jsonError("Forbidden", 403);

    ensureEmbeddedWorker();

    const body = await req.json();
    const parsed = executeSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const servers = await prisma.server.findMany({
      where: { id: { in: parsed.data.serverIds }, isActive: true },
      select: {
        id: true,
        name: true,
        hostname: true,
        inMaintenance: true,
        maintenanceNote: true,
        maintenanceUntil: true,
        isActive: true,
        manualPlatforms: true,
        detectedPlatforms: true,
        lastBackupAt: true,
        lastBackupSource: true,
      },
    });

    if (servers.length === 0) {
      return jsonError("No valid servers selected");
    }

    let plan;
    try {
      plan = await buildExecutionPlan(
        { ...parsed.data, role: user.role },
        servers,
      );
    } catch (error) {
      return jsonError(error instanceof Error ? error.message : "Invalid commands");
    }

    if (plan.runnableServerIds.length === 0) {
      const backupBlocked = plan.blockedServers.some((server) => server.backupBlocked);
      return jsonError(
        backupBlocked
          ? "All selected servers are blocked by stale or missing backups"
          : "All selected servers are blocked by maintenance windows",
      );
    }

    const changeReasonError = validateChangeReason(
      parsed.data.changeReason,
      plan.runnableServerIds.length,
      parsed.data.templateIds.length,
    );
    if (changeReasonError) return jsonError(changeReasonError);

    const changeReason = parsed.data.changeReason?.trim() || null;

    const batchId =
      plan.runnableServerIds.length > 1 || parsed.data.templateIds.length > 1
        ? randomUUID()
        : null;
    const runs = [];
    const primaryTemplate = plan.templates[0];
    const commandType = plan.templates.length === 1 ? primaryTemplate.type : ("CUSTOM" as const);

    for (const serverId of plan.runnableServerIds) {
      const server = servers.find((entry) => entry.id === serverId)!;
      const run = await prisma.commandRun.create({
        data: {
          batchId,
          userId: user.id,
          serverId: server.id,
          templateId: plan.templates.length === 1 ? primaryTemplate.id : null,
          commandType,
          label: plan.built.label,
          commandText: plan.built.commandText,
          workingDir: plan.built.workingDir,
          failureTemplateIds: plan.failureTemplateIds,
          changeReason,
          status: "PENDING",
        },
      });

      enqueueCommandRun(run.id);
      runs.push({ id: run.id, serverId: server.id, serverName: server.name });
    }

    await logAudit({
      userId: user.id,
      action: batchId ? "COMMAND_BATCH_STARTED" : "COMMAND_EXECUTED",
      resourceType: "command",
      resourceId: batchId ?? runs[0]?.id,
      details: {
        templateIds: parsed.data.templateIds,
        label: plan.built.label,
        serverCount: runs.length,
        batchId,
        blockedMaintenance: plan.blockedServers.map((server) => server.serverName),
        changeReason,
      },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({
      batchId,
      runs,
      label: plan.built.label,
      blockedServers: plan.blockedServers,
    }, { status: 202 });
  },
  { roles: ["ADMIN", "OPERATOR"] },
);
