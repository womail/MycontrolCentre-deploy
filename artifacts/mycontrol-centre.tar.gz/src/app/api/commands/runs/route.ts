import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { serializeCommandRunSummary } from "@/lib/commands/serialize-run";

export const GET = withAuth(async (req) => {
  const url = new URL(req.url);
  const batchId = url.searchParams.get("batchId");
  const limit = Math.min(parseInt(url.searchParams.get("limit") ?? "50", 10), 200);

  if (batchId) {
    const runs = await prisma.commandRun.findMany({
      where: { batchId },
      include: {
        server: { select: { id: true, name: true } },
        user: { select: { id: true, username: true } },
      },
      orderBy: { createdAt: "asc" },
    });
    return NextResponse.json({ runs: runs.map(serializeCommandRunSummary) });
  }

  const runs = await prisma.commandRun.findMany({
    take: limit,
    orderBy: { createdAt: "desc" },
    include: {
      server: { select: { id: true, name: true } },
      user: { select: { id: true, username: true } },
    },
  });

  return NextResponse.json({ runs: runs.map(serializeCommandRunSummary) });
});
