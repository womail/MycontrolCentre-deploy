import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";

export const GET = withAuth(async (_req, { params }) => {
  const run = await prisma.commandRun.findUnique({
    where: { id: params!.id },
    include: {
      server: { select: { id: true, name: true, hostname: true } },
      user: { select: { id: true, username: true } },
    },
  });

  if (!run) return jsonError("Run not found", 404);
  return NextResponse.json({ run });
});
