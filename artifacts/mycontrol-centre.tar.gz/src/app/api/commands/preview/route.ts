import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { buildExecutionPlan } from "@/lib/commands/plan-execution";
import { z } from "zod";

const overrideSchema = z.object({
  workingDir: z.string().optional(),
  listPath: z.string().optional(),
  customCommand: z.string().optional(),
});

const previewSchema = z.object({
  serverIds: z.array(z.string()).min(1),
  templateIds: z.array(z.string()).min(1),
  workingDir: z.string().optional(),
  listPath: z.string().optional(),
  customCommand: z.string().optional(),
  templateOverrides: z.record(overrideSchema).optional(),
  failureTemplateIds: z.array(z.string()).optional(),
  variables: z.record(z.string()).optional(),
  forceMaintenance: z.boolean().optional(),
  forceStaleBackup: z.boolean().optional(),
});

export const POST = withAuth(
  async (req, { user }) => {
    if (user.role === "VIEWER") return jsonError("Forbidden", 403);

    const body = await req.json();
    const parsed = previewSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const servers = await prisma.server.findMany({
      where: { id: { in: parsed.data.serverIds }, isActive: true },
      select: {
        id: true,
        name: true,
        hostname: true,
        inMaintenance: true,
        maintenanceNote: true,
        maintenanceUntil: true,
        isActive: true,
        manualPlatforms: true,
        detectedPlatforms: true,
        lastBackupAt: true,
        lastBackupSource: true,
      },
    });

    if (servers.length === 0) {
      return jsonError("No valid servers selected");
    }

    try {
      const plan = await buildExecutionPlan(
        { ...parsed.data, role: user.role },
        servers,
      );

      return NextResponse.json({
        label: plan.built.label,
        description: plan.built.description,
        commandText: plan.built.commandText,
        previews: plan.previews,
        runnableServerIds: plan.runnableServerIds,
        blockedServers: plan.blockedServers,
        failureTemplateIds: plan.failureTemplateIds,
      });
    } catch (error) {
      return jsonError(error instanceof Error ? error.message : "Invalid command plan");
    }
  },
  { roles: ["ADMIN", "OPERATOR"] },
);
