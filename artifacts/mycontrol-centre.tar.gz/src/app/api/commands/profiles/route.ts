import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { z } from "zod";
import { profileTargetsSchema } from "@/lib/servers/group-schemas";

const profileSchema = z
  .object({
    name: z.string().min(1).max(120),
    description: z.string().max(500).optional(),
    templateIds: z.array(z.string()).min(1),
    workingDir: z.string().optional(),
    listPath: z.string().optional(),
    customCommand: z.string().optional(),
    failureTemplateIds: z.array(z.string()).default([]),
  })
  .and(profileTargetsSchema);

export const GET = withAuth(async () => {
  const profiles = await prisma.savedRunProfile.findMany({
    orderBy: { updatedAt: "desc" },
    include: {
      createdBy: { select: { username: true } },
      schedule: true,
      serverGroup: { select: { id: true, name: true, kind: true } },
    },
  });
  return NextResponse.json({ profiles });
});

export const POST = withAuth(
  async (req, { user }) => {
    const body = await req.json();
    const parsed = profileSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const existing = await prisma.savedRunProfile.findUnique({
      where: { name: parsed.data.name },
    });
    if (existing) return jsonError("A profile with this name already exists", 409);

    if (parsed.data.serverGroupId) {
      const group = await prisma.serverGroup.findUnique({
        where: { id: parsed.data.serverGroupId },
      });
      if (!group) return jsonError("Server group not found", 404);
    }

    const profile = await prisma.savedRunProfile.create({
      data: {
        name: parsed.data.name,
        description: parsed.data.description,
        serverIds: parsed.data.serverGroupId ? [] : parsed.data.serverIds,
        serverGroupId: parsed.data.serverGroupId ?? null,
        templateIds: parsed.data.templateIds,
        workingDir: parsed.data.workingDir,
        listPath: parsed.data.listPath,
        customCommand: parsed.data.customCommand,
        failureTemplateIds: parsed.data.failureTemplateIds,
        createdById: user.id,
      },
    });

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "run_profile",
      resourceId: profile.id,
      details: { action: "created", name: profile.name },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ profile }, { status: 201 });
  },
  { roles: ["ADMIN", "OPERATOR"] },
);
