import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { runSavedProfile } from "@/lib/commands/run-profile";
import { ensureEmbeddedWorker } from "@/lib/queue/command-queue";
import { getClientIp } from "@/lib/rate-limit";

export const POST = withAuth(
  async (req, { user, params }) => {
    if (user.role === "VIEWER") return jsonError("Forbidden", 403);

    const profile = await prisma.savedRunProfile.findUnique({ where: { id: params!.id } });
    if (!profile) return jsonError("Profile not found", 404);

    const body = await req.json().catch(() => ({}));
    const forceMaintenance = Boolean(body.forceMaintenance);
    const forceStaleBackup = Boolean(body.forceStaleBackup);
    const changeReason = typeof body.changeReason === "string" ? body.changeReason : undefined;

    ensureEmbeddedWorker();

    try {
      const result = await runSavedProfile({
        profile,
        user,
        changeReason,
        forceMaintenance,
        forceStaleBackup,
        triggeredBy: "manual",
        ipAddress: getClientIp(req.headers),
      });

      return NextResponse.json(
        {
          batchId: result.batchId,
          runs: result.runs,
          label: result.label,
          blockedServers: result.blockedServers,
        },
        { status: 202 },
      );
    } catch (error) {
      return jsonError(error instanceof Error ? error.message : "Failed to run profile");
    }
  },
  { roles: ["ADMIN", "OPERATOR"] },
);
