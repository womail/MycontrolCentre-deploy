import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { z } from "zod";

const updateSchema = z
  .object({
    name: z.string().min(1).max(120).optional(),
    description: z.string().max(500).optional(),
    templateIds: z.array(z.string()).min(1).optional(),
    workingDir: z.string().optional(),
    listPath: z.string().optional(),
    customCommand: z.string().optional(),
    failureTemplateIds: z.array(z.string()).optional(),
    serverGroupId: z.string().cuid().nullable().optional(),
    serverIds: z.array(z.string()).optional(),
  })
  .superRefine((data, ctx) => {
    if (data.serverGroupId === undefined && data.serverIds === undefined) return;
    const hasGroup = data.serverGroupId != null && data.serverGroupId !== "";
    const hasServers = (data.serverIds?.length ?? 0) > 0;
    if (!hasGroup && !hasServers) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Select servers or a server group",
      });
    }
  });

export const PATCH = withAuth(
  async (req, { user, params }) => {
    const existing = await prisma.savedRunProfile.findUnique({ where: { id: params!.id } });
    if (!existing) return jsonError("Profile not found", 404);

    const body = await req.json();
    const parsed = updateSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    if (parsed.data.name && parsed.data.name !== existing.name) {
      const conflict = await prisma.savedRunProfile.findUnique({
        where: { name: parsed.data.name },
      });
      if (conflict) return jsonError("A profile with this name already exists", 409);
    }

    const updateData: Record<string, unknown> = { ...parsed.data };
    if (parsed.data.serverGroupId !== undefined) {
      if (parsed.data.serverGroupId) {
        updateData.serverIds = [];
      }
    } else if (parsed.data.serverIds !== undefined && parsed.data.serverIds.length > 0) {
      updateData.serverGroupId = null;
    }

    const profile = await prisma.savedRunProfile.update({
      where: { id: existing.id },
      data: updateData,
    });

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "run_profile",
      resourceId: profile.id,
      details: { action: "updated", name: profile.name },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ profile });
  },
  { roles: ["ADMIN", "OPERATOR"] },
);

export const DELETE = withAuth(
  async (req, { user, params }) => {
    const existing = await prisma.savedRunProfile.findUnique({ where: { id: params!.id } });
    if (!existing) return jsonError("Profile not found", 404);

    await prisma.savedRunProfile.delete({ where: { id: existing.id } });

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "run_profile",
      resourceId: existing.id,
      details: { action: "deleted", name: existing.name },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN", "OPERATOR"] },
);
