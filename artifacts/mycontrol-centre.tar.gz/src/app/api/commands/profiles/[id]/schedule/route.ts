import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { z } from "zod";

const scheduleSchema = z.object({
  enabled: z.boolean(),
  dayOfWeek: z.number().int().min(0).max(6),
  hourUtc: z.number().int().min(0).max(23),
  minuteUtc: z.number().int().min(0).max(59),
  changeReason: z.string().max(500).optional(),
});

export const GET = withAuth(
  async (_req, { params }) => {
    const schedule = await prisma.profileSchedule.findUnique({
      where: { profileId: params!.id },
    });
    return NextResponse.json({ schedule });
  },
  { roles: ["ADMIN", "OPERATOR"] },
);

export const PUT = withAuth(
  async (req, { user, params }) => {
    const profile = await prisma.savedRunProfile.findUnique({ where: { id: params!.id } });
    if (!profile) return jsonError("Profile not found", 404);

    const body = await req.json();
    const parsed = scheduleSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const schedule = await prisma.profileSchedule.upsert({
      where: { profileId: profile.id },
      create: {
        profileId: profile.id,
        ...parsed.data,
        changeReason: parsed.data.changeReason?.trim() || null,
      },
      update: {
        ...parsed.data,
        changeReason: parsed.data.changeReason?.trim() || null,
      },
    });

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "run_profile",
      resourceId: profile.id,
      details: { action: "schedule_updated", enabled: schedule.enabled },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ schedule });
  },
  { roles: ["ADMIN", "OPERATOR"] },
);
