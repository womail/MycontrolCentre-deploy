import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { buildFromTemplate } from "@/lib/commands/builder";
import { commandTypeUsesShellText } from "@/lib/commands/command-types";
import {
  listCommandTemplates,
} from "@/lib/commands/templates";
import {
  validateCustomCommand,
  validateOptionalPath,
  validateTemplateDescription,
  validateTemplateName,
} from "@/lib/commands/validate";
import { getClientIp } from "@/lib/rate-limit";
import { z } from "zod";

const createSchema = z.object({
  name: z.string().min(1),
  type: z.string().min(1).max(64),
  description: z.string().min(1),
  commandText: z.string().optional(),
  defaultWorkingDir: z.string().optional(),
  defaultListPath: z.string().optional(),
  category: z.string().min(1).max(40).optional(),
  platforms: z.array(z.union([z.enum(["proxmox", "debian", "docker", "arch", "generic", "ubuntu", "alpine"]), z.literal("all")])).optional(),
  sortOrder: z.number().int().optional(),
  adminOnly: z.boolean().optional(),
  isActive: z.boolean().optional(),
});

function normalizeTemplateInput(body: z.infer<typeof createSchema>) {
  const name = validateTemplateName(body.name);
  const description = validateTemplateDescription(body.description);
  const defaultWorkingDir = validateOptionalPath(body.defaultWorkingDir, "Default working directory");
  const defaultListPath = body.defaultListPath?.trim() || undefined;
  const commandText =
    commandTypeUsesShellText(body.type)
      ? validateCustomCommand(body.commandText ?? "")
      : body.commandText?.trim() || undefined;

  buildFromTemplate({
    id: "draft",
    name,
    type: body.type,
    description,
    commandText,
    defaultWorkingDir,
    defaultListPath,
    adminOnly: body.adminOnly ?? commandTypeUsesShellText(body.type),
  });

  return {
    name,
    description,
    type: body.type,
    commandText,
    defaultWorkingDir,
    defaultListPath,
    sortOrder: body.sortOrder ?? 100,
    category: body.category ?? "general",
    platforms: body.platforms ?? ["all"],
    adminOnly: body.adminOnly ?? commandTypeUsesShellText(body.type),
    isActive: body.isActive ?? true,
  };
}

export const GET = withAuth(async (req, { user }) => {
  const includeInactive = user.role === "ADMIN";
  const templates = await listCommandTemplates({ includeInactive });
  const visible =
    user.role === "ADMIN"
      ? templates
      : templates.filter((template) => !template.adminOnly);

  return NextResponse.json({ templates: visible });
});

export const POST = withAuth(
  async (req, { user }) => {
    const body = await req.json();
    const parsed = createSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    let data;
    try {
      data = normalizeTemplateInput(parsed.data);
    } catch (error) {
      return jsonError(error instanceof Error ? error.message : "Invalid template");
    }

    const existing = await prisma.commandTemplate.findUnique({
      where: { name: data.name },
    });
    if (existing) {
      return jsonError("A command with this name already exists", 409);
    }

    const template = await prisma.commandTemplate.create({
      data: {
        ...data,
        isBuiltIn: false,
      },
    });

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "command_template",
      resourceId: template.id,
      details: { action: "created", name: template.name, type: template.type },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ template }, { status: 201 });
  },
  { roles: ["ADMIN"] },
);
