import { NextResponse } from "next/server";
import type { Prisma } from "@prisma/client";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { buildFromTemplate } from "@/lib/commands/builder";
import { commandTypeUsesShellText } from "@/lib/commands/command-types";
import {
  validateCustomCommand,
  validateOptionalPath,
  validateTemplateDescription,
  validateTemplateName,
} from "@/lib/commands/validate";
import { getClientIp } from "@/lib/rate-limit";
import { z } from "zod";

const updateSchema = z.object({
  name: z.string().min(1).optional(),
  type: z.string().min(1).max(64).optional(),
  description: z.string().min(1).optional(),
  commandText: z.string().optional(),
  defaultWorkingDir: z.string().optional(),
  defaultListPath: z.string().optional(),
  sortOrder: z.number().int().optional(),
  category: z.string().min(1).max(40).optional(),
  platforms: z.array(z.string()).optional(),
  adminOnly: z.boolean().optional(),
  isActive: z.boolean().optional(),
});

export const PATCH = withAuth(
  async (req, { user, params }) => {
    const existing = await prisma.commandTemplate.findUnique({
      where: { id: params!.id },
    });
    if (!existing) return jsonError("Command template not found", 404);

    const body = await req.json();
    const parsed = updateSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const nextType = parsed.data.type ?? existing.type;

    const next = {
      name: parsed.data.name ? validateTemplateName(parsed.data.name) : existing.name,
      type: nextType,
      description: parsed.data.description
        ? validateTemplateDescription(parsed.data.description)
        : existing.description,
      commandText:
        parsed.data.commandText !== undefined
          ? commandTypeUsesShellText(nextType)
            ? validateCustomCommand(parsed.data.commandText)
            : parsed.data.commandText.trim() || null
          : commandTypeUsesShellText(nextType) && existing.type !== nextType && !commandTypeUsesShellText(existing.type)
            ? validateCustomCommand(existing.commandText ?? "")
            : commandTypeUsesShellText(nextType)
              ? existing.commandText
              : null,
      defaultWorkingDir:
        parsed.data.defaultWorkingDir !== undefined
          ? validateOptionalPath(parsed.data.defaultWorkingDir, "Default working directory") ?? null
          : existing.defaultWorkingDir,
      defaultListPath:
        parsed.data.defaultListPath !== undefined
          ? parsed.data.defaultListPath.trim() || null
          : existing.defaultListPath,
      sortOrder: parsed.data.sortOrder ?? existing.sortOrder,
      category: parsed.data.category ?? existing.category,
      platforms: parsed.data.platforms ?? existing.platforms,
      adminOnly: parsed.data.adminOnly ?? existing.adminOnly,
      isActive: parsed.data.isActive ?? existing.isActive,
    };

    if (existing.isBuiltIn && parsed.data.name && parsed.data.name !== existing.name) {
      return jsonError("Built-in command names cannot be changed", 400);
    }

    try {
      buildFromTemplate({
        id: existing.id,
        name: next.name,
        type: next.type,
        description: next.description,
        commandText: next.commandText,
        defaultWorkingDir: next.defaultWorkingDir,
        defaultListPath: next.defaultListPath,
        adminOnly: next.adminOnly,
      });
    } catch (error) {
      return jsonError(error instanceof Error ? error.message : "Invalid template");
    }

    if (next.name !== existing.name) {
      const conflict = await prisma.commandTemplate.findUnique({ where: { name: next.name } });
      if (conflict) return jsonError("A command with this name already exists", 409);
    }

    const template = await prisma.commandTemplate.update({
      where: { id: existing.id },
      data: {
        ...next,
        platforms: next.platforms as Prisma.InputJsonValue,
      },
    });

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "command_template",
      resourceId: template.id,
      details: { action: "updated", name: template.name },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ template });
  },
  { roles: ["ADMIN"] },
);

export const DELETE = withAuth(
  async (req, { user, params }) => {
    const existing = await prisma.commandTemplate.findUnique({
      where: { id: params!.id },
    });
    if (!existing) return jsonError("Command template not found", 404);
    if (existing.isBuiltIn) {
      return jsonError("Built-in commands cannot be deleted", 400);
    }

    await prisma.commandTemplate.delete({ where: { id: existing.id } });

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "command_template",
      resourceId: existing.id,
      details: { action: "deleted", name: existing.name },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);
