import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { encrypt } from "@/lib/crypto";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import type { SshAuthType } from "@prisma/client";
import { tagsToJson } from "@/lib/servers/tags";
import { serializeServer } from "@/lib/servers/serialize";
import { SERVER_PLATFORMS } from "@/lib/servers/platforms";
import { z } from "zod";

const platformSchema = z.enum(SERVER_PLATFORMS);

const serverSchema = z.object({
  name: z.string().min(1).max(100),
  hostname: z.string().min(1).max(255),
  port: z.number().int().min(1).max(65535).default(22),
  sshUser: z.string().min(1).max(64).transform((s) => s.trim()).default("root"),
  authType: z.enum(["KEY", "PASSWORD", "KEY_AND_PASSWORD"]),
  privateKey: z.string().optional(),
  password: z.string().optional(),
  knownHostKey: z.string().optional().nullable(),
  acceptNewHostKey: z.boolean().default(false),
  tags: z.array(z.string()).default([]),
  manualPlatforms: z.array(platformSchema).optional(),
  inMaintenance: z.boolean().optional(),
  maintenanceNote: z.string().max(500).optional().nullable(),
  maintenanceUntil: z.string().datetime().optional().nullable(),
  proxmoxApiPort: z.number().int().min(1).max(65535).optional(),
  proxmoxTokenId: z.string().max(200).optional().nullable(),
  proxmoxTokenSecret: z.string().optional(),
  proxmoxNodeName: z.string().max(120).optional().nullable(),
});

export const GET = withAuth(async () => {
  const servers = await prisma.server.findMany({
    orderBy: { name: "asc" },
    select: {
      id: true,
      name: true,
      hostname: true,
      port: true,
      sshUser: true,
      authType: true,
      tags: true,
      manualPlatforms: true,
      detectedPlatforms: true,
      detectedOsId: true,
      detectedOsLabel: true,
      detectedOsFamily: true,
      osDetectedAt: true,
      healthStatus: true,
      lastHealthCheck: true,
      healthMessage: true,
      isActive: true,
      inMaintenance: true,
      maintenanceNote: true,
      maintenanceUntil: true,
      proxmoxApiPort: true,
      proxmoxTokenId: true,
      proxmoxNodeName: true,
      proxmoxVersion: true,
      proxmoxSummary: true,
      lastProxmoxSync: true,
      pendingPackageUpdates: true,
      lastPackageUpdatesCheck: true,
      createdAt: true,
      updatedAt: true,
    },
  });
  return NextResponse.json({
    servers: servers.map((s) => serializeServer(s)),
  });
});

export const POST = withAuth(
  async (req, { user }) => {
    if (user.role !== "ADMIN") return jsonError("Forbidden", 403);

    const body = await req.json();
    const parsed = serverSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const data = parsed.data;

    if (data.authType === "KEY" || data.authType === "KEY_AND_PASSWORD") {
      if (!data.privateKey?.trim()) {
        return jsonError("Private key is required for key-based auth");
      }
    }
    if (data.authType === "PASSWORD" || data.authType === "KEY_AND_PASSWORD") {
      if (!data.password) {
        return jsonError("Password is required for password-based auth");
      }
    }

    const server = await prisma.server.create({
      data: {
        name: data.name,
        hostname: data.hostname,
        port: data.port,
        sshUser: data.sshUser,
        authType: data.authType as SshAuthType,
        encryptedPrivateKey: data.privateKey?.trim()
          ? encrypt(data.privateKey.trim())
          : null,
        encryptedPassword: data.password ? encrypt(data.password) : null,
        knownHostKey: data.knownHostKey ?? null,
        acceptNewHostKey: data.acceptNewHostKey,
        tags: tagsToJson(data.tags),
        manualPlatforms: data.manualPlatforms ?? [],
        inMaintenance: data.inMaintenance ?? false,
        maintenanceNote: data.maintenanceNote ?? null,
        maintenanceUntil: data.maintenanceUntil ? new Date(data.maintenanceUntil) : null,
        proxmoxApiPort: data.proxmoxApiPort ?? 8006,
        proxmoxTokenId: data.proxmoxTokenId ?? null,
        encryptedProxmoxToken: data.proxmoxTokenSecret
          ? encrypt(data.proxmoxTokenSecret)
          : null,
        proxmoxNodeName: data.proxmoxNodeName ?? null,
      },
    });

    await logAudit({
      userId: user.id,
      action: "SERVER_CREATED",
      resourceType: "server",
      resourceId: server.id,
      details: { name: server.name, hostname: server.hostname },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ server: { id: server.id, name: server.name } }, { status: 201 });
  },
  { roles: ["ADMIN"] },
);
