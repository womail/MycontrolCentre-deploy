import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import {
  loadServerForRemoteAccess,
  RemoteAccessError,
} from "@/lib/servers/remote-access";
import { sftpWriteFileBuffer } from "@/lib/ssh/sftp";
import { joinRemotePath, validateRemoteDirectoryPath } from "@/lib/ssh/remote-paths";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";

const MAX_UPLOAD_BYTES = 50 * 1024 * 1024;

export const POST = withAuth(async (req, { user, params }) => {
  try {
    const server = await loadServerForRemoteAccess(params!.id, user);
    const form = await req.formData();
    const parentPath = form.get("parentPath");
    const fileName = form.get("fileName");
    const file = form.get("file");

    if (typeof parentPath !== "string" || typeof fileName !== "string" || !(file instanceof File)) {
      return jsonError("parentPath, fileName, and file are required");
    }

    const directory = validateRemoteDirectoryPath(parentPath);
    const target = joinRemotePath(directory, fileName);
    const buffer = Buffer.from(await file.arrayBuffer());

    if (buffer.length > MAX_UPLOAD_BYTES) {
      return jsonError("File is too large (50 MB limit)");
    }

    await sftpWriteFileBuffer(server, target, buffer, {
      log: { purpose: "COMMAND", userId: user.id },
      timeoutMs: 300_000,
    });

    await logAudit({
      action: "SERVER_FILE_UPLOAD",
      userId: user.id,
      details: { serverId: server.id, path: target, bytes: buffer.length },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ path: target, bytes: buffer.length });
  } catch (error) {
    if (error instanceof RemoteAccessError) {
      return jsonError(error.message, error.status);
    }
    return jsonError(error instanceof Error ? error.message : "Upload failed");
  }
});
