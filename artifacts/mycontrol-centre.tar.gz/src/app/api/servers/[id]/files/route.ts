import { NextResponse } from "next/server";
import { z } from "zod";
import { withAuth, jsonError } from "@/lib/api-handler";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import {
  loadServerForRemoteAccess,
  RemoteAccessError,
} from "@/lib/servers/remote-access";
import { compressRemotePaths, decompressRemoteArchive } from "@/lib/ssh/archive";
import {
  joinRemotePath,
  validateRemoteDirectoryPath,
  validateRemoteEntryName,
  validateSafeRemoteDeletePath,
} from "@/lib/ssh/remote-paths";
import {
  sftpListDirectory,
  sftpMkdir,
  sftpRemoveDirectory,
  sftpRemoveFile,
  sftpRename,
  sftpStat,
  sftpWriteFileBuffer,
} from "@/lib/ssh/sftp";
import { validatePath } from "@/lib/commands/validate";
import { execOnServer, shellEscape } from "@/lib/ssh/client";

const MAX_UPLOAD_BYTES = 50 * 1024 * 1024;

const sshLog = (userId: string) => ({
  log: { purpose: "COMMAND" as const, userId },
  timeoutMs: 120_000,
});

export const GET = withAuth(async (req, { user, params }) => {
  try {
    const server = await loadServerForRemoteAccess(params!.id, user);
    const url = new URL(req.url);
    const pathParam = url.searchParams.get("path") ?? "/";
    const directory = validateRemoteDirectoryPath(pathParam);

    const entries = await sftpListDirectory(server, directory, sshLog(user.id));
    return NextResponse.json({ path: directory, entries });
  } catch (error) {
    if (error instanceof RemoteAccessError) {
      return jsonError(error.message, error.status);
    }
    return jsonError(error instanceof Error ? error.message : "Failed to list files");
  }
});

const postSchema = z.discriminatedUnion("action", [
  z.object({
    action: z.literal("mkdir"),
    parentPath: z.string(),
    name: z.string(),
  }),
  z.object({
    action: z.literal("createFile"),
    parentPath: z.string(),
    name: z.string(),
    content: z.string().optional(),
  }),
  z.object({
    action: z.literal("rename"),
    path: z.string(),
    newName: z.string(),
  }),
  z.object({
    action: z.literal("delete"),
    path: z.string(),
    recursive: z.boolean().optional(),
  }),
  z.object({
    action: z.literal("compress"),
    paths: z.array(z.string()).min(1),
    archivePath: z.string(),
  }),
  z.object({
    action: z.literal("decompress"),
    archivePath: z.string(),
    destDir: z.string().optional(),
  }),
  z.object({
    action: z.literal("resolveHome"),
  }),
]);

export const POST = withAuth(async (req, { user, params }) => {
  try {
    const server = await loadServerForRemoteAccess(params!.id, user);
    const body = await req.json();
    const parsed = postSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const data = parsed.data;
    const logOpts = sshLog(user.id);

    if (data.action === "resolveHome") {
      const result = await execOnServer(
        server,
        "cd ~ && pwd",
        logOpts,
      );
      if (result.exitCode !== 0) {
        return jsonError(result.stderr.trim() || "Could not resolve home directory");
      }
      const home = result.stdout.trim().split("\n").pop()?.trim() ?? "/";
      try {
        validatePath(home, "Home");
        return NextResponse.json({ path: home });
      } catch {
        return NextResponse.json({ path: "/" });
      }
    }

    if (data.action === "mkdir") {
      const target = joinRemotePath(data.parentPath, data.name);
      await sftpMkdir(server, target, logOpts);
      await logAudit({
        action: "SERVER_FILE_MKDIR",
        userId: user.id,
        details: { serverId: server.id, path: target },
        ipAddress: getClientIp(req.headers),
      });
      return NextResponse.json({ path: target });
    }

    if (data.action === "createFile") {
      const target = joinRemotePath(data.parentPath, data.name);
      const content = Buffer.from(data.content ?? "", "utf8");
      if (content.length > MAX_UPLOAD_BYTES) {
        return jsonError("File content too large");
      }
      await sftpWriteFileBuffer(server, target, content, logOpts);
      await logAudit({
        action: "SERVER_FILE_CREATE",
        userId: user.id,
        details: { serverId: server.id, path: target },
        ipAddress: getClientIp(req.headers),
      });
      return NextResponse.json({ path: target });
    }

    if (data.action === "rename") {
      const from = validatePath(data.path, "Path");
      const newName = validateRemoteEntryName(data.newName);
      const parent = from.slice(0, from.lastIndexOf("/")) || "/";
      const to = joinRemotePath(parent, newName);
      await sftpRename(server, from, to, logOpts);
      await logAudit({
        action: "SERVER_FILE_RENAME",
        userId: user.id,
        details: { serverId: server.id, from, to },
        ipAddress: getClientIp(req.headers),
      });
      return NextResponse.json({ path: to });
    }

    if (data.action === "delete") {
      const target = validateSafeRemoteDeletePath(data.path, "Path");
      const stat = await sftpStat(server, target, logOpts);
      if (stat.isDirectory) {
        if (data.recursive) {
          const escaped = shellEscape(target);
          const result = await execOnServer(
            server,
            `rm -rf ${escaped}`,
            logOpts,
          );
          if (result.exitCode !== 0) {
            return jsonError(result.stderr.trim() || "Delete failed");
          }
        } else {
          await sftpRemoveDirectory(server, target, logOpts);
        }
      } else {
        await sftpRemoveFile(server, target, logOpts);
      }
      await logAudit({
        action: "SERVER_FILE_DELETE",
        userId: user.id,
        details: { serverId: server.id, path: target, recursive: Boolean(data.recursive) },
        ipAddress: getClientIp(req.headers),
      });
      return NextResponse.json({ ok: true });
    }

    if (data.action === "compress") {
      await compressRemotePaths(server, data.paths, data.archivePath, logOpts);
      await logAudit({
        action: "SERVER_FILE_COMPRESS",
        userId: user.id,
        details: {
          serverId: server.id,
          paths: data.paths,
          archivePath: data.archivePath,
        },
        ipAddress: getClientIp(req.headers),
      });
      return NextResponse.json({ archivePath: validatePath(data.archivePath, "Archive path") });
    }

    if (data.action === "decompress") {
      await decompressRemoteArchive(
        server,
        data.archivePath,
        data.destDir,
        logOpts,
      );
      await logAudit({
        action: "SERVER_FILE_DECOMPRESS",
        userId: user.id,
        details: {
          serverId: server.id,
          archivePath: data.archivePath,
          destDir: data.destDir,
        },
        ipAddress: getClientIp(req.headers),
      });
      return NextResponse.json({ ok: true });
    }

    return jsonError("Unknown action");
  } catch (error) {
    if (error instanceof RemoteAccessError) {
      return jsonError(error.message, error.status);
    }
    return jsonError(error instanceof Error ? error.message : "File operation failed");
  }
});
