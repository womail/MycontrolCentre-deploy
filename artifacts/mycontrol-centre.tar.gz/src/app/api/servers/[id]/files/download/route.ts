import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import {
  loadServerForRemoteAccess,
  RemoteAccessError,
} from "@/lib/servers/remote-access";
import { validatePath } from "@/lib/commands/validate";
import { sftpReadFileBuffer } from "@/lib/ssh/sftp";

const MAX_DOWNLOAD_BYTES = 100 * 1024 * 1024;

export const GET = withAuth(async (req, { user, params }) => {
  try {
    const server = await loadServerForRemoteAccess(params!.id, user);
    const url = new URL(req.url);
    const pathParam = url.searchParams.get("path");
    if (!pathParam) return jsonError("path is required");

    const remotePath = validatePath(pathParam, "Path");
    const buffer = await sftpReadFileBuffer(server, remotePath, {
      log: { purpose: "COMMAND", userId: user.id },
      timeoutMs: 300_000,
    });

    if (buffer.length > MAX_DOWNLOAD_BYTES) {
      return jsonError("File is too large to download through the UI (100 MB limit)");
    }

    const name = remotePath.split("/").pop() ?? "download";
    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": `attachment; filename="${encodeURIComponent(name)}"`,
        "Content-Length": String(buffer.length),
      },
    });
  } catch (error) {
    if (error instanceof RemoteAccessError) {
      return jsonError(error.message, error.status);
    }
    return jsonError(error instanceof Error ? error.message : "Download failed");
  }
});
