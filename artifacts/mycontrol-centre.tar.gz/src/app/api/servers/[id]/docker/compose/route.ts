import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { deployComposeToServer } from "@/lib/docker/compose-deploy";
import { getClientIp } from "@/lib/rate-limit";
import { z } from "zod";

const deploySchema = z.object({
  remoteDir: z.string().min(1),
  composeYaml: z.string().min(1),
  envFile: z.string().optional(),
  pull: z.boolean().optional(),
  detach: z.boolean().optional(),
  projectName: z.string().max(64).optional(),
  changeReason: z.string().max(500).optional(),
});

export const POST = withAuth(
  async (req, { user, params }) => {
    if (user.role === "VIEWER") return jsonError("Forbidden", 403);

    const server = await prisma.server.findUnique({ where: { id: params!.id } });
    if (!server || !server.isActive) return jsonError("Server not found", 404);

    const body = await req.json();
    const parsed = deploySchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const startedAt = new Date();
    const run = await prisma.commandRun.create({
      data: {
        userId: user.id,
        serverId: server.id,
        commandType: "CUSTOM",
        label: "Deploy docker compose",
        commandText: `deploy compose → ${parsed.data.remoteDir}`,
        changeReason: parsed.data.changeReason?.trim() || null,
        status: "RUNNING",
        startedAt,
      },
    });

    try {
      const result = await deployComposeToServer(server, parsed.data, {
        userId: user.id,
        commandRunId: run.id,
      });

      const completedAt = new Date();
      await prisma.commandRun.update({
        where: { id: run.id },
        data: {
          status: "SUCCESS",
          exitCode: 0,
          stdout: result.stdout.slice(0, 500_000),
          stderr: result.stderr.slice(0, 500_000),
          completedAt,
          durationMs: completedAt.getTime() - startedAt.getTime(),
        },
      });

      await logAudit({
        userId: user.id,
        action: "COMMAND_EXECUTED",
        resourceType: "server",
        resourceId: server.id,
        details: {
          action: "docker_compose_deploy",
          remoteDir: result.remoteDir,
          composePath: result.composePath,
          envPath: result.envPath,
          runId: run.id,
        },
        ipAddress: getClientIp(req.headers),
      });

      return NextResponse.json({
        ok: true,
        runId: run.id,
        remoteDir: result.remoteDir,
        composePath: result.composePath,
        envPath: result.envPath,
        stdout: result.stdout,
        stderr: result.stderr,
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Deploy failed";
      await prisma.commandRun.update({
        where: { id: run.id },
        data: {
          status: "FAILED",
          exitCode: 1,
          stderr: message.slice(0, 500_000),
          completedAt: new Date(),
        },
      });
      return jsonError(message, 500);
    }
  },
  { roles: ["ADMIN", "OPERATOR"] },
);
