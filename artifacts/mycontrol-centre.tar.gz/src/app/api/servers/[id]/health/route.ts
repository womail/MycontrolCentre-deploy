import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { runServerHealthCheck } from "@/lib/health/check-server";
import { getClientIp } from "@/lib/rate-limit";

export const POST = withAuth(async (req, { user, params }) => {
  const server = await prisma.server.findUnique({ where: { id: params!.id } });
  if (!server) return jsonError("Server not found", 404);

  const result = await runServerHealthCheck({
    server,
    userId: user.id,
    triggeredBy: "manual",
    ipAddress: getClientIp(req.headers),
  });

  if (result.error) {
    return NextResponse.json({
      online: false,
      error: result.error,
      stderr: result.stderr,
    });
  }

  return NextResponse.json({
    online: result.online,
    stdout: result.stdout,
    stderr: result.stderr,
    exitCode: result.exitCode,
    pendingPackageUpdates: result.pendingPackageUpdates ?? null,
  });
});
