import { NextRequest } from "next/server";
import { getSessionUser } from "@/lib/auth/session";
import {
  assertShellSessionAccess,
  getShellSession,
  subscribeShellSession,
} from "@/lib/ssh/shell-sessions";

export async function GET(
  req: NextRequest,
  segmentData: { params: Promise<Record<string, string>> },
) {
  const user = await getSessionUser();
  if (!user || user.role === "VIEWER") {
    return new Response("Forbidden", { status: 403 });
  }

  const { id: serverId, sessionId } = await segmentData.params;
  const session = getShellSession(sessionId);
  if (!session) {
    return new Response("Session not found", { status: 404 });
  }

  try {
    assertShellSessionAccess(session, serverId, user.id);
  } catch {
    return new Response("Session not found", { status: 404 });
  }

  const encoder = new TextEncoder();

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      let closed = false;
      let heartbeat: ReturnType<typeof setInterval> | null = null;

      const closeStream = () => {
        if (closed) return;
        closed = true;
        if (heartbeat) clearInterval(heartbeat);
        unsubscribe();
        try {
          controller.close();
        } catch {
          /* ignore */
        }
      };

      const send = (payload: Record<string, unknown>) => {
        if (closed) return;
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(payload)}\n\n`));
      };

      const unsubscribe = subscribeShellSession(session, (event) => {
        if (event.type === "output") {
          send({ type: "output", data: event.data });
        } else if (event.type === "closed") {
          send({ type: "closed", message: event.message });
          closeStream();
        }
      });

      send({ type: "ready" });

      heartbeat = setInterval(() => {
        if (closed) return;
        controller.enqueue(encoder.encode(": ping\n\n"));
      }, 15000);

      req.signal.addEventListener("abort", closeStream);
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
