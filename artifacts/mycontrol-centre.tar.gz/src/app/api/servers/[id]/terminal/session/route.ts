import { NextResponse } from "next/server";
import { z } from "zod";
import { withAuth, jsonError } from "@/lib/api-handler";
import {
  loadServerForRemoteAccess,
  RemoteAccessError,
} from "@/lib/servers/remote-access";
import { createShellSession } from "@/lib/ssh/shell-sessions";
import { clampShellCols, clampShellRows } from "@/lib/ssh/shell-geometry";

const createSchema = z.object({
  cols: z
    .number()
    .int()
    .optional()
    .transform((v) => clampShellCols(v ?? 100)),
  rows: z
    .number()
    .int()
    .optional()
    .transform((v) => clampShellRows(v ?? 28)),
});

export const POST = withAuth(async (req, { user, params }) => {
  try {
    const server = await loadServerForRemoteAccess(params!.id, user);
    const body = await req.json().catch(() => ({}));
    const parsed = createSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const session = await createShellSession({
      server,
      userId: user.id,
      cols: parsed.data.cols ?? 100,
      rows: parsed.data.rows ?? 28,
    });

    return NextResponse.json({ sessionId: session.id });
  } catch (error) {
    if (error instanceof RemoteAccessError) {
      return jsonError(error.message, error.status);
    }
    return jsonError(error instanceof Error ? error.message : "Failed to start SSH session");
  }
});
