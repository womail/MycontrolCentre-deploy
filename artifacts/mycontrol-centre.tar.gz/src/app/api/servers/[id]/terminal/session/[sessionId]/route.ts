import { NextResponse } from "next/server";
import { z } from "zod";
import { withAuth, jsonError } from "@/lib/api-handler";
import {
  assertShellSessionAccess,
  destroyShellSession,
  getShellSession,
  resizeShellSession,
  writeShellInput,
} from "@/lib/ssh/shell-sessions";
import { clampShellCols, clampShellRows } from "@/lib/ssh/shell-geometry";

const patchSchema = z.discriminatedUnion("action", [
  z.object({
    action: z.literal("input"),
    data: z.string().max(65_536),
  }),
  z.object({
    action: z.literal("resize"),
    cols: z.number().int().transform(clampShellCols),
    rows: z.number().int().transform(clampShellRows),
  }),
]);

export const PATCH = withAuth(async (req, { user, params }) => {
  if (user.role === "VIEWER") return jsonError("Forbidden", 403);

  const session = getShellSession(params!.sessionId);
  if (!session) return jsonError("Session not found", 404);

  try {
    assertShellSessionAccess(session, params!.id, user.id);
  } catch {
    return jsonError("Session not found", 404);
  }

  const body = await req.json();
  const parsed = patchSchema.safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
  }

  try {
    if (parsed.data.action === "input") {
      writeShellInput(session, parsed.data.data);
    } else {
      resizeShellSession(session, parsed.data.cols, parsed.data.rows);
    }
    return NextResponse.json({ ok: true });
  } catch (error) {
    return jsonError(error instanceof Error ? error.message : "Session error");
  }
});

export const DELETE = withAuth(async (_req, { user, params }) => {
  if (user.role === "VIEWER") return jsonError("Forbidden", 403);

  const session = getShellSession(params!.sessionId);
  if (!session) return NextResponse.json({ ok: true });

  try {
    assertShellSessionAccess(session, params!.id, user.id);
  } catch {
    return jsonError("Session not found", 404);
  }

  destroyShellSession(session.id);
  return NextResponse.json({ ok: true });
});
