import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { syncProxmoxServer } from "@/lib/proxmox/sync";
import { getClientIp } from "@/lib/rate-limit";

export const GET = withAuth(async (_req, { params }) => {
  const server = await prisma.server.findUnique({
    where: { id: params!.id },
    select: {
      id: true,
      name: true,
      proxmoxNodeName: true,
      proxmoxVersion: true,
      proxmoxSummary: true,
      lastProxmoxSync: true,
      proxmoxTokenId: true,
      proxmoxApiPort: true,
    },
  });
  if (!server) return jsonError("Server not found", 404);

  const guests = await prisma.proxmoxGuest.findMany({
    where: { serverId: server.id },
    orderBy: { vmid: "asc" },
  });

  return NextResponse.json({
    server: {
      ...server,
      hasProxmoxToken: Boolean(server.proxmoxTokenId),
    },
    guests,
  });
});

export const POST = withAuth(
  async (req, { user, params }) => {
    try {
      const result = await syncProxmoxServer(params!.id);

      await logAudit({
        userId: user.id,
        action: "SERVER_HEALTH_CHECK",
        resourceType: "proxmox_sync",
        resourceId: params!.id,
        details: { guestCount: result.guestCount },
        ipAddress: getClientIp(req.headers),
      });

      return NextResponse.json(result);
    } catch (error) {
      return jsonError(error instanceof Error ? error.message : "Proxmox sync failed", 502);
    }
  },
  { roles: ["ADMIN", "OPERATOR"] },
);
