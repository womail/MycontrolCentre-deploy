import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { encrypt } from "@/lib/crypto";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { tagsToJson } from "@/lib/servers/tags";
import { serializeServer } from "@/lib/servers/serialize";
import { mergeManualPlatforms, SERVER_PLATFORMS } from "@/lib/servers/platforms";
import { z } from "zod";

const platformSchema = z.enum(SERVER_PLATFORMS);

const updateSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  hostname: z.string().min(1).max(255).optional(),
  port: z.number().int().min(1).max(65535).optional(),
  sshUser: z.string().min(1).max(64).transform((s) => s.trim()).optional(),
  authType: z.enum(["KEY", "PASSWORD", "KEY_AND_PASSWORD"]).optional(),
  privateKey: z.string().optional(),
  password: z.string().optional(),
  knownHostKey: z.string().optional().nullable(),
  acceptNewHostKey: z.boolean().optional(),
  tags: z.array(z.string()).optional(),
  manualPlatforms: z.array(platformSchema).optional(),
  isActive: z.boolean().optional(),
  inMaintenance: z.boolean().optional(),
  maintenanceNote: z.string().max(500).optional().nullable(),
  maintenanceUntil: z.string().datetime().optional().nullable(),
  proxmoxApiPort: z.number().int().min(1).max(65535).optional(),
  proxmoxTokenId: z.string().max(200).optional().nullable(),
  proxmoxTokenSecret: z.string().optional(),
  proxmoxNodeName: z.string().max(120).optional().nullable(),
});

export const GET = withAuth(async (_req, { params }) => {
  const server = await prisma.server.findUnique({
    where: { id: params!.id },
    select: {
      id: true,
      name: true,
      hostname: true,
      port: true,
      sshUser: true,
      authType: true,
      tags: true,
      manualPlatforms: true,
      detectedPlatforms: true,
      detectedOsId: true,
      detectedOsLabel: true,
      detectedOsFamily: true,
      osDetectedAt: true,
      healthStatus: true,
      lastHealthCheck: true,
      healthMessage: true,
      isActive: true,
      inMaintenance: true,
      maintenanceNote: true,
      maintenanceUntil: true,
      proxmoxApiPort: true,
      proxmoxTokenId: true,
      proxmoxNodeName: true,
      proxmoxVersion: true,
      proxmoxSummary: true,
      lastProxmoxSync: true,
      acceptNewHostKey: true,
      knownHostKey: true,
      createdAt: true,
      updatedAt: true,
    },
  });

  if (!server) return jsonError("Server not found", 404);
  return NextResponse.json({
    server: serializeServer(server),
  });
});

export const PATCH = withAuth(
  async (req, { user, params }) => {
    const existing = await prisma.server.findUnique({ where: { id: params!.id } });
    if (!existing) return jsonError("Server not found", 404);

    const body = await req.json();
    const parsed = updateSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const data = parsed.data;
    const updateData: Record<string, unknown> = { ...data };
    delete updateData.privateKey;
    delete updateData.password;
    delete updateData.tags;
    delete updateData.proxmoxTokenSecret;
    delete updateData.maintenanceUntil;

    if (data.tags) {
      updateData.tags = tagsToJson(data.tags);
    }

    if (data.manualPlatforms) {
      updateData.manualPlatforms = mergeManualPlatforms(existing.manualPlatforms, data.manualPlatforms);
    }

    if (data.maintenanceUntil !== undefined) {
      updateData.maintenanceUntil = data.maintenanceUntil
        ? new Date(data.maintenanceUntil)
        : null;
    }

    if (data.proxmoxTokenSecret) {
      updateData.encryptedProxmoxToken = encrypt(data.proxmoxTokenSecret);
    }

    if (data.privateKey?.trim()) {
      updateData.encryptedPrivateKey = encrypt(data.privateKey.trim());
    }
    if (data.password) {
      updateData.encryptedPassword = encrypt(data.password);
    }

    const server = await prisma.server.update({
      where: { id: params!.id },
      data: updateData,
    });

    await logAudit({
      userId: user.id,
      action: "SERVER_UPDATED",
      resourceType: "server",
      resourceId: server.id,
      details: { name: server.name },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);

export const DELETE = withAuth(
  async (req, { user, params }) => {
    const existing = await prisma.server.findUnique({ where: { id: params!.id } });
    if (!existing) return jsonError("Server not found", 404);

    await prisma.server.delete({ where: { id: params!.id } });

    await logAudit({
      userId: user.id,
      action: "SERVER_DELETED",
      resourceType: "server",
      resourceId: params!.id,
      details: { name: existing.name },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);
