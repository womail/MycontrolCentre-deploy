import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { serializeServer } from "@/lib/servers/serialize";

export const GET = withAuth(async () => {
  const servers = await prisma.server.findMany({
    where: { isActive: true },
    orderBy: { name: "asc" },
    select: {
      id: true,
      name: true,
      hostname: true,
      healthStatus: true,
      inMaintenance: true,
      proxmoxVersion: true,
      proxmoxNodeName: true,
      proxmoxSummary: true,
      lastProxmoxSync: true,
      manualPlatforms: true,
      detectedPlatforms: true,
      tags: true,
    },
  });

  const guests = await prisma.proxmoxGuest.groupBy({
    by: ["serverId"],
    _count: { _all: true },
  });
  const guestCountByServer = new Map(guests.map((row) => [row.serverId, row._count._all]));

  const nodes = servers.map((server) => {
    const serialized = serializeServer(server);
    const summary = server.proxmoxSummary as {
      vmCount?: number;
      lxcCount?: number;
      onlineNodes?: number;
      nodeCount?: number;
      quorum?: boolean;
    } | null;

    return {
      id: server.id,
      name: server.name,
      hostname: server.hostname,
      healthStatus: server.healthStatus,
      inMaintenance: server.inMaintenance,
      platforms: serialized.platforms,
      proxmoxVersion: server.proxmoxVersion,
      proxmoxNodeName: server.proxmoxNodeName,
      lastProxmoxSync: server.lastProxmoxSync,
      guestCount: guestCountByServer.get(server.id) ?? 0,
      summary,
    };
  });

  const proxmoxNodes = nodes.filter((node) => node.platforms.includes("proxmox"));
  const quorumIssues = proxmoxNodes.filter((node) => node.summary?.quorum === false);

  return NextResponse.json({
    nodes,
    proxmoxNodes,
    quorumIssues,
    totals: {
      servers: nodes.length,
      proxmoxNodes: proxmoxNodes.length,
      guests: nodes.reduce((sum, node) => sum + node.guestCount, 0),
      quorumIssues: quorumIssues.length,
    },
  });
});
