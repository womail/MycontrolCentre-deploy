import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { prisma } from "@/lib/db";

export const GET = withAuth(
  async (req) => {
  const url = new URL(req.url);
  const limit = Math.min(parseInt(url.searchParams.get("limit") ?? "100", 10), 500);
  const serverId = url.searchParams.get("serverId");
  const purpose = url.searchParams.get("purpose");
  const outcome = url.searchParams.get("outcome");

  const logs = await prisma.remoteConnectionLog.findMany({
    where: {
      ...(serverId ? { serverId } : {}),
      ...(purpose ? { purpose: purpose as never } : {}),
      ...(outcome ? { outcome: outcome as never } : {}),
    },
    take: limit,
    orderBy: { createdAt: "desc" },
    include: {
      user: { select: { id: true, username: true } },
      server: { select: { id: true, name: true } },
    },
  });

  return NextResponse.json({ logs });
  },
  { roles: ["ADMIN", "OPERATOR"] },
);
