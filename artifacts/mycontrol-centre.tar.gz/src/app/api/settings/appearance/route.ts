import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import {
  appearanceSchema,
  getAppearanceSettings,
  mergeAppearance,
  setAppearanceSettings,
} from "@/lib/settings/appearance";

export async function GET() {
  const appearance = await getAppearanceSettings();
  return NextResponse.json({ appearance });
}

export const PATCH = withAuth(
  async (req, { user }) => {
    const body = await req.json();
    const parsed = appearanceSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid appearance settings");
    }

    const current = await getAppearanceSettings();
    const next = mergeAppearance({ ...current, ...parsed.data });
    await setAppearanceSettings(next);

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "appearance",
      details: parsed.data,
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true, appearance: next });
  },
  { roles: ["ADMIN"] },
);
