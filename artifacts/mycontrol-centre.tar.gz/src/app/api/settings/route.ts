import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { getMaxConcurrentSsh, getSetting, setSetting } from "@/lib/settings";
import { getBackupMaxAgeHours, setBackupMaxAgeHours } from "@/lib/backup/settings";
import {
  getConsolePublicUrl,
  setConsolePublicUrl,
} from "@/lib/settings/console-url";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { z } from "zod";

export const GET = withAuth(async (req) => {
  const maxConcurrentSsh = await getMaxConcurrentSsh();
  const auditRetentionDays = await getSetting(
    "audit_retention_days",
    process.env.AUDIT_LOG_RETENTION_DAYS ?? "365",
  );
  const consolePublicUrl = await getConsolePublicUrl(req);
  const backupMaxAgeHours = await getBackupMaxAgeHours();

  return NextResponse.json({
    maxConcurrentSsh,
    auditRetentionDays: parseInt(auditRetentionDays, 10),
    consolePublicUrl,
    backupMaxAgeHours,
  });
});

const updateSchema = z.object({
  maxConcurrentSsh: z.number().int().min(1).max(50).optional(),
  auditRetentionDays: z.number().int().min(30).max(3650).optional(),
  consolePublicUrl: z.string().min(1).optional(),
  backupMaxAgeHours: z.number().int().min(1).max(8760).optional(),
});

export const PATCH = withAuth(
  async (req, { user }) => {
    const body = await req.json();
    const parsed = updateSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    if (parsed.data.maxConcurrentSsh != null) {
      await setSetting("max_concurrent_ssh", String(parsed.data.maxConcurrentSsh));
    }
    if (parsed.data.auditRetentionDays != null) {
      await setSetting("audit_retention_days", String(parsed.data.auditRetentionDays));
    }
    if (parsed.data.consolePublicUrl != null) {
      await setConsolePublicUrl(parsed.data.consolePublicUrl);
    }
    if (parsed.data.backupMaxAgeHours != null) {
      await setBackupMaxAgeHours(parsed.data.backupMaxAgeHours);
    }

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      details: parsed.data,
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);
