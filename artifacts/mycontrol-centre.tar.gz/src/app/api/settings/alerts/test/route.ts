import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { dispatchAlert } from "@/lib/alerts/dispatch";
import { getAlertSettings } from "@/lib/alerts/settings";

export const POST = withAuth(
  async () => {
    const settings = await getAlertSettings();
    if (!settings.enabled) {
      return jsonError("Alerts are disabled. Enable alerts before sending a test.");
    }

    const results = await dispatchAlert(settings, {
      title: "MyControl Centre test alert",
      message: "If you received this, alert delivery is configured correctly.",
      severity: "info",
      event: "test",
    });

    if (results.length === 0) {
      return jsonError("No enabled alert channels configured");
    }

    const failed = results.filter((result) => !result.ok);
    if (failed.length === results.length) {
      return jsonError(failed[0]?.error ?? "All alert channels failed");
    }

    return NextResponse.json({ ok: true, results });
  },
  { roles: ["ADMIN"] },
);
