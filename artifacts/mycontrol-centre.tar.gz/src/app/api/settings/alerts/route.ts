import { randomUUID } from "crypto";
import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import {
  getAlertSettings,
  mergeAlertSettingsUpdate,
  sanitizeAlertSettingsForClient,
  setAlertSettings,
  type AlertChannel,
  type AlertSettings,
} from "@/lib/alerts/settings";
import { restartHealthScheduler } from "@/lib/queue/background-services";
import { z } from "zod";

const channelSchema = z.object({
  id: z.string().optional(),
  type: z.enum(["webhook", "ntfy", "gotify"]),
  enabled: z.boolean().optional(),
  url: z.string().optional(),
  topic: z.string().optional(),
  token: z.string().optional(),
});

const updateSchema = z.object({
  enabled: z.boolean().optional(),
  healthCheckEnabled: z.boolean().optional(),
  healthCheckIntervalMinutes: z.number().int().min(1).max(1440).optional(),
  alertOnRecovery: z.boolean().optional(),
  alertCooldownMinutes: z.number().int().min(5).max(1440).optional(),
  skipAlertsInMaintenance: z.boolean().optional(),
  channels: z.array(channelSchema).optional(),
});

export const GET = withAuth(
  async () => {
    const settings = await getAlertSettings();
    return NextResponse.json({
      alerts: sanitizeAlertSettingsForClient(settings),
    });
  },
  { roles: ["ADMIN"] },
);

export const PATCH = withAuth(
  async (req, { user }) => {
    const body = await req.json();
    const parsed = updateSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const current = await getAlertSettings();
    const merged = mergeAlertSettingsUpdate(
      current,
      parsed.data as Partial<AlertSettings> & {
        channels?: Array<Partial<AlertChannel> & { id?: string; token?: string }>;
      },
    );

    if (parsed.data.channels) {
      merged.channels = parsed.data.channels.map((channel) => {
        const existing = channel.id
          ? current.channels.find((entry) => entry.id === channel.id)
          : undefined;
        const token =
          channel.token === "********"
            ? existing?.token
            : channel.token?.trim()
              ? channel.token.trim()
              : existing?.token;

        return {
          id: channel.id ?? existing?.id ?? randomUUID(),
          type: channel.type ?? existing?.type ?? "webhook",
          enabled: channel.enabled ?? existing?.enabled ?? true,
          url: channel.url ?? existing?.url,
          topic: channel.topic ?? existing?.topic,
          token,
        };
      });
    }

    await setAlertSettings(merged);
    await restartHealthScheduler();

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "alerts",
      details: {
        enabled: merged.enabled,
        healthCheckEnabled: merged.healthCheckEnabled,
        healthCheckIntervalMinutes: merged.healthCheckIntervalMinutes,
        channelCount: merged.channels.length,
      },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({
      ok: true,
      alerts: sanitizeAlertSettingsForClient(merged),
    });
  },
  { roles: ["ADMIN"] },
);
