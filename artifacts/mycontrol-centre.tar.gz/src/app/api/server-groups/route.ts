import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { createServerGroupSchema } from "@/lib/servers/group-schemas";
import { resolveServerGroupMembers } from "@/lib/servers/groups";
import { serializeServerGroup } from "@/lib/servers/serialize-group";
import { tagsToJson } from "@/lib/servers/tags";

export const GET = withAuth(async () => {
  const groups = await prisma.serverGroup.findMany({ orderBy: { name: "asc" } });
  const withCounts = await Promise.all(
    groups.map(async (group) => {
      const memberIds = await resolveServerGroupMembers(group, { activeOnly: true });
      return { ...serializeServerGroup(group), memberCount: memberIds.length };
    }),
  );
  return NextResponse.json({ groups: withCounts });
});

export const POST = withAuth(
  async (req, { user }) => {
    const body = await req.json();
    const parsed = createServerGroupSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const existing = await prisma.serverGroup.findUnique({ where: { name: parsed.data.name } });
    if (existing) return jsonError("A group with this name already exists", 409);

    if (parsed.data.kind === "STATIC") {
      const count = await prisma.server.count({
        where: { id: { in: parsed.data.serverIds }, isActive: true },
      });
      if (count === 0) return jsonError("Select at least one active server");
    }

    const matchTags =
      parsed.data.kind === "TAG" ? tagsToJson(parsed.data.matchTags) : [];

    const group = await prisma.serverGroup.create({
      data:
        parsed.data.kind === "STATIC"
          ? {
              name: parsed.data.name,
              description: parsed.data.description,
              kind: "STATIC",
              serverIds: parsed.data.serverIds,
            }
          : {
              name: parsed.data.name,
              description: parsed.data.description,
              kind: "TAG",
              matchTags,
              matchAnyTag: parsed.data.matchAnyTag,
            },
    });

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "server_group",
      resourceId: group.id,
      details: { action: "created", name: group.name, kind: group.kind },
      ipAddress: getClientIp(req.headers),
    });

    const memberIds = await resolveServerGroupMembers(group, { activeOnly: true });
    return NextResponse.json(
      { group: { ...serializeServerGroup(group), memberCount: memberIds.length } },
      { status: 201 },
    );
  },
  { roles: ["ADMIN"] },
);
