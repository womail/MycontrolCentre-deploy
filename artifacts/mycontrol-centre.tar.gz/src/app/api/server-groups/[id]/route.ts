import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { updateServerGroupSchema } from "@/lib/servers/group-schemas";
import { resolveServerGroupMembers } from "@/lib/servers/groups";
import { serializeServerGroup } from "@/lib/servers/serialize-group";
import { tagsToJson } from "@/lib/servers/tags";

export const GET = withAuth(async (_req, { params }) => {
  const group = await prisma.serverGroup.findUnique({ where: { id: params!.id } });
  if (!group) return jsonError("Group not found", 404);
  const memberIds = await resolveServerGroupMembers(group, { activeOnly: true });
  return NextResponse.json({
    group: { ...serializeServerGroup(group), memberCount: memberIds.length },
  });
});

export const PATCH = withAuth(
  async (req, { user, params }) => {
    const existing = await prisma.serverGroup.findUnique({ where: { id: params!.id } });
    if (!existing) return jsonError("Group not found", 404);

    const body = await req.json();
    const parsed = updateServerGroupSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    if (parsed.data.name && parsed.data.name !== existing.name) {
      const conflict = await prisma.serverGroup.findUnique({ where: { name: parsed.data.name } });
      if (conflict) return jsonError("A group with this name already exists", 409);
    }

    const nextKind = parsed.data.kind ?? existing.kind;
    const data: Record<string, unknown> = {};
    if (parsed.data.name !== undefined) data.name = parsed.data.name;
    if (parsed.data.description !== undefined) data.description = parsed.data.description;
    if (parsed.data.kind !== undefined) data.kind = parsed.data.kind;

    if (nextKind === "STATIC") {
      const serverIds =
        parsed.data.serverIds ??
        (existing.kind === "STATIC" ? existing.serverIds : undefined);
      if (parsed.data.kind === "TAG" || parsed.data.serverIds !== undefined) {
        if (!Array.isArray(serverIds) || serverIds.length === 0) {
          return jsonError("Static groups need at least one server");
        }
        data.serverIds = serverIds;
        data.matchTags = [];
      }
    } else {
      const matchTagsRaw =
        parsed.data.matchTags ??
        (existing.kind === "TAG" ? existing.matchTags : undefined);
      if (parsed.data.kind === "STATIC" || parsed.data.matchTags !== undefined) {
        const matchTags = tagsToJson(Array.isArray(matchTagsRaw) ? (matchTagsRaw as string[]) : []);
        if (matchTags.length === 0) return jsonError("Tag groups need at least one tag");
        data.matchTags = matchTags;
        data.serverIds = [];
      }
      if (parsed.data.matchAnyTag !== undefined) data.matchAnyTag = parsed.data.matchAnyTag;
    }

    const group = await prisma.serverGroup.update({
      where: { id: existing.id },
      data,
    });

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "server_group",
      resourceId: group.id,
      details: { action: "updated", name: group.name },
      ipAddress: getClientIp(req.headers),
    });

    const memberIds = await resolveServerGroupMembers(group, { activeOnly: true });
    return NextResponse.json({
      group: { ...serializeServerGroup(group), memberCount: memberIds.length },
    });
  },
  { roles: ["ADMIN"] },
);

export const DELETE = withAuth(
  async (req, { user, params }) => {
    const existing = await prisma.serverGroup.findUnique({ where: { id: params!.id } });
    if (!existing) return jsonError("Group not found", 404);

    await prisma.serverGroup.delete({ where: { id: existing.id } });

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "server_group",
      resourceId: existing.id,
      details: { action: "deleted", name: existing.name },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);
