import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { resolveServerGroupMembers } from "@/lib/servers/groups";

export const GET = withAuth(async (_req, { params }) => {
  const group = await prisma.serverGroup.findUnique({ where: { id: params!.id } });
  if (!group) return jsonError("Group not found", 404);

  const memberIds = await resolveServerGroupMembers(group, { activeOnly: true });
  const servers =
    memberIds.length === 0
      ? []
      : await prisma.server.findMany({
          where: { id: { in: memberIds } },
          select: { id: true, name: true, hostname: true, healthStatus: true, tags: true },
          orderBy: { name: "asc" },
        });

  const order = new Map(memberIds.map((id, index) => [id, index]));
  servers.sort((a, b) => (order.get(a.id) ?? 0) - (order.get(b.id) ?? 0));

  return NextResponse.json({ serverIds: memberIds, servers });
});
