import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { createUser } from "@/lib/auth/password";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { z } from "zod";

const createUserSchema = z.object({
  username: z.string().min(3).max(64),
  password: z.string().min(12),
  role: z.enum(["ADMIN", "OPERATOR", "VIEWER"]),
});

export const GET = withAuth(
  async () => {
    const users = await prisma.user.findMany({
      orderBy: { username: "asc" },
      select: {
        id: true,
        username: true,
        role: true,
        isActive: true,
        mustChangePassword: true,
        createdAt: true,
        userMfa: { select: { totpEnabled: true } },
      },
    });
    return NextResponse.json({
      users: users.map((u) => ({
        id: u.id,
        username: u.username,
        role: u.role,
        isActive: u.isActive,
        mustChangePassword: u.mustChangePassword,
        createdAt: u.createdAt,
        totpEnabled: Boolean(u.userMfa?.totpEnabled),
      })),
    });
  },
  { roles: ["ADMIN"] },
);

export const POST = withAuth(
  async (req, { user }) => {
    const body = await req.json();
    const parsed = createUserSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    const existing = await prisma.user.findUnique({
      where: { username: parsed.data.username },
    });
    if (existing) return jsonError("Username already exists");

    try {
      const newUser = await createUser(parsed.data);
      await logAudit({
        userId: user.id,
        action: "USER_CREATED",
        resourceType: "user",
        resourceId: newUser.id,
        details: { username: newUser.username, role: newUser.role },
        ipAddress: getClientIp(req.headers),
      });
      return NextResponse.json(
        { user: { id: newUser.id, username: newUser.username, role: newUser.role } },
        { status: 201 },
      );
    } catch (error) {
      return jsonError(error instanceof Error ? error.message : "Failed");
    }
  },
  { roles: ["ADMIN"] },
);
