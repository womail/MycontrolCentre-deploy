import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { z } from "zod";

const updateSchema = z.object({
  role: z.enum(["ADMIN", "OPERATOR", "VIEWER"]).optional(),
  isActive: z.boolean().optional(),
});

export const PATCH = withAuth(
  async (req, { user, params }) => {
    const target = await prisma.user.findUnique({ where: { id: params!.id } });
    if (!target) return jsonError("User not found", 404);

    const body = await req.json();
    const parsed = updateSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    if (target.id === user.id && (parsed.data.isActive === false || parsed.data.role)) {
      return jsonError("Cannot demote or deactivate your own account");
    }

    const updated = await prisma.user.update({
      where: { id: params!.id },
      data: parsed.data,
    });

    await logAudit({
      userId: user.id,
      action: "USER_UPDATED",
      resourceType: "user",
      resourceId: updated.id,
      details: parsed.data,
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);

export const DELETE = withAuth(
  async (req, { user, params }) => {
    if (params!.id === user.id) {
      return jsonError("Cannot delete your own account");
    }

    const target = await prisma.user.findUnique({ where: { id: params!.id } });
    if (!target) return jsonError("User not found", 404);

    await prisma.user.delete({ where: { id: params!.id } });

    await logAudit({
      userId: user.id,
      action: "USER_DELETED",
      resourceType: "user",
      resourceId: params!.id,
      details: { username: target.username },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);
