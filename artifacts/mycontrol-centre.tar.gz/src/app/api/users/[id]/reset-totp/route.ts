import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { adminResetTotpForUser } from "@/lib/mfa/totp";

export const POST = withAuth(
  async (req, { user, params }) => {
    const target = await prisma.user.findUnique({ where: { id: params!.id } });
    if (!target) return jsonError("User not found", 404);

    await adminResetTotpForUser(target.id);

    await logAudit({
      userId: user.id,
      action: "USER_UPDATED",
      resourceType: "user",
      resourceId: target.id,
      details: { action: "reset_totp", username: target.username },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);
