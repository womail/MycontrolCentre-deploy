import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { z } from "zod";

const rejectSchema = z.object({
  reason: z.string().max(500).optional(),
});

export const POST = withAuth(
  async (req, { user, params }) => {
    const enrollment = await prisma.serverEnrollmentRequest.findUnique({
      where: { id: params!.id },
    });
    if (!enrollment) return jsonError("Enrollment request not found", 404);
    if (enrollment.status !== "PENDING") {
      return jsonError(`Request already ${enrollment.status.toLowerCase()}`, 409);
    }

    const body = await req.json().catch(() => ({}));
    const parsed = rejectSchema.safeParse(body);

    await prisma.serverEnrollmentRequest.update({
      where: { id: enrollment.id },
      data: {
        status: "REJECTED",
        reviewedAt: new Date(),
        reviewedById: user.id,
        rejectReason: parsed.success ? parsed.data.reason?.trim() || null : null,
      },
    });

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "enrollment",
      resourceId: enrollment.id,
      details: { action: "rejected", hostname: enrollment.hostname },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);
