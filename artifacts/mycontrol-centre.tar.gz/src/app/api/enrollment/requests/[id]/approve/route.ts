import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { encrypt } from "@/lib/crypto";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { tagsToJson } from "@/lib/servers/tags";
import {
  consumeSetupSshKey,
  findStoredPrivateKeyForFingerprint,
} from "@/lib/enrollment/setup-key";
import { resolveEnrollmentKnownHostKey } from "@/lib/enrollment/known-host";
import { runServerHealthCheck } from "@/lib/health/check-server";
import { z } from "zod";

const approveSchema = z.object({
  privateKey: z.string().min(1).optional(),
  name: z.string().min(1).max(100).optional(),
  password: z.string().optional(),
  useStoredKey: z.boolean().optional(),
});

export const POST = withAuth(
  async (req, { user, params }) => {
    const enrollment = await prisma.serverEnrollmentRequest.findUnique({
      where: { id: params!.id },
    });
    if (!enrollment) return jsonError("Enrollment request not found", 404);
    if (enrollment.status !== "PENDING") {
      return jsonError(`Request already ${enrollment.status.toLowerCase()}`, 409);
    }

    const body = await req.json().catch(() => ({}));
    const parsed = approveSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    let privateKey = parsed.data.privateKey?.trim() ?? "";
    if (!privateKey && (parsed.data.useStoredKey ?? true)) {
      privateKey =
        (await findStoredPrivateKeyForFingerprint(enrollment.publicKeyFingerprint)) ?? "";
    }
    if (!privateKey) {
      return jsonError(
        "No matching setup key in the console. Generate a key in the wizard, run the install command on the host, then approve — or paste the private key manually.",
      );
    }

    const name = parsed.data.name?.trim() || enrollment.name;
    const existing = await prisma.server.findFirst({
      where: { name },
    });
    if (existing) return jsonError("A server with this name already exists", 409);

    const knownHostKey = resolveEnrollmentKnownHostKey({
      knownHostKey: enrollment.knownHostKey,
      metadata: enrollment.metadata,
    });

    const server = await prisma.server.create({
      data: {
        name,
        hostname: enrollment.hostname,
        port: enrollment.port,
        sshUser: enrollment.sshUser,
        authType: parsed.data.password ? "KEY_AND_PASSWORD" : "KEY",
        encryptedPrivateKey: encrypt(privateKey),
        encryptedPassword: parsed.data.password ? encrypt(parsed.data.password) : null,
        knownHostKey,
        acceptNewHostKey: !knownHostKey,
        tags: tagsToJson([]),
        manualPlatforms: [],
        isActive: true,
      },
    });

    await prisma.serverEnrollmentRequest.update({
      where: { id: enrollment.id },
      data: {
        status: "APPROVED",
        reviewedAt: new Date(),
        reviewedById: user.id,
        serverId: server.id,
        name,
      },
    });

    if (enrollment.publicKeyFingerprint) {
      await consumeSetupSshKey(enrollment.publicKeyFingerprint);
    }

    await logAudit({
      userId: user.id,
      action: "SERVER_CREATED",
      resourceType: "server",
      resourceId: server.id,
      details: {
        source: "enrollment",
        enrollmentRequestId: enrollment.id,
        hostname: enrollment.hostname,
      },
      ipAddress: getClientIp(req.headers),
    });

    const health = await runServerHealthCheck({
      server,
      userId: user.id,
      triggeredBy: "manual",
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({
      ok: true,
      server: { id: server.id, name: server.name },
      health: { online: health.online, error: health.error },
    });
  },
  { roles: ["ADMIN"] },
);
