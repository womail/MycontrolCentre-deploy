import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { hasStoredSetupKey } from "@/lib/enrollment/setup-key";

export const GET = withAuth(
  async (req) => {
    const status = req.nextUrl.searchParams.get("status") ?? "PENDING";
    const where =
      status === "all"
        ? {}
        : { status: status as "PENDING" | "APPROVED" | "REJECTED" };

    const requests = await prisma.serverEnrollmentRequest.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: 50,
      include: {
        reviewedBy: { select: { username: true } },
        server: { select: { id: true, name: true } },
      },
    });

    return NextResponse.json({
      requests: await Promise.all(
        requests.map(async (entry) => ({
          id: entry.id,
          status: entry.status,
          name: entry.name,
          hostname: entry.hostname,
          port: entry.port,
          sshUser: entry.sshUser,
          publicKey: entry.publicKey,
          publicKeyFingerprint: entry.publicKeyFingerprint,
          knownHostKey: entry.knownHostKey,
          hostKeyType: entry.hostKeyType,
          metadata: entry.metadata,
          requestIp: entry.requestIp,
          createdAt: entry.createdAt.toISOString(),
          reviewedAt: entry.reviewedAt?.toISOString() ?? null,
          reviewedBy: entry.reviewedBy?.username ?? null,
          rejectReason: entry.rejectReason,
          serverId: entry.serverId,
          serverName: entry.server?.name ?? null,
          canUseStoredKey: await hasStoredSetupKey(entry.publicKeyFingerprint),
        })),
      ),
    });
  },
  { roles: ["ADMIN"] },
);
