import { NextResponse } from "next/server";
import { withApiLog, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import {
  enrollmentRegisterSchema,
  fingerprintPublicKey,
  normalizeEnrollmentPublicKey,
} from "@/lib/enrollment/register";
import { getEnrollmentToken } from "@/lib/enrollment/token";
import { resolveEnrollmentKnownHostKey } from "@/lib/enrollment/known-host";
import { checkRateLimit, getClientIp } from "@/lib/rate-limit";
import { safeCompare } from "@/lib/auth/session";
import type { Prisma } from "@prisma/client";

function readEnrollmentToken(req: Request): string | null {
  const header = req.headers.get("x-enrollment-token")?.trim();
  if (header) return header;
  const auth = req.headers.get("authorization");
  if (auth?.toLowerCase().startsWith("bearer ")) {
    return auth.slice(7).trim();
  }
  return null;
}

export const POST = withApiLog(async (req) => {
  const ip = getClientIp(req.headers);
  const rate = checkRateLimit(`enrollment:${ip}`);
  if (!rate.allowed) {
    return jsonError("Too many enrollment attempts. Try again later.", 429);
  }

  const configured = await getEnrollmentToken();
  if (!configured) {
    return jsonError("Server enrollment is not enabled on this console", 503);
  }

  const provided = readEnrollmentToken(req);
  if (!provided || !configured || !safeCompare(provided, configured)) {
    return jsonError("Invalid enrollment token", 401);
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError("Invalid JSON body");
  }

  const parsed = enrollmentRegisterSchema.safeParse(body);
  if (!parsed.success) {
    const details = parsed.error.errors
      .map((issue) => {
        const path = issue.path.length ? issue.path.join(".") : "body";
        return `${path}: ${issue.message}`;
      })
      .join("; ");
    return jsonError(details || "Invalid enrollment payload");
  }

  let publicKey: string;
  try {
    publicKey = normalizeEnrollmentPublicKey(parsed.data.publicKey);
  } catch (error) {
    return jsonError(error instanceof Error ? error.message : "Invalid public key");
  }

  const fingerprint = fingerprintPublicKey(publicKey);
  const knownHostKey = resolveEnrollmentKnownHostKey({
    knownHostKey: parsed.data.knownHostKey,
    knownHostKeys: parsed.data.knownHostKeys,
    metadata: parsed.data.metadata as Prisma.JsonValue | undefined,
  });

  const duplicatePending = await prisma.serverEnrollmentRequest.findFirst({
    where: {
      status: "PENDING",
      hostname: parsed.data.hostname,
      sshUser: parsed.data.sshUser,
      publicKeyFingerprint: fingerprint,
    },
  });
  if (duplicatePending) {
    return NextResponse.json({
      ok: true,
      requestId: duplicatePending.id,
      status: duplicatePending.status,
      message: "Enrollment request already pending for this host",
    });
  }

  const request = await prisma.serverEnrollmentRequest.create({
    data: {
      name: parsed.data.name.trim(),
      hostname: parsed.data.hostname.trim(),
      port: parsed.data.port,
      sshUser: parsed.data.sshUser.trim(),
      publicKey,
      publicKeyFingerprint: fingerprint,
      knownHostKey,
      hostKeyType: parsed.data.hostKeyType?.trim() || null,
      metadata: (parsed.data.metadata ?? undefined) as Prisma.InputJsonValue | undefined,
      requestIp: ip,
    },
  });

  return NextResponse.json(
    {
      ok: true,
      requestId: request.id,
      status: request.status,
      message: "Enrollment submitted — waiting for admin approval",
    },
    { status: 201 },
  );
});
