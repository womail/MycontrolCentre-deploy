import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { prisma } from "@/lib/db";

export const GET = withAuth(
  async () => {
    const count = await prisma.serverEnrollmentRequest.count({
      where: { status: "PENDING" },
    });
    return NextResponse.json({ count });
  },
  { roles: ["ADMIN"] },
);
