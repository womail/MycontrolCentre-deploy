import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import {
  ensureEnrollmentToken,
  getEnrollmentToken,
  rotateEnrollmentToken,
  sanitizeEnrollmentTokenForClient,
} from "@/lib/enrollment/token";

export const GET = withAuth(
  async () => {
    const token = await getEnrollmentToken();
    return NextResponse.json({
      enabled: Boolean(token),
      tokenHint: sanitizeEnrollmentTokenForClient(token),
    });
  },
  { roles: ["ADMIN"] },
);

export const POST = withAuth(
  async (req, { user }) => {
    const url = new URL(req.url);
    const rotate = url.searchParams.get("rotate") === "1";

    const token = rotate ? await rotateEnrollmentToken() : await ensureEnrollmentToken();

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "enrollment",
      details: { action: rotate ? "rotate_token" : "ensure_token" },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({
      ok: true,
      token,
      tokenHint: sanitizeEnrollmentTokenForClient(token),
    });
  },
  { roles: ["ADMIN"] },
);
