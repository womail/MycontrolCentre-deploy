import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { prisma } from "@/lib/db";

export const GET = withAuth(
  async (req) => {
  const url = new URL(req.url);
  const limit = Math.min(parseInt(url.searchParams.get("limit") ?? "100", 10), 500);
  const action = url.searchParams.get("action");

  const logs = await prisma.auditLog.findMany({
    where: action ? { action: action as never } : undefined,
    take: limit,
    orderBy: { createdAt: "desc" },
    include: {
      user: { select: { id: true, username: true } },
    },
  });

  return NextResponse.json({ logs });
  },
  { roles: ["ADMIN", "OPERATOR"] },
);
