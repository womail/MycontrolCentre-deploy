import { NextRequest } from "next/server";
import { withApiLog, jsonError } from "@/lib/api-handler";
import { verifyMfaPendingToken } from "@/lib/mfa/pending-token";
import { verifyStepUpMfa } from "@/lib/mfa/verify-step-up";
import { webAuthnChallengeKeyForLogin } from "@/lib/mfa/webauthn-auth";
import { finishLoginSession } from "@/lib/auth/finish-login";
import { z } from "zod";
import type { AuthenticationResponseJSON } from "@simplewebauthn/server";

const schema = z.object({
  mfaToken: z.string().min(1),
  totpCode: z.string().optional(),
  webauthnResponse: z.custom<AuthenticationResponseJSON>().optional(),
});

export const POST = withApiLog(async (req: NextRequest) => {
  const body = await req.json().catch(() => ({}));
  const parsed = schema.safeParse(body);
  if (!parsed.success) return jsonError("Invalid MFA request");

  const pending = verifyMfaPendingToken(parsed.data.mfaToken);
  if (!pending) return jsonError("MFA session expired — sign in again", 401);

  const step = await verifyStepUpMfa({
    userId: pending.userId,
    totpCode: parsed.data.totpCode,
    webauthnResponse: parsed.data.webauthnResponse,
    request: req,
    webAuthnChallengeKey: webAuthnChallengeKeyForLogin(pending.userId),
  });
  if (!step.ok) return jsonError(step.error, 401);

  return finishLoginSession(pending.userId, req);
});
