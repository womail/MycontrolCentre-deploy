import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { verifyWebAuthnRegistration } from "@/lib/mfa/webauthn-register";
import type { RegistrationResponseJSON } from "@simplewebauthn/server";
import { z } from "zod";

const schema = z.object({
  response: z.custom<RegistrationResponseJSON>(),
  deviceName: z.string().max(80).optional(),
});

export const POST = withAuth(async (req, { user }) => {
  const body = await req.json().catch(() => ({}));
  const parsed = schema.safeParse(body);
  if (!parsed.success) return jsonError("Invalid registration response");

  const ok = await verifyWebAuthnRegistration({
    userId: user.id,
    response: parsed.data.response,
    deviceName: parsed.data.deviceName,
    request: req,
  });
  if (!ok) return jsonError("Could not register security key", 400);
  return NextResponse.json({ ok: true });
});
