import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { createWebAuthnRegistrationOptions } from "@/lib/mfa/webauthn-register";

export const POST = withAuth(async (req, { user }) => {
  const { options } = await createWebAuthnRegistrationOptions(
    { id: user.id, username: user.username },
    req,
  );
  return NextResponse.json(options);
});
