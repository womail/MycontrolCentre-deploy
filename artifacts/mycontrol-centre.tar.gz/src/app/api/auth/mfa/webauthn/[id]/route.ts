import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { verifyPassword } from "@/lib/auth/password";
import { z } from "zod";

const schema = z.object({ password: z.string().min(1) });

export const DELETE = withAuth(async (req, { user, params }) => {
  const id = params?.id;
  if (!id) return jsonError("Missing credential id");

  const body = await req.json().catch(() => ({}));
  const parsed = schema.safeParse(body);
  if (!parsed.success) return jsonError("Password required");

  if (!(await verifyPassword(parsed.data.password, user.passwordHash))) {
    return jsonError("Invalid password", 401);
  }

  const cred = await prisma.webAuthnCredential.findUnique({ where: { id } });
  if (!cred || cred.userId !== user.id) return jsonError("Not found", 404);

  await prisma.webAuthnCredential.delete({ where: { id } });
  return NextResponse.json({ ok: true });
});
