import { NextRequest, NextResponse } from "next/server";
import { withApiLog, jsonError } from "@/lib/api-handler";
import { verifyMfaPendingToken } from "@/lib/mfa/pending-token";
import { createWebAuthnLoginOptions } from "@/lib/mfa/webauthn-auth";
import { z } from "zod";

const schema = z.object({ mfaToken: z.string().min(1) });

export const POST = withApiLog(async (req: NextRequest) => {
  const body = await req.json().catch(() => ({}));
  const parsed = schema.safeParse(body);
  if (!parsed.success) return jsonError("Missing MFA token");

  const pending = verifyMfaPendingToken(parsed.data.mfaToken);
  if (!pending) return jsonError("MFA session expired", 401);

  const options = await createWebAuthnLoginOptions(pending.userId, req);
  return NextResponse.json(options);
});
