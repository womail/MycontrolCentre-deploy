import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { decrypt } from "@/lib/crypto";
import { verifyTotpCode, enableTotpForUser } from "@/lib/mfa/totp";
import { z } from "zod";

const schema = z.object({ code: z.string().min(6).max(8) });

export const POST = withAuth(async (req, { user }) => {
  const body = await req.json().catch(() => ({}));
  const parsed = schema.safeParse(body);
  if (!parsed.success) return jsonError("Enter the 6-digit code from your app");

  const row = await prisma.userMfa.findUnique({ where: { userId: user.id } });
  if (!row?.encryptedTotpSecret) {
    return jsonError("Start TOTP setup first");
  }
  const secret = decrypt(row.encryptedTotpSecret);
  if (!verifyTotpCode(secret, parsed.data.code)) {
    return jsonError("Invalid code — check time sync on your phone");
  }

  await enableTotpForUser(user.id);
  return NextResponse.json({ ok: true, totpEnabled: true });
});
