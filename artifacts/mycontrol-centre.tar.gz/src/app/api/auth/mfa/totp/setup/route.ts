import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { generateTotpSecret, storePendingTotpSecret, totpKeyUri } from "@/lib/mfa/totp";

export const POST = withAuth(async (_req, { user }) => {
  const secret = generateTotpSecret();
  await storePendingTotpSecret(user.id, secret);
  return NextResponse.json({
    secret,
    otpauthUrl: totpKeyUri(user.username, secret),
  });
});
