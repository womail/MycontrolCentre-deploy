import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { verifyPassword } from "@/lib/auth/password";
import { disableTotpForUser, getTotpSecretForUser, verifyTotpCode } from "@/lib/mfa/totp";
import { z } from "zod";

const schema = z.object({
  password: z.string().min(1),
  code: z.string().min(6).max(8),
});

export const DELETE = withAuth(async (req, { user }) => {
  const body = await req.json().catch(() => ({}));
  const parsed = schema.safeParse(body);
  if (!parsed.success) return jsonError("Password and current TOTP code required");

  if (!(await verifyPassword(parsed.data.password, user.passwordHash))) {
    return jsonError("Invalid password", 401);
  }
  const secret = await getTotpSecretForUser(user.id);
  if (!secret || !verifyTotpCode(secret, parsed.data.code)) {
    return jsonError("Invalid authenticator code", 401);
  }

  await disableTotpForUser(user.id);
  return NextResponse.json({ ok: true });
});
