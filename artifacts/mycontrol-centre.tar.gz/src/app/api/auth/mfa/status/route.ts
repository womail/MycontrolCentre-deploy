import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { getUserMfaSummary } from "@/lib/mfa/user-state";
import { prisma } from "@/lib/db";

export const GET = withAuth(async (_req, { user }) => {
  const summary = await getUserMfaSummary(user.id);
  const credentials = await prisma.webAuthnCredential.findMany({
    where: { userId: user.id },
    select: { id: true, deviceName: true, createdAt: true, lastUsedAt: true },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({
    totpEnabled: summary.totpEnabled,
    webAuthnCount: summary.webAuthnCount,
    credentials,
  });
});
