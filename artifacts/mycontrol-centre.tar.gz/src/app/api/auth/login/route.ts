import { NextRequest, NextResponse } from "next/server";
import { authenticateUser } from "@/lib/auth/password";
import {
  destroySession,
  getSessionUser,
} from "@/lib/auth/session";
import { finishLoginSession } from "@/lib/auth/finish-login";
import { logAudit } from "@/lib/audit";
import { withApiLog } from "@/lib/api-handler";
import { checkRateLimit, getClientIp, resetRateLimit } from "@/lib/rate-limit";
import { createMfaPendingToken } from "@/lib/mfa/pending-token";
import { getUserMfaSummary } from "@/lib/mfa/user-state";

export const POST = withApiLog(async (req: NextRequest) => {
  const ip = getClientIp(req.headers);
  const body = await req.json();
  const username = String(body.username ?? "").trim();
  const password = String(body.password ?? "");

  const rate = checkRateLimit(`login:${ip}`);
  const userRate = username
    ? checkRateLimit(`login:user:${username.toLowerCase()}`)
    : { allowed: true as const };
  if (!rate.allowed || !userRate.allowed) {
    return NextResponse.json(
      { error: "Too many login attempts. Try again later." },
      { status: 429 },
    );
  }

  if (!username || !password) {
    return NextResponse.json(
      { error: "Username and password are required" },
      { status: 400 },
    );
  }

  const user = await authenticateUser(username, password);
  if (!user) {
    await logAudit({
      action: "LOGIN_FAILED",
      details: { username },
      ipAddress: ip,
      userAgent: req.headers.get("user-agent") ?? undefined,
    });
    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
  }

  resetRateLimit(`login:${ip}`);
  resetRateLimit(`login:user:${username.toLowerCase()}`);

  const mfa = await getUserMfaSummary(user.id);
  if (mfa.requiresMfa) {
    return NextResponse.json({
      requiresMfa: true,
      mfaToken: createMfaPendingToken(user.id),
      methods: { totp: mfa.totpEnabled, webauthn: mfa.hasWebAuthn },
    });
  }

  return finishLoginSession(user.id, req);
});

export const DELETE = withApiLog(async (req: NextRequest) => {
  const user = await getSessionUser();
  if (user) {
    await logAudit({
      userId: user.id,
      action: "LOGOUT",
      ipAddress: getClientIp(req.headers),
      userAgent: req.headers.get("user-agent") ?? undefined,
    });
  }
  await destroySession();
  return NextResponse.json({ ok: true });
});
