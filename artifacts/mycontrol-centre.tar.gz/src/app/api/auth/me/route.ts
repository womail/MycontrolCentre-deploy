import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth/session";
import { withApiLog } from "@/lib/api-handler";

export const GET = withApiLog(async () => {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  return NextResponse.json({
    user: {
      id: user.id,
      username: user.username,
      role: user.role,
      mustChangePassword: user.mustChangePassword,
    },
  });
});
