import { NextRequest, NextResponse } from "next/server";
import { changePassword } from "@/lib/auth/password";
import { destroyAllUserSessions, getSessionUser } from "@/lib/auth/session";
import { logAudit } from "@/lib/audit";
import { withApiLog } from "@/lib/api-handler";
import { getClientIp } from "@/lib/rate-limit";

export const POST = withApiLog(async (req: NextRequest) => {
  const user = await getSessionUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const currentPassword = String(body.currentPassword ?? "");
  const newPassword = String(body.newPassword ?? "");

  if (!newPassword) {
    return NextResponse.json(
      { error: "New password is required" },
      { status: 400 },
    );
  }

  if (!user.mustChangePassword && !currentPassword) {
    return NextResponse.json(
      { error: "Current password is required" },
      { status: 400 },
    );
  }

  try {
    if (!user.mustChangePassword) {
      const { authenticateUser } = await import("@/lib/auth/password");
      const verified = await authenticateUser(user.username, currentPassword);
      if (!verified) {
        return NextResponse.json(
          { error: "Current password is incorrect" },
          { status: 400 },
        );
      }
    }

    await changePassword(user.id, newPassword);
    await destroyAllUserSessions(user.id);

    await logAudit({
      userId: user.id,
      action: "PASSWORD_CHANGED",
      ipAddress: getClientIp(req.headers),
      userAgent: req.headers.get("user-agent") ?? undefined,
    });

    return NextResponse.json({
      ok: true,
      message: "Password changed. Please log in again.",
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed";
    return NextResponse.json({ error: message }, { status: 400 });
  }
});
