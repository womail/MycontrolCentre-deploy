import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { collectSystemProfile } from "@/lib/admin/system-profile";

export const GET = withAuth(
  async () => {
    const profile = await collectSystemProfile();
    return NextResponse.json({ profile });
  },
  { roles: ["ADMIN"] },
);
