import { readFileSync, existsSync } from "fs";
import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { resolveSqliteFilePath } from "@/lib/db/sqlite-path";
import {
  encryptDatabaseBytes,
  getStoredBackupPassword,
  setStoredBackupPassword,
  clearStoredBackupPassword,
} from "@/lib/db/encrypted-backup";
import { z } from "zod";

export const GET = withAuth(
  async () => {
    const configured = Boolean(await getStoredBackupPassword());
    return NextResponse.json({ backupPasswordConfigured: configured });
  },
  { roles: ["ADMIN"] },
);

const passwordSchema = z.object({
  password: z.string().min(8).max(200),
  clear: z.boolean().optional(),
});

export const PATCH = withAuth(
  async (req, { user }) => {
    const body = await req.json();
    const parsed = passwordSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid password");
    }
    if (parsed.data.clear) {
      await clearStoredBackupPassword();
    } else {
      await setStoredBackupPassword(parsed.data.password);
    }
    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "database-backup",
      details: { action: parsed.data.clear ? "clear_password" : "set_password" },
      ipAddress: getClientIp(req.headers),
    });
    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);

const backupSchema = z.object({
  password: z.string().min(8).max(200).optional(),
});

export const POST = withAuth(
  async (req, { user }) => {
    const body = await req.json().catch(() => ({}));
    const parsed = backupSchema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }

    let password = parsed.data.password?.trim();
    if (!password) {
      password = (await getStoredBackupPassword()) ?? undefined;
    }
    if (!password) {
      return jsonError("Set a backup password in Database admin or pass password in the request");
    }

    const dbPath = resolveSqliteFilePath();
    if (!existsSync(dbPath)) {
      return jsonError("Database file not found", 404);
    }

    const plaintext = readFileSync(dbPath);
    const encrypted = encryptDatabaseBytes(plaintext, password);
    const filename = `mycontrol-backup-${new Date().toISOString().replace(/[:.]/g, "-")}.mccdb`;

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "database-backup",
      details: { action: "export", bytes: encrypted.length },
      ipAddress: getClientIp(req.headers),
    });

    return new NextResponse(new Uint8Array(encrypted), {
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    });
  },
  { roles: ["ADMIN"] },
);
