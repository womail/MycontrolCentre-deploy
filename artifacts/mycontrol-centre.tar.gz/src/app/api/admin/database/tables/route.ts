import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { ADMIN_TABLES } from "@/lib/admin/database-registry";

export const GET = withAuth(
  async () => NextResponse.json({ tables: ADMIN_TABLES }),
  { roles: ["ADMIN"] },
);
