import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import {
  deleteAdminTableRow,
  getAdminTableMeta,
  getAdminTableRow,
  updateAdminTableRow,
  type AdminTableId,
} from "@/lib/admin/database-registry";

export const GET = withAuth(
  async (_req, { params }) => {
    const tableId = params!.table as AdminTableId;
    const meta = getAdminTableMeta(tableId);
    if (!meta) return jsonError("Unknown table", 404);
    const row = await getAdminTableRow(tableId, params!.id);
    if (!row) return jsonError("Row not found", 404);
    return NextResponse.json({ meta, row });
  },
  { roles: ["ADMIN"] },
);

export const PATCH = withAuth(
  async (req, { params }) => {
    const tableId = params!.table as AdminTableId;
    const meta = getAdminTableMeta(tableId);
    if (!meta) return jsonError("Unknown table", 404);
    const body = (await req.json()) as Record<string, unknown>;
    const row = await updateAdminTableRow(tableId, params!.id, body);
    return NextResponse.json({ row });
  },
  { roles: ["ADMIN"] },
);

export const DELETE = withAuth(
  async (_req, { params }) => {
    const tableId = params!.table as AdminTableId;
    const meta = getAdminTableMeta(tableId);
    if (!meta) return jsonError("Unknown table", 404);
    if (!meta.canDelete) return jsonError("Delete not allowed for this table", 403);
    await deleteAdminTableRow(tableId, params!.id);
    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);
