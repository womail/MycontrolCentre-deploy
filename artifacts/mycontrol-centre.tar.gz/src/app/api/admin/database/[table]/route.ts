import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import {
  createAdminTableRow,
  getAdminTableMeta,
  listAdminTableRows,
  type AdminTableId,
} from "@/lib/admin/database-registry";

export const GET = withAuth(
  async (_req, { params }) => {
    const tableId = params!.table as AdminTableId;
    const meta = getAdminTableMeta(tableId);
    if (!meta) return jsonError("Unknown table", 404);
    const rows = await listAdminTableRows(tableId);
    return NextResponse.json({ meta, rows });
  },
  { roles: ["ADMIN"] },
);

export const POST = withAuth(
  async (req, { params }) => {
    const tableId = params!.table as AdminTableId;
    const meta = getAdminTableMeta(tableId);
    if (!meta) return jsonError("Unknown table", 404);
    if (!meta.canCreate) return jsonError("Create not allowed for this table", 403);

    const body = (await req.json()) as Record<string, unknown>;
    const row = await createAdminTableRow(tableId, body);
    return NextResponse.json({ row }, { status: 201 });
  },
  { roles: ["ADMIN"] },
);
