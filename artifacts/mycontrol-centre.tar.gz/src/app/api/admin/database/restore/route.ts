import { writeFileSync, copyFileSync, existsSync } from "fs";
import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { resolveSqliteFilePath } from "@/lib/db/sqlite-path";
import { decryptDatabaseBytes } from "@/lib/db/encrypted-backup";

export const POST = withAuth(
  async (req, { user }) => {
    const form = await req.formData();
    const file = form.get("file");
    const password = String(form.get("password") ?? "").trim();
    if (!(file instanceof File)) return jsonError("Missing backup file");
    if (password.length < 8) return jsonError("Backup password required (min 8 characters)");

    const dbPath = resolveSqliteFilePath();
    const buffer = Buffer.from(await file.arrayBuffer());
    let plaintext: Buffer;
    try {
      plaintext = decryptDatabaseBytes(buffer, password);
    } catch (error) {
      return jsonError(
        error instanceof Error ? error.message : "Decrypt failed — wrong password?",
        400,
      );
    }

    const preRestore = `${dbPath}.pre-restore-${Date.now()}`;
    if (existsSync(dbPath)) {
      copyFileSync(dbPath, preRestore);
    }
    writeFileSync(dbPath, plaintext);

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "database-backup",
      details: { action: "restore", preRestoreBackup: preRestore },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({
      ok: true,
      message:
        "Database restored. Restart MyControl Centre so all workers reload the database file.",
      preRestoreBackup: preRestore,
    });
  },
  { roles: ["ADMIN"] },
);
