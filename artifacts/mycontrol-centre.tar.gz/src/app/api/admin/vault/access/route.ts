import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { hasVaultUnlock } from "@/lib/vault/unlock";
import { logVaultEntryAccess } from "@/lib/vault/access-log";
import { getClientIp } from "@/lib/rate-limit";
import { z } from "zod";

const schema = z.object({
  entryType: z.enum(["SERVER", "SETUP_KEY"]),
  entryId: z.string().min(1),
  entryLabel: z.string().max(200).optional(),
  action: z.enum(["COPY"]),
  clientLabel: z.string().max(200).optional(),
  clientNode: z.string().max(120).optional(),
});

export const POST = withAuth(
  async (req, { user }) => {
    if (!(await hasVaultUnlock())) {
      return jsonError("Unlock the vault first", 403);
    }
    const body = await req.json().catch(() => ({}));
    const parsed = schema.safeParse(body);
    if (!parsed.success) return jsonError("Invalid access log payload");

    await logVaultEntryAccess({
      userId: user.id,
      entryType: parsed.data.entryType,
      entryId: parsed.data.entryId,
      entryLabel: parsed.data.entryLabel,
      action: "COPY",
      ipAddress: getClientIp(req.headers),
      userAgent: req.headers.get("user-agent"),
      clientLabel: parsed.data.clientLabel,
      clientNodeHint:
        parsed.data.clientNode ?? req.headers.get("x-mcc-client-node"),
    });

    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);
