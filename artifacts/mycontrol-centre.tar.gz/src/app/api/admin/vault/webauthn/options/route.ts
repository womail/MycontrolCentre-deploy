import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import { createWebAuthnStepUpOptions } from "@/lib/mfa/webauthn-auth";

export const POST = withAuth(
  async (req, { user }) => {
    const options = await createWebAuthnStepUpOptions(user.id, req, "vault");
    return NextResponse.json(options);
  },
  { roles: ["ADMIN"] },
);
