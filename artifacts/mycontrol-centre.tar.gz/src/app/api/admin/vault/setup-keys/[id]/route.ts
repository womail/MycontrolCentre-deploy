import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { hasVaultUnlock } from "@/lib/vault/unlock";
import { deleteSetupSshKeyById } from "@/lib/enrollment/setup-key";

export const DELETE = withAuth(
  async (req, { user, params }) => {
    if (!(await hasVaultUnlock())) {
      return jsonError("Unlock the vault first", 403);
    }

    const id = params?.id?.trim();
    if (!id) return jsonError("Missing setup key id");

    const row = await prisma.setupSshKey.findUnique({ where: { id } });
    if (!row) return jsonError("Setup key not found", 404);

    await deleteSetupSshKeyById(id);

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "vault",
      resourceId: id,
      details: { action: "delete_setup_key", fingerprint: row.publicKeyFingerprint },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true });
  },
  { roles: ["ADMIN"] },
);
