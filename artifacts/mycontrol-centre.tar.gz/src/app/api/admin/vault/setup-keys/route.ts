import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { hasVaultUnlock } from "@/lib/vault/unlock";
import {
  deleteAllSetupSshKeys,
  deleteExpiredSetupSshKeys,
} from "@/lib/enrollment/setup-key";

export const DELETE = withAuth(
  async (req, { user }) => {
    if (!(await hasVaultUnlock())) {
      return jsonError("Unlock the vault first", 403);
    }

    const scope = new URL(req.url).searchParams.get("scope");
    let deleted = 0;

    if (scope === "expired") {
      deleted = await deleteExpiredSetupSshKeys();
    } else if (scope === "all") {
      deleted = await deleteAllSetupSshKeys();
    } else {
      return jsonError("Use scope=expired or scope=all");
    }

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "vault",
      details: { action: "delete_setup_keys", scope, deleted },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true, deleted });
  },
  { roles: ["ADMIN"] },
);
