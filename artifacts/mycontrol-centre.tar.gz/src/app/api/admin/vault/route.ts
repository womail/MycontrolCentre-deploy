import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { prisma } from "@/lib/db";
import { decrypt } from "@/lib/crypto";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import { sessionCookieSecure } from "@/lib/auth/session";
import {
  createVaultUnlockToken,
  hasVaultUnlock,
  isVaultConfigured,
  verifyVaultPassword,
  VAULT_UNLOCK_COOKIE,
  vaultUnlockCookieOptions,
} from "@/lib/vault/unlock";
import { getUserMfaSummary } from "@/lib/mfa/user-state";
import {
  getLatestVaultAccessByEntry,
  logVaultEntryAccess,
} from "@/lib/vault/access-log";
import {
  fingerprintPrivateKeyPem,
  mergeSetupKeyHostLinks,
  opensshFingerprintLabelFromPrivate,
  opensshPublicLineFromPrivate,
  type SetupKeyHostLink,
} from "@/lib/enrollment/setup-key-hosts";
import {
  opensshSha256FingerprintLabel,
  publicKeysMatch,
} from "@/lib/ssh/openssh-fingerprint";
import { fingerprintPublicKeyLookupKeys } from "@/lib/enrollment/register";
import { z } from "zod";

export const GET = withAuth(
  async (req, { user }) => {
    if (!isVaultConfigured()) {
      return NextResponse.json({
        configured: false,
        unlocked: false,
        entries: [],
      });
    }
    const unlocked = await hasVaultUnlock();
    const mfa = await getUserMfaSummary(user.id);
    if (!unlocked) {
      return NextResponse.json({
        configured: true,
        unlocked: false,
        entries: [],
        accountUnlock: {
          totp: mfa.totpEnabled,
          webauthn: mfa.hasWebAuthn,
        },
      });
    }

    const servers = await prisma.server.findMany({
      orderBy: { name: "asc" },
      select: {
        id: true,
        name: true,
        hostname: true,
        port: true,
        sshUser: true,
        authType: true,
        encryptedPrivateKey: true,
        encryptedPassword: true,
        knownHostKey: true,
      },
    });

    const setupKeys = await prisma.setupSshKey.findMany({
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        publicKey: true,
        publicKeyFingerprint: true,
        encryptedPrivateKey: true,
        createdAt: true,
        expiresAt: true,
      },
    });

    const enrollments = await prisma.serverEnrollmentRequest.findMany({
      select: {
        id: true,
        status: true,
        name: true,
        hostname: true,
        port: true,
        sshUser: true,
        publicKey: true,
        publicKeyFingerprint: true,
        serverId: true,
        reviewedAt: true,
      },
      orderBy: { createdAt: "desc" },
    });

    const serverKeyMeta = new Map<
      string,
      {
        storedFingerprint: string | null;
        derivedPublicLine: string | null;
        opensshFingerprint: string | null;
      }
    >();
    for (const s of servers) {
      if (!s.encryptedPrivateKey) {
        serverKeyMeta.set(s.id, {
          storedFingerprint: null,
          derivedPublicLine: null,
          opensshFingerprint: null,
        });
        continue;
      }
      const plain = decrypt(s.encryptedPrivateKey);
      serverKeyMeta.set(s.id, {
        storedFingerprint: fingerprintPrivateKeyPem(plain),
        derivedPublicLine: opensshPublicLineFromPrivate(plain),
        opensshFingerprint: opensshFingerprintLabelFromPrivate(plain),
      });
    }

    function enrollmentMatchesSetupKey(
      enrollment: (typeof enrollments)[number],
      setupPublicKey: string,
      setupFingerprint: string,
    ): boolean {
      if (publicKeysMatch(enrollment.publicKey, setupPublicKey)) return true;
      const setupLookups = fingerprintPublicKeyLookupKeys(setupPublicKey);
      const enrollFp = enrollment.publicKeyFingerprint?.trim();
      if (enrollFp && setupLookups.includes(enrollFp)) return true;
      if (enrollFp && enrollFp === setupFingerprint) return true;
      return false;
    }

    function hostsForSetupPublicKey(setupPublicKey: string, setupFingerprint: string): SetupKeyHostLink[] {
      const links: SetupKeyHostLink[] = [];

      for (const e of enrollments) {
        if (!enrollmentMatchesSetupKey(e, setupPublicKey, setupFingerprint)) continue;
        const kind =
          e.status === "PENDING"
            ? "enrollment_pending"
            : e.status === "APPROVED"
              ? "enrollment_approved"
              : "enrollment_rejected";
        links.push({
          kind,
          label: e.name,
          hostname: e.hostname,
          port: e.port,
          sshUser: e.sshUser,
          serverId: e.serverId ?? undefined,
          enrollmentId: e.id,
          statusNote:
            e.status === "PENDING"
              ? "Install command run; awaiting approval"
              : e.status === "APPROVED"
                ? "Approved enrollment"
                : "Rejected enrollment",
        });
      }

      for (const s of servers) {
        const meta = serverKeyMeta.get(s.id);
        if (
          !meta?.derivedPublicLine ||
          !publicKeysMatch(meta.derivedPublicLine, setupPublicKey)
        ) {
          continue;
        }
        links.push({
          kind: "fleet",
          label: s.name,
          hostname: s.hostname,
          port: s.port,
          sshUser: s.sshUser,
          serverId: s.id,
          statusNote: "Fleet server (stored private key matches this wizard key)",
        });
      }

      return mergeSetupKeyHostLinks(links);
    }

    const ip = getClientIp(req.headers);
    const userAgent = req.headers.get("user-agent");
    const clientLabel = req.headers.get("x-mcc-client-label");
    const clientNodeHint = req.headers.get("x-mcc-client-node");

    await Promise.all([
      ...servers.map((s) =>
        logVaultEntryAccess({
          userId: user.id,
          entryType: "SERVER",
          entryId: s.id,
          entryLabel: s.name,
          action: "VIEW",
          ipAddress: ip,
          userAgent,
          clientLabel,
          clientNodeHint,
        }),
      ),
      ...setupKeys.map((k) =>
        logVaultEntryAccess({
          userId: user.id,
          entryType: "SETUP_KEY",
          entryId: k.id,
          entryLabel: k.publicKeyFingerprint,
          action: "VIEW",
          ipAddress: ip,
          userAgent,
          clientLabel,
          clientNodeHint,
        }),
      ),
    ]);

    const serverTargetNodes = new Map(
      servers.map((s) => [s.id, `${s.name} (${s.hostname}:${s.port})`]),
    );

    const [serverAccess, keyAccess] = await Promise.all([
      getLatestVaultAccessByEntry(
        "SERVER",
        servers.map((s) => s.id),
        serverTargetNodes,
      ),
      getLatestVaultAccessByEntry(
        "SETUP_KEY",
        setupKeys.map((k) => k.id),
      ),
    ]);

    return NextResponse.json({
      configured: true,
      unlocked: true,
      entries: {
        servers: servers.map((s) => {
          const last = serverAccess.get(s.id);
          const meta = serverKeyMeta.get(s.id);
          const storedFingerprint = meta?.storedFingerprint ?? null;
          return {
            id: s.id,
            name: s.name,
            hostname: s.hostname,
            port: s.port,
            sshUser: s.sshUser,
            authType: s.authType,
            privateKey: s.encryptedPrivateKey ? decrypt(s.encryptedPrivateKey) : null,
            password: s.encryptedPassword ? decrypt(s.encryptedPassword) : null,
            knownHostKey: s.knownHostKey,
            derivedPublicKey: meta?.derivedPublicLine ?? null,
            storedKeyFingerprint: storedFingerprint,
            opensshFingerprint: meta?.opensshFingerprint ?? null,
            matchesSetupWizardKey: setupKeys.some(
              (k) =>
                meta?.derivedPublicLine != null &&
                publicKeysMatch(meta.derivedPublicLine, k.publicKey),
            ),
            lastAccess: last
              ? {
                  at: last.at.toISOString(),
                  action: last.action,
                  username: last.username,
                  machine: last.machine,
                  clientNode: last.clientNode,
                  targetNode: last.targetNode,
                }
              : null,
          };
        }),
        setupKeys: setupKeys.map((k) => {
          const last = keyAccess.get(k.id);
          const wizardHosts = hostsForSetupPublicKey(k.publicKey, k.publicKeyFingerprint);
          const wizardPrivateFp = fingerprintPrivateKeyPem(decrypt(k.encryptedPrivateKey));
          const keyPairConsistent =
            wizardPrivateFp == null ||
            publicKeysMatch(
              opensshPublicLineFromPrivate(decrypt(k.encryptedPrivateKey)) ?? "",
              k.publicKey,
            );
          return {
            id: k.id,
            publicKey: k.publicKey,
            fingerprint: k.publicKeyFingerprint,
            opensshFingerprint: opensshSha256FingerprintLabel(k.publicKey),
            privateKey: decrypt(k.encryptedPrivateKey),
            createdAt: k.createdAt,
            expiresAt: k.expiresAt,
            wizardHosts,
            keyPairConsistent,
            lastAccess: last
              ? {
                  at: last.at.toISOString(),
                  action: last.action,
                  username: last.username,
                  machine: last.machine,
                  clientNode: last.clientNode,
                  targetNode: last.targetNode,
                }
              : null,
          };
        }),
      },
    });
  },
  { roles: ["ADMIN"] },
);

import { verifyAccountPassword } from "@/lib/mfa/account-password";
import { verifyStepUpMfa } from "@/lib/mfa/verify-step-up";
import { webAuthnChallengeKeyForVault } from "@/lib/mfa/webauthn-auth";
import type { AuthenticationResponseJSON } from "@simplewebauthn/server";

const unlockSchema = z.object({
  password: z.string().min(1),
  totpCode: z.string().optional(),
  webauthnResponse: z.custom<AuthenticationResponseJSON>().optional(),
});

export const POST = withAuth(
  async (req, { user }) => {
    if (!isVaultConfigured()) {
      return jsonError("SECRETS_VAULT_PASSWORD is not set on the server", 503);
    }
    const body = await req.json().catch(() => ({}));
    const parsed = unlockSchema.safeParse(body);
    if (!parsed.success) return jsonError("Password required");

    let unlockMethod: "env_password" | "account_mfa" = "env_password";

    if (verifyVaultPassword(parsed.data.password)) {
      unlockMethod = "env_password";
    } else if (await verifyAccountPassword(user.id, parsed.data.password)) {
      const step = await verifyStepUpMfa({
        userId: user.id,
        totpCode: parsed.data.totpCode,
        webauthnResponse: parsed.data.webauthnResponse,
        request: req,
        webAuthnChallengeKey: webAuthnChallengeKeyForVault(user.id),
      });
      if (!step.ok) return jsonError(step.error, 401);
      unlockMethod = "account_mfa";
    } else {
      return jsonError("Invalid vault or account password", 401);
    }

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "vault",
      details: { action: "unlock", method: unlockMethod },
      ipAddress: getClientIp(req.headers),
      userAgent: req.headers.get("user-agent") ?? undefined,
    });

    const token = createVaultUnlockToken();
    const res = NextResponse.json({ ok: true, unlocked: true });
    res.cookies.set(
      VAULT_UNLOCK_COOKIE,
      token,
      vaultUnlockCookieOptions(sessionCookieSecure(req)),
    );
    return res;
  },
  { roles: ["ADMIN"] },
);

export const DELETE = withAuth(
  async (req, { user }) => {
    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "vault",
      details: { action: "lock" },
      ipAddress: getClientIp(req.headers),
    });
    const res = NextResponse.json({ ok: true });
    res.cookies.set(VAULT_UNLOCK_COOKIE, "", { ...vaultUnlockCookieOptions(false), maxAge: 0 });
    return res;
  },
  { roles: ["ADMIN"] },
);
