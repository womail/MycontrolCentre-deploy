import { NextResponse } from "next/server";
import { withAuth, jsonError } from "@/lib/api-handler";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";
import {
  clearFailedCommandRuns,
  clearSshFailureLogs,
  clearAllAuditLogs,
  clearAllRemoteConnectionLogs,
  clearAllApiRequestLogs,
} from "@/lib/admin/cleanup";
import { z } from "zod";

const schema = z.object({
  failedRuns: z.boolean().optional(),
  sshFailures: z.boolean().optional(),
  auditLogs: z.boolean().optional(),
  remoteLogs: z.boolean().optional(),
  apiLogs: z.boolean().optional(),
});

export const POST = withAuth(
  async (req, { user }) => {
    const body = await req.json().catch(() => ({}));
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return jsonError(parsed.error.errors[0]?.message ?? "Invalid input");
    }
    if (
      !parsed.data.failedRuns &&
      !parsed.data.sshFailures &&
      !parsed.data.auditLogs &&
      !parsed.data.remoteLogs &&
      !parsed.data.apiLogs
    ) {
      return jsonError("Select at least one cleanup action");
    }

    let failedRuns = 0;
    let sshFailures = 0;
    let auditLogs = 0;
    let remoteLogs = 0;
    let apiLogs = 0;
    if (parsed.data.failedRuns) failedRuns = await clearFailedCommandRuns();
    if (parsed.data.sshFailures) sshFailures = await clearSshFailureLogs();
    if (parsed.data.auditLogs) auditLogs = await clearAllAuditLogs();
    if (parsed.data.remoteLogs) remoteLogs = await clearAllRemoteConnectionLogs();
    if (parsed.data.apiLogs) apiLogs = await clearAllApiRequestLogs();

    await logAudit({
      userId: user.id,
      action: "SETTINGS_UPDATED",
      resourceType: "cleanup",
      details: { failedRuns, sshFailures, auditLogs, remoteLogs, apiLogs },
      ipAddress: getClientIp(req.headers),
    });

    return NextResponse.json({ ok: true, failedRuns, sshFailures, auditLogs, remoteLogs, apiLogs });
  },
  { roles: ["ADMIN"] },
);
