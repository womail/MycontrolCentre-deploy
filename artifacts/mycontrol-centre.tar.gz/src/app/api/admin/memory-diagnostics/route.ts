import { NextResponse } from "next/server";
import { withAuth } from "@/lib/api-handler";
import {
  collectMemoryDiagnostics,
  formatMemoryDiagnosticsReport,
} from "@/lib/admin/memory-diagnostics";

export const GET = withAuth(
  async (req) => {
    const diagnostics = await collectMemoryDiagnostics();
    const url = new URL(req.url);
    if (url.searchParams.get("format") === "text") {
      return new NextResponse(formatMemoryDiagnosticsReport(diagnostics), {
        headers: { "Content-Type": "text/plain; charset=utf-8" },
      });
    }
    return NextResponse.json({ diagnostics });
  },
  { roles: ["ADMIN"] },
);
