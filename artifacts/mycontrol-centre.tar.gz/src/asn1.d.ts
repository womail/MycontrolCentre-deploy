declare module "asn1" {
  export namespace Ber {
    const Integer: number;
    const BitString: number;
    const OctetString: number;
    const Null: number;

    class Reader {
      constructor(data: Buffer);
      readSequence(): void;
      readOID(): string;
      readInt(): number;
      readString(type: number, trimLeadZeroes?: boolean): Buffer;
      readByte(): number;
    }
  }
}
