import { prisma } from "../db";

export interface FleetDashboardStats {
  serverCount: number;
  onlineCount: number;
  offlineCount: number;
  unknownCount: number;
  maintenanceCount: number;
  proxmoxGuestCount: number;
  proxmoxSyncedCount: number;
  quorumIssueCount: number;
  pendingRunCount: number;
  failedRunCount24h: number;
  sshFailureRate24h: number | null;
  offlineServers: Array<{
    id: string;
    name: string;
    hostname: string;
    port: number;
    sshUser: string;
    authType: string;
    healthStatus: string;
    healthMessage: string | null;
    lastHealthCheck: Date | null;
    inMaintenance: boolean;
  }>;
  quorumIssues: Array<{ id: string; name: string }>;
  recentFailedRuns: Array<{
    id: string;
    label: string | null;
    commandType: string;
    createdAt: Date;
    server: { name: string };
    changeReason: string | null;
  }>;
  recentRuns: Array<{
    id: string;
    commandType: string;
    label: string | null;
    status: string;
    createdAt: Date;
    server: { name: string };
  }>;
  recentLogs: Array<{
    id: string;
    action: string;
    createdAt: Date;
    user: { username: string } | null;
  }>;
}

export async function getFleetDashboardStats(): Promise<FleetDashboardStats> {
  const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const [
    serverCount,
    onlineCount,
    offlineCount,
    unknownCount,
    maintenanceCount,
    proxmoxGuestCount,
    proxmoxSyncedCount,
    pendingRunCount,
    failedRunCount24h,
    sshConnections24h,
    sshFailures24h,
    offlineServers,
    proxmoxServers,
    recentFailedRuns,
    recentRuns,
    recentLogs,
  ] = await Promise.all([
    prisma.server.count(),
    prisma.server.count({ where: { healthStatus: "ONLINE" } }),
    prisma.server.count({ where: { healthStatus: "OFFLINE" } }),
    prisma.server.count({ where: { healthStatus: "UNKNOWN" } }),
    prisma.server.count({ where: { inMaintenance: true } }),
    prisma.proxmoxGuest.count(),
    prisma.server.count({ where: { lastProxmoxSync: { not: null } } }),
    prisma.commandRun.count({
      where: { status: { in: ["PENDING", "RUNNING"] } },
    }),
    prisma.commandRun.count({
      where: { status: "FAILED", createdAt: { gte: since24h } },
    }),
    prisma.remoteConnectionLog.count({ where: { createdAt: { gte: since24h } } }),
    prisma.remoteConnectionLog.count({
      where: { createdAt: { gte: since24h }, outcome: "FAILED" },
    }),
    prisma.server.findMany({
      where: { healthStatus: "OFFLINE", isActive: true },
      orderBy: { name: "asc" },
      select: {
        id: true,
        name: true,
        hostname: true,
        port: true,
        sshUser: true,
        authType: true,
        healthStatus: true,
        healthMessage: true,
        lastHealthCheck: true,
        inMaintenance: true,
      },
    }),
    prisma.server.findMany({
      where: { lastProxmoxSync: { not: null } },
      select: { id: true, name: true, proxmoxSummary: true },
    }),
    prisma.commandRun.findMany({
      where: { status: "FAILED" },
      take: 5,
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        label: true,
        commandType: true,
        createdAt: true,
        changeReason: true,
        server: { select: { name: true } },
      },
    }),
    prisma.commandRun.findMany({
      take: 5,
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        commandType: true,
        label: true,
        status: true,
        createdAt: true,
        server: { select: { name: true } },
      },
    }),
    prisma.auditLog.findMany({
      take: 5,
      orderBy: { createdAt: "desc" },
      include: { user: { select: { username: true } } },
    }),
  ]);

  const quorumIssues = proxmoxServers.filter((server) => {
    const summary = server.proxmoxSummary as { quorum?: boolean } | null;
    return summary?.quorum === false;
  });

  return {
    serverCount,
    onlineCount,
    offlineCount,
    unknownCount,
    maintenanceCount,
    proxmoxGuestCount,
    proxmoxSyncedCount,
    quorumIssueCount: quorumIssues.length,
    pendingRunCount,
    failedRunCount24h,
    sshFailureRate24h:
      sshConnections24h > 0
        ? Math.round((sshFailures24h / sshConnections24h) * 100)
        : null,
    offlineServers,
    quorumIssues: quorumIssues.map((server) => ({ id: server.id, name: server.name })),
    recentFailedRuns,
    recentRuns,
    recentLogs,
  };
}
