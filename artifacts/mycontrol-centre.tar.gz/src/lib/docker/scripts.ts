/**
 * Install scripts aligned with official Docker and Portainer documentation:
 * - https://docs.docker.com/engine/install/ubuntu/
 * - https://docs.portainer.io/start/install-ce/server/docker/linux
 */

export const DOCKER_ENGINE_INSTALL_UBUNTU = `#!/bin/bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
if ! grep -qi ubuntu /etc/os-release 2>/dev/null; then
  echo "This installer requires Ubuntu (see Docker Engine docs for other distros)." >&2
  exit 1
fi
apt-get remove -y docker.io docker-compose docker-compose-v2 docker-doc podman-docker containerd runc 2>/dev/null || true
apt-get update -qq
apt-get install -y ca-certificates curl
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
chmod a+r /etc/apt/keyrings/docker.asc
. /etc/os-release
CODENAME="\${UBUNTU_CODENAME:-$VERSION_CODENAME}"
ARCH="$(dpkg --print-architecture)"
tee /etc/apt/sources.list.d/docker.sources >/dev/null <<EOF
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: \${CODENAME}
Components: stable
Architectures: \${ARCH}
Signed-By: /etc/apt/keyrings/docker.asc
EOF
apt-get update -qq
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker
if [ -n "\${SUDO_USER:-}" ] && [ "\$SUDO_USER" != root ]; then
  usermod -aG docker "\$SUDO_USER" || true
  echo "Added \$SUDO_USER to docker group (re-login required for compose without sudo)."
fi
docker run --rm hello-world
echo "Docker Engine installed successfully."
`;

export function portainerCeInstallScript(options?: {
  httpLegacyPort?: boolean;
}): string {
  const legacyPort = options?.httpLegacyPort ? "-p 9000:9000 " : "";
  return `#!/bin/bash
set -euo pipefail
if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is not installed. Run Install Docker Engine first." >&2
  exit 1
fi
docker volume create portainer_data 2>/dev/null || true
if docker ps -a --format '{{.Names}}' | grep -qx portainer; then
  echo "Container 'portainer' already exists — skipping create."
  docker start portainer 2>/dev/null || true
else
  docker run -d -p 8000:8000 -p 9443:9443 ${legacyPort}--name portainer --restart=always \\
    -v /var/run/docker.sock:/var/run/docker.sock \\
    -v portainer_data:/data \\
    portainer/portainer-ce:lts
fi
docker ps --filter name=portainer
echo "Portainer CE is running on https://<host>:9443"
`;
}

export function buildBashScriptCommand(script: string, useSudo = true): string {
  const b64 = Buffer.from(script, "utf8").toString("base64");
  const decode = `echo '${b64.replace(/'/g, `'\\''`)}' | base64 -d`;
  return useSudo ? `${decode} | sudo bash` : `${decode} | bash`;
}
