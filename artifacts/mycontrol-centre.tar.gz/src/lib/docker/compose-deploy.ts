import type { Server } from "@prisma/client";
import { validatePath } from "../commands/validate";
import { execOnServer, shellEscape, uploadRemoteFile } from "../ssh/client";
import { dockerCliPrefix } from "../ssh/privilege";

export const MAX_COMPOSE_BYTES = 512_000;
export const MAX_ENV_BYTES = 64_000;

export interface ComposeDeployInput {
  remoteDir: string;
  composeYaml: string;
  envFile?: string;
  pull?: boolean;
  detach?: boolean;
  projectName?: string;
}

export interface ComposeDeployResult {
  remoteDir: string;
  composePath: string;
  envPath: string | null;
  stdout: string;
  stderr: string;
  exitCode: number;
}

function validateComposeContent(content: string, label: string, maxBytes: number): string {
  const trimmed = content.trim();
  if (!trimmed) {
    throw new Error(`${label} is required`);
  }
  if (Buffer.byteLength(trimmed, "utf8") > maxBytes) {
    throw new Error(`${label} is too large (max ${maxBytes} bytes)`);
  }
  if (trimmed.includes("\0")) {
    throw new Error(`${label} contains invalid characters`);
  }
  return trimmed;
}

export function normalizeComposeDeployInput(input: ComposeDeployInput): ComposeDeployInput {
  const remoteDir = validatePath(input.remoteDir.trim(), "Remote directory");
  const composeYaml = validateComposeContent(input.composeYaml, "docker-compose.yml", MAX_COMPOSE_BYTES);
  const envFile =
    input.envFile != null && input.envFile.trim() !== ""
      ? validateComposeContent(input.envFile, ".env", MAX_ENV_BYTES)
      : undefined;

  const projectName = input.projectName?.trim();
  if (projectName && !/^[a-z0-9][a-z0-9_-]*$/i.test(projectName)) {
    throw new Error("Project name must be alphanumeric (dashes/underscores allowed)");
  }

  return {
    remoteDir,
    composeYaml,
    envFile,
    pull: input.pull !== false,
    detach: input.detach !== false,
    projectName,
  };
}

export async function deployComposeToServer(
  server: Server,
  input: ComposeDeployInput,
  log?: { userId?: string; commandRunId?: string },
): Promise<ComposeDeployResult> {
  const normalized = normalizeComposeDeployInput(input);
  const composePath = `${normalized.remoteDir}/docker-compose.yml`;
  const envPath = normalized.envFile ? `${normalized.remoteDir}/.env` : null;

  const mkdir = await execOnServer(server, `mkdir -p ${shellEscape(normalized.remoteDir)}`, {
    timeoutMs: 30_000,
    log: log ? { ...log, purpose: "COMMAND" } : undefined,
  });
  if (mkdir.exitCode !== 0) {
    throw new Error(mkdir.stderr.trim() || "Failed to create remote directory");
  }

  await uploadRemoteFile(server, composePath, normalized.composeYaml, {
    log: log ? { ...log, purpose: "COMMAND" } : undefined,
  });

  if (normalized.envFile && envPath) {
    await uploadRemoteFile(server, envPath, normalized.envFile, {
      log: log ? { ...log, purpose: "COMMAND" } : undefined,
    });
  }

  const docker = dockerCliPrefix(server);
  const projectFlag = normalized.projectName ? `-p ${normalized.projectName}` : "";
  const envFlag = envPath ? `--env-file .env` : "";
  const pullStep = normalized.pull ? `${docker} compose pull && ` : "";
  const upFlags = normalized.detach ? "-d" : "";

  const command = `cd ${shellEscape(normalized.remoteDir)} && ${pullStep}${docker} compose ${projectFlag} ${envFlag} up ${upFlags}`
    .replace(/\s+/g, " ")
    .trim();

  const result = await execOnServer(server, command, {
    timeoutMs: 600_000,
    log: log ? { ...log, purpose: "COMMAND" } : undefined,
  });

  if (result.exitCode !== 0) {
    throw new Error(result.stderr.trim() || result.stdout.trim() || "docker compose up failed");
  }

  return {
    remoteDir: normalized.remoteDir,
    composePath,
    envPath,
    stdout: result.stdout,
    stderr: result.stderr,
    exitCode: result.exitCode,
  };
}
