import type { AuthenticationResponseJSON } from "@simplewebauthn/server";
import { getUserMfaSummary } from "@/lib/mfa/user-state";
import { getTotpSecretForUser, verifyTotpCode } from "@/lib/mfa/totp";
import { verifyWebAuthnAssertion } from "@/lib/mfa/webauthn-auth";

export async function verifyStepUpMfa(input: {
  userId: string;
  totpCode?: string;
  webauthnResponse?: AuthenticationResponseJSON;
  request: Request;
  webAuthnChallengeKey: string;
}): Promise<{ ok: true } | { ok: false; error: string }> {
  const summary = await getUserMfaSummary(input.userId);
  if (!summary.requiresMfa) {
    return {
      ok: false,
      error: "Enroll TOTP or a security key under Account → Security, or use the vault password",
    };
  }

  if (input.totpCode?.trim() && summary.totpEnabled) {
    const secret = await getTotpSecretForUser(input.userId);
    if (secret && verifyTotpCode(secret, input.totpCode)) {
      return { ok: true };
    }
    return { ok: false, error: "Invalid authenticator code" };
  }

  if (input.webauthnResponse && summary.hasWebAuthn) {
    const ok = await verifyWebAuthnAssertion({
      userId: input.userId,
      response: input.webauthnResponse,
      challengeKey: input.webAuthnChallengeKey,
      request: input.request,
    });
    if (ok) return { ok: true };
    return { ok: false, error: "Security key verification failed" };
  }

  if (summary.totpEnabled && summary.hasWebAuthn) {
    return { ok: false, error: "Enter authenticator code or use your security key" };
  }
  if (summary.totpEnabled) {
    return { ok: false, error: "Enter your 6-digit authenticator code" };
  }
  return { ok: false, error: "Use your security key" };
}
