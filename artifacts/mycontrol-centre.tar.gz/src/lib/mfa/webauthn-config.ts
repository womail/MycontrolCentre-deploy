import { resolveAppUrl } from "@/lib/setup/app-url";

export function webAuthnConfig(request: Request) {
  const origin = resolveAppUrl(request);
  const hostname = new URL(origin).hostname;
  return {
    rpName: "MyControl Centre",
    rpID: hostname,
    origin,
  };
}
