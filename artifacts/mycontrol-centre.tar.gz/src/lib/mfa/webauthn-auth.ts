import { prisma } from "@/lib/db";
import {
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
  type AuthenticationResponseJSON,
  type AuthenticatorTransportFuture,
} from "@simplewebauthn/server";
import { webAuthnConfig } from "@/lib/mfa/webauthn-config";

const webAuthnChallenges = new Map<string, { challenge: string; expires: number }>();

export function storeWebAuthnChallenge(key: string, challenge: string) {
  webAuthnChallenges.set(key, { challenge, expires: Date.now() + 5 * 60 * 1000 });
}

export function consumeWebAuthnChallenge(key: string): string | null {
  const row = webAuthnChallenges.get(key);
  webAuthnChallenges.delete(key);
  if (!row || row.expires < Date.now()) return null;
  return row.challenge;
}

export async function createWebAuthnLoginOptions(userId: string, request: Request) {
  const credentials = await prisma.webAuthnCredential.findMany({ where: { userId } });
  const { rpID } = webAuthnConfig(request);
  const options = await generateAuthenticationOptions({
    rpID,
    allowCredentials: credentials.map((c) => ({
      id: c.credentialId,
      transports: [] as AuthenticatorTransportFuture[],
    })),
    userVerification: "preferred",
  });
  storeWebAuthnChallenge(`login:${userId}`, options.challenge);
  return options;
}

export async function verifyWebAuthnAssertion(input: {
  userId: string;
  response: AuthenticationResponseJSON;
  challengeKey: string;
  request: Request;
}): Promise<boolean> {
  const expectedChallenge = consumeWebAuthnChallenge(input.challengeKey);
  if (!expectedChallenge) return false;

  const cred = await prisma.webAuthnCredential.findUnique({
    where: { credentialId: input.response.id },
  });
  if (!cred || cred.userId !== input.userId) return false;

  const { rpID, origin } = webAuthnConfig(input.request);
  const verification = await verifyAuthenticationResponse({
    response: input.response,
    expectedChallenge,
    expectedOrigin: origin,
    expectedRPID: rpID,
    credential: {
      id: cred.credentialId,
      publicKey: Buffer.from(cred.publicKey, "base64url"),
      counter: Number(cred.counter),
    },
  });
  if (!verification.verified) return false;

  await prisma.webAuthnCredential.update({
    where: { id: cred.id },
    data: {
      counter: BigInt(verification.authenticationInfo.newCounter),
      lastUsedAt: new Date(),
    },
  });
  return true;
}

export function webAuthnChallengeKeyForLogin(userId: string) {
  return `login:${userId}`;
}

export function webAuthnChallengeKeyForVault(userId: string) {
  return `vault:${userId}`;
}

export async function createWebAuthnStepUpOptions(userId: string, request: Request, purpose: "login" | "vault") {
  const key = purpose === "login" ? webAuthnChallengeKeyForLogin(userId) : webAuthnChallengeKeyForVault(userId);
  const credentials = await prisma.webAuthnCredential.findMany({ where: { userId } });
  const { rpID } = webAuthnConfig(request);
  const options = await generateAuthenticationOptions({
    rpID,
    allowCredentials: credentials.map((c) => ({
      id: c.credentialId,
      transports: [] as AuthenticatorTransportFuture[],
    })),
    userVerification: "preferred",
  });
  storeWebAuthnChallenge(key, options.challenge);
  return options;
}
