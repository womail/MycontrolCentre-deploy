import { generateSecret, generateURI, verifySync } from "otplib";
import { encrypt, decrypt } from "@/lib/crypto";
import { prisma } from "@/lib/db";

const ISSUER = "MyControl Centre";

export function generateTotpSecret(): string {
  return generateSecret();
}

export function totpKeyUri(username: string, secret: string): string {
  return generateURI({ issuer: ISSUER, label: username, secret });
}

export function verifyTotpCode(secret: string, code: string): boolean {
  const normalized = code.replace(/\s/g, "");
  if (!/^\d{6}$/.test(normalized)) return false;
  return verifySync({ secret, token: normalized }).valid;
}

export async function getTotpSecretForUser(userId: string): Promise<string | null> {
  const row = await prisma.userMfa.findUnique({ where: { userId } });
  if (!row?.totpEnabled || !row.encryptedTotpSecret) return null;
  return decrypt(row.encryptedTotpSecret);
}

export async function storePendingTotpSecret(userId: string, secret: string): Promise<void> {
  await prisma.userMfa.upsert({
    where: { userId },
    create: {
      userId,
      totpEnabled: false,
      encryptedTotpSecret: encrypt(secret),
    },
    update: {
      totpEnabled: false,
      encryptedTotpSecret: encrypt(secret),
    },
  });
}

export async function enableTotpForUser(userId: string): Promise<void> {
  await prisma.userMfa.update({
    where: { userId },
    data: { totpEnabled: true },
  });
}

export async function disableTotpForUser(userId: string): Promise<void> {
  await prisma.userMfa.upsert({
    where: { userId },
    create: { userId, totpEnabled: false, encryptedTotpSecret: null },
    update: { totpEnabled: false, encryptedTotpSecret: null },
  });
}

/** Admin: clear TOTP so the user must enroll again on next login/MFA step. */
export async function adminResetTotpForUser(userId: string): Promise<void> {
  await disableTotpForUser(userId);
}
