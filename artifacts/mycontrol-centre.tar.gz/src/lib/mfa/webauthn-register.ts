import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
} from "@simplewebauthn/server";
import { prisma } from "@/lib/db";
import { webAuthnConfig } from "@/lib/mfa/webauthn-config";
import { consumeWebAuthnChallenge, storeWebAuthnChallenge } from "@/lib/mfa/webauthn-auth";

export function registerChallengeKey(userId: string) {
  return `register:${userId}`;
}

export async function createWebAuthnRegistrationOptions(user: { id: string; username: string }, request: Request) {
  const existing = await prisma.webAuthnCredential.findMany({ where: { userId: user.id } });
  const { rpID, rpName, origin } = webAuthnConfig(request);
  const options = await generateRegistrationOptions({
    rpName,
    rpID,
    userName: user.username,
    userID: new TextEncoder().encode(user.id),
    userDisplayName: user.username,
    excludeCredentials: existing.map((c) => ({ id: c.credentialId })),
    authenticatorSelection: {
      residentKey: "preferred",
      userVerification: "preferred",
    },
  });
  storeWebAuthnChallenge(registerChallengeKey(user.id), options.challenge);
  return { options, origin };
}

export async function verifyWebAuthnRegistration(input: {
  userId: string;
  response: Parameters<typeof verifyRegistrationResponse>[0]["response"];
  deviceName?: string;
  request: Request;
}): Promise<boolean> {
  const expectedChallenge = consumeWebAuthnChallenge(registerChallengeKey(input.userId));
  if (!expectedChallenge) return false;

  const { rpID, origin } = webAuthnConfig(input.request);
  const verification = await verifyRegistrationResponse({
    response: input.response,
    expectedChallenge,
    expectedOrigin: origin,
    expectedRPID: rpID,
  });
  if (!verification.verified || !verification.registrationInfo) return false;

  const { credential, credentialDeviceType, credentialBackedUp } = verification.registrationInfo;
  void credentialDeviceType;
  void credentialBackedUp;

  await prisma.webAuthnCredential.create({
    data: {
      userId: input.userId,
      credentialId: credential.id,
      publicKey: Buffer.from(credential.publicKey).toString("base64url"),
      counter: BigInt(credential.counter),
      deviceName: input.deviceName?.trim() || "Security key",
    },
  });
  return true;
}
