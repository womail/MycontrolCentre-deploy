import { prisma } from "@/lib/db";

export async function getUserMfaSummary(userId: string) {
  const [mfa, webAuthnCount] = await Promise.all([
    prisma.userMfa.findUnique({ where: { userId } }),
    prisma.webAuthnCredential.count({ where: { userId } }),
  ]);
  const totpEnabled = Boolean(mfa?.totpEnabled);
  const hasWebAuthn = webAuthnCount > 0;
  return {
    totpEnabled,
    hasWebAuthn,
    webAuthnCount,
    requiresMfa: totpEnabled || hasWebAuthn,
  };
}

export async function userHasAnyMfa(userId: string): Promise<boolean> {
  const s = await getUserMfaSummary(userId);
  return s.requiresMfa;
}
