import { prisma } from "@/lib/db";
import { verifyPassword } from "@/lib/auth/password";

export async function verifyAccountPassword(userId: string, password: string): Promise<boolean> {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) return false;
  return verifyPassword(password, user.passwordHash);
}
