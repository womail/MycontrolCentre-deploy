import type { AppearanceSettings } from "./appearance";

export const THEME_PRESET_IDS = [
  "classic",
  "graphite",
  "ocean",
  "evergreen",
  "burgundy",
  "amber-ops",
] as const;

export type ThemePresetId = (typeof THEME_PRESET_IDS)[number];

export interface ThemePresetDefinition {
  id: ThemePresetId;
  label: string;
  description: string;
  swatch: string[];
  appearance: Required<
    Pick<
      AppearanceSettings,
      | "primaryColor"
      | "successColor"
      | "warningColor"
      | "dangerColor"
      | "sidebarColor"
      | "buttonShape"
      | "fontFamily"
    >
  >;
  light: Record<string, string>;
  dark: Record<string, string>;
}

export const THEME_PRESETS: ThemePresetDefinition[] = [
  {
    id: "classic",
    label: "Classic",
    description: "Balanced blue accent on slate surfaces",
    swatch: ["#2563eb", "#0f172a", "#f8fafc"],
    appearance: {
      primaryColor: "#2563eb",
      successColor: "#16a34a",
      warningColor: "#d97706",
      dangerColor: "#dc2626",
      sidebarColor: "#0f172a",
      buttonShape: "rounded",
      fontFamily: "system",
    },
    light: {
      "--background": "#f8fafc",
      "--foreground": "#0f172a",
      "--card": "#ffffff",
      "--card-border": "#e2e8f0",
      "--muted": "#64748b",
      "--sidebar-text": "#e2e8f0",
      "--card-radius": "0.75rem",
    },
    dark: {
      "--background": "#0b1120",
      "--foreground": "#f1f5f9",
      "--card": "#111827",
      "--card-border": "#1f2937",
      "--muted": "#94a3b8",
      "--sidebar-text": "#cbd5e1",
      "--card-radius": "0.75rem",
    },
  },
  {
    id: "graphite",
    label: "Graphite",
    description: "Neutral zinc palette, minimal chrome",
    swatch: ["#52525b", "#18181b", "#fafafa"],
    appearance: {
      primaryColor: "#52525b",
      successColor: "#15803d",
      warningColor: "#a16207",
      dangerColor: "#b91c1c",
      sidebarColor: "#18181b",
      buttonShape: "square",
      fontFamily: "system",
    },
    light: {
      "--background": "#fafafa",
      "--foreground": "#18181b",
      "--card": "#ffffff",
      "--card-border": "#e4e4e7",
      "--muted": "#71717a",
      "--sidebar-text": "#f4f4f5",
      "--card-radius": "0.375rem",
    },
    dark: {
      "--background": "#09090b",
      "--foreground": "#fafafa",
      "--card": "#18181b",
      "--card-border": "#27272a",
      "--muted": "#a1a1aa",
      "--sidebar-text": "#e4e4e7",
      "--card-radius": "0.375rem",
    },
  },
  {
    id: "ocean",
    label: "Ocean",
    description: "Cool teal accents and deep navy sidebar",
    swatch: ["#0d9488", "#0c4a6e", "#ecfeff"],
    appearance: {
      primaryColor: "#0d9488",
      successColor: "#059669",
      warningColor: "#ca8a04",
      dangerColor: "#e11d48",
      sidebarColor: "#0c4a6e",
      buttonShape: "rounded",
      fontFamily: "sans",
    },
    light: {
      "--background": "#f0fdfa",
      "--foreground": "#134e4a",
      "--card": "#ffffff",
      "--card-border": "#99f6e4",
      "--muted": "#5eead4",
      "--sidebar-text": "#ccfbf1",
      "--card-radius": "0.625rem",
    },
    dark: {
      "--background": "#042f2e",
      "--foreground": "#ecfdf5",
      "--card": "#134e4a",
      "--card-border": "#115e59",
      "--muted": "#5eead4",
      "--sidebar-text": "#ccfbf1",
      "--card-radius": "0.625rem",
    },
  },
  {
    id: "evergreen",
    label: "Evergreen",
    description: "Forest green primary on warm gray paper",
    swatch: ["#166534", "#14532d", "#f5f5f4"],
    appearance: {
      primaryColor: "#166534",
      successColor: "#15803d",
      warningColor: "#b45309",
      dangerColor: "#be123c",
      sidebarColor: "#14532d",
      buttonShape: "rounded",
      fontFamily: "serif",
    },
    light: {
      "--background": "#f5f5f4",
      "--foreground": "#1c1917",
      "--card": "#fafaf9",
      "--card-border": "#d6d3d1",
      "--muted": "#78716c",
      "--sidebar-text": "#ecfccb",
      "--card-radius": "0.5rem",
    },
    dark: {
      "--background": "#1a1f16",
      "--foreground": "#ecfccb",
      "--card": "#1c2a1f",
      "--card-border": "#365314",
      "--muted": "#a3a3a3",
      "--sidebar-text": "#d9f99d",
      "--card-radius": "0.5rem",
    },
  },
  {
    id: "burgundy",
    label: "Burgundy",
    description: "Wine accent with editorial contrast",
    swatch: ["#9f1239", "#4c0519", "#fff1f2"],
    appearance: {
      primaryColor: "#9f1239",
      successColor: "#047857",
      warningColor: "#b45309",
      dangerColor: "#dc2626",
      sidebarColor: "#4c0519",
      buttonShape: "pill",
      fontFamily: "serif",
    },
    light: {
      "--background": "#fff1f2",
      "--foreground": "#4c0519",
      "--card": "#ffffff",
      "--card-border": "#fecdd3",
      "--muted": "#9f1239",
      "--sidebar-text": "#ffe4e6",
      "--card-radius": "1rem",
    },
    dark: {
      "--background": "#1f0a12",
      "--foreground": "#ffe4e6",
      "--card": "#3f0718",
      "--card-border": "#881337",
      "--muted": "#fda4af",
      "--sidebar-text": "#fecdd3",
      "--card-radius": "1rem",
    },
  },
  {
    id: "amber-ops",
    label: "Amber Ops",
    description: "Control-room amber on charcoal (monospace)",
    swatch: ["#f59e0b", "#1c1917", "#292524"],
    appearance: {
      primaryColor: "#f59e0b",
      successColor: "#22c55e",
      warningColor: "#fbbf24",
      dangerColor: "#f87171",
      sidebarColor: "#1c1917",
      buttonShape: "sharp",
      fontFamily: "mono",
    },
    light: {
      "--background": "#fafaf9",
      "--foreground": "#1c1917",
      "--card": "#ffffff",
      "--card-border": "#d6d3d1",
      "--muted": "#78716c",
      "--sidebar-text": "#fef3c7",
      "--card-radius": "0",
    },
    dark: {
      "--background": "#0c0a09",
      "--foreground": "#fef3c7",
      "--card": "#1c1917",
      "--card-border": "#44403c",
      "--muted": "#a8a29e",
      "--sidebar-text": "#fde68a",
      "--card-radius": "0",
    },
  },
];

export function getThemePreset(id: ThemePresetId): ThemePresetDefinition {
  return THEME_PRESETS.find((preset) => preset.id === id) ?? THEME_PRESETS[0];
}

export function themePresetSurfaceVariables(
  presetId: ThemePresetId,
  mode: "light" | "dark",
): Record<string, string> {
  const preset = getThemePreset(presetId);
  return mode === "dark" ? { ...preset.dark } : { ...preset.light };
}

export function appearanceForThemePreset(presetId: ThemePresetId): Required<AppearanceSettings> {
  const preset = getThemePreset(presetId);
  return {
    themePreset: presetId,
    primaryColor: preset.appearance.primaryColor,
    successColor: preset.appearance.successColor,
    warningColor: preset.appearance.warningColor,
    dangerColor: preset.appearance.dangerColor,
    sidebarColor: preset.appearance.sidebarColor,
    buttonSize: "md",
    buttonShape: preset.appearance.buttonShape,
    fontFamily: preset.appearance.fontFamily,
    fontSize: "md",
  };
}
