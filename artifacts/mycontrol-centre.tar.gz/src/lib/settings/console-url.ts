import { getSetting, setSetting } from "../settings";
import { resolveAppUrl, normalizeConsoleUrl } from "../setup/app-url";

const SETTING_KEY = "console_public_url";

export async function getConsolePublicUrl(request?: Request): Promise<string> {
  const stored = await getSetting(SETTING_KEY, "");
  if (stored.trim()) {
    return normalizeConsoleUrl(stored);
  }
  if (request) {
    return resolveAppUrl(request);
  }
  return normalizeConsoleUrl(process.env.APP_URL ?? "http://localhost:3000");
}

export async function setConsolePublicUrl(url: string): Promise<string> {
  const normalized = normalizeConsoleUrl(url);
  await setSetting(SETTING_KEY, normalized);
  return normalized;
}
