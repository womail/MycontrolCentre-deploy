import { z } from "zod";
import { getSetting, setSetting } from "../settings";
import { themePresetSurfaceVariables, type ThemePresetId } from "./theme-presets";

export const APPEARANCE_SETTING_KEY = "ui_appearance";

export const themePresetSchema = z.enum([
  "classic",
  "graphite",
  "ocean",
  "evergreen",
  "burgundy",
  "amber-ops",
]);

export const buttonSizeSchema = z.enum(["xs", "sm", "md", "lg"]);
export const buttonShapeSchema = z.enum([
  "sharp",
  "square",
  "rounded",
  "pill",
  "bevel",
  "soft",
  "outline",
  "notched",
  "glow",
]);
export const fontFamilySchema = z.enum(["system", "sans", "mono", "serif"]);
export const fontSizeSchema = z.enum(["xs", "sm", "md", "lg"]);

const hexColor = z.string().regex(/^#[0-9A-Fa-f]{6}$/, "Must be a hex color (#RRGGBB)");

export const appearanceSchema = z.object({
  themePreset: themePresetSchema.optional(),
  primaryColor: hexColor.optional(),
  successColor: hexColor.optional(),
  warningColor: hexColor.optional(),
  dangerColor: hexColor.optional(),
  sidebarColor: hexColor.optional(),
  buttonSize: buttonSizeSchema.optional(),
  buttonShape: buttonShapeSchema.optional(),
  fontFamily: fontFamilySchema.optional(),
  fontSize: fontSizeSchema.optional(),
});

export type AppearanceSettings = z.infer<typeof appearanceSchema>;

export const DEFAULT_APPEARANCE: Required<AppearanceSettings> = {
  themePreset: "classic",
  primaryColor: "#3b82f6",
  successColor: "#22c55e",
  warningColor: "#f59e0b",
  dangerColor: "#ef4444",
  sidebarColor: "#020617",
  buttonSize: "md",
  buttonShape: "rounded",
  fontFamily: "system",
  fontSize: "md",
};

const BUTTON_SIZE_VARS: Record<
  z.infer<typeof buttonSizeSchema>,
  { paddingY: string; paddingX: string; fontSize: string }
> = {
  xs: { paddingY: "0.2rem", paddingX: "0.5rem", fontSize: "0.75rem" },
  sm: { paddingY: "0.375rem", paddingX: "0.75rem", fontSize: "0.875rem" },
  md: { paddingY: "0.5rem", paddingX: "1rem", fontSize: "1rem" },
  lg: { paddingY: "0.75rem", paddingX: "1.25rem", fontSize: "1.125rem" },
};

const BUTTON_SHAPE_RADIUS: Record<z.infer<typeof buttonShapeSchema>, string> = {
  sharp: "0",
  square: "0.25rem",
  rounded: "0.5rem",
  pill: "9999px",
  bevel: "0.35rem",
  soft: "0.85rem",
  outline: "0.5rem",
  notched: "0.25rem",
  glow: "0.65rem",
};

const FONT_FAMILY_STACKS: Record<z.infer<typeof fontFamilySchema>, string> = {
  system:
    'ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  sans: '"Inter", ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  mono: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace',
  serif: 'ui-serif, Georgia, Cambria, "Times New Roman", Times, serif',
};

const FONT_SIZE_BASE: Record<z.infer<typeof fontSizeSchema>, string> = {
  xs: "12px",
  sm: "14px",
  md: "16px",
  lg: "18px",
};

export function mergeAppearance(partial?: AppearanceSettings | null): Required<AppearanceSettings> {
  return { ...DEFAULT_APPEARANCE, ...(partial ?? {}) };
}

export function parseAppearanceJson(raw: string | null | undefined): AppearanceSettings {
  if (!raw) return {};
  try {
    const parsed = appearanceSchema.safeParse(JSON.parse(raw));
    return parsed.success ? parsed.data : {};
  } catch {
    return {};
  }
}

export async function getAppearanceSettings(): Promise<Required<AppearanceSettings>> {
  const raw = await getSetting(APPEARANCE_SETTING_KEY, "");
  return mergeAppearance(parseAppearanceJson(raw || null));
}

export async function setAppearanceSettings(
  settings: Required<AppearanceSettings>,
): Promise<void> {
  const merged = mergeAppearance(settings);
  appearanceSchema.parse(merged);
  await setSetting(APPEARANCE_SETTING_KEY, JSON.stringify(merged));
}

export function appearanceToCssProperties(
  settings: Required<AppearanceSettings>,
  mode: "light" | "dark" = "dark",
): Record<string, string> {
  const btnSize = BUTTON_SIZE_VARS[settings.buttonSize];
  const presetId = (settings.themePreset ?? "classic") as ThemePresetId;
  const surfaces = themePresetSurfaceVariables(presetId, mode);
  return {
    ...surfaces,
    "--primary": settings.primaryColor,
    "--primary-hover": `color-mix(in srgb, ${settings.primaryColor} 82%, black)`,
    "--success": settings.successColor,
    "--warning": settings.warningColor,
    "--danger": settings.dangerColor,
    "--sidebar": settings.sidebarColor,
    "--btn-padding-y": btnSize.paddingY,
    "--btn-padding-x": btnSize.paddingX,
    "--btn-font-size": btnSize.fontSize,
    "--btn-radius": BUTTON_SHAPE_RADIUS[settings.buttonShape],
    "--font-family": FONT_FAMILY_STACKS[settings.fontFamily],
    "--font-size-base": FONT_SIZE_BASE[settings.fontSize],
  };
}

export function applyAppearanceToDocument(settings: Required<AppearanceSettings>): void {
  if (typeof document === "undefined") return;

  const mode = document.documentElement.classList.contains("dark") ? "dark" : "light";
  const root = document.documentElement;
  for (const [key, value] of Object.entries(appearanceToCssProperties(settings, mode))) {
    root.style.setProperty(key, value);
  }
  root.dataset.btnShape = settings.buttonShape;
  root.dataset.btnSize = settings.buttonSize;
}

export function clearAppearanceOverrides(): void {
  if (typeof document === "undefined") return;

  const root = document.documentElement;
  const keys = [
    "--background",
    "--foreground",
    "--card",
    "--card-border",
    "--card-radius",
    "--sidebar-text",
    "--primary",
    "--primary-hover",
    "--success",
    "--warning",
    "--danger",
    "--sidebar",
    "--btn-padding-y",
    "--btn-padding-x",
    "--btn-font-size",
    "--btn-radius",
    "--font-family",
    "--font-size-base",
  ];

  for (const key of keys) {
    root.style.removeProperty(key);
  }
  delete root.dataset.btnShape;
  delete root.dataset.btnSize;
}

export {
  BUTTON_SIZE_VARS,
  BUTTON_SHAPE_RADIUS,
  FONT_FAMILY_STACKS,
  FONT_SIZE_BASE,
};
