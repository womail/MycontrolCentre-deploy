import { accessSync, constants } from "fs";

const CANDIDATE_PATHS = ["/usr/bin/ssh-keygen", "/bin/ssh-keygen"];

/** Resolve ssh-keygen binary (minimal PATH when app runs as nextjs). */
export function resolveSshKeygenPath(): string | null {
  for (const candidate of CANDIDATE_PATHS) {
    try {
      accessSync(candidate, constants.X_OK);
      return candidate;
    } catch {
      /* try next */
    }
  }
  return null;
}

export function isSshKeygenAvailable(): boolean {
  return resolveSshKeygenPath() !== null;
}
