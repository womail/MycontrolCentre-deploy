export function buildRemoteCleanupCommand(
  appUrl: string,
  options: {
    publicKey?: string;
    sshUser?: string;
    removeUser?: boolean;
    keepSudo?: boolean;
  } = {},
): string {
  const base = appUrl.replace(/\/$/, "");
  const scriptUrl = `${base}/api/setup/proxmox-host-cleanup.sh`;
  const user = options.sshUser?.trim() || "mcc-auto";
  let scriptArgs = `--user '${user.replace(/'/g, `'\\''`)}'`;
  if (options.publicKey?.trim()) {
    const escapedKey = options.publicKey.trim().replace(/'/g, `'\\''`);
    scriptArgs += ` --pubkey '${escapedKey}'`;
  }
  if (options.removeUser) scriptArgs += " --remove-user";
  if (options.keepSudo) scriptArgs += " --keep-sudo";
  return [
    `curl -fsSL --connect-timeout 30 --noproxy '*' '${scriptUrl}'`,
    `| sudo bash -s -- ${scriptArgs}`,
  ].join(" ");
}
