export interface ParsedHostInfo {
  name?: string;
  hostname?: string;
  port?: number;
  sshUser?: string;
  knownHostKey?: string;
}

function pickString(value: unknown): string | undefined {
  if (value == null) return undefined;
  const s = String(value).trim();
  return s || undefined;
}

function pickNumber(value: unknown, fallback?: number): number | undefined {
  if (value == null || value === "") return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function extractBalancedJson(text: string, startIndex: number): string | null {
  if (text[startIndex] !== "{") return null;

  let depth = 0;
  let inString = false;
  let escape = false;

  for (let i = startIndex; i < text.length; i++) {
    const ch = text[i];

    if (inString) {
      if (escape) {
        escape = false;
      } else if (ch === "\\") {
        escape = true;
      } else if (ch === '"') {
        inString = false;
      }
      continue;
    }

    if (ch === '"') {
      inString = true;
      continue;
    }

    if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) return text.slice(startIndex, i + 1);
    }
  }

  return null;
}

function extractJsonBlock(text: string): string | null {
  const marker = text.search(/JSON\s*\(optional/i);
  const searchFrom = marker >= 0 ? marker : 0;
  const slice = text.slice(searchFrom);

  for (let i = 0; i < slice.length; i++) {
    if (slice[i] !== "{") continue;
    const block = extractBalancedJson(slice, i);
    if (block?.includes('"hostname"')) return block;
  }

  for (let i = text.length - 1; i >= 0; i--) {
    if (text[i] !== "{") continue;
    const block = extractBalancedJson(text, i);
    if (block?.includes('"hostname"')) return block;
  }

  return null;
}

function parseFromJson(text: string): ParsedHostInfo {
  const jsonBlock = extractJsonBlock(text);
  if (!jsonBlock) return {};

  try {
    const parsed = JSON.parse(jsonBlock) as Record<string, unknown>;
    return {
      name: pickString(parsed.name),
      hostname: pickString(parsed.hostname),
      port: pickNumber(parsed.port, 22),
      sshUser: pickString(parsed.sshUser) ?? "mcc-auto",
      knownHostKey: pickString(parsed.knownHostKey),
    };
  } catch {
    return {};
  }
}

function parseFromHumanReadable(text: string): ParsedHostInfo {
  const info: ParsedHostInfo = {};

  const nameMatch = text.match(/^\s*Name:\s*(.+)$/im);
  if (nameMatch) info.name = nameMatch[1].trim();

  const hostMatch =
    text.match(/^\s*Hostname\s*\/\s*IP:\s*(.+)$/im) ??
    text.match(/^\s*Hostname:\s*(.+)$/im);
  if (hostMatch) info.hostname = hostMatch[1].trim();

  const portMatch = text.match(/^\s*Port:\s*(\d+)/im);
  if (portMatch) info.port = parseInt(portMatch[1], 10);

  const userMatch = text.match(/^\s*SSH user:\s*(.+)$/im);
  if (userMatch) info.sshUser = userMatch[1].trim();

  const keyMatch = text.match(/^\s*Known host key:\s*(.+)$/im);
  if (keyMatch) {
    const key = keyMatch[1].trim();
    if (key && !key.startsWith("(")) {
      info.knownHostKey = key;
    }
  }

  const summaryMatch = text.match(/Host:\s*(\S+)\s+IP:\s*(\S+)/i);
  if (summaryMatch) {
    info.name = info.name || summaryMatch[1].trim();
    info.hostname = info.hostname || summaryMatch[2].trim();
  }

  return info;
}

function mergeHostInfo(primary: ParsedHostInfo, fallback: ParsedHostInfo): ParsedHostInfo {
  return {
    name: primary.name || fallback.name,
    hostname: primary.hostname || fallback.hostname,
    port: primary.port ?? fallback.port,
    sshUser: primary.sshUser || fallback.sshUser,
    knownHostKey: primary.knownHostKey || fallback.knownHostKey,
  };
}

function hasUsefulFields(info: ParsedHostInfo): boolean {
  return Boolean(info.name || info.hostname || info.port || info.sshUser || info.knownHostKey);
}

/** Parse Proxmox host setup script output (human-readable block and/or JSON). */
export function parseProxmoxHostOutput(text: string): ParsedHostInfo | null {
  const trimmed = text.trim();
  if (!trimmed) return null;

  const fromJson = parseFromJson(trimmed);
  const fromLines = parseFromHumanReadable(trimmed);
  const merged = mergeHostInfo(fromJson, fromLines);

  return hasUsefulFields(merged) ? merged : null;
}
