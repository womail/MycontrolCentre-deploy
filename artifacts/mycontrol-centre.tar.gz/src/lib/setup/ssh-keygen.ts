import { execFileSync } from "child_process";
import { mkdtempSync, readFileSync, rmSync } from "fs";
import { tmpdir } from "os";
import { join } from "path";
import { utils } from "ssh2";
import { fingerprintFromOpenSSHPublicLine } from "@/lib/ssh/pkcs8-ed25519-to-openssh";
import { resolveSshKeygenPath } from "@/lib/setup/ssh-keygen-bin";

export interface GeneratedSshKey {
  publicKey: string;
  privateKey: string;
  fingerprint: string;
}

const KEY_COMMENT = "mycontrol-centre";

function generateSshKeyPairWithSshKeygen(): GeneratedSshKey {
  const sshKeygen = resolveSshKeygenPath();
  if (!sshKeygen) {
    const err = new Error("ssh-keygen not found") as NodeJS.ErrnoException;
    err.code = "ENOENT";
    throw err;
  }

  const dir = mkdtempSync(join(tmpdir(), "mcc-key-"));
  const keyPath = join(dir, "mcc_automation");

  try {
    execFileSync(
      sshKeygen,
      ["-t", "ed25519", "-f", keyPath, "-N", "", "-C", KEY_COMMENT, "-q"],
      { stdio: "pipe" },
    );

    const privateKey = readFileSync(keyPath, "utf8");
    const publicKey = readFileSync(`${keyPath}.pub`, "utf8").trim();

    const fingerprint = execFileSync(
      sshKeygen,
      ["-lf", `${keyPath}.pub`],
      { encoding: "utf8" },
    ).trim();

    return { publicKey, privateKey, fingerprint };
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}

/** Fallback when `ssh-keygen` is not installed (e.g. some minimal hosts). */
function generateSshKeyPairWithSsh2(): GeneratedSshKey {
  const pair = utils.generateKeyPairSync("ed25519", { comment: KEY_COMMENT });
  const publicKeyLine = pair.public.trim();
  return {
    publicKey: publicKeyLine,
    privateKey: pair.private,
    fingerprint: fingerprintFromOpenSSHPublicLine(publicKeyLine, KEY_COMMENT),
  };
}

/** Generate Ed25519 key pair (OpenSSH PEM + public line). Prefers system `ssh-keygen`. */
export function generateSshKeyPair(): GeneratedSshKey {
  try {
    return generateSshKeyPairWithSshKeygen();
  } catch (error) {
    const err = error as NodeJS.ErrnoException;
    if (err.code === "ENOENT") {
      return generateSshKeyPairWithSsh2();
    }
    throw error;
  }
}

export interface InstallCommandOptions {
  enrollToken?: string;
  /** Run the downloaded script with sudo (non-root SSH session). */
  useSudo?: boolean;
}

const SETUP_SCRIPT_PATH = "/tmp/mcc-proxmox-setup.sh";

export function buildInstallCommand(
  appUrl: string,
  publicKey: string,
  options?: InstallCommandOptions,
): string {
  const base = appUrl.replace(/\/$/, "");
  const scriptUrl = `${base}/api/setup/proxmox-host.sh`;
  const enrollUrl = `${base}/api/enrollment/register`;
  const escapedKey = publicKey.replace(/'/g, `'\\''`);
  let scriptArgs = `--pubkey '${escapedKey}'`;
  if (options?.enrollToken?.trim()) {
    const escapedToken = options.enrollToken.trim().replace(/'/g, `'\\''`);
    scriptArgs += ` --enroll-url '${enrollUrl}' --enroll-token '${escapedToken}'`;
  }

  const download = [
    `rm -f ${SETUP_SCRIPT_PATH}`,
    `curl -fsSL --connect-timeout 30 --noproxy '*' '${scriptUrl}' -o ${SETUP_SCRIPT_PATH}`,
  ].join(" && ");
  const cleanup = `rm -f ${SETUP_SCRIPT_PATH}`;
  const runScript = options?.useSudo
    ? `sudo bash ${SETUP_SCRIPT_PATH} ${scriptArgs}`
    : `bash ${SETUP_SCRIPT_PATH} ${scriptArgs}`;

  return [download, runScript, cleanup].join(" && ");
}

export function buildInstallCommandPair(
  appUrl: string,
  publicKey: string,
  options?: Omit<InstallCommandOptions, "useSudo">,
) {
  return {
    asRoot: buildInstallCommand(appUrl, publicKey, options),
    withSudo: buildInstallCommand(appUrl, publicKey, { ...options, useSudo: true }),
  };
}
