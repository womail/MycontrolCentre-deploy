/**
 * Resolve the public URL of this console for install commands.
 * Uses the request Host when APP_URL is still localhost (common in dev).
 */
export function resolveAppUrl(request?: Request): string {
  const envUrl = process.env.APP_URL ?? "http://localhost:3000";

  if (!request) return envUrl.replace(/\/$/, "");

  try {
    const parsed = new URL(envUrl);
    const isLocal =
      parsed.hostname === "localhost" ||
      parsed.hostname === "127.0.0.1" ||
      parsed.hostname === "0.0.0.0";

    if (isLocal) {
      const host =
        request.headers.get("x-forwarded-host")?.split(",")[0]?.trim() ||
        request.headers.get("host");
      if (host) {
        const proto =
          request.headers.get("x-forwarded-proto")?.split(",")[0]?.trim() ||
          "http";
        return `${proto}://${host}`.replace(/\/$/, "");
      }
    }
  } catch {
    /* use env */
  }

  return envUrl.replace(/\/$/, "");
}

export function normalizeConsoleUrl(input: string): string {
  const trimmed = input.trim().replace(/\/$/, "");
  if (!trimmed) return "http://localhost:3000";
  if (!/^https?:\/\//i.test(trimmed)) {
    return `http://${trimmed}`;
  }
  return trimmed;
}

export function isLocalAppUrl(url: string): boolean {
  try {
    const h = new URL(url).hostname;
    return h === "localhost" || h === "127.0.0.1" || h === "0.0.0.0";
  } catch {
    return false;
  }
}
