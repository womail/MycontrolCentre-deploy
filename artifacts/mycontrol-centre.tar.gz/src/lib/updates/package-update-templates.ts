import { filterTemplatesForServers } from "@/lib/commands/platform-filter";
import type { ServerPlatform } from "@/lib/servers/platforms";

export interface PackageUpdateTemplatePick {
  id: string;
  type: string;
  name: string;
}

type PickInput = Pick<PackageUpdateTemplatePick, "id" | "type" | "name"> & {
  isActive?: boolean;
  platforms?: unknown;
};

type ServerPick = {
  id: string;
  manualPlatforms?: unknown;
  detectedPlatforms?: unknown;
  platforms?: ServerPlatform[];
};

const APT_FLOW: Array<{ type: string } | { name: string }> = [
  { type: "APT_UPDATE" },
  { type: "APT_UPGRADE" },
];

const PACMAN_FLOW: Array<{ name: string }> = [{ name: "Pacman Sync" }, { name: "Pacman Upgrade" }];

function findInVisible(
  visible: PickInput[],
  spec: { type?: string; name?: string },
): PickInput | undefined {
  if (spec.type) return visible.find((t) => t.type === spec.type);
  if (spec.name) return visible.find((t) => t.name === spec.name);
  return undefined;
}

/** Ordered template IDs for refresh + upgrade on a single host (apt or pacman). */
export function pickPackageUpdateTemplateIds(
  server: ServerPick,
  templates: PickInput[],
): string[] {
  const active = templates.filter((t) => t.isActive !== false);
  const visible = filterTemplatesForServers(active, [server]);

  const aptIds = APT_FLOW.map((spec) => findInVisible(visible, spec)?.id).filter(
    (id): id is string => Boolean(id),
  );
  if (aptIds.length === APT_FLOW.length) return aptIds;

  const pacmanIds = PACMAN_FLOW.map((spec) => findInVisible(visible, spec)?.id).filter(
    (id): id is string => Boolean(id),
  );
  if (pacmanIds.length === PACMAN_FLOW.length) return pacmanIds;

  return [];
}

export function packageUpdatesCommandsHref(serverId: string): string {
  return `/commands?runUpdates=${encodeURIComponent(serverId)}`;
}
