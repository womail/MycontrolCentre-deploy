import { prisma } from "../db";
import { execOnServer } from "../ssh/client";
import type { Server } from "@prisma/client";
import { effectivePlatforms, parsePlatformList } from "../servers/platforms";

const APT_UPDATE_COMMAND =
  "export DEBIAN_FRONTEND=noninteractive; apt-get update -qq 2>/dev/null; apt-get -s upgrade 2>/dev/null | grep -c ^Inst || echo 0";

const PACMAN_UPDATE_COMMAND = "pacman -Qu 2>/dev/null | wc -l";

function serverPlatforms(server: Server): ReturnType<typeof effectivePlatforms> {
  const manual = parsePlatformList(server.manualPlatforms);
  const detected = parsePlatformList(server.detectedPlatforms);
  return effectivePlatforms({ manualPlatforms: manual, detectedPlatforms: detected });
}

export function serverSupportsAptUpdates(server: Server): boolean {
  const platforms = serverPlatforms(server);
  return platforms.includes("debian") || platforms.includes("docker") || platforms.includes("proxmox");
}

export function serverSupportsPacmanUpdates(server: Server): boolean {
  return serverPlatforms(server).includes("arch");
}

export function serverSupportsPackageUpdates(server: Server): boolean {
  return serverSupportsAptUpdates(server) || serverSupportsPacmanUpdates(server);
}

function parseCountOutput(stdout: string, stderr: string): number | null {
  const line = (stdout || stderr).trim().split("\n").pop() ?? "0";
  const count = parseInt(line.replace(/[^0-9]/g, ""), 10);
  return Number.isFinite(count) ? count : null;
}

export async function syncServerPackageUpdates(server: Server): Promise<number | null> {
  if (server.healthStatus !== "ONLINE" || !server.isActive) return null;

  const usePacman = serverSupportsPacmanUpdates(server) && !serverSupportsAptUpdates(server);
  const useApt = serverSupportsAptUpdates(server);
  if (!usePacman && !useApt) return null;

  const command = usePacman && !useApt ? PACMAN_UPDATE_COMMAND : APT_UPDATE_COMMAND;

  try {
    const result = await execOnServer(server, command, { timeoutMs: 120_000 });
    const pending = parseCountOutput(result.stdout, result.stderr);
    if (pending == null) return null;

    await prisma.server.update({
      where: { id: server.id },
      data: {
        pendingPackageUpdates: pending,
        lastPackageUpdatesCheck: new Date(),
      },
    });
    return pending;
  } catch {
    return null;
  }
}

export async function runScheduledPackageUpdateChecks(): Promise<number> {
  const servers = await prisma.server.findMany({
    where: { isActive: true, healthStatus: "ONLINE" },
  });

  let checked = 0;
  for (const server of servers) {
    if (!serverSupportsPackageUpdates(server)) continue;
    const last = server.lastPackageUpdatesCheck;
    const stale = !last || Date.now() - last.getTime() > 6 * 60 * 60 * 1000;
    if (!stale) continue;
    await syncServerPackageUpdates(server);
    checked += 1;
  }
  return checked;
}
