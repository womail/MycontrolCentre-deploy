import { createHash } from "crypto";

/** Base64 key material from an OpenSSH public key line (middle field). */
export function opensshPublicKeyBlobB64(publicKeyLine: string): string | null {
  const parts = publicKeyLine.trim().split(/\s+/);
  if (parts.length < 2 || !parts[0].startsWith("ssh-")) return null;
  return parts[1] ?? null;
}

/** Same fingerprint as `ssh-keygen -lf` (SHA256 of decoded public key blob). */
export function opensshSha256Fingerprint(publicKeyLine: string): string | null {
  const b64 = opensshPublicKeyBlobB64(publicKeyLine);
  if (!b64) return null;
  try {
    const blob = Buffer.from(b64, "base64");
    return createHash("sha256").update(blob).digest("base64").replace(/=+$/, "");
  } catch {
    return null;
  }
}

export function opensshSha256FingerprintLabel(publicKeyLine: string): string | null {
  const fp = opensshSha256Fingerprint(publicKeyLine);
  if (!fp) return null;
  const parts = publicKeyLine.trim().split(/\s+/);
  const comment = parts[2] ?? "key";
  const type = parts[0]?.includes("ed25519")
    ? "ED25519"
    : parts[0]?.includes("rsa")
      ? "RSA"
      : "KEY";
  return `SHA256:${fp} ${comment} (${type})`;
}

/** @deprecated Legacy MCC hash (UTF-8 of base64 text); kept for old DB rows. */
export function legacyMccPublicKeyFingerprint(publicKeyLine: string): string | null {
  const b64 = opensshPublicKeyBlobB64(publicKeyLine);
  if (!b64) return null;
  return createHash("sha256").update(b64, "utf8").digest("base64");
}

export function publicKeysMatch(lineA: string, lineB: string): boolean {
  const a = opensshPublicKeyBlobB64(lineA);
  const b = opensshPublicKeyBlobB64(lineB);
  return a != null && b != null && a === b;
}
