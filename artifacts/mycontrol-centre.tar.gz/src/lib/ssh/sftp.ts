import { Client, type SFTPWrapper } from "ssh2";
import type { Server } from "@prisma/client";
import type { SshConnectionOptions } from "./client";
import { logRemoteConnection } from "../connection-log";
import { withHostSshLock } from "./host-lock";
import { buildSshConnectConfig } from "./connect-config";

export interface RemoteFileEntry {
  name: string;
  path: string;
  size: number;
  modifyTime: number;
  isDirectory: boolean;
  isSymlink: boolean;
  mode: number;
}

async function writeRemoteConnectionLog(
  server: Server,
  options: SshConnectionOptions | undefined,
  outcome: "SUCCESS" | "FAILED",
  data: {
    durationMs: number;
    errorMessage?: string;
  },
) {
  if (!options?.log) return;
  await logRemoteConnection({
    server,
    purpose: options.log.purpose,
    outcome,
    userId: options.log.userId,
    commandRunId: options.log.commandRunId,
    durationMs: data.durationMs,
    errorMessage: data.errorMessage,
  });
}

export function withSftp<T>(
  server: Server,
  fn: (sftp: SFTPWrapper) => Promise<T>,
  options: SshConnectionOptions = {},
): Promise<T> {
  return withHostSshLock(server, () => withSftpUnlocked(server, fn, options));
}

function withSftpUnlocked<T>(
  server: Server,
  fn: (sftp: SFTPWrapper) => Promise<T>,
  options: SshConnectionOptions = {},
): Promise<T> {
  const timeoutMs = options.timeoutMs ?? 120_000;
  const start = Date.now();

  return new Promise((resolve, reject) => {
    const conn = new Client();
    let settled = false;

    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        conn.destroy();
        reject(new Error(`SFTP timed out after ${timeoutMs}ms`));
      }
    }, timeoutMs);

    const fail = (error: Error) => {
      clearTimeout(timer);
      if (!settled) {
        settled = true;
        conn.destroy();
        void writeRemoteConnectionLog(server, options, "FAILED", {
          durationMs: Date.now() - start,
          errorMessage: error.message,
        });
        reject(error);
      }
    };

    conn
      .on("ready", () => {
        conn.sftp(async (err, sftp) => {
          if (err) {
            fail(err);
            return;
          }
          try {
            const result = await fn(sftp);
            clearTimeout(timer);
            if (!settled) {
              settled = true;
              conn.end();
              void writeRemoteConnectionLog(server, options, "SUCCESS", {
                durationMs: Date.now() - start,
              });
              resolve(result);
            }
          } catch (error) {
            fail(error instanceof Error ? error : new Error(String(error)));
          }
        });
      })
      .on("error", (err) => fail(err))
      .connect(buildSshConnectConfig(server));
  });
}

function modeIsDirectory(mode: number): boolean {
  return (mode & 0o170000) === 0o040000;
}

function modeIsSymlink(mode: number): boolean {
  return (mode & 0o170000) === 0o120000;
}

export async function sftpListDirectory(
  server: Server,
  directoryPath: string,
  options?: SshConnectionOptions,
): Promise<RemoteFileEntry[]> {
  return withSftp(
    server,
    (sftp) =>
      new Promise((resolve, reject) => {
        sftp.readdir(directoryPath, (err, list) => {
          if (err) {
            reject(err);
            return;
          }
          const base =
            directoryPath === "/" ? "" : directoryPath.replace(/\/+$/, "");
          const entries: RemoteFileEntry[] = (list ?? []).map((item) => {
            const mode = item.attrs.mode ?? 0;
            return {
              name: item.filename,
              path: `${base}/${item.filename}`,
              size: item.attrs.size ?? 0,
              modifyTime: (item.attrs.mtime ?? 0) * 1000,
              isDirectory: modeIsDirectory(mode),
              isSymlink: modeIsSymlink(mode),
              mode,
            };
          });
          entries.sort((a, b) => {
            if (a.isDirectory !== b.isDirectory) return a.isDirectory ? -1 : 1;
            return a.name.localeCompare(b.name);
          });
          resolve(entries);
        });
      }),
    options,
  );
}

export function sftpReadFileBuffer(
  server: Server,
  remotePath: string,
  options?: SshConnectionOptions,
): Promise<Buffer> {
  return withSftp(
    server,
    (sftp) =>
      new Promise((resolve, reject) => {
        const chunks: Buffer[] = [];
        const stream = sftp.createReadStream(remotePath);
        stream.on("data", (chunk: Buffer) => chunks.push(chunk));
        stream.on("error", reject);
        stream.on("close", () => resolve(Buffer.concat(chunks)));
      }),
    options,
  );
}

export function sftpWriteFileBuffer(
  server: Server,
  remotePath: string,
  content: Buffer,
  options?: SshConnectionOptions,
): Promise<void> {
  return withSftp(
    server,
    (sftp) =>
      new Promise((resolve, reject) => {
        const stream = sftp.createWriteStream(remotePath, { mode: 0o644 });
        stream.on("error", reject);
        stream.on("close", () => resolve());
        stream.end(content);
      }),
    options,
  );
}

export function sftpMkdir(
  server: Server,
  remotePath: string,
  options?: SshConnectionOptions,
): Promise<void> {
  return withSftp(
    server,
    (sftp) =>
      new Promise((resolve, reject) => {
        sftp.mkdir(remotePath, (err) => (err ? reject(err) : resolve()));
      }),
    options,
  );
}

export function sftpRemoveFile(
  server: Server,
  remotePath: string,
  options?: SshConnectionOptions,
): Promise<void> {
  return withSftp(
    server,
    (sftp) =>
      new Promise((resolve, reject) => {
        sftp.unlink(remotePath, (err) => (err ? reject(err) : resolve()));
      }),
    options,
  );
}

export function sftpRemoveDirectory(
  server: Server,
  remotePath: string,
  options?: SshConnectionOptions,
): Promise<void> {
  return withSftp(
    server,
    (sftp) =>
      new Promise((resolve, reject) => {
        sftp.rmdir(remotePath, (err) => (err ? reject(err) : resolve()));
      }),
    options,
  );
}

export function sftpRename(
  server: Server,
  fromPath: string,
  toPath: string,
  options?: SshConnectionOptions,
): Promise<void> {
  return withSftp(
    server,
    (sftp) =>
      new Promise((resolve, reject) => {
        sftp.rename(fromPath, toPath, (err) => (err ? reject(err) : resolve()));
      }),
    options,
  );
}

export function sftpStat(
  server: Server,
  remotePath: string,
  options?: SshConnectionOptions,
): Promise<{ isDirectory: boolean; size: number }> {
  return withSftp(
    server,
    (sftp) =>
      new Promise((resolve, reject) => {
        sftp.stat(remotePath, (err, stats) => {
          if (err) {
            reject(err);
            return;
          }
          const mode = stats.mode ?? 0;
          resolve({
            isDirectory: modeIsDirectory(mode),
            size: stats.size ?? 0,
          });
        });
      }),
    options,
  );
}
