/** Parse stored known host key(s): single base64 string or JSON string array. */
export function parseKnownHostKeys(raw: string | null | undefined): string[] {
  if (!raw?.trim()) return [];
  const trimmed = raw.trim();
  if (trimmed.startsWith("[")) {
    try {
      const parsed = JSON.parse(trimmed) as unknown;
      if (Array.isArray(parsed)) {
        return parsed
          .filter((entry): entry is string => typeof entry === "string")
          .map((entry) => entry.trim())
          .filter(Boolean);
      }
    } catch {
      /* fall through */
    }
  }
  return [trimmed];
}

export function serializeKnownHostKeys(keys: string[]): string | null {
  const unique = [...new Set(keys.map((k) => k.trim()).filter(Boolean))];
  if (unique.length === 0) return null;
  if (unique.length === 1) return unique[0]!;
  return JSON.stringify(unique);
}

export function hostKeyMatchesStored(stored: string | null | undefined, offered: Buffer): boolean {
  const offeredB64 = offered.toString("base64");
  return parseKnownHostKeys(stored).includes(offeredB64);
}
