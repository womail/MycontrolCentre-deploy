import { validatePath } from "../commands/validate";

const MAX_NAME_LENGTH = 255;

export function validateRemoteDirectoryPath(path: string, label = "Path"): string {
  return validatePath(path, label);
}

export function validateRemoteEntryName(name: string, label = "Name"): string {
  const trimmed = name.trim();
  if (!trimmed) {
    throw new Error(`${label} is required`);
  }
  if (trimmed.length > MAX_NAME_LENGTH) {
    throw new Error(`${label} is too long (max ${MAX_NAME_LENGTH} characters)`);
  }
  if (
    trimmed.includes("/") ||
    trimmed.includes("\0") ||
    trimmed.includes("\n") ||
    trimmed.includes("\r")
  ) {
    throw new Error(`${label} must be a single path segment`);
  }
  if (trimmed === "." || trimmed === "..") {
    throw new Error(`${label} is not allowed`);
  }
  return trimmed;
}

export function joinRemotePath(parentDir: string, name: string): string {
  const parent = validateRemoteDirectoryPath(parentDir);
  const entry = validateRemoteEntryName(name);
  if (parent === "/") return `/${entry}`;
  return `${parent.replace(/\/+$/, "")}/${entry}`;
}

export function parentRemotePath(path: string): string {
  const normalized = validateRemoteDirectoryPath(path);
  if (normalized === "/") return "/";
  const idx = normalized.lastIndexOf("/");
  if (idx <= 0) return "/";
  return normalized.slice(0, idx);
}

/** Block recursive delete of filesystem root and common OS top-level directories. */
const PROTECTED_DELETE_PREFIXES = [
  "/",
  "/bin",
  "/boot",
  "/dev",
  "/etc",
  "/lib",
  "/lib64",
  "/opt",
  "/proc",
  "/root",
  "/sbin",
  "/sys",
  "/usr",
  "/var",
] as const;

export function validateSafeRemoteDeletePath(path: string, label = "Path"): string {
  const normalized = validatePath(path, label);
  const lower = normalized.toLowerCase();
  for (const blocked of PROTECTED_DELETE_PREFIXES) {
    if (blocked === "/") {
      if (lower === "/") {
        throw new Error(`${label} cannot be the filesystem root`);
      }
      continue;
    }
    if (lower === blocked || lower.startsWith(`${blocked}/`)) {
      throw new Error(`${label} is under a protected system location`);
    }
  }
  return normalized;
}
