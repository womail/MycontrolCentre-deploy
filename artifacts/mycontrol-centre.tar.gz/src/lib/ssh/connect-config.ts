import type { ConnectConfig } from "ssh2";
import type { Server } from "@prisma/client";
import { decrypt } from "../crypto";
import { hostKeyMatchesStored } from "./known-host-keys";
import { privateKeyForSsh2 } from "./private-key-for-ssh2";

export function buildSshConnectConfig(server: Server): ConnectConfig {
  const username = server.sshUser.trim();
  const config: ConnectConfig = {
    host: server.hostname,
    port: server.port,
    username,
    readyTimeout: 15000,
    algorithms: {
      serverHostKey: [
        "ssh-rsa",
        "rsa-sha2-512",
        "rsa-sha2-256",
        "ecdsa-sha2-nistp256",
        "ecdsa-sha2-nistp384",
        "ecdsa-sha2-nistp521",
        "ssh-ed25519",
      ],
    },
  };

  if (
    (server.authType === "KEY" || server.authType === "KEY_AND_PASSWORD") &&
    server.encryptedPrivateKey
  ) {
    config.privateKey = privateKeyForSsh2(decrypt(server.encryptedPrivateKey));
  }

  if (
    (server.authType === "PASSWORD" ||
      server.authType === "KEY_AND_PASSWORD") &&
    server.encryptedPassword
  ) {
    config.password = decrypt(server.encryptedPassword);
  }

  if (server.knownHostKey) {
    config.hostVerifier = (key: Buffer) =>
      hostKeyMatchesStored(server.knownHostKey, key);
  } else if (!server.acceptNewHostKey) {
    config.hostVerifier = () => {
      throw new Error(
        "Host key not trusted. Add the host key or enable accept on first connect.",
      );
    };
  }

  return config;
}

export function buildSshConnectConfigForHostKeyCapture(server: Server): ConnectConfig {
  return buildSshConnectConfig({
    ...server,
    knownHostKey: null,
    acceptNewHostKey: true,
  });
}
