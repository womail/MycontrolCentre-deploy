import { execOnServer, shellEscape } from "./client";
import type { Server } from "@prisma/client";
import { validateRemoteDirectoryPath } from "./remote-paths";
import { validatePath } from "../commands/validate";
import type { SshConnectionOptions } from "./client";

function archiveKind(name: string): "tar.gz" | "tar" | "zip" | "gz" | null {
  const lower = name.toLowerCase();
  if (lower.endsWith(".tar.gz") || lower.endsWith(".tgz")) return "tar.gz";
  if (lower.endsWith(".tar")) return "tar";
  if (lower.endsWith(".zip")) return "zip";
  if (lower.endsWith(".gz") && !lower.endsWith(".tar.gz")) return "gz";
  return null;
}

export async function compressRemotePaths(
  server: Server,
  paths: string[],
  archivePath: string,
  options?: SshConnectionOptions,
): Promise<{ stdout: string; stderr: string; exitCode: number }> {
  if (paths.length === 0) throw new Error("Select at least one file or folder");
  const archive = validatePath(archivePath, "Archive path");
  const escapedPaths = paths.map((p) => shellEscape(validatePath(p, "Path")));
  const escapedArchive = shellEscape(archive);
  const command = `tar -czf ${escapedArchive} ${escapedPaths.join(" ")}`;
  const result = await execOnServer(server, command, options);
  if (result.exitCode !== 0) {
    throw new Error(result.stderr.trim() || result.stdout.trim() || "Compress failed");
  }
  return result;
}

export async function decompressRemoteArchive(
  server: Server,
  archivePath: string,
  destDir: string | undefined,
  options?: SshConnectionOptions,
): Promise<{ stdout: string; stderr: string; exitCode: number }> {
  const archive = validatePath(archivePath, "Archive path");
  const kind = archiveKind(archive.split("/").pop() ?? archive);
  if (!kind) {
    throw new Error("Unsupported archive type (use .tar.gz, .tgz, .tar, .zip, or .gz)");
  }

  const dest = destDir ? validateRemoteDirectoryPath(destDir) : validateRemoteDirectoryPath(
    archive.slice(0, archive.lastIndexOf("/")) || "/",
  );
  const escapedArchive = shellEscape(archive);
  const escapedDest = shellEscape(dest);

  let command: string;
  switch (kind) {
    case "tar.gz":
      command = `mkdir -p ${escapedDest} && tar -xzf ${escapedArchive} -C ${escapedDest}`;
      break;
    case "tar":
      command = `mkdir -p ${escapedDest} && tar -xf ${escapedArchive} -C ${escapedDest}`;
      break;
    case "zip":
      command = `mkdir -p ${escapedDest} && unzip -o ${escapedArchive} -d ${escapedDest}`;
      break;
    case "gz":
      command = `mkdir -p ${escapedDest} && gunzip -c ${escapedArchive} > ${shellEscape(`${dest}/${archive.split("/").pop()!.replace(/\.gz$/i, "")}`)}`;
      break;
  }

  const result = await execOnServer(server, command, options);
  if (result.exitCode !== 0) {
    throw new Error(result.stderr.trim() || result.stdout.trim() || "Extract failed");
  }
  return result;
}
