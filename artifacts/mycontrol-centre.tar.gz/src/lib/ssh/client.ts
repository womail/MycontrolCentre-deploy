import { Client } from "ssh2";
import type { Server } from "@prisma/client";
import { appendCapped, MAX_CAPTURED_OUTPUT_CHARS } from "../memory/output-cap";
import { buildSshConnectConfig, buildSshConnectConfigForHostKeyCapture } from "./connect-config";
import { withHostSshLock } from "./host-lock";
import {
  logRemoteConnection,
  type RemoteConnectionLogContext,
} from "../connection-log";

export interface SshExecResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  durationMs: number;
}

export interface SshStreamCallbacks {
  onStdout?: (chunk: string) => void;
  onStderr?: (chunk: string) => void;
}

export interface SshConnectionOptions {
  timeoutMs?: number;
  log?: RemoteConnectionLogContext;
  stream?: SshStreamCallbacks;
}

async function writeRemoteConnectionLog(
  server: Server,
  options: SshConnectionOptions | undefined,
  outcome: "SUCCESS" | "FAILED",
  data: {
    durationMs: number;
    exitCode?: number;
    errorMessage?: string;
  },
) {
  if (!options?.log) return;

  await logRemoteConnection({
    server,
    purpose: options.log.purpose,
    outcome,
    userId: options.log.userId,
    commandRunId: options.log.commandRunId,
    durationMs: data.durationMs,
    exitCode: data.exitCode,
    errorMessage: data.errorMessage,
  });
}

export function execOnServer(
  server: Server,
  command: string,
  options: SshConnectionOptions = {},
): Promise<SshExecResult> {
  return withHostSshLock(server, () => execOnServerUnlocked(server, command, options));
}

function execOnServerUnlocked(
  server: Server,
  command: string,
  options: SshConnectionOptions = {},
): Promise<SshExecResult> {
  const timeoutMs = options.timeoutMs ?? 300000;
  const start = Date.now();

  return new Promise((resolve, reject) => {
    const conn = new Client();
    let settled = false;

    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        conn.destroy();
        const durationMs = Date.now() - start;
        const message = `SSH command timed out after ${timeoutMs}ms`;
        void writeRemoteConnectionLog(server, options, "FAILED", {
          durationMs,
          errorMessage: message,
        }).catch((error) => {
          console.error("Failed to write remote connection log:", error);
        });
        reject(new Error(message));
      }
    }, timeoutMs);

    conn
      .on("ready", () => {
        conn.exec(command, { pty: false }, (err, stream) => {
          if (err) {
            clearTimeout(timer);
            settled = true;
            conn.end();
            const durationMs = Date.now() - start;
            void writeRemoteConnectionLog(server, options, "FAILED", {
              durationMs,
              errorMessage: err.message,
            }).catch((error) => {
              console.error("Failed to write remote connection log:", error);
            });
            reject(err);
            return;
          }

          let stdout = "";
          let stderr = "";

          stream.on("close", (code: number | null) => {
            clearTimeout(timer);
            if (!settled) {
              settled = true;
              conn.end();
              const durationMs = Date.now() - start;
              const result = {
                stdout: stdout.slice(0, MAX_CAPTURED_OUTPUT_CHARS),
                stderr: stderr.slice(0, MAX_CAPTURED_OUTPUT_CHARS),
                exitCode: code ?? 1,
                durationMs,
              };
              void writeRemoteConnectionLog(server, options, "SUCCESS", {
                durationMs,
                exitCode: result.exitCode,
              }).catch((error) => {
                console.error("Failed to write remote connection log:", error);
              });
              resolve(result);
            }
          });

          stream.on("data", (data: Buffer) => {
            const chunk = data.toString("utf8");
            stdout = appendCapped(stdout, chunk);
            options.stream?.onStdout?.(chunk);
          });

          stream.stderr.on("data", (data: Buffer) => {
            const chunk = data.toString("utf8");
            stderr = appendCapped(stderr, chunk);
            options.stream?.onStderr?.(chunk);
          });
        });
      })
      .on("error", (err) => {
        clearTimeout(timer);
        if (!settled) {
          settled = true;
          const durationMs = Date.now() - start;
          void writeRemoteConnectionLog(server, options, "FAILED", {
            durationMs,
            errorMessage: err.message,
          }).catch((error) => {
            console.error("Failed to write remote connection log:", error);
          });
          reject(err);
        }
      })
      .connect(buildSshConnectConfig(server));
  });
}

export function uploadRemoteFile(
  server: Server,
  remotePath: string,
  content: string,
  options: SshConnectionOptions = {},
): Promise<void> {
  return withHostSshLock(server, () =>
    uploadRemoteFileUnlocked(server, remotePath, content, options),
  );
}

function uploadRemoteFileUnlocked(
  server: Server,
  remotePath: string,
  content: string,
  options: SshConnectionOptions = {},
): Promise<void> {
  const timeoutMs = options.timeoutMs ?? 120_000;
  const start = Date.now();

  return new Promise((resolve, reject) => {
    const conn = new Client();
    let settled = false;

    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        conn.end();
        reject(new Error(`SFTP upload timed out after ${timeoutMs}ms`));
      }
    }, timeoutMs);

    const fail = (error: Error) => {
      clearTimeout(timer);
      if (!settled) {
        settled = true;
        conn.end();
        void writeRemoteConnectionLog(server, options, "FAILED", {
          durationMs: Date.now() - start,
          errorMessage: error.message,
        }).catch((logError) => {
          console.error("Failed to write remote connection log:", logError);
        });
        reject(error);
      }
    };

    conn
      .on("ready", () => {
        conn.sftp((err, sftp) => {
          if (err) {
            fail(err);
            return;
          }

          const stream = sftp.createWriteStream(remotePath, { mode: 0o644 });
          stream.on("error", (streamError: Error) => fail(streamError));
          stream.on("close", () => {
            clearTimeout(timer);
            if (!settled) {
              settled = true;
              conn.end();
              void writeRemoteConnectionLog(server, options, "SUCCESS", {
                durationMs: Date.now() - start,
              }).catch((logError) => {
                console.error("Failed to write remote connection log:", logError);
              });
              resolve();
            }
          });
          stream.end(content, "utf8");
        });
      })
      .on("error", (err) => fail(err))
      .connect(buildSshConnectConfig(server));
  });
}

export function testConnection(
  server: Server,
  log?: Omit<RemoteConnectionLogContext, "purpose">,
): Promise<SshExecResult> {
  return execOnServer(server, "echo ok && uname -a", {
    timeoutMs: 15000,
    log: log ? { ...log, purpose: "HEALTH_CHECK" } : undefined,
  });
}

export function shellEscape(path: string): string {
  return `'${path.replace(/'/g, `'\\''`)}'`;
}

export function buildRemoteCommand(
  workingDir: string | undefined,
  innerCommand: string,
): string {
  if (workingDir) {
    return `cd ${shellEscape(workingDir)} && ${innerCommand}`;
  }
  return innerCommand;
}

export function captureHostKey(
  server: Server,
  log?: Omit<RemoteConnectionLogContext, "purpose">,
): Promise<string> {
  const start = Date.now();

  return new Promise((resolve, reject) => {
    const conn = new Client();
    conn
      .on("ready", () => {
        reject(new Error("Unexpected ready without host key capture"));
      })
      .on("error", (err) => {
        const durationMs = Date.now() - start;
        void logRemoteConnection({
          server,
          purpose: "HOST_KEY_CAPTURE",
          outcome: "FAILED",
          userId: log?.userId,
          durationMs,
          errorMessage: err.message,
        }).catch((error) => {
          console.error("Failed to write remote connection log:", error);
        });
        reject(new Error("Failed to connect for host key capture"));
      });

    const config = buildSshConnectConfigForHostKeyCapture(server);

    config.hostVerifier = (key: Buffer) => {
      conn.end();
      const durationMs = Date.now() - start;
      void logRemoteConnection({
        server,
        purpose: "HOST_KEY_CAPTURE",
        outcome: "SUCCESS",
        userId: log?.userId,
        durationMs,
      }).catch((error) => {
        console.error("Failed to write remote connection log:", error);
      });
      resolve(key.toString("base64"));
      return true;
    };

    conn.connect(config);
  });
}
