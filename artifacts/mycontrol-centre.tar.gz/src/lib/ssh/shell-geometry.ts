export const SHELL_COLS_MIN = 40;
export const SHELL_COLS_MAX = 300;
export const SHELL_ROWS_MIN = 8;
export const SHELL_ROWS_MAX = 120;

export function clampShellCols(cols: number): number {
  if (!Number.isFinite(cols)) return 100;
  return Math.min(SHELL_COLS_MAX, Math.max(SHELL_COLS_MIN, Math.round(cols)));
}

export function clampShellRows(rows: number): number {
  if (!Number.isFinite(rows)) return 28;
  return Math.min(SHELL_ROWS_MAX, Math.max(SHELL_ROWS_MIN, Math.round(rows)));
}

export function clampShellGeometry(cols: number, rows: number) {
  return { cols: clampShellCols(cols), rows: clampShellRows(rows) };
}
