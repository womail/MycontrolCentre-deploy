import { utils } from "ssh2";
import { pkcs8Ed25519PemToOpenSSH } from "./pkcs8-ed25519-to-openssh";

/** Normalize stored private key material for ssh2 (OpenSSH PEM; legacy PKCS#8 Ed25519 supported). */
export function privateKeyForSsh2(stored: string): string {
  const trimmed = stored.trim();
  if (!(utils.parseKey(trimmed) instanceof Error)) return trimmed;

  const converted = pkcs8Ed25519PemToOpenSSH(trimmed);
  if (converted && !(utils.parseKey(converted) instanceof Error)) {
    return converted;
  }

  return trimmed;
}
