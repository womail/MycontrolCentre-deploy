import type { Server } from "@prisma/client";

const tailByKey = new Map<string, Promise<void>>();

function hostKey(server: Pick<Server, "hostname" | "port" | "sshUser">): string {
  return `${server.hostname}:${server.port}:${server.sshUser}`;
}

/** One SSH handshake at a time per host/user (avoids sshd MaxAuthTries / fail2ban bursts). */
export async function withHostSshLock<T>(
  server: Pick<Server, "hostname" | "port" | "sshUser">,
  fn: () => Promise<T>,
): Promise<T> {
  const key = hostKey(server);
  const prev = tailByKey.get(key) ?? Promise.resolve();

  let release!: () => void;
  const gate = new Promise<void>((resolve) => {
    release = resolve;
  });

  const next = prev.then(() => gate);
  tailByKey.set(key, next);

  await prev;
  try {
    return await fn();
  } finally {
    release();
    if (tailByKey.get(key) === next) {
      tailByKey.delete(key);
    }
  }
}
