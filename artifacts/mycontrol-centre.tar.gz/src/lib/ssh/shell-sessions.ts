import { randomUUID } from "crypto";
import { Client, type ClientChannel } from "ssh2";
import type { Server } from "@prisma/client";
import { withHostSshLock } from "./host-lock";
import { buildSshConnectConfig } from "./connect-config";
import { getMccGlobals } from "../queue/process-globals";
import { logRemoteConnection } from "../connection-log";
import { clampShellCols, clampShellRows } from "./shell-geometry";

const SESSION_IDLE_MS = 30 * 60_000;
const MAX_SESSIONS = 20;

export type ShellStreamEvent =
  | { type: "output"; data: string }
  | { type: "closed"; message?: string };

export type ShellSession = {
  id: string;
  serverId: string;
  ownerUserId: string;
  conn: Client;
  stream: ClientChannel;
  lastActivityAt: number;
  closed: boolean;
  listeners: Set<(event: ShellStreamEvent) => void>;
};

function shellGlobals(): { sessions: Map<string, ShellSession> } {
  const g = getMccGlobals();
  if (!g.shellSessions) {
    g.shellSessions = { sessions: new Map() };
  }
  return g.shellSessions;
}

function broadcast(session: ShellSession, event: ShellStreamEvent) {
  for (const listener of session.listeners) {
    listener(event);
  }
}

function closeSession(session: ShellSession, message?: string) {
  if (session.closed) return;
  session.closed = true;
  try {
    session.stream.end();
  } catch {
    /* ignore */
  }
  try {
    session.conn.end();
  } catch {
    /* ignore */
  }
  broadcast(session, { type: "closed", message });
  session.listeners.clear();
  shellGlobals().sessions.delete(session.id);
}

export function sweepIdleShellSessions(now = Date.now()) {
  for (const session of shellGlobals().sessions.values()) {
    if (now - session.lastActivityAt > SESSION_IDLE_MS) {
      closeSession(session, "Session closed due to inactivity");
    }
  }
}

export function createShellSession(params: {
  server: Server;
  userId: string;
  cols: number;
  rows: number;
}): Promise<ShellSession> {
  sweepIdleShellSessions();

  const { sessions } = shellGlobals();
  if (sessions.size >= MAX_SESSIONS) {
    return Promise.reject(new Error("Too many active SSH sessions. Close one and try again."));
  }

  const start = Date.now();
  const sessionId = randomUUID();

  return withHostSshLock(params.server, () =>
    new Promise<ShellSession>((resolve, reject) => {
    const conn = new Client();
    let settled = false;

    const fail = (error: Error) => {
      if (settled) return;
      settled = true;
      conn.end();
      void logRemoteConnection({
        server: params.server,
        purpose: "COMMAND",
        outcome: "FAILED",
        userId: params.userId,
        durationMs: Date.now() - start,
        errorMessage: error.message,
      });
      reject(error);
    };

    conn
      .on("ready", () => {
        conn.shell(
          {
            term: "xterm-256color",
            cols: clampShellCols(params.cols),
            rows: clampShellRows(params.rows),
          },
          (err, stream) => {
            if (err) {
              fail(err);
              return;
            }

            const session: ShellSession = {
              id: sessionId,
              serverId: params.server.id,
              ownerUserId: params.userId,
              conn,
              stream,
              lastActivityAt: Date.now(),
              closed: false,
              listeners: new Set(),
            };

            stream.on("data", (data: Buffer) => {
              session.lastActivityAt = Date.now();
              broadcast(session, { type: "output", data: data.toString("utf8") });
            });

            stream.stderr?.on("data", (data: Buffer) => {
              session.lastActivityAt = Date.now();
              broadcast(session, { type: "output", data: data.toString("utf8") });
            });

            stream.on("close", () => {
              closeSession(session, "Shell closed");
            });

            sessions.set(sessionId, session);
            settled = true;
            void logRemoteConnection({
              server: params.server,
              purpose: "COMMAND",
              outcome: "SUCCESS",
              userId: params.userId,
              durationMs: Date.now() - start,
            });
            resolve(session);
          },
        );
      })
      .on("error", (err) => fail(err))
      .connect(buildSshConnectConfig(params.server));
  }),
  );
}

export function getShellSession(sessionId: string): ShellSession | undefined {
  return shellGlobals().sessions.get(sessionId);
}

export function assertShellSessionAccess(
  session: ShellSession,
  serverId: string,
  userId: string,
): void {
  if (session.serverId !== serverId || session.ownerUserId !== userId) {
    throw new Error("Session not found");
  }
  if (session.closed) {
    throw new Error("Session closed");
  }
}

export function subscribeShellSession(
  session: ShellSession,
  listener: (event: ShellStreamEvent) => void,
): () => void {
  session.listeners.add(listener);
  return () => session.listeners.delete(listener);
}

export function writeShellInput(session: ShellSession, data: string) {
  if (session.closed) throw new Error("Session closed");
  session.lastActivityAt = Date.now();
  session.stream.write(data);
}

export function resizeShellSession(session: ShellSession, cols: number, rows: number) {
  session.lastActivityAt = Date.now();
  session.stream.setWindow(clampShellRows(rows), clampShellCols(cols), 0, 0);
}

export function destroyShellSession(sessionId: string) {
  const session = getShellSession(sessionId);
  if (session) closeSession(session, "Session closed");
}
