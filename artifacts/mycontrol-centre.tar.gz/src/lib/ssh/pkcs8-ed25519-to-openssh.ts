import { createHash, createPrivateKey, createPublicKey, randomBytes } from "crypto";
import { Ber } from "asn1";

const KEY_COMMENT = "mycontrol-centre";

/** Extract OpenSSH ed25519 public/private blobs from SPKI + PKCS#8 DER (ssh2-compatible). */
function ed25519DerToOpenSSHBlobs(pubDer: Buffer, privDer: Buffer) {
  let reader = new Ber.Reader(pubDer);
  reader.readSequence();
  reader.readSequence();
  if (reader.readOID() !== "1.3.101.112") {
    throw new Error("Expected Ed25519 public key");
  }
  let pubBin = reader.readString(Ber.BitString, true);
  {
    let i = 0;
    for (; i < pubBin.length && pubBin[i] === 0x00; i++);
    if (i > 0) pubBin = pubBin.slice(i);
  }

  reader = new Ber.Reader(privDer);
  reader.readSequence();
  if (reader.readInt() !== 0) throw new Error("Unsupported Ed25519 PKCS#8 version");
  reader.readSequence();
  if (reader.readOID() !== "1.3.101.112") {
    throw new Error("Expected Ed25519 private key");
  }
  reader = new Ber.Reader(reader.readString(Ber.OctetString, true));
  const privBin = reader.readString(Ber.OctetString, true);

  const keyName = Buffer.from("ssh-ed25519");
  const privBuf = Buffer.allocUnsafe(
    4 + keyName.length + 4 + pubBin.length + 4 + (privBin.length + pubBin.length),
  );
  let pos = 0;
  privBuf.writeUInt32BE(keyName.length, pos);
  pos += 4;
  privBuf.set(keyName, pos);
  pos += keyName.length;
  privBuf.writeUInt32BE(pubBin.length, pos);
  pos += 4;
  privBuf.set(pubBin, pos);
  pos += pubBin.length;
  privBuf.writeUInt32BE(privBin.length + pubBin.length, pos);
  pos += 4;
  privBuf.set(privBin, pos);
  pos += privBin.length;
  privBuf.set(pubBin, pos);

  const pubBuf = Buffer.allocUnsafe(4 + keyName.length + 4 + pubBin.length);
  pos = 0;
  pubBuf.writeUInt32BE(keyName.length, pos);
  pos += 4;
  pubBuf.set(keyName, pos);
  pos += keyName.length;
  pubBuf.writeUInt32BE(pubBin.length, pos);
  pos += 4;
  pubBuf.set(pubBin, pos);

  return { privBuf, pubBuf };
}

/** Wrap OpenSSH ed25519 blobs in openssh-key-v1 PEM (unencrypted). */
function wrapOpenSSHPrivateKey(privBuf: Buffer, pubBuf: Buffer, comment: string): string {
  const commentBin = Buffer.from(comment);
  const checkInt = randomBytes(4);
  const padding: number[] = [];
  const privBlobLen = 4 + 4 + privBuf.length + 4 + commentBin.length;
  for (let i = 1; (privBlobLen + padding.length) % 8; i++) {
    padding.push(i & 0xff);
  }
  const paddingBuf = Buffer.from(padding);
  const privBlob = Buffer.allocUnsafe(privBlobLen + paddingBuf.length);
  let pos = 0;
  privBlob.set(checkInt, pos);
  pos += 4;
  privBlob.set(checkInt, pos);
  pos += 4;
  privBlob.set(privBuf, pos);
  pos += privBuf.length;
  privBlob.writeUInt32BE(commentBin.length, pos);
  pos += 4;
  privBlob.set(commentBin, pos);
  pos += commentBin.length;
  privBlob.set(paddingBuf, pos);

  const cipherName = Buffer.from("none");
  const kdfName = Buffer.from("none");
  const kdfOptions = Buffer.alloc(0);
  const magicBytes = Buffer.from("openssh-key-v1\0");
  const privBin = Buffer.allocUnsafe(
    magicBytes.length +
      4 +
      cipherName.length +
      4 +
      kdfName.length +
      4 +
      kdfOptions.length +
      4 +
      4 +
      pubBuf.length +
      4 +
      privBlob.length,
  );
  pos = 0;
  privBin.set(magicBytes, pos);
  pos += magicBytes.length;
  privBin.writeUInt32BE(cipherName.length, pos);
  pos += 4;
  privBin.set(cipherName, pos);
  pos += cipherName.length;
  privBin.writeUInt32BE(kdfName.length, pos);
  pos += 4;
  privBin.set(kdfName, pos);
  pos += kdfName.length;
  privBin.writeUInt32BE(kdfOptions.length, pos);
  pos += 4;
  privBin.set(kdfOptions, pos);
  pos += kdfOptions.length;
  privBin.writeUInt32BE(1, pos);
  pos += 4;
  privBin.writeUInt32BE(pubBuf.length, pos);
  pos += 4;
  privBin.set(pubBuf, pos);
  pos += pubBuf.length;
  privBin.writeUInt32BE(privBlob.length, pos);
  pos += 4;
  privBin.set(privBlob, pos);

  const b64 = privBin.toString("base64");
  const formatted = b64.replace(/.{64}/g, "$&\n") + (b64.length & 63 ? "\n" : "\n");
  return (
    "-----BEGIN OPENSSH PRIVATE KEY-----\n" +
    formatted +
    "-----END OPENSSH PRIVATE KEY-----\n"
  );
}

/** Convert Node PKCS#8 Ed25519 PEM to OpenSSH private key PEM for ssh2. */
export function pkcs8Ed25519PemToOpenSSH(
  pem: string,
  comment = KEY_COMMENT,
): string | null {
  const trimmed = pem.trim();
  if (!trimmed.includes("BEGIN PRIVATE KEY")) return null;
  try {
    const keyObj = createPrivateKey(trimmed);
    const pubObj = createPublicKey(keyObj);
    const privDer = keyObj.export({ format: "der", type: "pkcs8" }) as Buffer;
    const pubDer = pubObj.export({ format: "der", type: "spki" }) as Buffer;
    const { privBuf, pubBuf } = ed25519DerToOpenSSHBlobs(pubDer, privDer);
    return wrapOpenSSHPrivateKey(privBuf, pubBuf, comment);
  } catch {
    return null;
  }
}

export function fingerprintFromOpenSSHPublicLine(line: string, comment = KEY_COMMENT): string {
  const b64 = line.trim().split(/\s+/)[1];
  if (!b64) throw new Error("Invalid OpenSSH public key line");
  const blob = Buffer.from(b64, "base64");
  const hash = createHash("sha256").update(blob).digest("base64").replace(/=+$/, "");
  return `256 SHA256:${hash} ${comment} (ED25519)`;
}
