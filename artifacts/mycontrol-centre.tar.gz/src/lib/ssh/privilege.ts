import { randomBytes } from "crypto";
import type { Server } from "@prisma/client";
import { decrypt } from "../crypto";
import { shellEscape } from "./client";

export function getServerSshPassword(server: Server): string | null {
  if (
    (server.authType === "PASSWORD" || server.authType === "KEY_AND_PASSWORD") &&
    server.encryptedPassword
  ) {
    return decrypt(server.encryptedPassword);
  }
  return null;
}

export function isRootSshUser(server: Server): boolean {
  return server.sshUser === "root";
}

export function dockerCliPrefix(server: Server): string {
  if (isRootSshUser(server)) return "docker";
  const password = getServerSshPassword(server);
  if (password) return `echo ${shellEscape(password)} | sudo -S docker`;
  return "sudo -n docker";
}

/**
 * Run a bash script on the remote host with root privileges when needed.
 * Non-interactive: uses sudo -S when an SSH password is stored, else sudo -n.
 */
export function buildRemoteScriptExecution(server: Server, script: string): string {
  const tmp = `/tmp/mcc-${randomBytes(6).toString("hex")}.sh`;
  const b64 = Buffer.from(script, "utf8").toString("base64");
  const write = `echo ${shellEscape(b64)} | base64 -d > ${shellEscape(tmp)} && chmod 700 ${shellEscape(tmp)}`;
  const cleanup = `rm -f ${shellEscape(tmp)}`;

  if (isRootSshUser(server)) {
    return `${write} && bash ${shellEscape(tmp)}; RC=$?; ${cleanup}; exit $RC`;
  }

  const password = getServerSshPassword(server);
  if (password) {
    return `${write} && echo ${shellEscape(password)} | sudo -S bash ${shellEscape(tmp)}; RC=$?; ${cleanup}; exit $RC`;
  }

  return `${write} && sudo -n bash ${shellEscape(tmp)}; RC=$?; ${cleanup}; exit $RC`;
}

const LEGACY_SCRIPT_PIPE =
  /^echo '((?:[^'\\]|\\.|'\\'')*)' \| base64 -d \| sudo(?: -n)? bash$/;

/** Plain `sudo` over SSH hangs without a TTY; automation users use NOPASSWD (`sudo -n`) or `-S` with stored password. */
export function applyNonInteractiveSudo(command: string): string {
  return command.replace(/\bsudo(?!\s+-[nS])\s+/g, "sudo -n ");
}

/**
 * Rewrite queued commands so sudo works without a TTY (docker installs, apt, etc.).
 */
export function adaptCommandForServer(server: Server, command: string): string {
  let cmd = command.trim();

  const legacyMatch = cmd.match(LEGACY_SCRIPT_PIPE);
  if (legacyMatch) {
    const encoded = legacyMatch[1].replace(/'\\''/g, "'");
    const script = Buffer.from(encoded, "base64").toString("utf8");
    return buildRemoteScriptExecution(server, script);
  }

  if (isRootSshUser(server)) {
    cmd = cmd.replace(/\bsudo\s+-n\s+/g, "");
    cmd = cmd.replace(/\bsudo\s+-S\s+/g, "");
    cmd = cmd.replace(/\bsudo\s+/g, "");
    return cmd;
  }

  const password = getServerSshPassword(server);
  if (password) {
    if (/\bsudo\s+-S\b/.test(cmd)) {
      return cmd;
    }

    if (/^sudo\s+/.test(cmd)) {
      const inner = cmd.replace(/^sudo\s+(-n\s+)?/, "");
      return `echo ${shellEscape(password)} | sudo -S ${inner}`;
    }

    if (cmd.includes(" && sudo ")) {
      return cmd.replace(/\s&&\s+sudo\s+(-n\s+)?/g, ` && echo ${shellEscape(password)} | sudo -S `);
    }

    return cmd;
  }

  return applyNonInteractiveSudo(cmd);
}
