import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "./auth/session";
import { logApiRequest } from "./connection-log";
import type { User } from "@prisma/client";

type ApiHandler = (
  req: NextRequest,
  context: { user: User; params?: Record<string, string> },
) => Promise<NextResponse>;

export type RouteContext = { params: Promise<Record<string, string>> };

type PublicHandlerFn = (
  req: NextRequest,
  context: RouteContext,
) => Promise<NextResponse>;

function recordApiRequest(
  req: NextRequest,
  response: NextResponse,
  startedAt: number,
  userId?: string | null,
) {
  void logApiRequest({ req, response, startedAt, userId }).catch((error) => {
    console.error("Failed to write API request log:", error);
  });
}

export function withApiLog(handler: PublicHandlerFn): PublicHandlerFn {
  return async (req, context) => {
    const startedAt = Date.now();
    let userId: string | null = null;
    try {
      userId = (await getSessionUser())?.id ?? null;
    } catch {
      userId = null;
    }

    const response = await handler(req, context);
    recordApiRequest(req, response, startedAt, userId);
    return response;
  };
}

export function withAuth(handler: ApiHandler, options?: { roles?: User["role"][] }) {
  return async (
    req: NextRequest,
    segmentData: { params: Promise<Record<string, string>> },
  ) => {
    const startedAt = Date.now();
    const user = await getSessionUser();
    if (!user) {
      const response = NextResponse.json({ error: "Unauthorized" }, { status: 401 });
      recordApiRequest(req, response, startedAt, null);
      return response;
    }

    if (options?.roles && !options.roles.includes(user.role)) {
      const response = NextResponse.json({ error: "Forbidden" }, { status: 403 });
      recordApiRequest(req, response, startedAt, user.id);
      return response;
    }

    const params = await segmentData.params;
    const response = await handler(req, { user, params });
    recordApiRequest(req, response, startedAt, user.id);
    return response;
  };
}

export function jsonError(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}
