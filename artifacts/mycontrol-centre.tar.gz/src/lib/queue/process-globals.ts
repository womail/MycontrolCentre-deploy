import type { RunStreamState } from "../commands/run-stream-state";
import type { ShellSession } from "../ssh/shell-sessions";

/** Process-wide timer handles and shared maps (survive Next.js HMR module reloads). */
export type MccProcessGlobals = {
  shellSessions?: { sessions: Map<string, ShellSession> };
  commandPollTimer?: ReturnType<typeof setInterval>;
  background?: {
    maintenance?: ReturnType<typeof setInterval>;
    commandQueue?: ReturnType<typeof setInterval>;
    schedule?: ReturnType<typeof setInterval>;
    updates?: ReturnType<typeof setInterval>;
    health?: ReturnType<typeof setInterval>;
    healthSchedulerStarted?: boolean;
  };
  runStreamSweep?: ReturnType<typeof setInterval>;
  runStreams?: Map<string, RunStreamState>;
};

export function getMccGlobals(): MccProcessGlobals {
  const root = globalThis as typeof globalThis & { __mcc?: MccProcessGlobals };
  if (!root.__mcc) root.__mcc = {};
  return root.__mcc;
}

export function clearMccInterval(timer: ReturnType<typeof setInterval> | undefined) {
  if (timer) clearInterval(timer);
}

export function stopAllMccTimers() {
  const g = getMccGlobals();
  clearMccInterval(g.commandPollTimer);
  g.commandPollTimer = undefined;
  if (g.background) {
    clearMccInterval(g.background.maintenance);
    clearMccInterval(g.background.commandQueue);
    clearMccInterval(g.background.schedule);
    clearMccInterval(g.background.updates);
    clearMccInterval(g.background.health);
  }
  g.background = undefined;
  clearMccInterval(g.runStreamSweep);
  g.runStreamSweep = undefined;
}
