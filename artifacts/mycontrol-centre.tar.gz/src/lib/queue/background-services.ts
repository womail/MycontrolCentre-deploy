import { getAlertSettings } from "../alerts/settings";
import { runScheduledHealthChecks } from "../health/check-server";
import { runDueProfileSchedules } from "../schedules/run-profile-schedules";
import { getActiveCommandRunCount } from "./active-ssh-runs";
import { purgeOldAuditLogs } from "../audit";
import { purgeOldConnectionLogs } from "../connection-log";
import { purgeIdleRunStreams } from "../commands/run-stream";
import { recoverStaleCommandRuns } from "./command-queue";
import { sweepIdleShellSessions } from "../ssh/shell-sessions";
import { runScheduledPackageUpdateChecks } from "../updates/sync-package-updates";
import { clearMccInterval, getMccGlobals } from "./process-globals";

let healthLoopRunning = false;
let scheduleLoopRunning = false;

async function runMaintenanceTasks() {
  const purged = await purgeOldAuditLogs();
  if (purged > 0) {
    console.log(`[background] Purged ${purged} old audit log entries`);
  }

  const connectionLogs = await purgeOldConnectionLogs();
  if (connectionLogs.remote > 0 || connectionLogs.api > 0) {
    console.log(
      `[background] Purged ${connectionLogs.remote} remote + ${connectionLogs.api} API connection log entries`,
    );
  }

  const purgedStreams = purgeIdleRunStreams();
  if (purgedStreams > 0) {
    console.log(`[background] Purged ${purgedStreams} idle run stream buffer(s)`);
  }

  const recovered = await recoverStaleCommandRuns();
  if (recovered > 0) {
    console.log(`[background] Recovered ${recovered} stale command run(s)`);
  }

  sweepIdleShellSessions();
}

async function runHealthChecks() {
  if (healthLoopRunning) return;
  healthLoopRunning = true;

  try {
    const settings = await getAlertSettings();
    if (!settings.healthCheckEnabled) return;

    if (getActiveCommandRunCount() > 0) {
      console.log("[background] Deferring scheduled health checks — command runs in progress");
      return;
    }

    const checked = await runScheduledHealthChecks();
    if (checked > 0) {
      console.log(`[background] Completed scheduled health checks for ${checked} servers`);
    }
  } catch (error) {
    console.error("[background] Scheduled health checks failed:", error);
  } finally {
    healthLoopRunning = false;
  }
}

async function runProfileSchedules() {
  if (scheduleLoopRunning) return;
  scheduleLoopRunning = true;

  try {
    const ran = await runDueProfileSchedules();
    if (ran > 0) {
      console.log(`[background] Completed ${ran} scheduled profile run(s)`);
    }
  } catch (error) {
    console.error("[background] Scheduled profile runs failed:", error);
  } finally {
    scheduleLoopRunning = false;
  }
}

function ensureBackgroundSlots() {
  const g = getMccGlobals();
  if (!g.background) g.background = {};
  return g.background;
}

export function startBackgroundServices() {
  const bg = ensureBackgroundSlots();

  if (!bg.maintenance) {
    void runMaintenanceTasks();
    bg.maintenance = setInterval(() => {
      void runMaintenanceTasks();
    }, 6 * 60 * 60 * 1000);
  }

  if (!bg.commandQueue) {
    void recoverStaleCommandRuns();
    bg.commandQueue = setInterval(() => {
      void recoverStaleCommandRuns();
    }, 90_000);
  }

  if (!bg.schedule) {
    void runProfileSchedules();
    bg.schedule = setInterval(() => {
      void runProfileSchedules();
    }, 60_000);
  }

  if (!bg.updates) {
    void runScheduledPackageUpdateChecks().then((n) => {
      if (n > 0) console.log(`[background] Checked package updates on ${n} servers`);
    });
    bg.updates = setInterval(() => {
      void runScheduledPackageUpdateChecks().then((n) => {
        if (n > 0) console.log(`[background] Checked package updates on ${n} servers`);
      });
    }, 6 * 60 * 60 * 1000);
  }

  if (!bg.healthSchedulerStarted) {
    bg.healthSchedulerStarted = true;
    void restartHealthScheduler();
  }
}

let healthSchedulerGeneration = 0;

export async function restartHealthScheduler() {
  const generation = ++healthSchedulerGeneration;
  const bg = ensureBackgroundSlots();
  clearMccInterval(bg.health);
  bg.health = undefined;

  const settings = await getAlertSettings();
  if (generation !== healthSchedulerGeneration) return;

  if (!settings.healthCheckEnabled) return;

  const intervalMs = settings.healthCheckIntervalMinutes * 60_000;
  void runHealthChecks();
  bg.health = setInterval(() => {
    void runHealthChecks();
  }, intervalMs);
}

export function stopBackgroundServices() {
  const g = getMccGlobals();
  if (!g.background) return;
  clearMccInterval(g.background.maintenance);
  clearMccInterval(g.background.commandQueue);
  clearMccInterval(g.background.schedule);
  clearMccInterval(g.background.updates);
  clearMccInterval(g.background.health);
  g.background = undefined;
  healthSchedulerGeneration += 1;
}
