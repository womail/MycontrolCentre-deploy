let activeCommandRuns = 0;

export function getActiveCommandRunCount(): number {
  return activeCommandRuns;
}

export function trackCommandRunStart(): void {
  activeCommandRuns += 1;
}

export function trackCommandRunEnd(): void {
  activeCommandRuns = Math.max(0, activeCommandRuns - 1);
}
