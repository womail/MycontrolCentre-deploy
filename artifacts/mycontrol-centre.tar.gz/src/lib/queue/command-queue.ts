import { prisma } from "../db";
import { execOnServer } from "../ssh/client";
import { adaptCommandForServer } from "../ssh/privilege";
import { getMaxConcurrentSsh } from "../settings";
import { buildCommandChain } from "../commands/builder";
import { getCommandTemplatesByIds } from "../commands/templates";
import { publishRunStreamEvent } from "../commands/run-stream";
import { appendCapped, MAX_CAPTURED_OUTPUT_CHARS } from "../memory/output-cap";
import { clearMccInterval, getMccGlobals } from "./process-globals";
import { startBackgroundServices } from "./background-services";
import { getActiveCommandRunCount, trackCommandRunEnd, trackCommandRunStart } from "./active-ssh-runs";

export interface CommandWorkerHandle {
  close: () => Promise<void>;
}

let draining = false;
let queueLoopRunning = false;

function parseFailureTemplateIds(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
}

async function queueFailureRemediation(run: {
  id: string;
  batchId: string | null;
  userId: string;
  serverId: string;
  failureTemplateIds: unknown;
  server: { id: string };
}): Promise<void> {
  const templateIds = parseFailureTemplateIds(run.failureTemplateIds);
  if (templateIds.length === 0) return;

  const templates = await getCommandTemplatesByIds(templateIds);
  const built = buildCommandChain(templates);

  const remediation = await prisma.commandRun.create({
    data: {
      batchId: run.batchId,
      userId: run.userId,
      serverId: run.serverId,
      commandType: "CUSTOM",
      label: `Remediation: ${built.label}`,
      commandText: built.commandText,
      workingDir: built.workingDir,
      status: "PENDING",
    },
  });

  enqueueCommandRun(remediation.id);
}

async function markRunFailed(
  runId: string,
  start: number,
  stderr: string,
  run: {
    id: string;
    batchId: string | null;
    userId: string;
    serverId: string;
    failureTemplateIds: unknown;
    server: { id: string };
  },
) {
  await prisma.commandRun.update({
    where: { id: runId },
    data: {
      status: "FAILED",
      exitCode: 1,
      stderr: stderr.slice(0, 500000),
      completedAt: new Date(),
      durationMs: Date.now() - start,
    },
  });
  await queueFailureRemediation(run);
}

/** Default SSH exec timeout in execOnServer (ms). */
export const SSH_EXEC_TIMEOUT_MS = 300_000;

async function recoverStaleRunningRuns(): Promise<number> {
  const staleMs = SSH_EXEC_TIMEOUT_MS + 60_000;
  const cutoff = new Date(Date.now() - staleMs);
  const result = await prisma.commandRun.updateMany({
    where: {
      status: "RUNNING",
      startedAt: { lt: cutoff },
    },
    data: {
      status: "FAILED",
      exitCode: 1,
      stderr: "Run interrupted (stale RUNNING — worker recovered after timeout or restart)",
      completedAt: new Date(),
    },
  });
  if (result.count > 0) {
    console.warn(`[command-queue] Recovered ${result.count} stale RUNNING command(s)`);
    void processQueue();
  }
  return result.count;
}

async function executeRun(runId: string): Promise<void> {
  const run = await prisma.commandRun.findUnique({
    where: { id: runId },
    include: { server: true },
  });

  if (!run || run.status === "CANCELLED") return;

  const start = Date.now();
  let stdout = "";
  let stderr = "";
  let flushTimer: ReturnType<typeof setInterval> | null = null;
  let lastFlushStdoutLen = 0;
  let lastFlushStderrLen = 0;

  publishRunStreamEvent(runId, { type: "status", status: "RUNNING" });

  async function flushOutput() {
    if (
      stdout.length === lastFlushStdoutLen &&
      stderr.length === lastFlushStderrLen
    ) {
      return;
    }
    lastFlushStdoutLen = stdout.length;
    lastFlushStderrLen = stderr.length;
    await prisma.commandRun.update({
      where: { id: runId },
      data: {
        stdout: stdout.slice(0, MAX_CAPTURED_OUTPUT_CHARS),
        stderr: stderr.slice(0, MAX_CAPTURED_OUTPUT_CHARS),
      },
    });
  }

  flushTimer = setInterval(() => {
    void flushOutput();
  }, 5000);

  try {
    const remoteCommand = adaptCommandForServer(run.server, run.commandText);
    const result = await execOnServer(run.server, remoteCommand, {
      log: {
        purpose: "COMMAND",
        userId: run.userId,
        commandRunId: run.id,
      },
      stream: {
        onStdout: (chunk) => {
          stdout = appendCapped(stdout, chunk);
          publishRunStreamEvent(runId, { type: "stdout", data: chunk });
        },
        onStderr: (chunk) => {
          stderr = appendCapped(stderr, chunk);
          publishRunStreamEvent(runId, { type: "stderr", data: chunk });
        },
      },
    });

    if (flushTimer) {
      clearInterval(flushTimer);
      flushTimer = null;
    }

    if (result.exitCode === 0) {
      await prisma.commandRun.update({
        where: { id: runId },
        data: {
          status: "SUCCESS",
          exitCode: result.exitCode,
          stdout: result.stdout.slice(0, 500000),
          stderr: result.stderr.slice(0, 500000),
          completedAt: new Date(),
          durationMs: result.durationMs ?? Date.now() - start,
        },
      });
      publishRunStreamEvent(runId, {
        type: "status",
        status: "SUCCESS",
        exitCode: result.exitCode,
        durationMs: result.durationMs ?? Date.now() - start,
      });
      return;
    }

    await prisma.commandRun.update({
      where: { id: runId },
      data: {
        status: "FAILED",
        exitCode: result.exitCode,
        stdout: result.stdout.slice(0, 500000),
        stderr: result.stderr.slice(0, 500000),
        completedAt: new Date(),
        durationMs: result.durationMs ?? Date.now() - start,
      },
    });
    publishRunStreamEvent(runId, {
      type: "status",
      status: "FAILED",
      exitCode: result.exitCode,
      durationMs: result.durationMs ?? Date.now() - start,
    });
    await queueFailureRemediation(run);
  } catch (error) {
    if (flushTimer) {
      clearInterval(flushTimer);
      flushTimer = null;
    }
    const message = error instanceof Error ? error.message : "Unknown error";
    stderr += stderr ? `\n${message}` : message;
    publishRunStreamEvent(runId, { type: "stderr", data: message });
    publishRunStreamEvent(runId, {
      type: "status",
      status: "FAILED",
      exitCode: 1,
      durationMs: Date.now() - start,
    });
    await markRunFailed(runId, start, message, run);
  }
}

async function claimNextRun(): Promise<string | null> {
  const pending = await prisma.commandRun.findFirst({
    where: { status: "PENDING" },
    orderBy: { createdAt: "asc" },
    select: { id: true },
  });

  if (!pending) return null;

  const claimed = await prisma.commandRun.updateMany({
    where: { id: pending.id, status: "PENDING" },
    data: { status: "RUNNING", startedAt: new Date() },
  });

  return claimed.count === 1 ? pending.id : null;
}

async function processQueue(): Promise<void> {
  if (queueLoopRunning || draining) return;
  queueLoopRunning = true;

  try {
    const maxConcurrent = await getMaxConcurrentSsh();

    while (getActiveCommandRunCount() < maxConcurrent) {
      const runId = await claimNextRun();
      if (!runId) break;

      trackCommandRunStart();
      executeRun(runId)
        .catch((error) => {
          console.error(`Command run ${runId} failed:`, error);
        })
        .finally(() => {
          trackCommandRunEnd();
          void processQueue();
        });
    }
  } finally {
    queueLoopRunning = false;
  }
}

export function enqueueCommandRun(runId: string): void {
  void runId;
  ensureEmbeddedWorker();
  void processQueue();
}

/** Mark long-stuck RUNNING rows failed so the queue can progress (also called from background maintenance). */
export async function recoverStaleCommandRuns(): Promise<number> {
  return recoverStaleRunningRuns();
}

export function startCommandWorker(): CommandWorkerHandle {
  const g = getMccGlobals();
  void recoverStaleRunningRuns().then(() => void processQueue());

  if (!g.commandPollTimer) {
    g.commandPollTimer = setInterval(() => {
      void processQueue();
    }, 2000);
  }

  void processQueue();

  return {
    close: async () => {
      draining = true;
      clearMccInterval(g.commandPollTimer);
      g.commandPollTimer = undefined;
      while (getActiveCommandRunCount() > 0) {
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
    },
  };
}

/** Start embedded worker (timers on globalThis to avoid HMR duplicate intervals). */
export function ensureEmbeddedWorker(): void {
  if (process.env.RUN_EMBEDDED_WORKER !== "true") return;
  startCommandWorker();
  startBackgroundServices();
}
