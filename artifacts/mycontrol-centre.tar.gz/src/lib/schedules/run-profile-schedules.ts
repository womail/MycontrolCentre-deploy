import { prisma } from "../db";
import { runSavedProfile } from "../commands/run-profile";
import { resolveProfileServerIds } from "../servers/groups";

function parseStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
}

export function isProfileScheduleDue(
  schedule: {
    enabled: boolean;
    dayOfWeek: number;
    hourUtc: number;
    minuteUtc: number;
    lastRunAt: Date | null;
  },
  now: Date,
): boolean {
  if (!schedule.enabled) return false;

  const day = now.getUTCDay();
  const hour = now.getUTCHours();
  const minute = now.getUTCMinutes();

  if (day !== schedule.dayOfWeek || hour !== schedule.hourUtc || minute !== schedule.minuteUtc) {
    return false;
  }

  if (schedule.lastRunAt) {
    const last = schedule.lastRunAt;
    if (
      last.getUTCFullYear() === now.getUTCFullYear() &&
      last.getUTCMonth() === now.getUTCMonth() &&
      last.getUTCDate() === now.getUTCDate() &&
      last.getUTCHours() === hour &&
      last.getUTCMinutes() === minute
    ) {
      return false;
    }
  }

  return true;
}

export async function runDueProfileSchedules(): Promise<number> {
  const schedules = await prisma.profileSchedule.findMany({
    where: { enabled: true },
    include: {
      profile: {
        include: {
          createdBy: { select: { id: true, role: true, isActive: true } },
        },
      },
    },
  });

  const now = new Date();
  let ran = 0;

  for (const schedule of schedules) {
    if (!isProfileScheduleDue(schedule, now)) continue;

    const creator = schedule.profile.createdBy;
    if (!creator.isActive || (creator.role !== "ADMIN" && creator.role !== "OPERATOR")) {
      console.warn(
        `[scheduler] Skipping profile "${schedule.profile.name}": creator not eligible`,
      );
      continue;
    }

    const serverIds = await resolveProfileServerIds(schedule.profile);
    const templateIds = parseStringArray(schedule.profile.templateIds);
    if (serverIds.length === 0 || templateIds.length === 0) {
      console.warn(`[scheduler] Skipping profile "${schedule.profile.name}": empty selection`);
      continue;
    }

    try {
      const result = await runSavedProfile({
        profile: schedule.profile,
        user: { id: creator.id, role: creator.role },
        changeReason: schedule.changeReason ?? undefined,
        triggeredBy: "scheduled",
      });

      await prisma.profileSchedule.update({
        where: { id: schedule.id },
        data: { lastRunAt: now, lastBatchId: result.batchId },
      });

      console.log(
        `[scheduler] Ran profile "${schedule.profile.name}" (${result.runs.length} servers, batch ${result.batchId})`,
      );
      ran += 1;
    } catch (error) {
      console.error(
        `[scheduler] Failed to run profile "${schedule.profile.name}":`,
        error instanceof Error ? error.message : error,
      );
    }
  }

  return ran;
}
