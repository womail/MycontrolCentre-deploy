import type { HealthStatus, Server } from "@prisma/client";
import { prisma } from "../db";
import { logAudit } from "../audit";
import { evaluateHealthAlert } from "../alerts/evaluate";
import { isServerInMaintenance } from "../servers/maintenance";
import { detectServerPlatforms } from "../servers/platform-detect";
import { detectServerOs } from "../servers/os-detect";
import { syncServerBackupStatus, serverNeedsBackupProbe } from "../backup/sync-server-backup";
import { testConnection } from "../ssh/client";

export interface HealthCheckResult {
  online: boolean;
  stdout: string;
  stderr: string;
  exitCode: number | null;
  error?: string;
  previousStatus: HealthStatus;
  newStatus: HealthStatus;
  pendingPackageUpdates?: number | null;
}

export async function runServerHealthCheck(input: {
  server: Server;
  userId?: string | null;
  triggeredBy: "manual" | "scheduled";
  ipAddress?: string | null;
}): Promise<HealthCheckResult> {
  const previousStatus = input.server.healthStatus;

  if (
    input.server.inMaintenance &&
    input.server.maintenanceUntil &&
    input.server.maintenanceUntil < new Date()
  ) {
    await prisma.server.update({
      where: { id: input.server.id },
      data: {
        inMaintenance: false,
        maintenanceNote: null,
        maintenanceUntil: null,
      },
    });
    input.server = { ...input.server, inMaintenance: false };
  }

  try {
    const result = await testConnection(input.server, {
      userId: input.userId ?? undefined,
    });
    const online = result.exitCode === 0;
    const newStatus: HealthStatus = online ? "ONLINE" : "OFFLINE";

    await prisma.server.update({
      where: { id: input.server.id },
      data: {
        healthStatus: newStatus,
        lastHealthCheck: new Date(),
        healthMessage: online
          ? result.stdout.trim().slice(0, 500)
          : result.stderr.trim().slice(0, 500) || "Health check failed",
      },
    });

    const detectedPlatforms =
      online ? await detectServerPlatforms(input.server) : [];
    const detectedOs = online ? await detectServerOs(input.server) : null;

    const platformUpdate =
      detectedPlatforms.length > 0 ? { detectedPlatforms } : {};
    const osUpdate = detectedOs
      ? {
          detectedOsId: detectedOs.id,
          detectedOsLabel: detectedOs.label,
          detectedOsFamily: detectedOs.family,
          osDetectedAt: new Date(),
        }
      : {};

    if (detectedPlatforms.length > 0 || detectedOs) {
      await prisma.server.update({
        where: { id: input.server.id },
        data: { ...platformUpdate, ...osUpdate },
      });
    }

    if (detectedPlatforms.length > 0) {
      input.server = { ...input.server, detectedPlatforms };
    }
    if (detectedOs) {
      input.server = {
        ...input.server,
        detectedOsId: detectedOs.id,
        detectedOsLabel: detectedOs.label,
        detectedOsFamily: detectedOs.family,
      };
    }

    if (online && serverNeedsBackupProbe(input.server)) {
      await syncServerBackupStatus(input.server);
    }

    let pendingPackageUpdates: number | null | undefined;
    if (online) {
      const { syncServerPackageUpdates, serverSupportsPackageUpdates } = await import(
        "../updates/sync-package-updates"
      );
      const fresh = await prisma.server.findUnique({ where: { id: input.server.id } });
      const forUpdates = fresh ?? input.server;
      if (serverSupportsPackageUpdates(forUpdates)) {
        pendingPackageUpdates = await syncServerPackageUpdates(forUpdates);
      }
    }

    if (input.triggeredBy === "manual" && input.userId) {
      await logAudit({
        userId: input.userId,
        action: "SERVER_HEALTH_CHECK",
        resourceType: "server",
        resourceId: input.server.id,
        details: { online, exitCode: result.exitCode, triggeredBy: input.triggeredBy },
        ipAddress: input.ipAddress ?? undefined,
      });
    }

    await evaluateHealthAlert({
      server: {
        id: input.server.id,
        name: input.server.name,
        hostname: input.server.hostname,
        healthStatus: newStatus,
        inMaintenance: input.server.inMaintenance,
        maintenanceUntil: input.server.maintenanceUntil,
        healthMessage: online
          ? result.stdout.trim().slice(0, 500)
          : result.stderr.trim().slice(0, 500),
      },
      previousStatus,
      newStatus,
      triggeredBy: input.triggeredBy,
    });

    return {
      online,
      stdout: result.stdout,
      stderr: result.stderr,
      exitCode: result.exitCode,
      previousStatus,
      newStatus,
      pendingPackageUpdates,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Health check failed";
    const newStatus: HealthStatus = "OFFLINE";

    await prisma.server.update({
      where: { id: input.server.id },
      data: {
        healthStatus: newStatus,
        lastHealthCheck: new Date(),
        healthMessage: message.slice(0, 500),
      },
    });

    if (input.triggeredBy === "manual" && input.userId) {
      await logAudit({
        userId: input.userId,
        action: "SERVER_HEALTH_CHECK",
        resourceType: "server",
        resourceId: input.server.id,
        details: { online: false, error: message, triggeredBy: input.triggeredBy },
        ipAddress: input.ipAddress ?? undefined,
      });
    }

    await evaluateHealthAlert({
      server: {
        id: input.server.id,
        name: input.server.name,
        hostname: input.server.hostname,
        healthStatus: newStatus,
        inMaintenance: input.server.inMaintenance,
        maintenanceUntil: input.server.maintenanceUntil,
        healthMessage: message.slice(0, 500),
      },
      previousStatus,
      newStatus,
      triggeredBy: input.triggeredBy,
    });

    return {
      online: false,
      stdout: "",
      stderr: message,
      exitCode: null,
      error: message,
      previousStatus,
      newStatus,
    };
  }
}

export async function runScheduledHealthChecks(): Promise<number> {
  const servers = await prisma.server.findMany({
    where: { isActive: true },
    orderBy: { name: "asc" },
  });

  let checked = 0;
  for (const server of servers) {
    if (isServerInMaintenance(server)) {
      continue;
    }
    await runServerHealthCheck({
      server,
      triggeredBy: "scheduled",
    });
    checked += 1;
  }

  return checked;
}
