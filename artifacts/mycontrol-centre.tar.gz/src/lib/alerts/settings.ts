import { randomUUID } from "crypto";
import { getSetting, setSetting } from "../settings";

export type AlertChannelType = "webhook" | "ntfy" | "gotify";

export interface AlertChannel {
  id: string;
  type: AlertChannelType;
  enabled: boolean;
  url?: string;
  topic?: string;
  token?: string;
}

export interface AlertSettings {
  enabled: boolean;
  healthCheckEnabled: boolean;
  healthCheckIntervalMinutes: number;
  alertOnRecovery: boolean;
  alertCooldownMinutes: number;
  skipAlertsInMaintenance: boolean;
  channels: AlertChannel[];
}

export const DEFAULT_ALERT_SETTINGS: AlertSettings = {
  enabled: false,
  healthCheckEnabled: true,
  healthCheckIntervalMinutes: 5,
  alertOnRecovery: true,
  alertCooldownMinutes: 30,
  skipAlertsInMaintenance: true,
  channels: [],
};

const SETTINGS_KEY = "alert_settings";

export function normalizeAlertSettings(raw: unknown): AlertSettings {
  if (!raw || typeof raw !== "object") return { ...DEFAULT_ALERT_SETTINGS };

  const input = raw as Partial<AlertSettings>;
  const channels = Array.isArray(input.channels)
    ? input.channels
        .filter((channel) => channel && typeof channel === "object")
        .map((channel) => {
          const entry = channel as Partial<AlertChannel>;
          return {
            id: typeof entry.id === "string" ? entry.id : randomUUID(),
            type:
              entry.type === "ntfy" || entry.type === "gotify" || entry.type === "webhook"
                ? entry.type
                : "webhook",
            enabled: entry.enabled !== false,
            url: typeof entry.url === "string" ? entry.url : undefined,
            topic: typeof entry.topic === "string" ? entry.topic : undefined,
            token: typeof entry.token === "string" ? entry.token : undefined,
          } satisfies AlertChannel;
        })
    : [];

  const interval = Number(input.healthCheckIntervalMinutes);
  const cooldown = Number(input.alertCooldownMinutes);

  return {
    enabled: Boolean(input.enabled),
    healthCheckEnabled: input.healthCheckEnabled !== false,
    healthCheckIntervalMinutes:
      Number.isFinite(interval) && interval >= 1 && interval <= 1440 ? interval : 5,
    alertOnRecovery: input.alertOnRecovery !== false,
    alertCooldownMinutes:
      Number.isFinite(cooldown) && cooldown >= 5 && cooldown <= 1440 ? cooldown : 30,
    skipAlertsInMaintenance: input.skipAlertsInMaintenance !== false,
    channels,
  };
}

export async function getAlertSettings(): Promise<AlertSettings> {
  const raw = await getSetting(SETTINGS_KEY, "");
  if (!raw) return { ...DEFAULT_ALERT_SETTINGS };
  try {
    return normalizeAlertSettings(JSON.parse(raw));
  } catch {
    return { ...DEFAULT_ALERT_SETTINGS };
  }
}

export async function setAlertSettings(settings: AlertSettings): Promise<void> {
  await setSetting(SETTINGS_KEY, JSON.stringify(normalizeAlertSettings(settings)));
}

export function sanitizeAlertSettingsForClient(
  settings: AlertSettings,
): AlertSettings {
  return {
    ...settings,
    channels: settings.channels.map((channel) => ({
      ...channel,
      token: channel.token ? "********" : undefined,
    })),
  };
}

export function mergeAlertSettingsUpdate(
  current: AlertSettings,
  update: Partial<AlertSettings> & {
    channels?: Array<Partial<AlertChannel> & { id?: string; token?: string }>;
  },
): AlertSettings {
  const next = normalizeAlertSettings({ ...current, ...update });

  if (update.channels) {
    next.channels = update.channels.map((channel) => {
      const existing = channel.id
        ? current.channels.find((entry) => entry.id === channel.id)
        : undefined;
      const token =
        channel.token === "********"
          ? existing?.token
          : channel.token?.trim()
            ? channel.token.trim()
            : existing?.token;

      return normalizeAlertSettings({
        channels: [
          {
            id: channel.id ?? existing?.id ?? randomUUID(),
            type: channel.type ?? existing?.type ?? "webhook",
            enabled: channel.enabled ?? existing?.enabled ?? true,
            url: channel.url ?? existing?.url,
            topic: channel.topic ?? existing?.topic,
            token,
          },
        ],
      }).channels[0];
    });

    if (next.channels.length === 0 && update.channels.length === 0) {
      next.channels = [];
    }
  }

  return normalizeAlertSettings(next);
}
