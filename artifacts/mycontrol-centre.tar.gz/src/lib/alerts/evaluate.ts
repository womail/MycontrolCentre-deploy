import type { HealthStatus, Server } from "@prisma/client";
import { prisma } from "../db";
import { isServerInMaintenance } from "../servers/maintenance";
import { dispatchAlert, type AlertPayload } from "./dispatch";
import { getAlertSettings } from "./settings";

function cooldownElapsed(since: Date | null | undefined, minutes: number, now: Date) {
  if (!since) return true;
  return now.getTime() - since.getTime() >= minutes * 60_000;
}

function buildPayload(
  event: AlertPayload["event"],
  server: Pick<Server, "name" | "hostname">,
  message: string,
): AlertPayload {
  const severity = event === "server_offline" ? "critical" : "info";
  const title =
    event === "server_offline"
      ? `Server offline: ${server.name}`
      : event === "server_online"
        ? `Server recovered: ${server.name}`
        : "MyControl Centre test alert";

  return {
    title,
    message,
    severity,
    serverName: server.name,
    hostname: server.hostname,
    event,
  };
}

export async function evaluateHealthAlert(input: {
  server: Pick<
    Server,
    "id" | "name" | "hostname" | "healthStatus" | "inMaintenance" | "maintenanceUntil" | "healthMessage"
  >;
  previousStatus: HealthStatus;
  newStatus: HealthStatus;
  triggeredBy: "manual" | "scheduled";
}) {
  const settings = await getAlertSettings();
  if (!settings.enabled) return;

  const inMaintenance = isServerInMaintenance(input.server);
  if (settings.skipAlertsInMaintenance && inMaintenance) return;

  const now = new Date();
  const state = await prisma.serverAlertState.upsert({
    where: { serverId: input.server.id },
    create: { serverId: input.server.id },
    update: {},
  });

  const wentOffline =
    input.newStatus !== "ONLINE" &&
    (input.previousStatus === "ONLINE" ||
      (input.triggeredBy === "scheduled" && input.previousStatus === "UNKNOWN"));
  const wentOnline =
    input.previousStatus !== "ONLINE" &&
    input.newStatus === "ONLINE" &&
    input.previousStatus !== "UNKNOWN";

  if (wentOffline) {
    if (!cooldownElapsed(state.lastOfflineAlertAt, settings.alertCooldownMinutes, now)) {
      return;
    }

    const detail = input.server.healthMessage
      ? `${input.server.name} (${input.server.hostname}) is offline. ${input.server.healthMessage}`
      : `${input.server.name} (${input.server.hostname}) is offline.`;

    await dispatchAlert(
      settings,
      buildPayload("server_offline", input.server, detail.slice(0, 1000)),
    );

    await prisma.serverAlertState.update({
      where: { serverId: input.server.id },
      data: { lastOfflineAlertAt: now },
    });
    return;
  }

  if (wentOnline && settings.alertOnRecovery) {
    if (!cooldownElapsed(state.lastOnlineAlertAt, settings.alertCooldownMinutes, now)) {
      return;
    }

    await dispatchAlert(
      settings,
      buildPayload(
        "server_online",
        input.server,
        `${input.server.name} (${input.server.hostname}) is back online.`,
      ),
    );

    await prisma.serverAlertState.update({
      where: { serverId: input.server.id },
      data: { lastOnlineAlertAt: now },
    });
  }
}
