import type { AlertChannel, AlertSettings } from "./settings";

export interface AlertPayload {
  title: string;
  message: string;
  severity: "info" | "warning" | "critical";
  serverName?: string;
  hostname?: string;
  event: "server_offline" | "server_online" | "test";
}

export interface AlertDispatchResult {
  channelId: string;
  type: AlertChannel["type"];
  ok: boolean;
  error?: string;
}

function severityPriority(severity: AlertPayload["severity"]): number {
  if (severity === "critical") return 5;
  if (severity === "warning") return 3;
  return 1;
}

async function postJson(url: string, body: unknown, headers: Record<string, string> = {}) {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...headers,
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(`HTTP ${response.status}${text ? `: ${text.slice(0, 200)}` : ""}`);
  }
}

async function dispatchWebhook(channel: AlertChannel, payload: AlertPayload) {
  if (!channel.url) throw new Error("Webhook URL is required");
  await postJson(channel.url, {
    source: "mycontrol-centre",
    ...payload,
    timestamp: new Date().toISOString(),
  });
}

async function dispatchNtfy(channel: AlertChannel, payload: AlertPayload) {
  const base = (channel.url ?? "https://ntfy.sh").replace(/\/$/, "");
  const topic = channel.topic?.trim();
  if (!topic) throw new Error("ntfy topic is required");

  const headers: Record<string, string> = {
    Title: payload.title,
    Tags: payload.severity === "critical" ? "warning,red_circle" : "white_check_mark",
    Priority: String(severityPriority(payload.severity)),
  };
  if (channel.token) headers.Authorization = `Bearer ${channel.token}`;

  const response = await fetch(`${base}/${encodeURIComponent(topic)}`, {
    method: "POST",
    headers,
    body: payload.message,
  });

  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(`HTTP ${response.status}${text ? `: ${text.slice(0, 200)}` : ""}`);
  }
}

async function dispatchGotify(channel: AlertChannel, payload: AlertPayload) {
  const base = channel.url?.replace(/\/$/, "");
  const token = channel.token?.trim();
  if (!base) throw new Error("Gotify server URL is required");
  if (!token) throw new Error("Gotify app token is required");

  await postJson(`${base}/message?token=${encodeURIComponent(token)}`, {
    title: payload.title,
    message: payload.message,
    priority: severityPriority(payload.severity),
  });
}

export async function dispatchAlert(
  settings: AlertSettings,
  payload: AlertPayload,
): Promise<AlertDispatchResult[]> {
  if (!settings.enabled) return [];

  const channels = settings.channels.filter((channel) => channel.enabled);
  const results: AlertDispatchResult[] = [];

  for (const channel of channels) {
    try {
      if (channel.type === "webhook") await dispatchWebhook(channel, payload);
      else if (channel.type === "ntfy") await dispatchNtfy(channel, payload);
      else if (channel.type === "gotify") await dispatchGotify(channel, payload);
      results.push({ channelId: channel.id, type: channel.type, ok: true });
    } catch (error) {
      results.push({
        channelId: channel.id,
        type: channel.type,
        ok: false,
        error: error instanceof Error ? error.message : "Dispatch failed",
      });
    }
  }

  return results;
}
