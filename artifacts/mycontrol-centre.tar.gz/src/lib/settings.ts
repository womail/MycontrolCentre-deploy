import { prisma } from "./db";

export async function getSetting(key: string, fallback: string): Promise<string> {
  const setting = await prisma.appSetting.findUnique({ where: { key } });
  return setting?.value ?? fallback;
}

export async function setSetting(key: string, value: string): Promise<void> {
  await prisma.appSetting.upsert({
    where: { key },
    create: { key, value },
    update: { value },
  });
}

export async function getMaxConcurrentSsh(): Promise<number> {
  const value = await getSetting(
    "max_concurrent_ssh",
    process.env.MAX_CONCURRENT_SSH ?? "5",
  );
  const parsed = parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 5;
}
