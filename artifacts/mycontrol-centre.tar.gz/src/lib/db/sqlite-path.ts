import { join } from "path";

export function resolveSqliteFilePath(): string {
  const url = process.env.DATABASE_URL ?? "file:../.data/mycontrol.db";
  const raw = url.replace(/^file:/, "").trim();
  if (raw.startsWith("/")) return raw;
  return join(process.cwd(), raw);
}
