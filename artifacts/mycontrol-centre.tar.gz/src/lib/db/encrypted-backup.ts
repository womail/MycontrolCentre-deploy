import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from "crypto";
import { encrypt, decrypt } from "../crypto";
import { getSetting, setSetting } from "../settings";

const SETTINGS_KEY = "backup_encryption_password";

export async function getStoredBackupPassword(): Promise<string | null> {
  const raw = await getSetting(SETTINGS_KEY, "");
  if (!raw.trim()) return null;
  try {
    return decrypt(raw);
  } catch {
    return null;
  }
}

export async function setStoredBackupPassword(password: string): Promise<void> {
  await setSetting(SETTINGS_KEY, encrypt(password));
}

export async function clearStoredBackupPassword(): Promise<void> {
  await setSetting(SETTINGS_KEY, "");
}

const MAGIC = Buffer.from("MCCBKP1\0");
const ALGORITHM = "aes-256-gcm";

function deriveKey(password: string, salt: Buffer): Buffer {
  return scryptSync(password, salt, 32);
}

export function encryptDatabaseBytes(plaintext: Buffer, password: string): Buffer {
  const salt = randomBytes(16);
  const key = deriveKey(password, salt);
  const iv = randomBytes(12);
  const cipher = createCipheriv(ALGORITHM, key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([MAGIC, salt, iv, tag, encrypted]);
}

export function decryptDatabaseBytes(payload: Buffer, password: string): Buffer {
  if (payload.length < MAGIC.length + 16 + 12 + 16 + 1) {
    throw new Error("Backup file is too small or corrupt");
  }
  if (!payload.subarray(0, MAGIC.length).equals(MAGIC)) {
    throw new Error("Not a MyControl Centre encrypted backup");
  }
  let offset = MAGIC.length;
  const salt = payload.subarray(offset, offset + 16);
  offset += 16;
  const iv = payload.subarray(offset, offset + 12);
  offset += 12;
  const tag = payload.subarray(offset, offset + 16);
  offset += 16;
  const encrypted = payload.subarray(offset);
  const key = deriveKey(password, salt);
  const decipher = createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(encrypted), decipher.final()]);
}
