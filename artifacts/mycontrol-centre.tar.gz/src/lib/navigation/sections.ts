export const SERVER_SECTIONS = ["fleet", "setup", "groups", "approvals"] as const;
export type ServerSection = (typeof SERVER_SECTIONS)[number];

export function parseServerSection(section: string[] | undefined): ServerSection {
  if (!section || section.length === 0) return "fleet";
  if (section.length === 1 && SERVER_SECTIONS.includes(section[0] as ServerSection)) {
    return section[0] as ServerSection;
  }
  return "fleet";
}

export function isValidServerSectionPath(section: string[] | undefined): boolean {
  if (!section || section.length === 0) return true;
  return section.length === 1 && SERVER_SECTIONS.includes(section[0] as ServerSection);
}

export function serverSectionHref(section: ServerSection): string {
  return section === "fleet" ? "/servers" : `/servers/${section}`;
}

export const LOG_SECTIONS = ["audit", "remote", "api"] as const;
export type LogSection = (typeof LOG_SECTIONS)[number];

export function parseLogSection(section: string[] | undefined): LogSection {
  if (!section || section.length === 0) return "audit";
  if (section.length === 1 && LOG_SECTIONS.includes(section[0] as LogSection)) {
    return section[0] as LogSection;
  }
  return "audit";
}

export function isValidLogSectionPath(section: string[] | undefined): boolean {
  if (!section || section.length === 0) return true;
  return section.length === 1 && LOG_SECTIONS.includes(section[0] as LogSection);
}

export function logSectionHref(section: LogSection): string {
  return section === "audit" ? "/logs" : `/logs/${section}`;
}

export const COMMAND_SECTIONS = ["run", "docker", "profiles", "batches", "manage"] as const;
export type CommandSection = (typeof COMMAND_SECTIONS)[number];

export function parseCommandSection(section: string[] | undefined): CommandSection {
  if (!section || section.length === 0) return "run";
  if (section.length === 1 && COMMAND_SECTIONS.includes(section[0] as CommandSection)) {
    return section[0] as CommandSection;
  }
  return "run";
}

export function isValidCommandSectionPath(section: string[] | undefined): boolean {
  if (!section || section.length === 0) return true;
  return section.length === 1 && COMMAND_SECTIONS.includes(section[0] as CommandSection);
}

export function commandSectionHref(section: CommandSection): string {
  return section === "run" ? "/commands" : `/commands/${section}`;
}

/** Next.js `useParams().section` for `[[...section]]` routes */
export function sectionPartsFromParams(
  section: string | string[] | undefined,
): string[] | undefined {
  if (section == null) return undefined;
  return Array.isArray(section) ? section : [section];
}
