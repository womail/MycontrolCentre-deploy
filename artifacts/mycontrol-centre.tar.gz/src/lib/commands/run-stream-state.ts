export type RunStreamEvent =
  | { type: "stdout"; data: string }
  | { type: "stderr"; data: string }
  | {
      type: "status";
      status: "RUNNING" | "SUCCESS" | "FAILED" | "CANCELLED";
      exitCode?: number | null;
      durationMs?: number | null;
    };

export type RunStreamListener = (event: RunStreamEvent) => void;

export interface RunStreamState {
  events: RunStreamEvent[];
  listeners: Set<RunStreamListener>;
  cleanupTimer: ReturnType<typeof setTimeout> | null;
  lastActivityAt: number;
  bufferedChars: number;
}
