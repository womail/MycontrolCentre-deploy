import { randomUUID } from "crypto";
import type { SavedRunProfile, User, UserRole } from "@prisma/client";
import { prisma } from "../db";
import { logAudit } from "../audit";
import { buildExecutionPlan } from "./plan-execution";
import { validateChangeReason } from "./change-reason";
import { enqueueCommandRun, ensureEmbeddedWorker } from "../queue/command-queue";
import { parseStringArray, resolveProfileServerIds } from "../servers/groups";

export interface RunProfileOptions {
  profile: SavedRunProfile;
  user: Pick<User, "id" | "role">;
  changeReason?: string;
  forceMaintenance?: boolean;
  forceStaleBackup?: boolean;
  triggeredBy?: "manual" | "scheduled";
  ipAddress?: string;
}

export interface RunProfileResult {
  batchId: string;
  runs: Array<{ id: string; serverId: string; serverName: string }>;
  label: string;
  blockedServers: Array<{ serverName: string; blockReason?: string; backupWarning?: string }>;
}

export async function runSavedProfile(options: RunProfileOptions): Promise<RunProfileResult> {
  const {
    profile,
    user,
    changeReason,
    forceMaintenance = false,
    forceStaleBackup = false,
    triggeredBy = "manual",
    ipAddress,
  } = options;

  ensureEmbeddedWorker();

  const serverIds = await resolveProfileServerIds(profile);
  const templateIds = parseStringArray(profile.templateIds);
  const failureTemplateIds = parseStringArray(profile.failureTemplateIds);

  if (serverIds.length === 0) {
    throw new Error("No active servers in selection or group");
  }

  const servers = await prisma.server.findMany({
    where: { id: { in: serverIds }, isActive: true },
    select: {
      id: true,
      name: true,
      hostname: true,
      inMaintenance: true,
      maintenanceNote: true,
      maintenanceUntil: true,
      isActive: true,
      manualPlatforms: true,
      detectedPlatforms: true,
      lastBackupAt: true,
      lastBackupSource: true,
    },
  });

  const plan = await buildExecutionPlan(
    {
      serverIds,
      templateIds,
      workingDir: profile.workingDir ?? undefined,
      listPath: profile.listPath ?? undefined,
      customCommand: profile.customCommand ?? undefined,
      failureTemplateIds,
      role: user.role as UserRole,
      forceMaintenance,
      forceStaleBackup,
    },
    servers,
  );

  if (plan.runnableServerIds.length === 0) {
    throw new Error("All selected servers are blocked by maintenance or backup checks");
  }

  const changeReasonError = validateChangeReason(
    changeReason,
    plan.runnableServerIds.length,
    templateIds.length,
  );
  if (changeReasonError) {
    throw new Error(changeReasonError);
  }

  const normalizedChangeReason =
    changeReason?.trim() ||
    (triggeredBy === "scheduled" ? `Scheduled run: ${profile.name}` : null);

  const batchId = randomUUID();
  const runs: RunProfileResult["runs"] = [];

  for (const serverId of plan.runnableServerIds) {
    const server = servers.find((entry) => entry.id === serverId)!;
    const run = await prisma.commandRun.create({
      data: {
        batchId,
        userId: user.id,
        serverId: server.id,
        templateId: plan.templates.length === 1 ? plan.templates[0].id : null,
        commandType: plan.templates.length === 1 ? plan.templates[0].type : "CUSTOM",
        label: plan.built.label,
        commandText: plan.built.commandText,
        workingDir: plan.built.workingDir,
        failureTemplateIds: plan.failureTemplateIds,
        changeReason: normalizedChangeReason,
        status: "PENDING",
      },
    });
    enqueueCommandRun(run.id);
    runs.push({ id: run.id, serverId: server.id, serverName: server.name });
  }

  await logAudit({
    userId: user.id,
    action: "COMMAND_BATCH_STARTED",
    resourceType: "run_profile",
    resourceId: profile.id,
    details: {
      profileName: profile.name,
      batchId,
      serverCount: runs.length,
      changeReason: normalizedChangeReason,
      triggeredBy,
    },
    ipAddress,
  });

  return {
    batchId,
    runs,
    label: plan.built.label,
    blockedServers: plan.blockedServers.map((server) => ({
      serverName: server.serverName,
      blockReason: server.blockReason,
      backupWarning: server.backupWarning,
    })),
  };
}
