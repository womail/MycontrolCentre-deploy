import type { UserRole } from "@prisma/client";
import { buildCommandChain, type BuiltCommand } from "./builder";
import {
  assertTemplatesAllowed,
  getCommandTemplatesByIds,
  templateRequiresPathInput,
  type CommandTemplateRecord,
} from "./templates";
import { isServerInMaintenance, maintenanceBlockedMessage } from "../servers/maintenance";
import { substituteTemplateVariables } from "./variables";
import { evaluateBackupFreshness } from "../backup/check-backup-freshness";
import { parseTemplatePlatforms } from "../servers/platforms";

export interface ExecutionOverrides {
  workingDir?: string;
  listPath?: string;
  customCommand?: string;
  templateOverrides?: Record<
    string,
    { workingDir?: string; listPath?: string; customCommand?: string }
  >;
  variables?: Record<string, string>;
}

export interface ExecutionPlanInput extends ExecutionOverrides {
  serverIds: string[];
  templateIds: string[];
  failureTemplateIds?: string[];
  role: UserRole;
  forceMaintenance?: boolean;
  forceStaleBackup?: boolean;
}

export interface ServerPreview {
  serverId: string;
  serverName: string;
  hostname: string;
  inMaintenance: boolean;
  blocked: boolean;
  blockReason?: string;
  backupWarning?: string;
  backupBlocked?: boolean;
  commandText: string;
}

export interface ExecutionPlan {
  templates: CommandTemplateRecord[];
  built: BuiltCommand;
  failureTemplateIds: string[];
  previews: ServerPreview[];
  runnableServerIds: string[];
  blockedServers: ServerPreview[];
}

type ServerRow = {
  id: string;
  name: string;
  hostname: string;
  inMaintenance: boolean;
  maintenanceNote: string | null;
  maintenanceUntil: Date | null;
  isActive: boolean;
  manualPlatforms?: unknown;
  detectedPlatforms?: unknown;
  lastBackupAt?: Date | null;
  lastBackupSource?: string | null;
};

export async function buildExecutionPlan(
  input: ExecutionPlanInput,
  servers: ServerRow[],
): Promise<ExecutionPlan> {
  const templates = await getCommandTemplatesByIds(input.templateIds);
  assertTemplatesAllowed(templates, input.role);

  const mergedOverrides = resolveOverrides(input, templates);
  const templatesWithVars = applyVariableSubstitution(templates, input.variables);
  const built = buildCommandChain(templatesWithVars, mergedOverrides);

  const failureTemplateIds = input.failureTemplateIds ?? [];
  if (failureTemplateIds.length > 0) {
    await getCommandTemplatesByIds(failureTemplateIds);
  }

  const requiresFreshBackup = templates.some((template) => template.requiresFreshBackup);

  const previews: ServerPreview[] = [];
  for (const server of servers) {
    const inMaintenance = isServerInMaintenance(server);
    let blocked = inMaintenance && !(input.forceMaintenance && input.role === "ADMIN");
    let blockReason = blocked ? maintenanceBlockedMessage(server) : undefined;
    let backupWarning: string | undefined;
    let backupBlocked = false;

    const manual = parseTemplatePlatforms(server.manualPlatforms ?? []);
    const detected = parseTemplatePlatforms(server.detectedPlatforms ?? []);
    const isProxmoxHost = manual.includes("proxmox") || detected.includes("proxmox");

    if (requiresFreshBackup && isProxmoxHost) {
      const backup = await evaluateBackupFreshness({
        lastBackupAt: server.lastBackupAt ?? null,
        lastBackupSource: server.lastBackupSource ?? null,
        requiresFreshBackup: true,
        isProxmoxHost: true,
      });
      if (backup.stale) {
        backupWarning = backup.message;
        if (!(input.forceStaleBackup && input.role === "ADMIN")) {
          blocked = true;
          backupBlocked = true;
          blockReason = backup.message;
        }
      }
    }

    previews.push({
      serverId: server.id,
      serverName: server.name,
      hostname: server.hostname,
      inMaintenance,
      blocked,
      blockReason,
      backupWarning,
      backupBlocked,
      commandText: built.commandText,
    });
  }

  const runnableServerIds = previews.filter((preview) => !preview.blocked).map((p) => p.serverId);
  const blockedServers = previews.filter((preview) => preview.blocked);

  return {
    templates,
    built,
    failureTemplateIds,
    previews,
    runnableServerIds,
    blockedServers,
  };
}

function resolveOverrides(
  input: ExecutionOverrides,
  templates: CommandTemplateRecord[],
): Record<string, { workingDir?: string; listPath?: string; customCommand?: string }> {
  const globalOverrides = {
    workingDir: input.workingDir,
    listPath: input.listPath,
    customCommand: input.customCommand,
  };

  const mergedOverrides: Record<
    string,
    { workingDir?: string; listPath?: string; customCommand?: string }
  > = { ...(input.templateOverrides ?? {}) };

  for (const template of templates) {
    const pathNeed = templateRequiresPathInput(template);
    const overrides = {
      ...globalOverrides,
      ...(mergedOverrides[template.id] ?? {}),
    };

    if (pathNeed === "workingDir" && !overrides.workingDir && !template.defaultWorkingDir) {
      throw new Error(`Command "${template.name}" requires a directory path`);
    }
    if (pathNeed === "listPath" && !overrides.listPath && !template.defaultListPath) {
      throw new Error(`Command "${template.name}" requires a path to list`);
    }
    if (template.type === "CUSTOM" && !overrides.customCommand && !template.commandText) {
      throw new Error(`Command "${template.name}" requires command text`);
    }

    mergedOverrides[template.id] = overrides;
  }

  return mergedOverrides;
}

function applyVariableSubstitution(
  templates: CommandTemplateRecord[],
  variables?: Record<string, string>,
): CommandTemplateRecord[] {
  if (!variables || Object.keys(variables).length === 0) return templates;

  return templates.map((template) => ({
    ...template,
    commandText: template.commandText
      ? substituteTemplateVariables(template.commandText, variables)
      : template.commandText,
    defaultWorkingDir: template.defaultWorkingDir
      ? substituteTemplateVariables(template.defaultWorkingDir, variables)
      : template.defaultWorkingDir,
    defaultListPath: template.defaultListPath
      ? substituteTemplateVariables(template.defaultListPath, variables)
      : template.defaultListPath,
  }));
}
