export function requiresChangeReason(serverCount: number, templateCount: number): boolean {
  return serverCount > 1 || templateCount > 1;
}

export function validateChangeReason(
  changeReason: string | undefined,
  serverCount: number,
  templateCount: number,
): string | null {
  if (!requiresChangeReason(serverCount, templateCount)) return null;

  const trimmed = changeReason?.trim();
  if (!trimmed) {
    return "Change reason is required for batch or multi-command runs";
  }
  if (trimmed.length < 3) {
    return "Change reason must be at least 3 characters";
  }
  if (trimmed.length > 500) {
    return "Change reason must be 500 characters or fewer";
  }
  return null;
}
