import { prisma } from "../db";
import type { UserRole } from "@prisma/client";
import { buildFromTemplate, type CommandTemplateInput } from "./builder";
import { parseTemplatePlatforms } from "../servers/platforms";

export interface CommandTemplateRecord extends CommandTemplateInput {
  id: string;
  category: string;
  platforms: string[];
  sortOrder: number;
  isBuiltIn: boolean;
  isActive: boolean;
  requiresFreshBackup: boolean;
}

function mapTemplate(template: {
  id: string;
  name: string;
  type: string;
  description: string;
  commandText: string | null;
  defaultWorkingDir: string | null;
  defaultListPath: string | null;
  category: string;
  platforms: unknown;
  sortOrder: number;
  adminOnly: boolean;
  isBuiltIn: boolean;
  isActive: boolean;
  requiresFreshBackup: boolean;
}): CommandTemplateRecord {
  return {
    id: template.id,
    name: template.name,
    type: template.type,
    description: template.description,
    commandText: template.commandText,
    defaultWorkingDir: template.defaultWorkingDir,
    defaultListPath: template.defaultListPath,
    category: template.category,
    platforms: parseTemplatePlatforms(template.platforms),
    sortOrder: template.sortOrder,
    adminOnly: template.adminOnly,
    isBuiltIn: template.isBuiltIn,
    isActive: template.isActive,
    requiresFreshBackup: template.requiresFreshBackup ?? false,
  };
}

export async function listCommandTemplates(options?: {
  includeInactive?: boolean;
}): Promise<CommandTemplateRecord[]> {
  const templates = await prisma.commandTemplate.findMany({
    where: options?.includeInactive ? undefined : { isActive: true },
    orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
  });

  return templates.map(mapTemplate);
}

export async function getCommandTemplatesByIds(ids: string[]): Promise<CommandTemplateRecord[]> {
  const templates = await prisma.commandTemplate.findMany({
    where: { id: { in: ids }, isActive: true },
  });

  const byId = new Map(templates.map((template) => [template.id, template]));
  const ordered = ids
    .map((id) => byId.get(id))
    .filter((template): template is NonNullable<typeof template> => Boolean(template));

  if (ordered.length !== ids.length) {
    throw new Error("One or more selected commands are invalid or inactive");
  }

  return ordered.map(mapTemplate);
}

export function assertTemplatesAllowed(
  templates: CommandTemplateRecord[],
  role: UserRole,
): void {
  if (role === "VIEWER") {
    throw new Error("Forbidden");
  }

  for (const template of templates) {
    if (template.adminOnly && role !== "ADMIN") {
      throw new Error(`Command "${template.name}" requires admin role`);
    }
  }
}

export function templateRequiresPathInput(template: CommandTemplateRecord): "workingDir" | "listPath" | null {
  if (template.type === "CD") {
    return template.defaultWorkingDir ? null : "workingDir";
  }
  if (template.type === "LS") {
    return template.defaultListPath ? null : "listPath";
  }
  return null;
}

export function resolveTemplateForDraft(draft: {
  name: string;
  type: string;
  description: string;
  commandText?: string | null;
  defaultWorkingDir?: string | null;
  defaultListPath?: string | null;
  adminOnly?: boolean;
}): CommandTemplateInput {
  return {
    id: "draft",
    name: draft.name,
    type: draft.type,
    description: draft.description,
    commandText: draft.commandText,
    defaultWorkingDir: draft.defaultWorkingDir,
    defaultListPath: draft.defaultListPath,
    adminOnly: draft.adminOnly ?? false,
  };
}

export function previewTemplateBuild(template: CommandTemplateInput) {
  return buildFromTemplate(template);
}
