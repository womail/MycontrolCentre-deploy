const MAX_COMMAND_LENGTH = 4000;
const MAX_PATH_LENGTH = 1024;

const BLOCKED_PATTERNS = [
  /rm\s+-rf\s+\/(?:\s|$)/i,
  /:\(\)\s*\{\s*:\|:&\s*\};:/,
  /mkfs\./i,
  /dd\s+if=/i,
  />\s*\/dev\/sd/i,
];

export function validatePath(path: string, label = "Path"): string {
  const trimmed = path.trim();
  if (!trimmed) {
    throw new Error(`${label} is required`);
  }
  if (trimmed.length > MAX_PATH_LENGTH) {
    throw new Error(`${label} is too long (max ${MAX_PATH_LENGTH} characters)`);
  }
  if (trimmed.includes("\0")) {
    throw new Error(`${label} contains invalid characters`);
  }
  if (!trimmed.startsWith("/")) {
    throw new Error(`${label} must be an absolute path starting with /`);
  }
  if (/\.\./.test(trimmed)) {
    throw new Error(`${label} must not contain .. segments`);
  }
  return trimmed;
}

export function validateOptionalPath(path: string | undefined, label = "Path"): string | undefined {
  if (path == null || path.trim() === "") return undefined;
  return validatePath(path, label);
}

export function validateCustomCommand(command: string): string {
  const trimmed = command.trim();
  if (!trimmed) {
    throw new Error("Command text is required");
  }
  if (trimmed.length > MAX_COMMAND_LENGTH) {
    throw new Error(`Command is too long (max ${MAX_COMMAND_LENGTH} characters)`);
  }
  if (trimmed.includes("\n") || trimmed.includes("\r")) {
    throw new Error("Multi-line commands are not allowed");
  }
  if (trimmed.includes("\0")) {
    throw new Error("Command contains invalid characters");
  }

  for (const pattern of BLOCKED_PATTERNS) {
    if (pattern.test(trimmed)) {
      throw new Error("Command contains a blocked destructive pattern");
    }
  }

  return trimmed;
}

export function validateTemplateName(name: string): string {
  const trimmed = name.trim();
  if (!trimmed) throw new Error("Name is required");
  if (trimmed.length > 120) throw new Error("Name is too long (max 120 characters)");
  return trimmed;
}

export function validateListTarget(path: string, label = "Path to list"): string {
  const trimmed = path.trim();
  if (!trimmed) {
    throw new Error(`${label} is required`);
  }
  if (trimmed.length > MAX_PATH_LENGTH) {
    throw new Error(`${label} is too long (max ${MAX_PATH_LENGTH} characters)`);
  }
  if (trimmed.includes("\0") || trimmed.includes("\n") || trimmed.includes("\r")) {
    throw new Error(`${label} contains invalid characters`);
  }
  return trimmed;
}

export function validateTemplateDescription(description: string): string {
  const trimmed = description.trim();
  if (!trimmed) throw new Error("Description is required");
  if (trimmed.length > 500) throw new Error("Description is too long (max 500 characters)");
  return trimmed;
}
