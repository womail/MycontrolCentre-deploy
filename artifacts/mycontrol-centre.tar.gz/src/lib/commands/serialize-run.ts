import type { CommandRun, Server, User } from "@prisma/client";

const LIST_STDOUT_SNIPPET = 200;
const LIST_STDERR_SNIPPET = 200;

type RunWithRelations = CommandRun & {
  server: Pick<Server, "id" | "name">;
  user: Pick<User, "id" | "username">;
};

/** List/history payload — omits full captured output to keep polling lightweight. */
export function serializeCommandRunSummary(run: RunWithRelations) {
  const { stdout, stderr, ...rest } = run;
  return {
    ...rest,
    stdoutSnippet: stdout.slice(0, LIST_STDOUT_SNIPPET),
    stderrSnippet: stderr.slice(0, LIST_STDERR_SNIPPET),
    hasStdout: stdout.length > 0,
    hasStderr: stderr.length > 0,
  };
}
