import { buildRemoteCommand, shellEscape } from "../ssh/client";
import { commandTypeUsesShellText, isBuiltInCommandType } from "./command-types";
import {
  validateCustomCommand,
  validateListTarget,
  validateOptionalPath,
  validatePath,
} from "./validate";

export interface CommandBuildInput {
  type: string;
  workingDir?: string;
  customCommand?: string;
  listPath?: string;
}

export interface CommandTemplateInput {
  id?: string;
  name: string;
  type: string;
  description: string;
  commandText?: string | null;
  defaultWorkingDir?: string | null;
  defaultListPath?: string | null;
  adminOnly?: boolean;
}

export interface BuiltCommand {
  commandText: string;
  workingDir?: string;
  description: string;
  label: string;
}

const NONINTERACTIVE_PREFIX =
  "export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a; ";

export function buildCommand(input: CommandBuildInput): BuiltCommand {
  switch (input.type) {
    case "CD": {
      const dir = validatePath(input.workingDir ?? input.listPath ?? "/", "Directory");
      return {
        commandText: buildRemoteCommand(undefined, `cd ${shellEscape(dir)} && pwd`),
        workingDir: dir,
        description: `Change directory to ${dir}`,
        label: `CD ${dir}`,
      };
    }
    case "LS": {
      const listDir = validateListTarget(input.listPath ?? ".", "Path to list");
      const workingDir = validateOptionalPath(input.workingDir, "Working directory");
      return {
        commandText: buildRemoteCommand(
          workingDir,
          `ls -la ${shellEscape(listDir)}`,
        ),
        workingDir,
        description: `List directory ${listDir}`,
        label: `LS ${listDir}`,
      };
    }
    case "APT_UPDATE":
      return {
        commandText: buildRemoteCommand(
          validateOptionalPath(input.workingDir, "Working directory"),
          `${NONINTERACTIVE_PREFIX}sudo apt-get update -qq`,
        ),
        workingDir: validateOptionalPath(input.workingDir, "Working directory"),
        description: "Run apt-get update (non-interactive)",
        label: "APT Update",
      };
    case "APT_UPGRADE":
      return {
        commandText: buildRemoteCommand(
          validateOptionalPath(input.workingDir, "Working directory"),
          `${NONINTERACTIVE_PREFIX}sudo apt-get upgrade -y -qq -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold"`,
        ),
        workingDir: validateOptionalPath(input.workingDir, "Working directory"),
        description: "Run apt-get upgrade (non-interactive)",
        label: "APT Upgrade",
      };
    case "CUSTOM": {
      const cmd = validateCustomCommand(input.customCommand ?? "");
      return {
        commandText: buildRemoteCommand(
          validateOptionalPath(input.workingDir, "Working directory"),
          cmd,
        ),
        workingDir: validateOptionalPath(input.workingDir, "Working directory"),
        description: `Custom: ${cmd.slice(0, 120)}`,
        label: cmd.length > 60 ? `${cmd.slice(0, 57)}...` : cmd,
      };
    }
    default:
      if (isBuiltInCommandType(input.type)) {
        throw new Error(`Unhandled built-in command type: ${input.type}`);
      }
      throw new Error(`Unknown command type: ${input.type}`);
  }
}

export function buildFromTemplate(
  template: CommandTemplateInput,
  overrides?: {
    workingDir?: string;
    listPath?: string;
    customCommand?: string;
  },
): BuiltCommand {
  const workingDir = overrides?.workingDir ?? template.defaultWorkingDir ?? undefined;
  const listPath = overrides?.listPath ?? template.defaultListPath ?? undefined;

  if (template.type === "CD") {
    return buildCommand({
      type: "CD",
      workingDir: workingDir ?? listPath,
    });
  }

  if (template.type === "LS") {
    return buildCommand({
      type: "LS",
      workingDir,
      listPath,
    });
  }

  if (commandTypeUsesShellText(template.type)) {
    const customCommand = overrides?.customCommand ?? template.commandText ?? "";
    return buildCommand({
      type: "CUSTOM",
      workingDir,
      customCommand,
    });
  }

  if (template.type === "APT_UPDATE" || template.type === "APT_UPGRADE") {
    return buildCommand({
      type: template.type,
      workingDir,
    });
  }

  throw new Error(`Unknown command type: ${template.type}`);
}

export function buildCommandChain(
  templates: CommandTemplateInput[],
  overrides?: Record<
    string,
    { workingDir?: string; listPath?: string; customCommand?: string }
  >,
): BuiltCommand {
  if (templates.length === 0) {
    throw new Error("Select at least one command");
  }

  const builtParts = templates.map((template) =>
    buildFromTemplate(template, overrides?.[template.id ?? ""] ?? overrides?.[template.name]),
  );

  const commandText =
    templates.length === 1
      ? builtParts[0].commandText
      : `set -e; ${builtParts.map((part) => part.commandText).join(" && ")}`;

  return {
    commandText,
    workingDir: builtParts.find((part) => part.workingDir)?.workingDir,
    description: builtParts.map((part) => part.description).join(" → "),
    label: builtParts.map((part) => part.label).join(" → "),
  };
}

export const BUILT_IN_COMMANDS = [
  {
    type: "CD" as const,
    name: "Change Directory",
    description: "Verify access to a directory path",
    requiresPath: true,
    adminOnly: false,
  },
  {
    type: "LS" as const,
    name: "List Directory",
    description: "List files in a directory (ls -la)",
    requiresPath: true,
    adminOnly: false,
  },
  {
    type: "APT_UPDATE" as const,
    name: "APT Update",
    description: "Refresh package lists (non-interactive)",
    requiresPath: false,
    adminOnly: false,
  },
  {
    type: "APT_UPGRADE" as const,
    name: "APT Upgrade",
    description: "Upgrade installed packages (non-interactive)",
    requiresPath: false,
    adminOnly: false,
  },
  {
    type: "CUSTOM" as const,
    name: "Custom Command",
    description: "Run a custom shell command (admin only)",
    requiresPath: false,
    adminOnly: true,
  },
];
