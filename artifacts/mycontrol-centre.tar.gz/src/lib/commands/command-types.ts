export const BUILT_IN_COMMAND_TYPES = ["CD", "LS", "APT_UPDATE", "APT_UPGRADE"] as const;
export type BuiltInCommandType = (typeof BUILT_IN_COMMAND_TYPES)[number];

export const SUGGESTED_COMMAND_TYPES = [
  ...BUILT_IN_COMMAND_TYPES,
  "CUSTOM",
] as const;

export function isBuiltInCommandType(type: string): type is BuiltInCommandType {
  return (BUILT_IN_COMMAND_TYPES as readonly string[]).includes(type);
}

/** Types that run template.commandText (CUSTOM or any user-defined type name). */
export function commandTypeUsesShellText(type: string): boolean {
  return type === "CUSTOM" || !isBuiltInCommandType(type);
}
