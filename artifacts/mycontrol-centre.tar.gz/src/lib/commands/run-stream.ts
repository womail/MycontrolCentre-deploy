import { appendCapped } from "../memory/output-cap";
import { clearMccInterval, getMccGlobals } from "../queue/process-globals";
import type { RunStreamEvent, RunStreamListener, RunStreamState } from "./run-stream-state";

export type { RunStreamEvent } from "./run-stream-state";

const MAX_BUFFER_EVENTS = 80;
const MAX_STREAMS = 64;
const MAX_BUFFERED_CHARS_PER_RUN = 48_000;
const MAX_REPLAY_CHUNK_CHARS = 4_096;
const CLEANUP_AFTER_MS = 2 * 60 * 1000;
const IDLE_NO_LISTENERS_MS = 45 * 1000;
const SWEEP_MS = 30 * 1000;

function getStreams(): Map<string, RunStreamState> {
  const g = getMccGlobals();
  if (!g.runStreams) g.runStreams = new Map();
  return g.runStreams;
}

function eventCharWeight(event: RunStreamEvent): number {
  if (event.type === "stdout" || event.type === "stderr") return event.data.length;
  return 64;
}

function capReplayChunk(event: RunStreamEvent): RunStreamEvent {
  if (event.type !== "stdout" && event.type !== "stderr") return event;
  if (event.data.length <= MAX_REPLAY_CHUNK_CHARS) return event;
  return { ...event, data: event.data.slice(-MAX_REPLAY_CHUNK_CHARS) };
}

function pushBufferedEvent(state: RunStreamState, event: RunStreamEvent) {
  const stored = capReplayChunk(event);
  if (stored.type === "stdout" || stored.type === "stderr") {
    const last = state.events[state.events.length - 1];
    if (last?.type === stored.type) {
      const merged = appendCapped(last.data, stored.data, MAX_REPLAY_CHUNK_CHARS);
      const delta = merged.length - last.data.length;
      state.bufferedChars += delta;
      last.data = merged;
      trimBufferedEvents(state);
      return;
    }
  }

  state.events.push(stored);
  state.bufferedChars += eventCharWeight(stored);
  trimBufferedEvents(state);
}

function trimBufferedEvents(state: RunStreamState) {
  while (
    state.events.length > MAX_BUFFER_EVENTS ||
    state.bufferedChars > MAX_BUFFERED_CHARS_PER_RUN
  ) {
    const removed = state.events.shift();
    if (!removed) break;
    state.bufferedChars = Math.max(0, state.bufferedChars - eventCharWeight(removed));
    if (state.events.length <= 1) break;
  }
}

function deleteStream(runId: string) {
  const streams = getStreams();
  const state = streams.get(runId);
  if (!state) return;
  if (state.cleanupTimer) clearTimeout(state.cleanupTimer);
  state.listeners.clear();
  streams.delete(runId);
}

function touch(state: RunStreamState) {
  state.lastActivityAt = Date.now();
}

function getState(runId: string): RunStreamState {
  const streams = getStreams();
  let state = streams.get(runId);
  if (!state) {
    if (streams.size >= MAX_STREAMS) {
      let oldestId: string | undefined;
      let oldestAt = Infinity;
      for (const [id, entry] of streams) {
        if (entry.lastActivityAt < oldestAt) {
          oldestAt = entry.lastActivityAt;
          oldestId = id;
        }
      }
      if (oldestId) deleteStream(oldestId);
    }
    state = {
      events: [],
      listeners: new Set(),
      cleanupTimer: null,
      lastActivityAt: Date.now(),
      bufferedChars: 0,
    };
    streams.set(runId, state);
  }
  return state;
}

function scheduleCleanup(runId: string, delayMs = CLEANUP_AFTER_MS) {
  const state = getStreams().get(runId);
  if (!state) return;

  if (state.cleanupTimer) clearTimeout(state.cleanupTimer);
  state.cleanupTimer = setTimeout(() => {
    deleteStream(runId);
  }, delayMs);
}

function ensureStreamSweep() {
  const g = getMccGlobals();
  if (g.runStreamSweep) return;
  g.runStreamSweep = setInterval(() => {
    const now = Date.now();
    const streams = getStreams();
    for (const [runId, state] of streams) {
      const idle = now - state.lastActivityAt;
      const terminal = state.events.some(isTerminalStatusEvent);
      if (state.listeners.size === 0 && idle > IDLE_NO_LISTENERS_MS) {
        deleteStream(runId);
        continue;
      }
      if (terminal && state.listeners.size === 0 && idle > 10_000) {
        deleteStream(runId);
      }
    }
  }, SWEEP_MS);
}

export function publishRunStreamEvent(runId: string, event: RunStreamEvent) {
  ensureStreamSweep();
  const state = getState(runId);
  touch(state);
  pushBufferedEvent(state, event);

  for (const listener of state.listeners) {
    listener(event);
  }

  if (
    event.type === "status" &&
    (event.status === "SUCCESS" ||
      event.status === "FAILED" ||
      event.status === "CANCELLED")
  ) {
    scheduleCleanup(runId, 8_000);
  }
}

export function subscribeRunStream(runId: string, listener: RunStreamListener): () => void {
  ensureStreamSweep();
  const state = getState(runId);
  touch(state);

  for (const event of state.events) {
    listener(event);
  }

  state.listeners.add(listener);
  if (state.cleanupTimer) {
    clearTimeout(state.cleanupTimer);
    state.cleanupTimer = null;
  }

  return () => {
    state.listeners.delete(listener);
    touch(state);
    if (state.listeners.size === 0) {
      const delay = state.events.some(isTerminalStatusEvent) ? 3_000 : IDLE_NO_LISTENERS_MS;
      scheduleCleanup(runId, delay);
    }
  };
}

function isTerminalStatusEvent(event: RunStreamEvent): boolean {
  return (
    event.type === "status" &&
    (event.status === "SUCCESS" ||
      event.status === "FAILED" ||
      event.status === "CANCELLED")
  );
}

export function getRunStreamStats() {
  const streams = getStreams();
  let listenerCount = 0;
  let bufferedEvents = 0;
  let bufferedChars = 0;
  for (const state of streams.values()) {
    listenerCount += state.listeners.size;
    bufferedEvents += state.events.length;
    bufferedChars += state.bufferedChars;
  }
  return {
    activeStreams: streams.size,
    listenerCount,
    bufferedEvents,
    bufferedChars,
  };
}

/** Drop finished streams with no subscribers (maintenance / memory pressure). */
export function purgeIdleRunStreams(): number {
  const streams = getStreams();
  let removed = 0;
  for (const [runId, state] of streams) {
    if (state.listeners.size > 0) continue;
    const terminal = state.events.some(isTerminalStatusEvent);
    if (terminal || Date.now() - state.lastActivityAt > 60_000) {
      deleteStream(runId);
      removed += 1;
    }
  }
  return removed;
}

export function resetRunStreamForTests() {
  const streams = getStreams();
  for (const state of streams.values()) {
    if (state.cleanupTimer) clearTimeout(state.cleanupTimer);
    state.listeners.clear();
  }
  streams.clear();
  const g = getMccGlobals();
  clearMccInterval(g.runStreamSweep);
  g.runStreamSweep = undefined;
}
