import {
  effectivePlatforms,
  parseTemplatePlatforms,
  type ServerPlatform,
} from "../servers/platforms";

/** Host platforms implied for template matching (Proxmox/Ubuntu → Debian packages). */
export function expandServerPlatformsForMatching(platforms: Set<ServerPlatform>): Set<ServerPlatform> {
  const expanded = new Set(platforms);
  if (expanded.has("proxmox")) expanded.add("debian");
  if (expanded.has("ubuntu")) expanded.add("debian");
  return expanded;
}

export interface PlatformAwareServer {
  manualPlatforms?: unknown;
  detectedPlatforms?: unknown;
  platforms?: ServerPlatform[];
}

export interface PlatformAwareTemplate {
  platforms?: unknown;
}

export function getServerPlatformSet(server: PlatformAwareServer): Set<ServerPlatform> {
  const platforms = server.platforms ?? effectivePlatforms(server);
  return new Set(platforms);
}

export function templateMatchesServerPlatforms(
  template: PlatformAwareTemplate,
  serverPlatforms: Set<ServerPlatform>,
): boolean {
  const templatePlatforms = parseTemplatePlatforms(template.platforms);
  if (templatePlatforms.includes("all")) return true;
  const expanded = expandServerPlatformsForMatching(serverPlatforms);
  return templatePlatforms.some((platform) =>
    expanded.has(platform as ServerPlatform),
  );
}

export function filterTemplatesForServers<T extends PlatformAwareTemplate>(
  templates: T[],
  servers: PlatformAwareServer[],
): T[] {
  if (servers.length === 0) return templates;

  return templates.filter((template) =>
    servers.every((server) =>
      templateMatchesServerPlatforms(template, getServerPlatformSet(server)),
    ),
  );
}

export function commonServerPlatforms(servers: PlatformAwareServer[]): ServerPlatform[] {
  if (servers.length === 0) return [];
  const sets = servers.map((server) => getServerPlatformSet(server));
  const intersection = [...sets[0]].filter((platform) =>
    sets.every((set) => set.has(platform)),
  );
  return intersection.length > 0 ? intersection : [...sets[0]];
}
