import { CATEGORY_LABELS, COMMAND_CATEGORIES } from "../servers/platforms";

export function groupTemplatesByCategory<T extends { category?: string | null; sortOrder: number; name: string }>(
  templates: T[],
): Array<{ category: string; label: string; templates: T[] }> {
  const groups = new Map<string, T[]>();

  for (const template of templates) {
    const category = (template.category ?? "general").trim() || "general";
    const list = groups.get(category) ?? [];
    list.push(template);
    groups.set(category, list);
  }

  const preferredOrder: string[] = [...COMMAND_CATEGORIES];
  const seen = new Set<string>();
  const orderedKeys: string[] = [];

  for (const category of preferredOrder) {
    if (groups.has(category)) {
      orderedKeys.push(category);
      seen.add(category);
    }
  }

  const extras = [...groups.keys()].filter((key) => !seen.has(key)).sort();
  orderedKeys.push(...extras);

  return orderedKeys.map((category) => ({
    category,
    label: CATEGORY_LABELS[category] ?? category.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
    templates: (groups.get(category) ?? []).sort(
      (a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name),
    ),
  }));
}

export function categoryLabel(category: string): string {
  return CATEGORY_LABELS[category] ?? category;
}
