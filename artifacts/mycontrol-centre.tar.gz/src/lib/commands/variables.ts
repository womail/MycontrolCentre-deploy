const VARIABLE_PATTERN = /\{\{([a-zA-Z][a-zA-Z0-9_]*)\}\}/g;

export function substituteTemplateVariables(
  text: string,
  variables: Record<string, string>,
): string {
  return text.replace(VARIABLE_PATTERN, (_, key: string) => {
    const value = variables[key];
    if (value == null || value.trim() === "") {
      throw new Error(`Missing value for variable {{${key}}}`);
    }
    return value.trim();
  });
}

export function extractTemplateVariables(text: string | null | undefined): string[] {
  if (!text) return [];
  const found = new Set<string>();
  for (const match of text.matchAll(VARIABLE_PATTERN)) {
    found.add(match[1]);
  }
  return [...found];
}
