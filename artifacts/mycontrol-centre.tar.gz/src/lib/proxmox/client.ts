import https from "node:https";
import { decrypt } from "../crypto";

export interface ProxmoxClientConfig {
  hostname: string;
  port?: number;
  tokenId: string;
  tokenSecret: string;
}

export interface ProxmoxResource {
  id: string;
  type: string;
  node?: string;
  vmid?: number;
  name?: string;
  status?: string;
  cpu?: number;
  mem?: number;
  maxmem?: number;
  disk?: number;
  maxdisk?: number;
  uptime?: number;
}

export interface ProxmoxNodeStatus {
  node: string;
  status?: string;
  cpu?: number;
  maxcpu?: number;
  mem?: number;
  maxmem?: number;
  uptime?: number;
  pveversion?: string;
}

export interface ProxmoxClusterSummary {
  nodeCount: number;
  vmCount: number;
  lxcCount: number;
  onlineNodes: number;
  totalMem: number;
  usedMem: number;
  totalDisk: number;
  usedDisk: number;
  version?: string;
  subscription?: string;
  quorum?: boolean;
}

function proxmoxRequest<T>(
  config: ProxmoxClientConfig,
  path: string,
  method = "GET",
): Promise<T> {
  return new Promise((resolve, reject) => {
    const auth = `PVEAPIToken=${config.tokenId}=${config.tokenSecret}`;
    const req = https.request(
      {
        hostname: config.hostname,
        port: config.port ?? 8006,
        path,
        method,
        headers: {
          Authorization: auth,
          Accept: "application/json",
        },
        rejectUnauthorized: false,
      },
      (res) => {
        let body = "";
        res.on("data", (chunk) => {
          body += chunk;
        });
        res.on("end", () => {
          try {
            const parsed = JSON.parse(body) as { data?: T; errors?: unknown };
            if ((res.statusCode ?? 500) >= 400) {
              reject(new Error(`Proxmox API error ${res.statusCode}: ${body.slice(0, 300)}`));
              return;
            }
            resolve(parsed.data as T);
          } catch {
            reject(new Error(`Invalid Proxmox API response: ${body.slice(0, 300)}`));
          }
        });
      },
    );
    req.on("error", reject);
    req.end();
  });
}

export function buildProxmoxConfig(
  server: {
    hostname: string;
    proxmoxApiPort?: number | null;
    proxmoxTokenId?: string | null;
    encryptedProxmoxToken?: string | null;
  },
): ProxmoxClientConfig | null {
  if (!server.proxmoxTokenId || !server.encryptedProxmoxToken) return null;
  return {
    hostname: server.hostname,
    port: server.proxmoxApiPort ?? 8006,
    tokenId: server.proxmoxTokenId,
    tokenSecret: decrypt(server.encryptedProxmoxToken),
  };
}

export async function fetchClusterResources(config: ProxmoxClientConfig): Promise<ProxmoxResource[]> {
  return proxmoxRequest<ProxmoxResource[]>(config, "/api2/json/cluster/resources");
}

export async function fetchNodeStatus(
  config: ProxmoxClientConfig,
  node: string,
): Promise<ProxmoxNodeStatus> {
  const data = await proxmoxRequest<Record<string, unknown>>(
    config,
    `/api2/json/nodes/${encodeURIComponent(node)}/status`,
  );
  return {
    node,
    status: String(data.status ?? "unknown"),
    cpu: Number(data.cpu ?? 0),
    maxcpu: Number(data.maxcpu ?? 0),
    mem: Number(data.mem ?? 0),
    maxmem: Number(data.maxmem ?? 0),
    uptime: Number(data.uptime ?? 0),
    pveversion: data.pveversion ? String(data.pveversion) : undefined,
  };
}

export async function fetchClusterStatus(config: ProxmoxClientConfig): Promise<Record<string, unknown>[]> {
  return proxmoxRequest<Record<string, unknown>[]>(config, "/api2/json/cluster/status");
}

export async function fetchSubscription(config: ProxmoxClientConfig): Promise<Record<string, unknown>> {
  return proxmoxRequest<Record<string, unknown>>(config, "/api2/json/nodes/localhost/subscription");
}

export function summarizeCluster(
  resources: ProxmoxResource[],
  clusterStatus: Record<string, unknown>[],
  nodeStatus?: ProxmoxNodeStatus,
): ProxmoxClusterSummary {
  const nodes = resources.filter((resource) => resource.type === "node");
  const vms = resources.filter((resource) => resource.type === "qemu");
  const lxcs = resources.filter((resource) => resource.type === "lxc");
  const onlineNodes = nodes.filter((node) => node.status === "online").length;

  let totalMem = 0;
  let usedMem = 0;
  let totalDisk = 0;
  let usedDisk = 0;

  for (const node of nodes) {
    totalMem += node.maxmem ?? 0;
    usedMem += node.mem ?? 0;
    totalDisk += node.maxdisk ?? 0;
    usedDisk += node.disk ?? 0;
  }

  const quorumEntry = clusterStatus.find((entry) => entry.type === "cluster");
  const subscriptionEntry = clusterStatus.find((entry) => entry.type === "node");

  return {
    nodeCount: nodes.length,
    vmCount: vms.length,
    lxcCount: lxcs.length,
    onlineNodes,
    totalMem,
    usedMem,
    totalDisk,
    usedDisk,
    version: nodeStatus?.pveversion,
    subscription: subscriptionEntry ? String(subscriptionEntry.name ?? "") : undefined,
    quorum: quorumEntry ? Boolean(quorumEntry.quorate) : undefined,
  };
}
