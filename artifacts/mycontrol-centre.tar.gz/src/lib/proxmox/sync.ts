import type { Prisma, Server } from "@prisma/client";
import { prisma } from "../db";
import { parsePlatformList } from "../servers/platforms";
import {
  buildProxmoxConfig,
  fetchClusterResources,
  fetchClusterStatus,
  fetchNodeStatus,
  summarizeCluster,
} from "./client";

export async function syncProxmoxServer(serverId: string) {
  const server = await prisma.server.findUnique({ where: { id: serverId } });
  if (!server) throw new Error("Server not found");

  const config = buildProxmoxConfig(server);
  if (!config) {
    throw new Error("Proxmox API token is not configured for this server");
  }

  const nodeName = server.proxmoxNodeName ?? server.name;
  const [resources, clusterStatus, nodeStatus] = await Promise.all([
    fetchClusterResources(config),
    fetchClusterStatus(config).catch(() => [] as Record<string, unknown>[]),
    fetchNodeStatus(config, nodeName).catch(() => undefined),
  ]);

  const summary = summarizeCluster(resources, clusterStatus, nodeStatus);
  const guests = resources.filter(
    (resource) => resource.type === "qemu" || resource.type === "lxc",
  );

  await prisma.$transaction(async (tx) => {
    await tx.proxmoxGuest.deleteMany({ where: { serverId } });

    for (const guest of guests) {
      if (!guest.vmid) continue;
      await tx.proxmoxGuest.create({
        data: {
          serverId,
          guestType: guest.type === "lxc" ? "LXC" : "QEMU",
          vmid: guest.vmid,
          name: guest.name ?? `guest-${guest.vmid}`,
          status: guest.status ?? null,
          cpu: guest.cpu != null ? String(guest.cpu) : null,
          mem: guest.mem ?? null,
          maxmem: guest.maxmem ?? null,
          disk: guest.disk ?? null,
          maxdisk: guest.maxdisk ?? null,
        },
      });
    }

    await tx.server.update({
      where: { id: serverId },
      data: {
        proxmoxNodeName: nodeName,
        proxmoxVersion: summary.version ?? server.proxmoxVersion,
        proxmoxSummary: summary as unknown as Prisma.InputJsonValue,
        lastProxmoxSync: new Date(),
        detectedPlatforms: [
          ...new Set([...parsePlatformList(server.detectedPlatforms), "proxmox"]),
        ],
      },
    });
  });

  return { summary, guestCount: guests.length };
}

export async function validateGuestVmid(server: Server, vmid: number): Promise<boolean> {
  const guest = await prisma.proxmoxGuest.findUnique({
    where: { serverId_vmid: { serverId: server.id, vmid } },
  });
  return Boolean(guest);
}
