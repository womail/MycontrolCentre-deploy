import { prisma } from "./db";
import type {
  ConnectionOutcome,
  RemoteConnectionPurpose,
  Server,
} from "@prisma/client";
import type { NextRequest, NextResponse } from "next/server";
import { getClientIp } from "./rate-limit";

export interface RemoteConnectionLogContext {
  purpose: RemoteConnectionPurpose;
  userId?: string | null;
  commandRunId?: string | null;
}

export async function logRemoteConnection(params: {
  server: Pick<Server, "id" | "name" | "hostname" | "port" | "sshUser">;
  purpose: RemoteConnectionPurpose;
  outcome: ConnectionOutcome;
  userId?: string | null;
  commandRunId?: string | null;
  durationMs?: number;
  exitCode?: number;
  errorMessage?: string;
}) {
  return prisma.remoteConnectionLog.create({
    data: {
      serverId: params.server.id,
      serverName: params.server.name,
      hostname: params.server.hostname,
      port: params.server.port,
      sshUser: params.server.sshUser,
      purpose: params.purpose,
      userId: params.userId ?? null,
      commandRunId: params.commandRunId ?? null,
      outcome: params.outcome,
      durationMs: params.durationMs,
      exitCode: params.exitCode,
      errorMessage: params.errorMessage?.slice(0, 2000),
    },
  });
}

export async function logApiRequest(params: {
  req: NextRequest;
  response: NextResponse;
  startedAt: number;
  userId?: string | null;
}) {
  const url = new URL(params.req.url);
  if (shouldSkipApiRequestLog(params.req.method, url.pathname)) {
    return null;
  }

  return prisma.apiRequestLog.create({
    data: {
      method: params.req.method,
      path: url.pathname,
      query: url.search ? url.search.slice(1) : null,
      statusCode: params.response.status,
      durationMs: Math.max(0, Date.now() - params.startedAt),
      userId: params.userId ?? null,
      ipAddress: getClientIp(params.req.headers),
      userAgent: params.req.headers.get("user-agent")?.slice(0, 500) ?? null,
    },
  });
}

/** High-frequency polling endpoints — skip DB write to reduce load and log bloat. */
export function shouldSkipApiRequestLog(method: string, pathname: string): boolean {
  if (method !== "GET") return false;
  if (pathname === "/api/auth/me") return true;
  if (pathname.startsWith("/api/commands/runs")) return true;
  if (pathname.includes("/terminal/session/") && pathname.endsWith("/stream")) return true;
  if (pathname === "/api/enrollment/pending-count") return true;
  if (pathname === "/api/admin/system-profile") return true;
  if (pathname === "/api/admin/memory-diagnostics") return true;
  if (pathname === "/api/servers") return true;
  if (pathname.startsWith("/api/commands/templates")) return true;
  if (pathname.startsWith("/api/server-groups")) return true;
  if (pathname.startsWith("/api/commands/profiles")) return true;
  if (pathname.startsWith("/api/commands/batches")) return true;
  if (pathname.startsWith("/api/settings/appearance")) return true;
  return false;
}

function apiLogRetentionCutoff(): Date {
  const retentionDays = parseInt(process.env.API_LOG_RETENTION_DAYS ?? "14", 10);
  return new Date(Date.now() - retentionDays * 24 * 60 * 60 * 1000);
}

function retentionCutoff(): Date {
  const retentionDays = parseInt(
    process.env.AUDIT_LOG_RETENTION_DAYS ?? "365",
    10,
  );
  return new Date(Date.now() - retentionDays * 24 * 60 * 60 * 1000);
}

export async function purgeOldConnectionLogs(): Promise<{
  remote: number;
  api: number;
}> {
  const cutoff = retentionCutoff();
  const apiCutoff = apiLogRetentionCutoff();
  const [remote, api] = await Promise.all([
    prisma.remoteConnectionLog.deleteMany({
      where: { createdAt: { lt: cutoff } },
    }),
    prisma.apiRequestLog.deleteMany({
      where: { createdAt: { lt: apiCutoff } },
    }),
  ]);
  return { remote: remote.count, api: api.count };
}
