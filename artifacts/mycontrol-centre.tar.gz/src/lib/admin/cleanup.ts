import { prisma } from "../db";

export async function clearFailedCommandRuns(): Promise<number> {
  const result = await prisma.commandRun.deleteMany({
    where: { status: "FAILED" },
  });
  return result.count;
}

export async function clearSshFailureLogs(): Promise<number> {
  const result = await prisma.remoteConnectionLog.deleteMany({
    where: { outcome: "FAILED" },
  });
  return result.count;
}

export async function clearAllAuditLogs(): Promise<number> {
  const result = await prisma.auditLog.deleteMany({});
  return result.count;
}

export async function clearAllRemoteConnectionLogs(): Promise<number> {
  const result = await prisma.remoteConnectionLog.deleteMany({});
  return result.count;
}

export async function clearAllApiRequestLogs(): Promise<number> {
  const result = await prisma.apiRequestLog.deleteMany({});
  return result.count;
}
