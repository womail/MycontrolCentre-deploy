import { prisma } from "../db";
import type { Prisma } from "@prisma/client";

export type AdminTableId =
  | "appSetting"
  | "commandTemplate"
  | "serverEnrollmentRequest"
  | "setupSshKey"
  | "savedRunProfile"
  | "profileSchedule";

export interface AdminTableMeta {
  id: AdminTableId;
  label: string;
  description: string;
  idField: string;
  canCreate: boolean;
  canDelete: boolean;
}

export const ADMIN_TABLES: AdminTableMeta[] = [
  {
    id: "appSetting",
    label: "App settings",
    description: "Key/value configuration stored in SQLite",
    idField: "key",
    canCreate: true,
    canDelete: true,
  },
  {
    id: "commandTemplate",
    label: "Command templates",
    description: "Built-in and custom command definitions",
    idField: "id",
    canCreate: true,
    canDelete: true,
  },
  {
    id: "serverEnrollmentRequest",
    label: "Enrollment requests",
    description: "Remote host enrollment queue history",
    idField: "id",
    canCreate: false,
    canDelete: true,
  },
  {
    id: "setupSshKey",
    label: "Setup SSH keys",
    description: "Temporary wizard keys awaiting enrollment approve",
    idField: "id",
    canCreate: false,
    canDelete: true,
  },
  {
    id: "savedRunProfile",
    label: "Saved run profiles",
    description: "Command batch profiles",
    idField: "id",
    canCreate: true,
    canDelete: true,
  },
  {
    id: "profileSchedule",
    label: "Profile schedules",
    description: "Weekly UTC schedules for profiles",
    idField: "id",
    canCreate: true,
    canDelete: true,
  },
];

export function getAdminTableMeta(tableId: string): AdminTableMeta | null {
  return ADMIN_TABLES.find((t) => t.id === tableId) ?? null;
}

export async function listAdminTableRows(tableId: AdminTableId, take = 100) {
  switch (tableId) {
    case "appSetting":
      return prisma.appSetting.findMany({ orderBy: { key: "asc" }, take });
    case "commandTemplate":
      return prisma.commandTemplate.findMany({ orderBy: { sortOrder: "asc" }, take });
    case "serverEnrollmentRequest":
      return prisma.serverEnrollmentRequest.findMany({
        orderBy: { createdAt: "desc" },
        take,
      });
    case "setupSshKey":
      return prisma.setupSshKey.findMany({
        orderBy: { createdAt: "desc" },
        take,
        select: {
          id: true,
          createdById: true,
          publicKeyFingerprint: true,
          createdAt: true,
          expiresAt: true,
        },
      });
    case "savedRunProfile":
      return prisma.savedRunProfile.findMany({ orderBy: { name: "asc" }, take });
    case "profileSchedule":
      return prisma.profileSchedule.findMany({ orderBy: { profileId: "asc" }, take });
    default:
      throw new Error("Unknown table");
  }
}

export async function getAdminTableRow(tableId: AdminTableId, id: string) {
  switch (tableId) {
    case "appSetting":
      return prisma.appSetting.findUnique({ where: { key: id } });
    case "commandTemplate":
      return prisma.commandTemplate.findUnique({ where: { id } });
    case "serverEnrollmentRequest":
      return prisma.serverEnrollmentRequest.findUnique({ where: { id } });
    case "setupSshKey":
      return prisma.setupSshKey.findUnique({
        where: { id },
        select: {
          id: true,
          createdById: true,
          publicKeyFingerprint: true,
          createdAt: true,
          expiresAt: true,
        },
      });
    case "savedRunProfile":
      return prisma.savedRunProfile.findUnique({ where: { id } });
    case "profileSchedule":
      return prisma.profileSchedule.findUnique({ where: { id } });
    default:
      throw new Error("Unknown table");
  }
}

export async function createAdminTableRow(tableId: AdminTableId, data: Record<string, unknown>) {
  switch (tableId) {
    case "appSetting":
      return prisma.appSetting.create({
        data: {
          key: String(data.key ?? ""),
          value: String(data.value ?? ""),
        },
      });
    case "commandTemplate":
      return prisma.commandTemplate.create({ data: data as Prisma.CommandTemplateCreateInput });
    case "savedRunProfile":
      return prisma.savedRunProfile.create({ data: data as Prisma.SavedRunProfileCreateInput });
    case "profileSchedule":
      return prisma.profileSchedule.create({ data: data as Prisma.ProfileScheduleCreateInput });
    default:
      throw new Error("Create not supported for this table");
  }
}

export async function updateAdminTableRow(
  tableId: AdminTableId,
  id: string,
  data: Record<string, unknown>,
) {
  switch (tableId) {
    case "appSetting":
      return prisma.appSetting.update({
        where: { key: id },
        data: {
          key: data.key != null ? String(data.key) : undefined,
          value: data.value != null ? String(data.value) : undefined,
        },
      });
    case "commandTemplate":
      return prisma.commandTemplate.update({
        where: { id },
        data: data as Prisma.CommandTemplateUpdateInput,
      });
    case "serverEnrollmentRequest":
      return prisma.serverEnrollmentRequest.update({
        where: { id },
        data: data as Prisma.ServerEnrollmentRequestUpdateInput,
      });
    case "savedRunProfile":
      return prisma.savedRunProfile.update({
        where: { id },
        data: data as Prisma.SavedRunProfileUpdateInput,
      });
    case "profileSchedule":
      return prisma.profileSchedule.update({
        where: { id },
        data: data as Prisma.ProfileScheduleUpdateInput,
      });
    default:
      throw new Error("Update not supported for this table");
  }
}

export async function deleteAdminTableRow(tableId: AdminTableId, id: string) {
  switch (tableId) {
    case "appSetting":
      await prisma.appSetting.delete({ where: { key: id } });
      return;
    case "commandTemplate":
      await prisma.commandTemplate.delete({ where: { id } });
      return;
    case "serverEnrollmentRequest":
      await prisma.serverEnrollmentRequest.delete({ where: { id } });
      return;
    case "setupSshKey":
      await prisma.setupSshKey.delete({ where: { id } });
      return;
    case "savedRunProfile":
      await prisma.savedRunProfile.delete({ where: { id } });
      return;
    case "profileSchedule":
      await prisma.profileSchedule.delete({ where: { id } });
      return;
    default:
      throw new Error("Delete not supported for this table");
  }
}
