import v8 from "node:v8";
import fs from "node:fs";
import path from "node:path";
import { getRunStreamStats } from "../commands/run-stream";
import { getMccGlobals } from "../queue/process-globals";
import { prisma } from "../db";

function mb(bytes: number): number {
  return Math.round((bytes / (1024 * 1024)) * 10) / 10;
}

function sqliteFilePathFromEnv(): string | null {
  const url = process.env.DATABASE_URL ?? "";
  const match = url.match(/^file:(.+)$/);
  if (!match) return null;
  const raw = match[1].trim();
  if (path.isAbsolute(raw)) return raw;
  return path.resolve(process.cwd(), raw);
}

function countActiveHandles(): number | null {
  const proc = process as NodeJS.Process & {
    _getActiveHandles?: () => unknown[];
  };
  if (typeof proc._getActiveHandles !== "function") return null;
  try {
    return proc._getActiveHandles().length;
  } catch {
    return null;
  }
}

function countActiveRequests(): number | null {
  const proc = process as NodeJS.Process & {
    _getActiveRequests?: () => unknown[];
  };
  if (typeof proc._getActiveRequests !== "function") return null;
  try {
    return proc._getActiveRequests().length;
  } catch {
    return null;
  }
}

export interface MemoryDiagnostics {
  generatedAt: string;
  nodeEnv: string;
  nextRuntime: string | null;
  execArgv: string[];
  memory: ReturnType<typeof process.memoryUsage> & {
    rssMb: number;
    heapUsedMb: number;
    heapTotalMb: number;
    externalMb: number;
    arrayBuffersMb: number;
  };
  v8Heap: ReturnType<typeof v8.getHeapStatistics>;
  heapSpaces: Array<{
    name: string;
    sizeMb: number;
    usedMb: number;
    availableMb: number;
  }>;
  activeHandles: number | null;
  activeRequests: number | null;
  resourceUsage: NodeJS.ResourceUsage | null;
  mcc: {
    hasCommandPollTimer: boolean;
    runStream: ReturnType<typeof getRunStreamStats>;
    backgroundTimers: number;
    healthSchedulerStarted: boolean;
  };
  database: {
    fileSizeMb: number | null;
    apiRequestLogs: number;
    capturedOutputBytes: number;
    largestRunOutputBytes: number;
  };
  assessment: string[];
  recommendations: string[];
}

export async function collectMemoryDiagnostics(): Promise<MemoryDiagnostics> {
  const mem = process.memoryUsage();
  const v8Heap = v8.getHeapStatistics();
  const heapSpaces = v8.getHeapSpaceStatistics().map((space) => ({
    name: space.space_name,
    sizeMb: mb(space.space_size),
    usedMb: mb(space.space_used_size),
    availableMb: mb(space.space_available_size),
  }));

  const streamStats = getRunStreamStats();
  const bg = getMccGlobals().background;
  let backgroundTimers = 0;
  if (bg?.maintenance) backgroundTimers += 1;
  if (bg?.schedule) backgroundTimers += 1;
  if (bg?.updates) backgroundTimers += 1;
  if (bg?.health) backgroundTimers += 1;

  const filePath = sqliteFilePathFromEnv();
  let fileSizeMb: number | null = null;
  if (filePath) {
    try {
      fileSizeMb = mb(fs.statSync(filePath).size);
    } catch {
      fileSizeMb = null;
    }
  }

  const [apiRequestLogs, outputAgg] = await Promise.all([
    prisma.apiRequestLog.count(),
    prisma.$queryRaw<Array<{ total: bigint | number | null; maxLen: bigint | number | null }>>`
      SELECT
        COALESCE(SUM(LENGTH(stdout) + LENGTH(stderr)), 0) AS total,
        COALESCE(MAX(LENGTH(stdout) + LENGTH(stderr)), 0) AS maxLen
      FROM CommandRun
    `,
  ]);

  const totalOut = outputAgg[0]?.total ?? 0;
  const maxOut = outputAgg[0]?.maxLen ?? 0;
  const capturedOutputBytes = Number(totalOut);
  const largestRunOutputBytes = Number(maxOut);

  const heapUsedMb = mb(mem.heapUsed);
  const rssMb = mb(mem.rss);
  const nodeEnv = process.env.NODE_ENV ?? "unknown";

  const assessment: string[] = [];
  const recommendations: string[] = [];

  if (nodeEnv === "development" && heapUsedMb > 600) {
    assessment.push(
      `Heap ${heapUsedMb} MB in development — Next.js dev compiler/HMR commonly holds 800MB–2GB+; this is often not an app data leak.`,
    );
    recommendations.push(
      "Run production mode locally: ./scripts/start.sh prod (build + next start) — typically 150–400 MB RSS.",
    );
  } else if (heapUsedMb > 800) {
    assessment.push(`Heap ${heapUsedMb} MB is high for ${nodeEnv} mode — investigate runtime buffers and restart.`);
  }

  if (rssMb > 1500) {
    assessment.push(`RSS ${rssMb} MB — process retained memory (includes heap, native, Turbopack/Webpack cache in dev).`);
  }

  if (streamStats.bufferedChars > 100_000 || streamStats.activeStreams > 20) {
    assessment.push("Elevated in-memory command stream buffers.");
    recommendations.push("Close Commands live-output tabs; wait for runs to finish or restart the app.");
  }

  if (backgroundTimers > 4) {
    assessment.push(`Background timer count ${backgroundTimers} — possible duplicate intervals after hot reload.`);
    recommendations.push("Restart the Node process (./scripts/start.sh stop && ./scripts/start.sh local).");
  }

  if (apiRequestLogs > 10_000) {
    assessment.push(`${apiRequestLogs} API log rows — extra Prisma/ SQLite work on logged routes.`);
    recommendations.push("Logs → Wipe API logs; set API_LOG_RETENTION_DAYS (default 14) and wait for maintenance purge.");
  }

  if (capturedOutputBytes > 50_000_000) {
    assessment.push("Large total command output stored in SQLite — list/history queries cost more when full runs are fetched.");
  }

  const activeHandles = countActiveHandles();
  if (activeHandles !== null && activeHandles > 200) {
    assessment.push(`${activeHandles} active handles — many open sockets/timers/streams.`);
  }

  let resourceUsage: NodeJS.ResourceUsage | null = null;
  try {
    resourceUsage = process.resourceUsage();
  } catch {
    resourceUsage = null;
  }

  return {
    generatedAt: new Date().toISOString(),
    nodeEnv,
    nextRuntime: process.env.NEXT_RUNTIME ?? null,
    execArgv: process.execArgv,
    memory: {
      ...mem,
      rssMb,
      heapUsedMb,
      heapTotalMb: mb(mem.heapTotal),
      externalMb: mb(mem.external),
      arrayBuffersMb: mb(mem.arrayBuffers ?? 0),
    },
    v8Heap,
    heapSpaces,
    activeHandles,
    activeRequests: countActiveRequests(),
    resourceUsage,
    mcc: {
      hasCommandPollTimer: Boolean(getMccGlobals().commandPollTimer),
      runStream: streamStats,
      backgroundTimers,
      healthSchedulerStarted: Boolean(bg?.healthSchedulerStarted),
    },
    database: {
      fileSizeMb,
      apiRequestLogs,
      capturedOutputBytes,
      largestRunOutputBytes,
    },
    assessment,
    recommendations,
  };
}

export function formatMemoryDiagnosticsReport(d: MemoryDiagnostics): string {
  const lines: string[] = [
    "MyControl Centre — memory diagnostics",
    `Generated: ${d.generatedAt}`,
    "",
    "=== Process ===",
    `NODE_ENV=${d.nodeEnv}  NEXT_RUNTIME=${d.nextRuntime ?? "n/a"}  PID=${process.pid}`,
    `Uptime: ${Math.round(process.uptime())}s`,
    `execArgv: ${d.execArgv.join(" ") || "(none)"}`,
    "",
    "=== Memory (process.memoryUsage) ===",
    `RSS:          ${d.memory.rssMb} MB`,
    `Heap used:    ${d.memory.heapUsedMb} MB`,
    `Heap total:   ${d.memory.heapTotalMb} MB`,
    `External:     ${d.memory.externalMb} MB`,
    `ArrayBuffers: ${d.memory.arrayBuffersMb} MB`,
    "",
    "=== V8 heap ===",
    `total_heap_size: ${mb(d.v8Heap.total_heap_size)} MB`,
    `used_heap_size:  ${mb(d.v8Heap.used_heap_size)} MB`,
    `heap_size_limit: ${mb(d.v8Heap.heap_size_limit)} MB`,
    `malloced_memory: ${mb(d.v8Heap.malloced_memory)} MB`,
    "",
    "=== Heap spaces ===",
    ...d.heapSpaces.map(
      (s) => `  ${s.name.padEnd(22)} used ${String(s.usedMb).padStart(8)} MB / size ${s.sizeMb} MB`,
    ),
    "",
    "=== Active resources ===",
    `Handles:  ${d.activeHandles ?? "n/a"}`,
    `Requests: ${d.activeRequests ?? "n/a"}`,
    "",
    "=== MCC runtime (__mcc on globalThis) ===",
    `Command poll timer: ${d.mcc.hasCommandPollTimer}`,
    `Background timers:  ${d.mcc.backgroundTimers}`,
    `Health scheduler:   ${d.mcc.healthSchedulerStarted}`,
    `Run streams:        ${d.mcc.runStream.activeStreams}`,
    `SSE listeners:      ${d.mcc.runStream.listenerCount}`,
    `Buffered events:    ${d.mcc.runStream.bufferedEvents}`,
    `Buffered chars:     ${d.mcc.runStream.bufferedChars}`,
    "",
    "=== Database ===",
    `File size:          ${d.database.fileSizeMb ?? "?"} MB`,
    `API request logs:   ${d.database.apiRequestLogs}`,
    `Captured output:    ${d.database.capturedOutputBytes} bytes (all runs)`,
    `Largest run output: ${d.database.largestRunOutputBytes} bytes`,
    "",
    "=== Assessment ===",
    ...(d.assessment.length ? d.assessment.map((a) => `- ${a}`) : ["- No automatic issues flagged."]),
    "",
    "=== Recommendations ===",
    ...(d.recommendations.length
      ? d.recommendations.map((r) => `- ${r}`)
      : ["- Restart after long dev sessions; use prod mode for steady-state memory."]),
    "",
  ];
  return lines.join("\n");
}
