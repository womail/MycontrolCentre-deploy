import fs from "fs";
import path from "path";
import { prisma } from "../db";
import { getRunStreamStats } from "../commands/run-stream";
import { getMccGlobals } from "../queue/process-globals";

export interface SystemProfile {
  generatedAt: string;
  process: {
    uptimeSec: number;
    nodeVersion: string;
    platform: string;
    pid: number;
    embeddedWorker: boolean;
    nodeEnv: string;
  };
  memory: {
    rssMb: number;
    heapUsedMb: number;
    heapTotalMb: number;
    externalMb: number;
  };
  database: {
    pingMs: number;
    filePath: string | null;
    fileSizeMb: number | null;
    counts: {
      servers: number;
      commandRuns: number;
      commandRunsPending: number;
      commandRunsRunning: number;
      auditLogs: number;
      remoteConnectionLogs: number;
      apiRequestLogs: number;
      serverGroups: number;
    };
  };
  hints: string[];
  runtime: {
    activeRunStreams: number;
    runStreamListeners: number;
    bufferedStreamEvents: number;
    bufferedStreamChars: number;
    backgroundTimers: number;
  };
}

function sqliteFilePathFromEnv(): string | null {
  const url = process.env.DATABASE_URL ?? "";
  const match = url.match(/^file:(.+)$/);
  if (!match) return null;
  const raw = match[1].trim();
  if (path.isAbsolute(raw)) return raw;
  return path.resolve(process.cwd(), raw);
}

function mb(bytes: number): number {
  return Math.round((bytes / (1024 * 1024)) * 10) / 10;
}

export async function collectSystemProfile(): Promise<SystemProfile> {
  const mem = process.memoryUsage();
  const dbStart = Date.now();
  await prisma.$queryRaw`SELECT 1`;
  const pingMs = Date.now() - dbStart;

  const [
    servers,
    commandRuns,
    commandRunsPending,
    commandRunsRunning,
    auditLogs,
    remoteConnectionLogs,
    apiRequestLogs,
    serverGroups,
  ] = await Promise.all([
    prisma.server.count(),
    prisma.commandRun.count(),
    prisma.commandRun.count({ where: { status: "PENDING" } }),
    prisma.commandRun.count({ where: { status: "RUNNING" } }),
    prisma.auditLog.count(),
    prisma.remoteConnectionLog.count(),
    prisma.apiRequestLog.count(),
    prisma.serverGroup.count(),
  ]);

  const filePath = sqliteFilePathFromEnv();
  let fileSizeMb: number | null = null;
  if (filePath) {
    try {
      const stat = fs.statSync(filePath);
      fileSizeMb = mb(stat.size);
    } catch {
      fileSizeMb = null;
    }
  }

  const hints: string[] = [];
  const heapUsedMb = mb(mem.heapUsed);
  if (apiRequestLogs > 50_000) {
    hints.push("API request log table is large — use Logs → Wipe API logs or reduce polling.");
  }
  if (auditLogs > 100_000) {
    hints.push("Audit log table is large — review retention or wipe audit logs.");
  }
  if (remoteConnectionLogs > 50_000) {
    hints.push("Remote SSH log table is large — wipe remote logs if not needed.");
  }
  if (commandRuns > 20_000) {
    hints.push("Command run history is large — use dashboard cleanup for failed runs.");
  }
  if (commandRunsPending + commandRunsRunning > 10) {
    hints.push("Many queued/running commands — check worker load and SSH concurrency.");
  }
  if (heapUsedMb > 400) {
    const env = process.env.NODE_ENV ?? "unknown";
    if (env === "development") {
      hints.push(
        "Node heap is high — normal for `next dev`. Use ./scripts/start.sh prod for ~150–400 MB RSS, or restart dev after long sessions.",
      );
    } else {
      hints.push(
        "Node heap is high — open Admin memory diagnostics, close Commands streaming tabs, then restart the app.",
      );
    }
  }
  if (pingMs > 100) {
    hints.push("SQLite ping is slow — disk contention or very large database file.");
  }

  const streamStats = getRunStreamStats();
  if (streamStats.activeStreams > 40) {
    hints.push("Many in-memory command stream buffers — close stale run output tabs or restart the app.");
  }
  if (streamStats.listenerCount > 20) {
    hints.push("Many open live run SSE listeners — memory will stay elevated until they disconnect.");
  }
  if (streamStats.bufferedChars > 500_000) {
    hints.push("Large in-memory run output buffers — finish or cancel active runs, or restart the app.");
  }

  const bg = getMccGlobals().background;
  let backgroundTimers = 0;
  if (bg?.maintenance) backgroundTimers += 1;
  if (bg?.schedule) backgroundTimers += 1;
  if (bg?.updates) backgroundTimers += 1;
  if (bg?.health) backgroundTimers += 1;
  if (backgroundTimers > 5) {
    hints.push("Unexpected number of background timers — restart the app (often caused by dev hot reload).");
  }

  return {
    generatedAt: new Date().toISOString(),
    process: {
      uptimeSec: Math.round(process.uptime()),
      nodeVersion: process.version,
      platform: process.platform,
      pid: process.pid,
      embeddedWorker: process.env.RUN_EMBEDDED_WORKER === "true",
      nodeEnv: process.env.NODE_ENV ?? "unknown",
    },
    memory: {
      rssMb: mb(mem.rss),
      heapUsedMb,
      heapTotalMb: mb(mem.heapTotal),
      externalMb: mb(mem.external),
    },
    database: {
      pingMs,
      filePath,
      fileSizeMb,
      counts: {
        servers,
        commandRuns,
        commandRunsPending,
        commandRunsRunning,
        auditLogs,
        remoteConnectionLogs,
        apiRequestLogs,
        serverGroups,
      },
    },
    hints,
    runtime: {
      activeRunStreams: streamStats.activeStreams,
      runStreamListeners: streamStats.listenerCount,
      bufferedStreamEvents: streamStats.bufferedEvents,
      bufferedStreamChars: streamStats.bufferedChars,
      backgroundTimers,
    },
  };
}
