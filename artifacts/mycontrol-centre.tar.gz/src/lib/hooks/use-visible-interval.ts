"use client";

import { useEffect, useRef } from "react";

/** Runs callback on an interval only while the document tab is visible. */
export function useVisibleInterval(callback: () => void, ms: number, enabled = true) {
  const saved = useRef(callback);
  saved.current = callback;

  useEffect(() => {
    if (!enabled || ms <= 0) return;

    function tick() {
      if (typeof document !== "undefined" && document.hidden) return;
      saved.current();
    }

    tick();
    const id = setInterval(tick, ms);
    const onVis = () => {
      if (!document.hidden) tick();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      clearInterval(id);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [ms, enabled]);
}
