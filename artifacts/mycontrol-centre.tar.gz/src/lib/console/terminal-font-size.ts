export const TERMINAL_FONT_MIN = 10;
export const TERMINAL_FONT_MAX = 24;
export const TERMINAL_FONT_DEFAULT = 14;
export const UI_TABLE_FONT_STORAGE_KEY = "mcc_table_font_size";
/** @deprecated alias — same preference as table font */
export const TERMINAL_FONT_STORAGE_KEY = UI_TABLE_FONT_STORAGE_KEY;

export function clampTerminalFontSize(size: number): number {
  return Math.min(TERMINAL_FONT_MAX, Math.max(TERMINAL_FONT_MIN, Math.round(size)));
}

export function readStoredTerminalFontSize(): number {
  if (typeof window === "undefined") return TERMINAL_FONT_DEFAULT;
  const raw =
    window.localStorage.getItem(UI_TABLE_FONT_STORAGE_KEY) ??
    window.localStorage.getItem("mcc_console_font_size");
  if (!raw) return TERMINAL_FONT_DEFAULT;
  const parsed = parseInt(raw, 10);
  if (Number.isNaN(parsed)) return TERMINAL_FONT_DEFAULT;
  return clampTerminalFontSize(parsed);
}

export function storeTerminalFontSize(size: number) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(UI_TABLE_FONT_STORAGE_KEY, String(clampTerminalFontSize(size)));
}
