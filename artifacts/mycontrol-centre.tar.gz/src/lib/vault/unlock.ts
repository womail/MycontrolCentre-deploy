import { createHmac, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";

export const VAULT_UNLOCK_COOKIE = "mcc_vault_unlock";
const VAULT_UNLOCK_MS = 15 * 60 * 1000;

function signingSecret(): string {
  const vault = process.env.SECRETS_VAULT_PASSWORD?.trim();
  if (vault) return vault;
  return process.env.SESSION_SECRET ?? "";
}

export function isVaultConfigured(): boolean {
  return Boolean(process.env.SECRETS_VAULT_PASSWORD?.trim());
}

export function verifyVaultPassword(password: string): boolean {
  const expected = process.env.SECRETS_VAULT_PASSWORD?.trim();
  if (!expected) return false;
  const a = Buffer.from(password, "utf8");
  const b = Buffer.from(expected, "utf8");
  if (a.length !== b.length) {
    timingSafeEqual(a, a);
    return false;
  }
  return timingSafeEqual(a, b);
}

export function createVaultUnlockToken(): string {
  const exp = Date.now() + VAULT_UNLOCK_MS;
  const sig = createHmac("sha256", signingSecret()).update(String(exp)).digest("base64url");
  return `${exp}.${sig}`;
}

export function isValidVaultUnlockToken(token: string | undefined): boolean {
  if (!token || !isVaultConfigured()) return false;
  const dot = token.lastIndexOf(".");
  if (dot <= 0) return false;
  const expStr = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  const exp = Number(expStr);
  if (!Number.isFinite(exp) || exp < Date.now()) return false;
  const expected = createHmac("sha256", signingSecret()).update(expStr).digest("base64url");
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

export async function hasVaultUnlock(): Promise<boolean> {
  const store = await cookies();
  return isValidVaultUnlockToken(store.get(VAULT_UNLOCK_COOKIE)?.value);
}

export function vaultUnlockCookieOptions(secure: boolean) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure,
    path: "/",
    maxAge: VAULT_UNLOCK_MS / 1000,
  };
}
