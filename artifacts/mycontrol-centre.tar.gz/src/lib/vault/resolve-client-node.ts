import dns from "dns/promises";

const REVERSE_DNS_MS = 800;

/** Best-effort PTR / reverse DNS for the client IP (admin workstation on LAN). */
export async function resolveClientNode(ip: string | null | undefined): Promise<string | null> {
  const trimmed = ip?.trim();
  if (!trimmed) return null;
  if (trimmed === "127.0.0.1" || trimmed === "::1") return "localhost";

  try {
    const names = await Promise.race([
      dns.reverse(trimmed),
      new Promise<string[]>((_, reject) =>
        setTimeout(() => reject(new Error("timeout")), REVERSE_DNS_MS),
      ),
    ]);
    const host = names[0]?.trim();
    if (!host) return null;
    return host.split(".")[0] || host;
  } catch {
    return null;
  }
}

export function formatClientNodeDisplay(input: {
  clientNode?: string | null;
  ipAddress?: string | null;
}): string {
  const node = input.clientNode?.trim();
  const ip = input.ipAddress?.trim();
  if (node && ip) return `${node} (${ip})`;
  if (node) return node;
  if (ip) return ip;
  return "Unknown node";
}
