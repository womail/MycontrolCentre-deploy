const STORAGE_KEY = "mcc_vault_client_node";

/** Admin workstation label (optional); sent as X-MCC-Client-Node on vault API calls. */
export function getVaultClientNode(): string {
  if (typeof localStorage === "undefined") return "";
  return localStorage.getItem(STORAGE_KEY)?.trim() ?? "";
}

export function setVaultClientNode(name: string): void {
  if (typeof localStorage === "undefined") return;
  const trimmed = name.trim();
  if (trimmed) localStorage.setItem(STORAGE_KEY, trimmed);
  else localStorage.removeItem(STORAGE_KEY);
}

/** Short label sent with vault API calls to identify the admin browser/host. */
export function vaultClientLabel(): string {
  if (typeof navigator === "undefined") return "";
  const platform = navigator.platform?.trim() || "unknown platform";
  const ua = navigator.userAgent?.trim() || "";
  return ua.length > 100 ? `${platform} · ${ua.slice(0, 100)}…` : `${platform} · ${ua}`;
}

export function vaultClientHeaders(): HeadersInit {
  const headers: Record<string, string> = {};
  const label = vaultClientLabel();
  const node = getVaultClientNode();
  if (label) headers["X-MCC-Client-Label"] = label;
  if (node) headers["X-MCC-Client-Node"] = node;
  return headers;
}
