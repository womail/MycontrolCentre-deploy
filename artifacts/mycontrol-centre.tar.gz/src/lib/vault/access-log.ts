import type { VaultAccessAction, VaultEntryType } from "@prisma/client";
import { prisma } from "@/lib/db";
import { formatClientNodeDisplay, resolveClientNode } from "@/lib/vault/resolve-client-node";

export function formatVaultMachine(input: {
  ipAddress?: string | null;
  userAgent?: string | null;
  clientLabel?: string | null;
}): string {
  const parts: string[] = [];
  if (input.clientLabel?.trim()) parts.push(input.clientLabel.trim());
  if (input.ipAddress?.trim()) parts.push(input.ipAddress.trim());
  const ua = input.userAgent?.trim() ?? "";
  if (ua) {
    const browser =
      ua.match(/Edg\/[\d.]+/)?.[0]?.replace("Edg/", "Edge ") ??
      ua.match(/Chrome\/[\d.]+/)?.[0]?.replace("Chrome/", "Chrome ") ??
      ua.match(/Firefox\/[\d.]+/)?.[0]?.replace("Firefox/", "Firefox ") ??
      ua.match(/Safari\/[\d.]+/)?.[0]?.replace("Safari/", "Safari ") ??
      ua.slice(0, 48);
    const os =
      ua.includes("Windows") ? "Windows" :
      ua.includes("Mac OS") ? "macOS" :
      ua.includes("Android") ? "Android" :
      ua.includes("Linux") ? "Linux" :
      null;
    if (os) parts.push(os);
    if (browser) parts.push(browser);
  }
  return parts.length > 0 ? parts.join(" · ") : "Unknown client";
}

export async function logVaultEntryAccess(input: {
  userId: string;
  entryType: VaultEntryType;
  entryId: string;
  entryLabel?: string;
  action: VaultAccessAction;
  ipAddress?: string | null;
  userAgent?: string | null;
  clientLabel?: string | null;
  clientNodeHint?: string | null;
}) {
  let clientNode = input.clientNodeHint?.trim() || null;
  if (!clientNode) {
    clientNode = await resolveClientNode(input.ipAddress);
  }

  await prisma.vaultAccessLog.create({
    data: {
      userId: input.userId,
      entryType: input.entryType,
      entryId: input.entryId,
      entryLabel: input.entryLabel ?? null,
      action: input.action,
      ipAddress: input.ipAddress ?? null,
      userAgent: input.userAgent ?? null,
      clientLabel: input.clientLabel ?? null,
      clientNode,
    },
  });
}

export type VaultLastAccess = {
  at: Date;
  action: VaultAccessAction;
  username: string;
  ipAddress: string | null;
  clientNode: string;
  machine: string;
  targetNode: string | null;
};

export async function getLatestVaultAccessByEntry(
  entryType: VaultEntryType,
  entryIds: string[],
  targetNodeByEntryId?: Map<string, string>,
): Promise<Map<string, VaultLastAccess>> {
  const map = new Map<string, VaultLastAccess>();
  if (entryIds.length === 0) return map;

  const logs = await prisma.vaultAccessLog.findMany({
    where: { entryType, entryId: { in: entryIds } },
    orderBy: { createdAt: "desc" },
    take: Math.min(entryIds.length * 8, 500),
    include: { user: { select: { username: true } } },
  });

  for (const log of logs) {
    if (map.has(log.entryId)) continue;
    map.set(log.entryId, {
      at: log.createdAt,
      action: log.action,
      username: log.user.username,
      ipAddress: log.ipAddress,
      clientNode: formatClientNodeDisplay({
        clientNode: log.clientNode,
        ipAddress: log.ipAddress,
      }),
      machine: formatVaultMachine({
        ipAddress: log.ipAddress,
        userAgent: log.userAgent,
        clientLabel: log.clientLabel,
      }),
      targetNode: targetNodeByEntryId?.get(log.entryId) ?? null,
    });
  }
  return map;
}
