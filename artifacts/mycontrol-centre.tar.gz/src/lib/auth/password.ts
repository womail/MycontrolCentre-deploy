import bcrypt from "bcryptjs";
import { prisma } from "../db";
import type { UserRole } from "@prisma/client";

const BCRYPT_ROUNDS = 12;

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}

export async function verifyPassword(
  password: string,
  hash: string,
): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function validatePasswordStrength(password: string): string | null {
  if (password.length < 12) {
    return "Password must be at least 12 characters";
  }
  if (!/[A-Z]/.test(password)) {
    return "Password must contain at least one uppercase letter";
  }
  if (!/[a-z]/.test(password)) {
    return "Password must contain at least one lowercase letter";
  }
  if (!/[0-9]/.test(password)) {
    return "Password must contain at least one number";
  }
  return null;
}

export async function authenticateUser(
  username: string,
  password: string,
) {
  const user = await prisma.user.findUnique({ where: { username } });
  if (!user || !user.isActive) return null;
  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) return null;
  return user;
}

export async function createUser(data: {
  username: string;
  password: string;
  role: UserRole;
  mustChangePassword?: boolean;
}) {
  const strengthError = validatePasswordStrength(data.password);
  if (strengthError && !data.mustChangePassword) {
    throw new Error(strengthError);
  }

  return prisma.user.create({
    data: {
      username: data.username,
      passwordHash: await hashPassword(data.password),
      role: data.role,
      mustChangePassword: data.mustChangePassword ?? false,
    },
  });
}

export async function changePassword(
  userId: string,
  newPassword: string,
): Promise<void> {
  const strengthError = validatePasswordStrength(newPassword);
  if (strengthError) throw new Error(strengthError);

  await prisma.user.update({
    where: { id: userId },
    data: {
      passwordHash: await hashPassword(newPassword),
      mustChangePassword: false,
    },
  });
}
