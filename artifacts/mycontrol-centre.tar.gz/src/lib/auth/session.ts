import { createHash, randomBytes, timingSafeEqual } from "crypto";
import type { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "../db";
import type { User, UserRole } from "@prisma/client";

import { SESSION_COOKIE } from "./constants";

const SESSION_MAX_AGE_HOURS = parseInt(
  process.env.SESSION_MAX_AGE_HOURS ?? "24",
  10,
);

/** Secure cookies require HTTPS; default off for http:// APP_URL and LAN Docker. */
export function sessionCookieSecure(request?: { headers: Headers }): boolean {
  const flag = process.env.SESSION_COOKIE_SECURE?.trim().toLowerCase();
  if (flag === "true" || flag === "1" || flag === "yes") return true;
  if (flag === "false" || flag === "0" || flag === "no") return false;

  if (request) {
    const forwarded = request.headers.get("x-forwarded-proto")?.split(",")[0]?.trim().toLowerCase();
    if (forwarded === "https") return true;
    if (forwarded === "http") return false;
  }

  const appUrl = (process.env.APP_URL ?? "http://localhost:3000").trim().toLowerCase();
  if (appUrl.startsWith("https://")) return true;

  return false;
}

function hashToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

export function generateSessionToken(): string {
  return randomBytes(32).toString("base64url");
}

export async function createSession(
  userId: string,
  ipAddress?: string,
  userAgent?: string,
): Promise<string> {
  const token = generateSessionToken();
  const expiresAt = new Date(
    Date.now() + SESSION_MAX_AGE_HOURS * 60 * 60 * 1000,
  );

  await prisma.session.create({
    data: {
      tokenHash: hashToken(token),
      userId,
      ipAddress,
      userAgent,
      expiresAt,
    },
  });

  return token;
}

export async function getSessionUser(): Promise<
  (User & { sessionId: string }) | null
> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  const session = await prisma.session.findUnique({
    where: { tokenHash: hashToken(token) },
    include: { user: true },
  });

  if (!session || session.expiresAt < new Date() || !session.user.isActive) {
    return null;
  }

  return { ...session.user, sessionId: session.id };
}

export async function destroySession(): Promise<void> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (token) {
    await prisma.session.deleteMany({
      where: { tokenHash: hashToken(token) },
    });
  }
  cookieStore.delete(SESSION_COOKIE);
}

export async function destroyAllUserSessions(userId: string): Promise<void> {
  await prisma.session.deleteMany({ where: { userId } });
}

export function setSessionCookie(token: string, request?: { headers: Headers }): {
  name: string;
  value: string;
  httpOnly: boolean;
  secure: boolean;
  sameSite: "lax";
  path: string;
  maxAge: number;
} {
  return {
    name: SESSION_COOKIE,
    value: token,
    httpOnly: true,
    secure: sessionCookieSecure(request),
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_MAX_AGE_HOURS * 60 * 60,
  };
}

export function applySessionCookie(
  response: NextResponse,
  token: string,
  request?: { headers: Headers },
): void {
  const cookie = setSessionCookie(token, request);
  const options: {
    httpOnly: boolean;
    sameSite: "lax";
    path: string;
    maxAge: number;
    secure?: boolean;
  } = {
    httpOnly: cookie.httpOnly,
    sameSite: cookie.sameSite,
    path: cookie.path,
    maxAge: cookie.maxAge,
  };
  if (cookie.secure) {
    options.secure = true;
  }
  response.cookies.set(cookie.name, cookie.value, options);
}

export function hasRole(user: User, ...roles: UserRole[]): boolean {
  return roles.includes(user.role);
}

export function canManageUsers(user: User): boolean {
  return user.role === "ADMIN";
}

export function canManageServers(user: User): boolean {
  return user.role === "ADMIN";
}

export function canRunCommands(user: User): boolean {
  return user.role === "ADMIN" || user.role === "OPERATOR";
}

export function canViewOnly(user: User): boolean {
  return user.role === "VIEWER";
}

export function safeCompare(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}
