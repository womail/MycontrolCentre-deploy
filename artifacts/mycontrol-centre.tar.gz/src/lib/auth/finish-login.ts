import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { createSession, applySessionCookie } from "@/lib/auth/session";
import { logAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/rate-limit";

export async function finishLoginSession(
  userId: string,
  req: NextRequest,
): Promise<NextResponse> {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user || !user.isActive) {
    return NextResponse.json({ error: "Account unavailable" }, { status: 403 });
  }

  const ip = getClientIp(req.headers);
  const token = await createSession(user.id, ip, req.headers.get("user-agent") ?? undefined);

  await logAudit({
    userId: user.id,
    action: "LOGIN",
    ipAddress: ip,
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  const response = NextResponse.json({
    user: {
      id: user.id,
      username: user.username,
      role: user.role,
      mustChangePassword: user.mustChangePassword,
    },
  });
  applySessionCookie(response, token, req);
  return response;
}
