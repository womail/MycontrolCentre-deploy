export const SESSION_COOKIE = "mcc_session";
