import { describe, expect, it } from "vitest";
import { groupTemplatesByCategory } from "@/lib/commands/categories";

describe("groupTemplatesByCategory", () => {
  it("includes disk category templates in the Run picker", () => {
    const groups = groupTemplatesByCategory([
      { name: "APT Clean Cache", category: "disk", sortOrder: 42 },
      { name: "APT Update", category: "apt", sortOrder: 30 },
    ]);
    expect(groups.map((g) => g.category)).toContain("disk");
    expect(groups.find((g) => g.category === "disk")?.templates[0].name).toBe("APT Clean Cache");
  });
});
