import { describe, expect, it } from "vitest";
import { generateKeyPairSync } from "crypto";
import { utils } from "ssh2";
import { generateSshKeyPair } from "@/lib/setup/ssh-keygen";
import { pkcs8Ed25519PemToOpenSSH } from "@/lib/ssh/pkcs8-ed25519-to-openssh";
import { privateKeyForSsh2 } from "@/lib/ssh/private-key-for-ssh2";

describe("privateKeyForSsh2", () => {
  it("accepts OpenSSH keys from generateSshKeyPair", () => {
    const keys = generateSshKeyPair();
    const resolved = privateKeyForSsh2(keys.privateKey);
    expect(utils.parseKey(resolved)).not.toBeInstanceOf(Error);
  });

  it("converts legacy PKCS#8 Ed25519 PEM for ssh2", () => {
    const { privateKey } = generateKeyPairSync("ed25519", {
      publicKeyEncoding: { type: "spki", format: "pem" },
      privateKeyEncoding: { type: "pkcs8", format: "pem" },
    });
    expect(utils.parseKey(privateKey)).toBeInstanceOf(Error);

    const openssh = pkcs8Ed25519PemToOpenSSH(privateKey);
    expect(openssh).toContain("BEGIN OPENSSH PRIVATE KEY");
    expect(utils.parseKey(openssh!)).not.toBeInstanceOf(Error);

    const resolved = privateKeyForSsh2(privateKey);
    expect(resolved).toContain("BEGIN OPENSSH PRIVATE KEY");
  });
});
