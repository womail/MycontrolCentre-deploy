import { describe, expect, it } from "vitest";
import { filterTemplatesForServers } from "@/lib/commands/platform-filter";
import {
  effectivePlatforms,
  parseDetectOutput,
  parsePlatformList,
} from "@/lib/servers/platforms";

describe("platform filter", () => {
  it("shows all templates when no servers selected", () => {
    const templates = [{ id: "1", platforms: ["proxmox"] }];
    expect(filterTemplatesForServers(templates, [])).toEqual(templates);
  });

  it("filters proxmox commands for debian-only servers", () => {
    const templates = [
      { id: "1", platforms: ["all"] },
      { id: "2", platforms: ["proxmox"] },
      { id: "3", platforms: ["debian"] },
    ];
    const servers = [{ platforms: ["debian"] as const }];
    const filtered = filterTemplatesForServers(templates, servers);
    expect(filtered.map((template) => template.id)).toEqual(["1", "3"]);
  });

  it("requires compatibility with every selected server", () => {
    const templates = [
      { id: "1", platforms: ["debian"] },
      { id: "2", platforms: ["docker"] },
      { id: "3", platforms: ["all"] },
    ];
    const servers = [{ platforms: ["debian"] }, { platforms: ["docker"] }];
    const filtered = filterTemplatesForServers(templates, servers);
    expect(filtered.map((template) => template.id)).toEqual(["3"]);
  });

  it("shows debian templates on proxmox-only servers", () => {
    const templates = [{ id: "1", platforms: ["debian"] }];
    const servers = [{ platforms: ["proxmox"] as const }];
    expect(filterTemplatesForServers(templates, servers).map((t) => t.id)).toEqual(["1"]);
  });
});

describe("platform detection parsing", () => {
  it("parses detect command output", () => {
    expect(parseDetectOutput("proxmox\ndebian\ndocker\n")).toEqual([
      "proxmox",
      "debian",
      "docker",
    ]);
  });

  it("merges manual and detected platforms", () => {
    expect(
      effectivePlatforms({
        manualPlatforms: ["debian"],
        detectedPlatforms: ["docker"],
      }),
    ).toEqual(["debian", "docker"]);
  });

  it("defaults to generic when empty", () => {
    expect(effectivePlatforms({ manualPlatforms: [], detectedPlatforms: [] })).toEqual([
      "generic",
    ]);
    expect(parsePlatformList(["proxmox", "bad"])).toEqual(["proxmox"]);
  });
});
