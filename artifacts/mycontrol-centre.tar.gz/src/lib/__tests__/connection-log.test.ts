import { describe, it, expect } from "vitest";

describe("connection log retention", () => {
  it("uses AUDIT_LOG_RETENTION_DAYS env default", () => {
    const retentionDays = parseInt(process.env.AUDIT_LOG_RETENTION_DAYS ?? "365", 10);
    expect(retentionDays).toBeGreaterThan(0);
  });
});
