import { describe, it, expect, beforeEach, afterEach } from "vitest";
import type { User } from "@prisma/client";
import {
  hasRole,
  canManageUsers,
  canManageServers,
  canRunCommands,
  canViewOnly,
  safeCompare,
  generateSessionToken,
  setSessionCookie,
  sessionCookieSecure,
} from "@/lib/auth/session";
import { SESSION_COOKIE } from "@/lib/auth/constants";

function user(role: User["role"]): User {
  return {
    id: "u1",
    username: "test",
    passwordHash: "hash",
    role,
    mustChangePassword: false,
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  };
}

describe("role helpers", () => {
  it("hasRole matches assigned roles", () => {
    expect(hasRole(user("ADMIN"), "ADMIN", "OPERATOR")).toBe(true);
    expect(hasRole(user("VIEWER"), "ADMIN")).toBe(false);
  });

  it("canManageUsers is admin only", () => {
    expect(canManageUsers(user("ADMIN"))).toBe(true);
    expect(canManageUsers(user("OPERATOR"))).toBe(false);
  });

  it("canManageServers is admin only", () => {
    expect(canManageServers(user("ADMIN"))).toBe(true);
    expect(canManageServers(user("OPERATOR"))).toBe(false);
  });

  it("canRunCommands allows admin and operator", () => {
    expect(canRunCommands(user("ADMIN"))).toBe(true);
    expect(canRunCommands(user("OPERATOR"))).toBe(true);
    expect(canRunCommands(user("VIEWER"))).toBe(false);
  });

  it("canViewOnly is viewer only", () => {
    expect(canViewOnly(user("VIEWER"))).toBe(true);
    expect(canViewOnly(user("ADMIN"))).toBe(false);
  });
});

describe("safeCompare", () => {
  it("returns true for equal strings", () => {
    expect(safeCompare("abc", "abc")).toBe(true);
  });

  it("returns false for different strings", () => {
    expect(safeCompare("abc", "abd")).toBe(false);
  });

  it("returns false for different lengths", () => {
    expect(safeCompare("abc", "abcd")).toBe(false);
  });
});

describe("session tokens", () => {
  it("generateSessionToken returns url-safe string", () => {
    const token = generateSessionToken();
    expect(token.length).toBeGreaterThan(20);
    expect(token).toMatch(/^[A-Za-z0-9_-]+$/);
  });

  it("setSessionCookie returns secure httpOnly cookie config", () => {
    const cookie = setSessionCookie("test-token");
    expect(cookie.name).toBe(SESSION_COOKIE);
    expect(cookie.httpOnly).toBe(true);
    expect(cookie.sameSite).toBe("lax");
    expect(cookie.value).toBe("test-token");
  });
});

describe("sessionCookieSecure", () => {
  const env = process.env;

  beforeEach(() => {
    process.env = { ...env };
    delete process.env.SESSION_COOKIE_SECURE;
  });

  afterEach(() => {
    process.env = env;
  });

  it("is false for http APP_URL in production", () => {
    process.env.NODE_ENV = "production";
    process.env.APP_URL = "http://10.0.0.5:3000";
    expect(sessionCookieSecure()).toBe(false);
  });

  it("defaults to false when APP_URL unset (no production fallback)", () => {
    process.env.NODE_ENV = "production";
    delete process.env.APP_URL;
    expect(sessionCookieSecure()).toBe(false);
  });

  it("uses x-forwarded-proto http", () => {
    process.env.APP_URL = "https://ignored.example.com";
    const headers = new Headers({ "x-forwarded-proto": "http" });
    expect(sessionCookieSecure({ headers })).toBe(false);
  });

  it("is true for https APP_URL", () => {
    process.env.APP_URL = "https://mcc.example.com";
    expect(sessionCookieSecure()).toBe(true);
  });

  it("honors SESSION_COOKIE_SECURE=false", () => {
    process.env.NODE_ENV = "production";
    process.env.APP_URL = "https://mcc.example.com";
    process.env.SESSION_COOKIE_SECURE = "false";
    expect(sessionCookieSecure()).toBe(false);
  });
});
