import { describe, expect, it } from "vitest";
import { buildRemoteCleanupCommand } from "@/lib/setup/remote-cleanup";

describe("buildRemoteCleanupCommand", () => {
  it("includes curl, bash, and rm", () => {
    const cmd = buildRemoteCleanupCommand("http://10.0.0.1:3000", {
      publicKey: "ssh-ed25519 AAAA test",
    });
    expect(cmd).toContain("proxmox-host-cleanup.sh");
    expect(cmd).toContain("| sudo bash -s --");
    expect(cmd).toContain("--pubkey");
  });
});
