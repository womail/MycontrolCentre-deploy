import { describe, expect, it } from "vitest";
import { generateSshKeyPair } from "@/lib/setup/ssh-keygen";
import { fingerprintPublicKey } from "@/lib/enrollment/register";

describe("generateSshKeyPair", () => {
  it("returns OpenSSH ed25519 public line and PEM private key", () => {
    const keys = generateSshKeyPair();
    expect(keys.publicKey).toMatch(/^ssh-ed25519 AAAA/);
    expect(keys.publicKey).toContain("mycontrol-centre");
    expect(keys.privateKey).toContain("BEGIN OPENSSH PRIVATE KEY");
    expect(keys.fingerprint).toContain("SHA256:");
    expect(fingerprintPublicKey(keys.publicKey).length).toBeGreaterThan(10);
  });
});
