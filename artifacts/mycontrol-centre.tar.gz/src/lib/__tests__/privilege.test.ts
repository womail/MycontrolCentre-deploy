import { describe, expect, it } from "vitest";
import { encrypt } from "@/lib/crypto";
import {
  adaptCommandForServer,
  buildRemoteScriptExecution,
  dockerCliPrefix,
} from "@/lib/ssh/privilege";
import type { Server } from "@prisma/client";

function mockServer(overrides: Partial<Server> = {}): Server {
  return {
    id: "s1",
    name: "test",
    hostname: "10.0.0.1",
    port: 22,
    sshUser: "mcc-auto",
    authType: "KEY",
    encryptedPrivateKey: null,
    encryptedPassword: null,
    knownHostKey: null,
    acceptNewHostKey: false,
    tags: [],
    manualPlatforms: [],
    detectedPlatforms: [],
    healthStatus: "UNKNOWN",
    lastHealthCheck: null,
    healthMessage: null,
    isActive: true,
    inMaintenance: false,
    maintenanceNote: null,
    maintenanceUntil: null,
    proxmoxApiPort: 8006,
    proxmoxTokenId: null,
    encryptedProxmoxToken: null,
    proxmoxNodeName: null,
    proxmoxVersion: null,
    proxmoxSummary: null,
    lastProxmoxSync: null,
    lastBackupAt: null,
    lastBackupSource: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

describe("adaptCommandForServer", () => {
  it("strips sudo for root ssh user", () => {
    const server = mockServer({ sshUser: "root" });
    expect(adaptCommandForServer(server, "sudo apt-get update -qq")).toBe("apt-get update -qq");
  });

  it("rewrites legacy docker install pipe to temp script with sudo -n", () => {
    const server = mockServer();
    const script = "#!/bin/bash\necho hi";
    const b64 = Buffer.from(script).toString("base64");
    const legacy = `echo '${b64}' | base64 -d | sudo bash`;
    const adapted = adaptCommandForServer(server, legacy);
    expect(adapted).toContain("sudo -n bash");
    expect(adapted).toContain("/tmp/mcc-");
  });

  it("prefixes sudo apt with -S when ssh password is stored", () => {
    const server = mockServer({
      authType: "KEY_AND_PASSWORD",
      encryptedPassword: encrypt("secret-pass"),
    });
    const adapted = adaptCommandForServer(server, "sudo apt-get update -qq");
    expect(adapted).toContain("sudo -S apt-get update -qq");
    expect(adapted).toContain("secret-pass");
  });

  it("uses sudo -n for key-only automation user apt commands", () => {
    const adapted = adaptCommandForServer(
      mockServer(),
      "sudo apt-get clean && sudo apt-get autoclean -qq",
    );
    expect(adapted).toBe("sudo -n apt-get clean && sudo -n apt-get autoclean -qq");
  });
});

describe("dockerCliPrefix", () => {
  it("uses plain docker for root", () => {
    expect(dockerCliPrefix(mockServer({ sshUser: "root" }))).toBe("docker");
  });

  it("uses sudo -n docker for key-only automation user", () => {
    expect(dockerCliPrefix(mockServer())).toBe("sudo -n docker");
  });
});

describe("buildRemoteScriptExecution", () => {
  it("writes script to temp file before execution", () => {
    const cmd = buildRemoteScriptExecution(mockServer(), "echo test");
    expect(cmd).toMatch(/base64 -d > '\/tmp\/mcc-/);
    expect(cmd).toContain("sudo -n bash");
  });
});
