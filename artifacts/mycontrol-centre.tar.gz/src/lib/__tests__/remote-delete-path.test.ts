import { describe, expect, it } from "vitest";
import { validateSafeRemoteDeletePath } from "../ssh/remote-paths";

describe("validateSafeRemoteDeletePath", () => {
  it("allows normal user paths", () => {
    expect(validateSafeRemoteDeletePath("/home/mcc-auto/tmp")).toBe("/home/mcc-auto/tmp");
  });

  it("blocks filesystem root", () => {
    expect(() => validateSafeRemoteDeletePath("/")).toThrow(/root/i);
  });

  it("blocks /etc and children", () => {
    expect(() => validateSafeRemoteDeletePath("/etc/passwd")).toThrow(/protected/i);
  });
});
