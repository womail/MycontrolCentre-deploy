import { describe, it, expect } from "vitest";
import { buildCommand, buildCommandChain, BUILT_IN_COMMANDS } from "@/lib/commands/builder";

describe("buildCommand", () => {
  it("builds cd command with escaped path", () => {
    const result = buildCommand({ type: "CD", workingDir: "/var/log" });
    expect(result.commandText).toBe("cd '/var/log' && pwd");
    expect(result.workingDir).toBe("/var/log");
    expect(result.label).toContain("/var/log");
  });

  it("builds ls with working directory prefix", () => {
    const result = buildCommand({
      type: "LS",
      workingDir: "/opt",
      listPath: "apps",
    });
    expect(result.commandText).toBe("cd '/opt' && ls -la 'apps'");
  });

  it("builds apt update with non-interactive prefix", () => {
    const result = buildCommand({ type: "APT_UPDATE" });
    expect(result.commandText).toContain("DEBIAN_FRONTEND=noninteractive");
    expect(result.commandText).toContain("sudo apt-get update -qq");
  });

  it("builds apt upgrade with dpkg non-interactive options", () => {
    const result = buildCommand({ type: "APT_UPGRADE" });
    expect(result.commandText).toContain("sudo apt-get upgrade -y -qq");
    expect(result.commandText).toContain("force-confdef");
    expect(result.commandText).toContain("force-confold");
  });

  it("builds custom command in working directory", () => {
    const result = buildCommand({
      type: "CUSTOM",
      workingDir: "/root",
      customCommand: "uname -a",
    });
    expect(result.commandText).toBe("cd '/root' && uname -a");
  });

  it("rejects empty custom command", () => {
    expect(() => buildCommand({ type: "CUSTOM", customCommand: "  " })    ).toThrow("Command text is required");
  });

  it("rejects multi-line custom command", () => {
    expect(() =>
      buildCommand({ type: "CUSTOM", customCommand: "ls\nrm -rf /" }),
    ).toThrow("Multi-line commands are not allowed");
  });
});

describe("buildCommandChain", () => {
  it("chains multiple commands with set -e", () => {
    const result = buildCommandChain([
      { name: "APT Update", type: "APT_UPDATE", description: "update" },
      { name: "APT Upgrade", type: "APT_UPGRADE", description: "upgrade" },
    ]);
    expect(result.commandText).toMatch(/^set -e;/);
    expect(result.commandText).toContain("apt-get update");
    expect(result.commandText).toContain("apt-get upgrade");
    expect(result.label).toBe("APT Update → APT Upgrade");
  });
});

describe("BUILT_IN_COMMANDS", () => {
  it("includes all v1 command types", () => {
    const types = BUILT_IN_COMMANDS.map((c) => c.type);
    expect(types).toContain("CD");
    expect(types).toContain("LS");
    expect(types).toContain("APT_UPDATE");
    expect(types).toContain("APT_UPGRADE");
    expect(types).toContain("CUSTOM");
  });

  it("marks custom command as admin only", () => {
    const custom = BUILT_IN_COMMANDS.find((c) => c.type === "CUSTOM");
    expect(custom?.adminOnly).toBe(true);
  });
});
