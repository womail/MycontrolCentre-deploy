import { describe, it, expect } from "vitest";
import { parseTags, tagsToJson } from "@/lib/servers/tags";

describe("parseTags", () => {
  it("returns string array from json array", () => {
    expect(parseTags(["prod", "pve"])).toEqual(["prod", "pve"]);
  });

  it("filters non-strings", () => {
    expect(parseTags(["ok", 1, null])).toEqual(["ok"]);
  });

  it("returns empty for invalid input", () => {
    expect(parseTags(null)).toEqual([]);
    expect(parseTags("prod")).toEqual([]);
  });
});

describe("tagsToJson", () => {
  it("trims and filters empty tags", () => {
    expect(tagsToJson([" prod ", "", "lab"])).toEqual(["prod", "lab"]);
  });
});
