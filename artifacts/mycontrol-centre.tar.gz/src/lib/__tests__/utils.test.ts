import { describe, it, expect } from "vitest";
import { formatDate, formatDuration, cn } from "@/lib/utils";

describe("formatDate", () => {
  it("returns em dash for null", () => {
    expect(formatDate(null)).toBe("—");
  });

  it("formats valid dates", () => {
    const formatted = formatDate("2026-01-15T10:30:00.000Z");
    expect(formatted).toMatch(/2026/);
  });
});

describe("formatDuration", () => {
  it("returns em dash for null", () => {
    expect(formatDuration(null)).toBe("—");
  });

  it("formats milliseconds", () => {
    expect(formatDuration(450)).toBe("450ms");
  });

  it("formats seconds", () => {
    expect(formatDuration(5000)).toBe("5s");
  });

  it("formats minutes and seconds", () => {
    expect(formatDuration(125000)).toBe("2m 5s");
  });
});

describe("cn", () => {
  it("merges class names", () => {
    expect(cn("px-2", "py-1", false && "hidden", "font-bold")).toContain("px-2");
  });
});
