import { describe, expect, it } from "vitest";
import { createMfaPendingToken, verifyMfaPendingToken } from "@/lib/mfa/pending-token";

describe("MFA pending token", () => {
  it("round-trips user id", () => {
    process.env.SESSION_SECRET = "test-session-secret-at-least-32-chars!!";
    const token = createMfaPendingToken("user-1");
    const parsed = verifyMfaPendingToken(token);
    expect(parsed?.userId).toBe("user-1");
  });
});
