import { describe, expect, it } from "vitest";
import { requiresChangeReason, validateChangeReason } from "@/lib/commands/change-reason";
import { normalizeAlertSettings } from "@/lib/alerts/settings";

describe("change reason", () => {
  it("requires reason for multi-server or multi-command runs", () => {
    expect(requiresChangeReason(1, 1)).toBe(false);
    expect(requiresChangeReason(2, 1)).toBe(true);
    expect(requiresChangeReason(1, 2)).toBe(true);
  });

  it("validates required change reason", () => {
    expect(validateChangeReason(undefined, 2, 1)).toMatch(/required/i);
    expect(validateChangeReason("ab", 2, 1)).toMatch(/at least 3/i);
    expect(validateChangeReason("Weekly patch", 2, 1)).toBeNull();
    expect(validateChangeReason(undefined, 1, 1)).toBeNull();
  });
});

describe("alert settings", () => {
  it("normalizes defaults", () => {
    const settings = normalizeAlertSettings({});
    expect(settings.healthCheckIntervalMinutes).toBe(5);
    expect(settings.alertCooldownMinutes).toBe(30);
    expect(settings.skipAlertsInMaintenance).toBe(true);
  });

  it("clamps interval values", () => {
    const settings = normalizeAlertSettings({
      healthCheckIntervalMinutes: 9999,
      alertCooldownMinutes: 1,
    });
    expect(settings.healthCheckIntervalMinutes).toBe(5);
    expect(settings.alertCooldownMinutes).toBe(30);
  });
});
