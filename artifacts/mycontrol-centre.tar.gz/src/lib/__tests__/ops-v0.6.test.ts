import { describe, expect, it, vi } from "vitest";

vi.mock("@/lib/backup/settings", () => ({
  DEFAULT_BACKUP_MAX_AGE_HOURS: 168,
  getBackupMaxAgeHours: vi.fn(async () => 168),
  setBackupMaxAgeHours: vi.fn(async () => undefined),
}));

import {
  evaluateBackupFreshness,
  formatBackupAge,
} from "@/lib/backup/check-backup-freshness";
import { parseBackupProbeOutput } from "@/lib/backup/sync-server-backup";
import { isProfileScheduleDue } from "@/lib/schedules/run-profile-schedules";

describe("parseBackupProbeOutput", () => {
  it("parses vzdump log timestamps", () => {
    const result = parseBackupProbeOutput("vzdump:2024-06-15 03:00:01\n");
    expect(result.lastBackupSource).toBe("vzdump");
    expect(result.lastBackupAt?.toISOString()).toBe("2024-06-15T03:00:01.000Z");
  });

  it("parses zfs snapshot epochs", () => {
    const result = parseBackupProbeOutput("zfs:1718424000\n");
    expect(result.lastBackupSource).toBe("zfs");
    expect(result.lastBackupAt?.getTime()).toBe(1718424000 * 1000);
  });

  it("returns null for empty output", () => {
    expect(parseBackupProbeOutput("")).toEqual({
      lastBackupAt: null,
      lastBackupSource: null,
    });
  });
});

describe("evaluateBackupFreshness", () => {
  it("allows non-proxmox hosts without backup data", async () => {
    const result = await evaluateBackupFreshness({
      lastBackupAt: null,
      lastBackupSource: null,
      requiresFreshBackup: true,
      isProxmoxHost: false,
    });
    expect(result.stale).toBe(false);
  });

  it("blocks proxmox hosts with missing backups", async () => {
    const result = await evaluateBackupFreshness({
      lastBackupAt: null,
      lastBackupSource: null,
      requiresFreshBackup: true,
      isProxmoxHost: true,
    });
    expect(result.stale).toBe(true);
    expect(result.missing).toBe(true);
    expect(result.message).toMatch(/No recent vzdump/);
  });

  it("blocks stale backups beyond max age", async () => {
    const old = new Date(Date.now() - 200 * 60 * 60 * 1000);
    const result = await evaluateBackupFreshness({
      lastBackupAt: old,
      lastBackupSource: "vzdump",
      requiresFreshBackup: true,
      isProxmoxHost: true,
    });
    expect(result.stale).toBe(true);
    expect(result.message).toMatch(/max 168h/);
  });
});

describe("formatBackupAge", () => {
  it("formats hours and days", () => {
    expect(formatBackupAge(5)).toBe("5h ago");
    expect(formatBackupAge(48)).toBe("2d ago");
  });
});

describe("isProfileScheduleDue", () => {
  const base = {
    enabled: true,
    dayOfWeek: 1,
    hourUtc: 4,
    minuteUtc: 30,
    lastRunAt: null,
  };

  it("matches weekly UTC slot", () => {
    const now = new Date("2024-06-17T04:30:00.000Z");
    expect(isProfileScheduleDue(base, now)).toBe(true);
  });

  it("skips disabled schedules", () => {
    const now = new Date("2024-06-17T04:30:00.000Z");
    expect(isProfileScheduleDue({ ...base, enabled: false }, now)).toBe(false);
  });

  it("avoids duplicate runs in the same minute", () => {
    const now = new Date("2024-06-17T04:30:00.000Z");
    expect(
      isProfileScheduleDue({ ...base, lastRunAt: new Date("2024-06-17T04:30:10.000Z") }, now),
    ).toBe(false);
  });
});
