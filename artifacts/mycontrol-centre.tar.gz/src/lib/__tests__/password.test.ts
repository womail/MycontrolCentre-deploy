import { describe, it, expect } from "vitest";
import {
  validatePasswordStrength,
  hashPassword,
  verifyPassword,
} from "@/lib/auth/password";

describe("validatePasswordStrength", () => {
  it("accepts a strong password", () => {
    expect(validatePasswordStrength("SecurePass123")).toBeNull();
  });

  it("rejects short passwords", () => {
    expect(validatePasswordStrength("Short1A")).toMatch(/12 characters/);
  });

  it("requires uppercase", () => {
    expect(validatePasswordStrength("alllowercase1")).toMatch(/uppercase/);
  });

  it("requires lowercase", () => {
    expect(validatePasswordStrength("ALLUPPERCASE1")).toMatch(/lowercase/);
  });

  it("requires a digit", () => {
    expect(validatePasswordStrength("NoDigitsHereAB")).toMatch(/number/);
  });
});

describe("hashPassword / verifyPassword", () => {
  it("hashes and verifies correctly", async () => {
    const hash = await hashPassword("SecurePass123");
    expect(hash).not.toBe("SecurePass123");
    expect(await verifyPassword("SecurePass123", hash)).toBe(true);
    expect(await verifyPassword("WrongPassword1", hash)).toBe(false);
  });
});
