import { describe, expect, it } from "vitest";
import { generateSshKeyPair } from "@/lib/setup/ssh-keygen";
import {
  opensshSha256Fingerprint,
  opensshSha256FingerprintLabel,
  publicKeysMatch,
} from "@/lib/ssh/openssh-fingerprint";
import { fingerprintPublicKey } from "@/lib/enrollment/register";

describe("openssh-fingerprint", () => {
  it("matches generateSshKeyPair ssh-keygen -lf output", () => {
    const keys = generateSshKeyPair();
    const fromLine = opensshSha256Fingerprint(keys.publicKey);
    expect(fromLine).toBeTruthy();
    expect(keys.fingerprint).toContain(`SHA256:${fromLine}`);
    expect(opensshSha256FingerprintLabel(keys.publicKey)).toContain(`SHA256:${fromLine}`);
    expect(fingerprintPublicKey(keys.publicKey)).toBe(fromLine);
  });

  it("compares public keys by blob", () => {
    const keys = generateSshKeyPair();
    const copy = `${keys.publicKey.split(/\s+/)[0]} ${keys.publicKey.split(/\s+/)[1]} copy`;
    expect(publicKeysMatch(keys.publicKey, copy)).toBe(true);
  });
});
