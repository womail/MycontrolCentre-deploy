import { describe, expect, it } from "vitest";
import { clampShellCols, clampShellGeometry, clampShellRows } from "../ssh/shell-geometry";

describe("shell-geometry", () => {
  it("clamps cols to 300 max", () => {
    expect(clampShellCols(400)).toBe(300);
    expect(clampShellCols(40)).toBe(40);
  });

  it("clamps rows to 120 max", () => {
    expect(clampShellRows(200)).toBe(120);
  });

  it("clamps both dimensions", () => {
    expect(clampShellGeometry(500, 8)).toEqual({ cols: 300, rows: 8 });
  });
});
