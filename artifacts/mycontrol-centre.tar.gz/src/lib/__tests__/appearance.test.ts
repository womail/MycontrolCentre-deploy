import { describe, it, expect } from "vitest";
import {
  DEFAULT_APPEARANCE,
  mergeAppearance,
  parseAppearanceJson,
  appearanceSchema,
} from "@/lib/settings/appearance";

describe("appearance settings", () => {
  it("merges partial settings with defaults", () => {
    const merged = mergeAppearance({ primaryColor: "#ff0000", buttonSize: "lg" });
    expect(merged.primaryColor).toBe("#ff0000");
    expect(merged.buttonSize).toBe("lg");
    expect(merged.fontFamily).toBe(DEFAULT_APPEARANCE.fontFamily);
  });

  it("parses stored JSON", () => {
    const parsed = parseAppearanceJson(
      JSON.stringify({ buttonShape: "pill", fontSize: "sm" }),
    );
    expect(parsed.buttonShape).toBe("pill");
    expect(parsed.fontSize).toBe("sm");
  });

  it("returns empty object for invalid JSON", () => {
    expect(parseAppearanceJson("{not json")).toEqual({});
    expect(parseAppearanceJson('{"buttonSize":"xl"}')).toEqual({});
  });

  it("validates hex colors", () => {
    const ok = appearanceSchema.safeParse({ primaryColor: "#3b82f6" });
    const bad = appearanceSchema.safeParse({ primaryColor: "blue" });
    expect(ok.success).toBe(true);
    expect(bad.success).toBe(false);
  });
});
