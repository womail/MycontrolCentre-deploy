import { describe, it, expect } from "vitest";
import { encrypt, decrypt, redactSecrets } from "@/lib/crypto";

describe("crypto", () => {
  it("encrypts and decrypts round-trip", () => {
    const secret = "my-ssh-private-key-content";
    const ciphertext = encrypt(secret);
    expect(ciphertext).not.toContain(secret);
    expect(decrypt(ciphertext)).toBe(secret);
  });

  it("produces different ciphertext for same plaintext", () => {
    const a = encrypt("same");
    const b = encrypt("same");
    expect(a).not.toBe(b);
  });

  it("redacts password-like patterns", () => {
    const input = "connect password=SuperSecret123 token=abc";
    const redacted = redactSecrets(input);
    expect(redacted).toContain("password=[REDACTED]");
    expect(redacted).toContain("token=[REDACTED]");
    expect(redacted).not.toContain("SuperSecret123");
  });

  it("redacts PEM keys", () => {
    const pem = "-----BEGIN OPENSSH PRIVATE KEY-----\nabc\n-----END OPENSSH PRIVATE KEY-----";
    expect(redactSecrets(pem)).toBe("[REDACTED KEY]");
  });
});
