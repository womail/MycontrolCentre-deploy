import { describe, expect, it } from "vitest";
import {
  parseStringArray,
  serverMatchesTags,
} from "@/lib/servers/groups";

describe("serverMatchesTags", () => {
  it("matches any tag when matchAnyTag is true", () => {
    expect(serverMatchesTags(["Prod", "docker"], ["prod"], true)).toBe(true);
    expect(serverMatchesTags(["staging"], ["prod"], true)).toBe(false);
  });

  it("requires all tags when matchAnyTag is false", () => {
    expect(serverMatchesTags(["prod", "docker"], ["prod", "docker"], false)).toBe(true);
    expect(serverMatchesTags(["prod"], ["prod", "docker"], false)).toBe(false);
  });

  it("is case-insensitive", () => {
    expect(serverMatchesTags(["Proxmox"], ["proxmox"], true)).toBe(true);
  });

  it("returns false when match list is empty", () => {
    expect(serverMatchesTags(["prod"], [], true)).toBe(false);
  });
});

describe("parseStringArray", () => {
  it("filters non-strings", () => {
    expect(parseStringArray(["a", 1, "b"])).toEqual(["a", "b"]);
  });
});
