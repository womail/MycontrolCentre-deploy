import { describe, it, expect } from "vitest";
import { encryptDatabaseBytes, decryptDatabaseBytes } from "@/lib/db/encrypted-backup";

describe("encrypted database backup", () => {
  it("round-trips sqlite bytes with password", () => {
    const sample = Buffer.from("SQLite format 3\x00test payload");
    const encrypted = encryptDatabaseBytes(sample, "test-backup-password");
    const decrypted = decryptDatabaseBytes(encrypted, "test-backup-password");
    expect(decrypted.equals(sample)).toBe(true);
  });

  it("rejects wrong password", () => {
    const encrypted = encryptDatabaseBytes(Buffer.from("data"), "correct-password");
    expect(() => decryptDatabaseBytes(encrypted, "wrong-password")).toThrow();
  });
});
