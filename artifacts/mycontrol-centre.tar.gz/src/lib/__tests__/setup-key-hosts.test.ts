import { describe, expect, it } from "vitest";
import { generateSshKeyPair } from "@/lib/setup/ssh-keygen";
import {
  fingerprintPrivateKeyPem,
  opensshPublicLineFromPrivate,
} from "@/lib/enrollment/setup-key-hosts";
import { fingerprintPublicKey } from "@/lib/enrollment/register";

describe("setup-key-hosts", () => {
  it("derives the same fingerprint from private key as from public line", () => {
    const keys = generateSshKeyPair();
    const fromPrivate = fingerprintPrivateKeyPem(keys.privateKey);
    const fromPublic = fingerprintPublicKey(keys.publicKey);
    expect(fromPrivate).toBe(fromPublic);

    const line = opensshPublicLineFromPrivate(keys.privateKey);
    expect(line?.split(/\s+/)[1]).toBe(keys.publicKey.split(/\s+/)[1]);
  });
});
