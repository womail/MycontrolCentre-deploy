import { describe, expect, it } from "vitest";
import { shouldSkipApiRequestLog } from "@/lib/connection-log";

describe("shouldSkipApiRequestLog", () => {
  it("skips high-frequency GET polls", () => {
    expect(shouldSkipApiRequestLog("GET", "/api/auth/me")).toBe(true);
    expect(shouldSkipApiRequestLog("GET", "/api/commands/runs")).toBe(true);
    expect(shouldSkipApiRequestLog("GET", "/api/enrollment/pending-count")).toBe(true);
  });

  it("logs mutating and normal GET routes", () => {
    expect(shouldSkipApiRequestLog("POST", "/api/commands")).toBe(false);
    expect(shouldSkipApiRequestLog("GET", "/api/servers")).toBe(true);
    expect(shouldSkipApiRequestLog("GET", "/api/commands/templates")).toBe(true);
    expect(shouldSkipApiRequestLog("GET", "/api/audit")).toBe(false);
  });
});
