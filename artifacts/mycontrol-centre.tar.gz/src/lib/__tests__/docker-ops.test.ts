import { describe, expect, it } from "vitest";
import { normalizeComposeDeployInput } from "@/lib/docker/compose-deploy";
import {
  buildBashScriptCommand,
  DOCKER_ENGINE_INSTALL_UBUNTU,
  portainerCeInstallScript,
} from "@/lib/docker/scripts";

describe("docker install scripts", () => {
  it("builds base64 bash commands under custom command limit", () => {
    const docker = buildBashScriptCommand(DOCKER_ENGINE_INSTALL_UBUNTU);
    const portainer = buildBashScriptCommand(portainerCeInstallScript());
    expect(docker.length).toBeLessThan(4000);
    expect(portainer.length).toBeLessThan(4000);
    expect(docker).toMatch(/base64 -d \| sudo bash/);
  });

  it("includes ubuntu docker apt repo steps", () => {
    expect(DOCKER_ENGINE_INSTALL_UBUNTU).toContain("download.docker.com");
    expect(DOCKER_ENGINE_INSTALL_UBUNTU).toContain("docker-compose-plugin");
  });

  it("portainer script uses official image", () => {
    expect(portainerCeInstallScript()).toContain("portainer/portainer-ce:lts");
    expect(portainerCeInstallScript({ httpLegacyPort: true })).toContain("9000:9000");
  });
});

describe("normalizeComposeDeployInput", () => {
  it("requires absolute remote directory and compose content", () => {
    expect(() =>
      normalizeComposeDeployInput({
        remoteDir: "relative/path",
        composeYaml: "services: {}",
      }),
    ).toThrow(/absolute path/i);

    expect(() =>
      normalizeComposeDeployInput({
        remoteDir: "/opt/stacks/app",
        composeYaml: "   ",
      }),
    ).toThrow(/required/i);
  });

  it("accepts optional env file and project name", () => {
    const input = normalizeComposeDeployInput({
      remoteDir: "/opt/stacks/app",
      composeYaml: "services:\n  web:\n    image: nginx",
      envFile: "FOO=bar",
      projectName: "my-stack",
    });
    expect(input.envFile).toBe("FOO=bar");
    expect(input.projectName).toBe("my-stack");
  });
});
