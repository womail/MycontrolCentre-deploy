import { describe, expect, it } from "vitest";
import { pickPackageUpdateTemplateIds } from "@/lib/updates/package-update-templates";

describe("pickPackageUpdateTemplateIds", () => {
  const aptTemplates = [
    { id: "t1", type: "APT_UPDATE", name: "APT Update", isActive: true, platforms: ["debian"] },
    { id: "t2", type: "APT_UPGRADE", name: "APT Upgrade", isActive: true, platforms: ["debian"] },
  ];

  const archTemplates = [
    { id: "a1", type: "CUSTOM", name: "Pacman Sync", isActive: true, platforms: ["arch"] },
    { id: "a2", type: "CUSTOM", name: "Pacman Upgrade", isActive: true, platforms: ["arch"] },
  ];

  it("picks apt update then upgrade for debian hosts", () => {
    const ids = pickPackageUpdateTemplateIds(
      { id: "s1", platforms: ["debian"] },
      aptTemplates,
    );
    expect(ids).toEqual(["t1", "t2"]);
  });

  it("picks pacman sync then upgrade for arch hosts", () => {
    const ids = pickPackageUpdateTemplateIds(
      { id: "s1", platforms: ["arch"] },
      archTemplates,
    );
    expect(ids).toEqual(["a1", "a2"]);
  });

  it("prefers apt when both platform sets match", () => {
    const ids = pickPackageUpdateTemplateIds(
      { id: "s1", platforms: ["debian", "arch"] },
      [...aptTemplates, ...archTemplates],
    );
    expect(ids).toEqual(["t1", "t2"]);
  });
});
