import { describe, expect, it } from "vitest";
import {
  osFamilyFromRelease,
  parseOsDetectOutput,
} from "@/lib/servers/os-detect";
import { effectivePlatforms, parseDetectOutput } from "@/lib/servers/platforms";

describe("parseOsDetectOutput", () => {
  it("parses ubuntu as debian family", () => {
    const os = parseOsDetectOutput(
      "MCC_OS_ID=ubuntu\nMCC_OS_PRETTY=Ubuntu 24.04.1 LTS\nMCC_OS_LIKE=debian\n",
    );
    expect(os?.id).toBe("ubuntu");
    expect(os?.family).toBe("debian");
    expect(os?.label).toContain("Ubuntu");
  });

  it("parses alpine", () => {
    const os = parseOsDetectOutput(
      "MCC_OS_ID=alpine\nMCC_OS_PRETTY=Alpine Linux v3.20.0\nMCC_OS_LIKE=\n",
    );
    expect(os?.family).toBe("alpine");
  });

  it("parses arch via ID_LIKE", () => {
    expect(osFamilyFromRelease("manjaro", "arch")).toBe("arch");
  });
});

describe("platform detect with OS ids", () => {
  it("includes ubuntu and alpine in detect output", () => {
    expect(parseDetectOutput("ubuntu\ndebian\ndocker\n")).toEqual([
      "ubuntu",
      "debian",
      "docker",
    ]);
  });

  it("maps ubuntu to debian for apt capabilities", () => {
    expect(
      effectivePlatforms({
        manualPlatforms: [],
        detectedPlatforms: ["ubuntu", "docker"],
      }),
    ).toEqual(["ubuntu", "docker", "debian"]);
  });
});
