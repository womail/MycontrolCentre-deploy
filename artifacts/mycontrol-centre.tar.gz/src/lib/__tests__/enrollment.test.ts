import { describe, it, expect } from "vitest";
import {
  enrollmentRegisterSchema,
  fingerprintPublicKey,
  normalizeEnrollmentPublicKey,
} from "@/lib/enrollment/register";
import { buildInstallCommand } from "@/lib/setup/ssh-keygen";

const sampleKey =
  "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAITest mycontrol-centre";

describe("enrollment register", () => {
  it("accepts RSA-length host keys in knownHostKeys", () => {
    const rsaHostKey =
      "AAAAB3NzaC1yc2EAAAADAQABAAABgQCwaLn0ybiiB4YoUBl8eI6UB7t1QojvTm4PTQpLb3+NJj9D+YXfjtLOiP8xgureAuupArnZcIVu7sifc2SAxERICssy5IqcYtxpDwHJ2quz7+4r8vyhIANrq4IMKPZCts7+GpOGw2vhATX81rgXAL+9nyTZJZEBEIN0LVhJ40SZSH3TJuxyS2jJvP/aXjTtiC0VnbTNRFnV+i7eKDlpfC0pIll96A/5wnRjZcevwvFYiTpl8loIAu//yzzFd2ilpBnMvfnywqjQxWUes4hX+pmK/b2sJVqz0CUoaO1oJqV4nwNQgx7KNZiBjSDCu/KCGBfI10/kv4XbVYpreToPHxHX+U/swkPZmlRrofNX2Fq0w6jXT4F6GI8o1tA+GW7kavkPDXid9D31amkIbQ0P4YyeYaH/D2hzOz/WwpAl4d09EANPxeExuxh8qcC/s7zTpv6iP37FY7IbovNOUBMhF+MurtKJZ5Zi+rGiEnv6+WeobuZ2bODwo6sJyoc1EesLBo0=";
    expect(rsaHostKey.length).toBeGreaterThan(500);
    const parsed = enrollmentRegisterSchema.parse({
      name: "pve1",
      hostname: "10.0.0.5",
      sshUser: "mcc-auto",
      publicKey: sampleKey,
      knownHostKeys: [rsaHostKey],
    });
    expect(parsed.knownHostKeys?.[0]).toBe(rsaHostKey);
  });

  it("normalizes and fingerprints public keys", () => {
    const normalized = normalizeEnrollmentPublicKey(`  ${sampleKey}  `);
    expect(normalized).toBe(sampleKey);
    expect(fingerprintPublicKey(normalized).length).toBeGreaterThan(10);
  });

  it("parses enrollment payload", () => {
    const parsed = enrollmentRegisterSchema.parse({
      name: "pve1",
      hostname: "10.0.0.5",
      sshUser: "mcc-auto",
      publicKey: sampleKey,
    });
    expect(parsed.port).toBe(22);
  });
});

describe("buildInstallCommand enrollment", () => {
  it("adds enroll flags when token provided", () => {
    const cmd = buildInstallCommand("http://console:3000", sampleKey, {
      enrollToken: "secret-token",
    });
    expect(cmd).toContain("--enroll-url 'http://console:3000/api/enrollment/register'");
    expect(cmd).toContain("--enroll-token 'secret-token'");
  });
});
