import { describe, it, expect, beforeEach } from "vitest";
import { checkRateLimit, resetRateLimit, getClientIp } from "@/lib/rate-limit";

describe("checkRateLimit", () => {
  beforeEach(() => {
    resetRateLimit("test-ip");
  });

  it("allows first request", () => {
    expect(checkRateLimit("test-ip").allowed).toBe(true);
  });

  it("blocks after max attempts", () => {
    for (let i = 0; i < 5; i++) {
      checkRateLimit("test-ip");
    }
    const result = checkRateLimit("test-ip");
    expect(result.allowed).toBe(false);
    expect(result.retryAfterMs).toBeGreaterThan(0);
  });

  it("resets after resetRateLimit", () => {
    for (let i = 0; i < 5; i++) {
      checkRateLimit("test-ip");
    }
    resetRateLimit("test-ip");
    expect(checkRateLimit("test-ip").allowed).toBe(true);
  });
});

describe("getClientIp", () => {
  it("reads x-forwarded-for first hop", () => {
    const headers = new Headers({
      "x-forwarded-for": "203.0.113.1, 10.0.0.1",
    });
    expect(getClientIp(headers)).toBe("203.0.113.1");
  });

  it("falls back to x-real-ip", () => {
    const headers = new Headers({ "x-real-ip": "198.51.100.2" });
    expect(getClientIp(headers)).toBe("198.51.100.2");
  });

  it("returns unknown when no headers", () => {
    expect(getClientIp(new Headers())).toBe("unknown");
  });
});
