import { describe, expect, it } from "vitest";
import {
  isServerInMaintenance,
  maintenanceBlockedMessage,
} from "@/lib/servers/maintenance";

describe("maintenance windows", () => {
  it("returns false when not in maintenance", () => {
    expect(
      isServerInMaintenance({ inMaintenance: false, maintenanceUntil: null }),
    ).toBe(false);
  });

  it("returns true when in maintenance without expiry", () => {
    expect(
      isServerInMaintenance({ inMaintenance: true, maintenanceUntil: null }),
    ).toBe(true);
  });

  it("auto-expires maintenance after maintenanceUntil", () => {
    const past = new Date(Date.now() - 60_000);
    expect(
      isServerInMaintenance({ inMaintenance: true, maintenanceUntil: past }),
    ).toBe(false);
  });

  it("builds a readable block message", () => {
    const until = new Date("2030-01-01T12:00:00.000Z");
    const message = maintenanceBlockedMessage({
      name: "pve-01",
      maintenanceNote: "Kernel upgrade",
      maintenanceUntil: until,
    });
    expect(message).toContain('pve-01');
    expect(message).toContain("Kernel upgrade");
    expect(message).toContain("2030-01-01");
  });
});
