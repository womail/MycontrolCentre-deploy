import { describe, expect, it } from "vitest";
import { getServerHealthAdvice } from "@/lib/servers/health-advice";

const base = {
  name: "udoo",
  hostname: "10.1.1.243",
  port: 22,
  sshUser: "mcc-auto",
  authType: "KEY",
};

describe("getServerHealthAdvice", () => {
  it("detects authentication failure", () => {
    const advice = getServerHealthAdvice({
      ...base,
      healthMessage: "All configured authentication methods failed",
    });
    expect(advice?.id).toBe("auth-failed");
    expect(advice?.commands.length).toBeGreaterThan(0);
  });

  it("detects host key mismatch", () => {
    const advice = getServerHealthAdvice({
      ...base,
      healthMessage: "Host key verification failed",
    });
    expect(advice?.id).toBe("host-key");
  });

  it("returns maintenance notice", () => {
    const advice = getServerHealthAdvice({
      ...base,
      inMaintenance: true,
      healthMessage: null,
    });
    expect(advice?.id).toBe("maintenance");
  });
});
