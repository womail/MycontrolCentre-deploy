import { describe, expect, it } from "vitest";
import { appendCapped } from "@/lib/memory/output-cap";

describe("appendCapped", () => {
  it("appends when under limit", () => {
    expect(appendCapped("ab", "cd", 10)).toBe("abcd");
  });

  it("keeps tail when over limit", () => {
    expect(appendCapped("12345", "67890", 5)).toBe("67890");
  });
});
