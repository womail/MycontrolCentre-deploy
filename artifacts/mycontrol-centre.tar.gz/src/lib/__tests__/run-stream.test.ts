import { describe, expect, it, afterEach } from "vitest";
import {
  publishRunStreamEvent,
  resetRunStreamForTests,
  subscribeRunStream,
} from "@/lib/commands/run-stream";

describe("run stream bus", () => {
  afterEach(() => {
    resetRunStreamForTests();
  });

  it("replays buffered events to late subscribers", () => {
    publishRunStreamEvent("run-1", { type: "stdout", data: "hello" });
    publishRunStreamEvent("run-1", { type: "stderr", data: "warn" });

    const seen: string[] = [];
    subscribeRunStream("run-1", (event) => {
      if (event.type === "stdout" || event.type === "stderr") {
        seen.push(`${event.type}:${event.data}`);
      }
    });

    expect(seen).toEqual(["stdout:hello", "stderr:warn"]);
  });

  it("notifies live subscribers", () => {
    const seen: string[] = [];
    subscribeRunStream("run-2", (event) => {
      if (event.type === "stdout") seen.push(event.data);
    });

    publishRunStreamEvent("run-2", { type: "stdout", data: "line1" });
    publishRunStreamEvent("run-2", { type: "stdout", data: "line2" });

    expect(seen).toEqual(["line1", "line2"]);
  });

  it("unsubscribe stops notifications", () => {
    const seen: string[] = [];
    const unsubscribe = subscribeRunStream("run-3", (event) => {
      if (event.type === "stdout") seen.push(event.data);
    });

    publishRunStreamEvent("run-3", { type: "stdout", data: "before" });
    unsubscribe();
    publishRunStreamEvent("run-3", { type: "stdout", data: "after" });

    expect(seen).toEqual(["before"]);
  });
});
