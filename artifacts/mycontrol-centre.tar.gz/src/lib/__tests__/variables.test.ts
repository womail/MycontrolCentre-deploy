import { describe, expect, it } from "vitest";
import {
  extractTemplateVariables,
  substituteTemplateVariables,
} from "@/lib/commands/variables";

describe("template variables", () => {
  it("extracts unique variable names", () => {
    expect(extractTemplateVariables("qm status {{vmid}} on {{node}}")).toEqual([
      "vmid",
      "node",
    ]);
    expect(extractTemplateVariables("plain command")).toEqual([]);
  });

  it("substitutes variables in command text", () => {
    const result = substituteTemplateVariables("pct status {{vmid}}", { vmid: "101" });
    expect(result).toBe("pct status 101");
  });

  it("throws when a variable is missing", () => {
    expect(() => substituteTemplateVariables("qm status {{vmid}}", {})).toThrow(
      "Missing value for variable {{vmid}}",
    );
  });
});
