import { describe, expect, it } from "vitest";
import { formatVaultMachine } from "@/lib/vault/access-log";
import { formatClientNodeDisplay } from "@/lib/vault/resolve-client-node";

describe("formatVaultMachine", () => {
  it("combines client label, ip, and browser hints", () => {
    const s = formatVaultMachine({
      clientLabel: "Linux x86_64",
      ipAddress: "10.1.1.50",
      userAgent:
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    });
    expect(s).toContain("10.1.1.50");
    expect(s).toContain("Linux");
  });
});

describe("formatClientNodeDisplay", () => {
  it("shows node with ip when both present", () => {
    expect(
      formatClientNodeDisplay({ clientNode: "will-laptop", ipAddress: "10.1.1.50" }),
    ).toBe("will-laptop (10.1.1.50)");
  });

  it("falls back to ip or unknown", () => {
    expect(formatClientNodeDisplay({ ipAddress: "10.1.1.50" })).toBe("10.1.1.50");
    expect(formatClientNodeDisplay({})).toBe("Unknown node");
  });
});
