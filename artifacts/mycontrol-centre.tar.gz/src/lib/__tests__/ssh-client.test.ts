import { describe, it, expect } from "vitest";
import { shellEscape, buildRemoteCommand } from "@/lib/ssh/client";

describe("shellEscape", () => {
  it("wraps simple paths in single quotes", () => {
    expect(shellEscape("/var/log")).toBe("'/var/log'");
  });

  it("escapes embedded single quotes", () => {
    expect(shellEscape("/it's/here")).toBe("'/it'\\''s/here'");
  });
});

describe("buildRemoteCommand", () => {
  it("returns inner command when no working dir", () => {
    expect(buildRemoteCommand(undefined, "uname -a")).toBe("uname -a");
  });

  it("prefixes with cd when working dir set", () => {
    expect(buildRemoteCommand("/opt", "ls -la")).toBe("cd '/opt' && ls -la");
  });
});
