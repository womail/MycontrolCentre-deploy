import { describe, it, expect } from "vitest";
import { parseProxmoxHostOutput } from "@/lib/setup/parse-host-output";

const humanBlock = `
================================================================================
  MyControl Centre — copy these values into Add Server
================================================================================

  Name:              pve-node1
  Hostname / IP:     10.1.3.50
  Port:              22
  SSH user:          mcc-auto
  Auth type:         KEY
  Known host key:    abc123base64key==
`;

const jsonBlock = `
{
  "name": "pve-node1",
  "hostname": "10.1.3.50",
  "port": 22,
  "sshUser": "mcc-auto",
  "authType": "KEY",
  "knownHostKey": "abc123base64key==",
  "acceptNewHostKey": false
}
`;

describe("parseProxmoxHostOutput", () => {
  it("parses human-readable Name and Hostname / IP lines", () => {
    const result = parseProxmoxHostOutput(humanBlock);
    expect(result).toEqual({
      name: "pve-node1",
      hostname: "10.1.3.50",
      port: 22,
      sshUser: "mcc-auto",
      knownHostKey: "abc123base64key==",
    });
  });

  it("parses JSON block", () => {
    const result = parseProxmoxHostOutput(jsonBlock);
    expect(result?.name).toBe("pve-node1");
    expect(result?.hostname).toBe("10.1.3.50");
    expect(result?.port).toBe(22);
    expect(result?.sshUser).toBe("mcc-auto");
    expect(result?.knownHostKey).toBe("abc123base64key==");
  });

  it("parses human-readable only when JSON is missing", () => {
    const result = parseProxmoxHostOutput(humanBlock);
    expect(result?.name).toBe("pve-node1");
    expect(result?.hostname).toBe("10.1.3.50");
  });

  it("parses setup log summary line Host: ... IP: ...", () => {
    const result = parseProxmoxHostOutput("==> User: mcc-auto  Host: proxmox.local  IP: 10.1.3.99");
    expect(result?.name).toBe("proxmox.local");
    expect(result?.hostname).toBe("10.1.3.99");
  });

  it("ignores placeholder known host key text", () => {
    const text = `
  Name:              node
  Hostname / IP:     10.0.0.1
  Known host key:    (leave empty and enable 'Accept on first connect')
`;
    const result = parseProxmoxHostOutput(text);
    expect(result?.knownHostKey).toBeUndefined();
    expect(result?.hostname).toBe("10.0.0.1");
  });

  it("returns null for empty or unrecognised input", () => {
    expect(parseProxmoxHostOutput("")).toBeNull();
    expect(parseProxmoxHostOutput("random text")).toBeNull();
  });
});
