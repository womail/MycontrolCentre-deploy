import { describe, it, expect } from "vitest";
import {
  hostKeyMatchesStored,
  parseKnownHostKeys,
  serializeKnownHostKeys,
} from "@/lib/ssh/known-host-keys";

describe("known host keys", () => {
  const ed25519 = "AAAAC3NzaC1lZDI1NTE5AAAAIExwaoVGBXb1GbF5sIorMuY9dISkEd21nxQ/jLTHhgpt";
  const rsa =
    "AAAAB3NzaC1yc2EAAAADAQABAAABgQCwaLn0ybiiB4YoUBl8eI6UB7t1QojvTm4PTQpLb3+NJj9D+YXfjtLOiP8xgureAuupArnZcIVu7sifc2SAxERICssy5IqcYtxpDwHJ2quz7+4r8vyhIANrq4IMKPZCts7+GpOGw2vhATX81rgXAL+9nyTZJZEBEIN0LVhJ40SZSH3TJuxyS2jJvP/aXjTtiC0VnbTNRFnV+i7eKDlpfC0pIll96A/5wnRjZcevwvFYiTpl8loIAu//yzzFd2ilpBnMvfnywqjQxWUes4hX+pmK/b2sJVqz0CUoaO1oJqV4nwNQgx7KNZiBjSDCu/KCGBfI10/kv4XbVYpreToPHxHX+U/swkPZmlRrofNX2Fq0w6jXT4F6GI8o1tA+GW7kavkPDXid9D31amkIbQ0P4YyeYaH/D2hzOz/WwpAl4d09EANPxeExuxh8qcC/s7zTpv6iP37FY7IbovNOUBMhF+MurtKJZ5Zi+rGiEnv6+WeobuZ2bODwo6sJyoc1EesLBo0=";

  it("matches any key in JSON array storage", () => {
    const stored = serializeKnownHostKeys([ed25519, rsa]);
    expect(stored).toContain("[");
    const rsaBytes = Buffer.from(rsa, "base64");
    expect(hostKeyMatchesStored(stored, rsaBytes)).toBe(true);
    const edBytes = Buffer.from(ed25519, "base64");
    expect(hostKeyMatchesStored(stored, edBytes)).toBe(true);
  });

  it("parses single legacy key", () => {
    expect(parseKnownHostKeys(ed25519)).toEqual([ed25519]);
  });
});
