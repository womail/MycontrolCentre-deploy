import { describe, it, expect } from "vitest";
import { buildInstallCommand, buildInstallCommandPair } from "@/lib/setup/ssh-keygen";

describe("buildInstallCommand", () => {
  it("downloads script then runs with --pubkey (no bash -s --)", () => {
    const cmd = buildInstallCommand(
      "http://10.1.3.230:3000",
      "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAITest mycontrol-centre",
    );
    expect(cmd).toContain(
      "curl -fsSL --connect-timeout 30 --noproxy '*' 'http://10.1.3.230:3000/api/setup/proxmox-host.sh'",
    );
    expect(cmd).toContain("rm -f /tmp/mcc-proxmox-setup.sh");
    expect(cmd).toContain("-o /tmp/mcc-proxmox-setup.sh");
    expect(cmd).toContain("bash /tmp/mcc-proxmox-setup.sh --pubkey '");
    expect(cmd).toMatch(/rm -f \/tmp\/mcc-proxmox-setup\.sh$/);
  });

  it("provides root and sudo variants", () => {
    const pair = buildInstallCommandPair(
      "http://10.1.3.230:3000",
      "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAITest mycontrol-centre",
    );
    expect(pair.asRoot).toContain("bash /tmp/mcc-proxmox-setup.sh");
    expect(pair.withSudo).toContain("sudo bash /tmp/mcc-proxmox-setup.sh");
    expect(pair.withSudo).not.toContain("&& bash /tmp/mcc-proxmox-setup.sh");
  });
});
