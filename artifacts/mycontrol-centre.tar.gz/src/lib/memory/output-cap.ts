/** Max characters retained in memory for live command output (matches DB slice). */
export const MAX_CAPTURED_OUTPUT_CHARS = 500_000;

export function appendCapped(existing: string, chunk: string, max = MAX_CAPTURED_OUTPUT_CHARS): string {
  if (!chunk) return existing;
  const combined = existing + chunk;
  if (combined.length <= max) return combined;
  return combined.slice(combined.length - max);
}
