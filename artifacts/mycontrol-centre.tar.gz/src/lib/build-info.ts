import { accessSync, constants } from "fs";

export interface BuildInfo {
  service: string;
  version: string;
  buildRef: string;
  buildTime: string | null;
  sshKeygen: string | null;
}

function resolveSshKeygenPath(): string | null {
  for (const path of ["/usr/bin/ssh-keygen", "/bin/ssh-keygen"]) {
    try {
      accessSync(path, constants.X_OK);
      return path;
    } catch {
      /* try next */
    }
  }
  return null;
}

export function getBuildInfo(): BuildInfo {
  return {
    service: "mycontrol-centre",
    version: process.env.MCC_APP_VERSION ?? "unknown",
    buildRef: process.env.MCC_BUILD_REF ?? "unknown",
    buildTime: process.env.MCC_BUILD_TIME ?? null,
    sshKeygen: resolveSshKeygenPath(),
  };
}
