import type { ServerGroup } from "@prisma/client";
import { parseStringArray } from "./groups";

export function serializeServerGroup(group: ServerGroup) {
  return {
    id: group.id,
    name: group.name,
    description: group.description,
    kind: group.kind,
    serverIds: parseStringArray(group.serverIds),
    matchTags: parseStringArray(group.matchTags),
    matchAnyTag: group.matchAnyTag,
    createdAt: group.createdAt.toISOString(),
    updatedAt: group.updatedAt.toISOString(),
  };
}
