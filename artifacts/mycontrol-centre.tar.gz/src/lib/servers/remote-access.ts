import type { Server, User } from "@prisma/client";
import { prisma } from "../db";
import { isServerInMaintenance, maintenanceBlockedMessage } from "./maintenance";

export class RemoteAccessError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
    this.name = "RemoteAccessError";
  }
}

export async function loadServerForRemoteAccess(
  serverId: string,
  user: User,
  options?: { allowMaintenance?: boolean },
): Promise<Server> {
  if (user.role === "VIEWER") {
    throw new RemoteAccessError("Forbidden", 403);
  }

  const server = await prisma.server.findUnique({ where: { id: serverId } });
  if (!server || !server.isActive) {
    throw new RemoteAccessError("Server not found", 404);
  }

  if (
    !options?.allowMaintenance &&
    user.role !== "ADMIN" &&
    isServerInMaintenance(server)
  ) {
    throw new RemoteAccessError(maintenanceBlockedMessage(server), 423);
  }

  return server;
}
