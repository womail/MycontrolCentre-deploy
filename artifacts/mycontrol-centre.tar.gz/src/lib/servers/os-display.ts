/** Grouped OS families for display (no Node/SSH imports — safe for client components). */
export const OS_FAMILIES = ["debian", "arch", "alpine", "unknown"] as const;
export type OsFamily = (typeof OS_FAMILIES)[number];

export const OS_FAMILY_LABELS: Record<OsFamily, string> = {
  debian: "Debian / Ubuntu",
  arch: "Arch",
  alpine: "Alpine",
  unknown: "Unknown",
};

export function osBadgeTitle(detected: {
  detectedOsId: string | null;
  detectedOsLabel: string | null;
  detectedOsFamily: string | null;
}): string {
  if (detected.detectedOsLabel) return detected.detectedOsLabel;
  if (detected.detectedOsId && detected.detectedOsId !== "unknown") {
    return formatOsIdLabel(detected.detectedOsId);
  }
  const family = detected.detectedOsFamily as OsFamily | null;
  if (family && family in OS_FAMILY_LABELS) return OS_FAMILY_LABELS[family];
  return "OS not detected yet — run a health check";
}

function formatOsIdLabel(id: string): string {
  if (id === "ubuntu") return "Ubuntu";
  if (id === "debian") return "Debian";
  if (id === "arch") return "Arch Linux";
  if (id === "alpine") return "Alpine";
  return id.charAt(0).toUpperCase() + id.slice(1);
}
