export const SERVER_PLATFORMS = [
  "proxmox",
  "debian",
  "ubuntu",
  "alpine",
  "docker",
  "arch",
  "generic",
] as const;
export type ServerPlatform = (typeof SERVER_PLATFORMS)[number];

export const COMMAND_CATEGORIES = [
  "general",
  "filesystem",
  "disk",
  "apt",
  "proxmox",
  "docker",
  "arch",
] as const;
export type CommandCategory = (typeof COMMAND_CATEGORIES)[number] | string;

export const CATEGORY_LABELS: Record<string, string> = {
  general: "General",
  filesystem: "Filesystem",
  disk: "Disk & cache",
  apt: "APT / Debian",
  proxmox: "Proxmox",
  docker: "Docker",
  arch: "Pacman / Arch",
};

export const PLATFORM_LABELS: Record<ServerPlatform, string> = {
  proxmox: "Proxmox",
  debian: "Debian",
  ubuntu: "Ubuntu",
  alpine: "Alpine",
  docker: "Docker",
  arch: "Arch",
  generic: "Generic Linux",
};

export function parsePlatformList(value: unknown): ServerPlatform[] {
  if (!Array.isArray(value)) return [];
  return value.filter(
    (item): item is ServerPlatform =>
      typeof item === "string" && SERVER_PLATFORMS.includes(item as ServerPlatform),
  );
}

export function parseTemplatePlatforms(value: unknown): string[] {
  if (!Array.isArray(value) || value.length === 0) return ["all"];
  return value.filter((item): item is string => typeof item === "string" && item.length > 0);
}

export function effectivePlatforms(input: {
  manualPlatforms?: unknown;
  detectedPlatforms?: unknown;
}): ServerPlatform[] {
  const manual = parsePlatformList(input.manualPlatforms);
  const detected = parsePlatformList(input.detectedPlatforms);
  const merged = [...new Set([...manual, ...detected])];
  if (merged.includes("ubuntu") && !merged.includes("debian")) {
    merged.push("debian");
  }
  return merged.length > 0 ? merged : ["generic"];
}

export function mergeManualPlatforms(
  currentManual: unknown,
  selected: ServerPlatform[],
): ServerPlatform[] {
  return [...new Set(selected)];
}

export const PLATFORM_DETECT_COMMAND = `(
  command -v pveversion >/dev/null 2>&1 && echo proxmox
  grep -q '^ID=ubuntu' /etc/os-release 2>/dev/null && echo ubuntu
  grep -q '^ID=debian' /etc/os-release 2>/dev/null && echo debian
  grep -q '^ID=alpine' /etc/os-release 2>/dev/null && echo alpine
  grep -q '^ID=arch' /etc/os-release 2>/dev/null && echo arch
  command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1 && echo docker
) 2>/dev/null | sort -u`;

export function parseDetectOutput(stdout: string): ServerPlatform[] {
  const found = stdout
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .filter((line): line is ServerPlatform =>
      SERVER_PLATFORMS.includes(line as ServerPlatform),
    );
  return [...new Set(found)];
}
