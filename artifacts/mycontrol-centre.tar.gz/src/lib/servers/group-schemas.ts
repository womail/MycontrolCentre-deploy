import { z } from "zod";

const groupBase = {
  name: z.string().min(1).max(100),
  description: z.string().max(500).optional(),
};

export const createServerGroupSchema = z.discriminatedUnion("kind", [
  z.object({
    ...groupBase,
    kind: z.literal("STATIC"),
    serverIds: z.array(z.string()).min(1),
  }),
  z.object({
    ...groupBase,
    kind: z.literal("TAG"),
    matchTags: z.array(z.string()).min(1),
    matchAnyTag: z.boolean().default(true),
  }),
]);

export const updateServerGroupSchema = z
  .object({
    name: z.string().min(1).max(100).optional(),
    description: z.string().max(500).optional().nullable(),
    kind: z.enum(["STATIC", "TAG"]).optional(),
    serverIds: z.array(z.string()).min(1).optional(),
    matchTags: z.array(z.string()).min(1).optional(),
    matchAnyTag: z.boolean().optional(),
  })
  .superRefine((data, ctx) => {
    if (data.kind === "STATIC" && data.serverIds !== undefined && data.serverIds.length === 0) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Static groups need at least one server" });
    }
    if (data.kind === "TAG" && data.matchTags !== undefined && data.matchTags.length === 0) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Tag groups need at least one tag" });
    }
  });

export const profileTargetsSchema = z
  .object({
    serverIds: z.array(z.string()).default([]),
    serverGroupId: z.string().cuid().nullable().optional(),
  })
  .superRefine((data, ctx) => {
    const hasGroup = Boolean(data.serverGroupId);
    const hasServers = data.serverIds.length > 0;
    if (!hasGroup && !hasServers) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Select servers or a server group",
        path: ["serverIds"],
      });
    }
  });
