import type { Server } from "@prisma/client";

export function isServerInMaintenance(
  server: Pick<Server, "inMaintenance" | "maintenanceUntil">,
  now = new Date(),
): boolean {
  if (!server.inMaintenance) return false;
  if (server.maintenanceUntil && server.maintenanceUntil < now) return false;
  return true;
}

export function maintenanceBlockedMessage(
  server: Pick<Server, "name" | "maintenanceNote" | "maintenanceUntil">,
): string {
  const parts = [`Server "${server.name}" is in maintenance`];
  if (server.maintenanceNote) parts.push(server.maintenanceNote);
  if (server.maintenanceUntil) {
    parts.push(`until ${server.maintenanceUntil.toISOString()}`);
  }
  return parts.join(" — ");
}
