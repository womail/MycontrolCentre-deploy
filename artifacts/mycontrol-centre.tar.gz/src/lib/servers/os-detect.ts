import type { Server } from "@prisma/client";
import { execOnServer } from "../ssh/client";
import {
  OS_FAMILY_LABELS,
  type OsFamily,
} from "./os-display";

export { OS_FAMILIES, OS_FAMILY_LABELS, osBadgeTitle, type OsFamily } from "./os-display";

export interface DetectedOs {
  id: string;
  family: OsFamily;
  label: string;
}

/** Remote shell: print os-release fields (one line each). */
export const OS_DETECT_COMMAND = `. /etc/os-release 2>/dev/null || true
echo "MCC_OS_ID=\${ID:-unknown}"
echo "MCC_OS_PRETTY=\${PRETTY_NAME:-}"
echo "MCC_OS_LIKE=\${ID_LIKE:-}"`;

const DEBIAN_LIKE_IDS = new Set([
  "debian",
  "ubuntu",
  "raspbian",
  "linuxmint",
  "pop",
  "elementary",
  "kali",
]);

const ARCH_LIKE_IDS = new Set(["arch", "manjaro", "endeavouros", "garuda"]);

export function parseOsDetectOutput(stdout: string): DetectedOs | null {
  let id = "unknown";
  let pretty = "";
  let idLike = "";

  for (const line of stdout.split("\n")) {
    const trimmed = line.trim();
    if (trimmed.startsWith("MCC_OS_ID=")) {
      id = trimmed.slice("MCC_OS_ID=".length).trim().toLowerCase() || "unknown";
    } else if (trimmed.startsWith("MCC_OS_PRETTY=")) {
      pretty = trimmed.slice("MCC_OS_PRETTY=".length).trim();
    } else if (trimmed.startsWith("MCC_OS_LIKE=")) {
      idLike = trimmed.slice("MCC_OS_LIKE=".length).trim().toLowerCase();
    }
  }

  if (id === "unknown" && !pretty && !idLike) return null;

  const family = osFamilyFromRelease(id, idLike);
  const label = pretty || osLabelFromId(id);

  return { id, family, label };
}

export function osFamilyFromRelease(id: string, idLike: string): OsFamily {
  const normalized = id.toLowerCase();
  if (normalized === "alpine") return "alpine";
  if (ARCH_LIKE_IDS.has(normalized) || idLike.split(/\s+/).includes("arch")) {
    return "arch";
  }
  if (
    DEBIAN_LIKE_IDS.has(normalized) ||
    idLike.split(/\s+/).some((part) => part === "debian" || part === "ubuntu")
  ) {
    return "debian";
  }
  return "unknown";
}

function osLabelFromId(id: string): string {
  if (id === "unknown") return OS_FAMILY_LABELS.unknown;
  if (id === "ubuntu") return "Ubuntu";
  if (id === "debian") return "Debian";
  if (id === "arch") return "Arch Linux";
  if (id === "alpine") return "Alpine";
  return id.charAt(0).toUpperCase() + id.slice(1);
}

export async function detectServerOs(server: Server): Promise<DetectedOs | null> {
  try {
    const result = await execOnServer(server, OS_DETECT_COMMAND, { timeoutMs: 15_000 });
    if (result.exitCode !== 0) return null;
    return parseOsDetectOutput(result.stdout);
  } catch {
    return null;
  }
}
