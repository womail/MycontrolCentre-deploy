import {
  effectivePlatforms,
  parsePlatformList,
  type ServerPlatform,
} from "./platforms";
import { parseTags } from "./tags";

export function serializeServer<T extends {
  tags: unknown;
  manualPlatforms?: unknown;
  detectedPlatforms?: unknown;
}>(
  server: T,
): T & {
  tags: string[];
  platforms: ServerPlatform[];
  manualPlatforms: ServerPlatform[];
  detectedPlatforms: ServerPlatform[];
} {
  const manualPlatforms = parsePlatformList(server.manualPlatforms);
  const detectedPlatforms = parsePlatformList(server.detectedPlatforms);
  return {
    ...server,
    tags: parseTags(server.tags),
    manualPlatforms,
    detectedPlatforms,
    platforms: effectivePlatforms({ manualPlatforms, detectedPlatforms }),
  };
}
