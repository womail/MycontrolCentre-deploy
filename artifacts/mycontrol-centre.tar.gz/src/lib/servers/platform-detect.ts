import type { Server } from "@prisma/client";
import { execOnServer } from "../ssh/client";
import {
  parseDetectOutput,
  PLATFORM_DETECT_COMMAND,
  type ServerPlatform,
} from "./platforms";

export async function detectServerPlatforms(server: Server): Promise<ServerPlatform[]> {
  try {
    const result = await execOnServer(server, PLATFORM_DETECT_COMMAND, {
      timeoutMs: 30_000,
    });
    if (result.exitCode !== 0) return [];
    return parseDetectOutput(result.stdout);
  } catch {
    return [];
  }
}
