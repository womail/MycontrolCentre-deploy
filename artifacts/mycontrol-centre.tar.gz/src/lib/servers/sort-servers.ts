export type ServerSortKey =
  | "name"
  | "host"
  | "user"
  | "auth"
  | "health"
  | "os"
  | "platforms"
  | "status"
  | "updates"
  | "lastCheck";

export type SortDir = "asc" | "desc";

export interface SortableServerRow {
  name: string;
  hostname: string;
  port: number;
  sshUser: string;
  authType: string;
  healthStatus: string;
  platforms: string[];
  detectedOsFamily: string | null;
  detectedOsLabel: string | null;
  inMaintenance: boolean;
  isActive: boolean;
  proxmoxVersion: string | null;
  lastHealthCheck: string | null;
  pendingPackageUpdates: number | null;
}

function statusRank(row: SortableServerRow): string {
  if (row.inMaintenance) return "maintenance";
  if (!row.isActive) return "inactive";
  if (row.proxmoxVersion) return row.proxmoxVersion;
  return "active";
}

export function compareServers(
  a: SortableServerRow,
  b: SortableServerRow,
  key: ServerSortKey,
  dir: SortDir,
): number {
  let cmp = 0;
  switch (key) {
    case "name":
      cmp = a.name.localeCompare(b.name);
      break;
    case "host":
      cmp = `${a.hostname}:${a.port}`.localeCompare(`${b.hostname}:${b.port}`);
      break;
    case "user":
      cmp = a.sshUser.localeCompare(b.sshUser);
      break;
    case "auth":
      cmp = a.authType.localeCompare(b.authType);
      break;
    case "health":
      cmp = a.healthStatus.localeCompare(b.healthStatus);
      break;
    case "os": {
      const oa = a.detectedOsLabel ?? a.detectedOsFamily ?? "";
      const ob = b.detectedOsLabel ?? b.detectedOsFamily ?? "";
      cmp = oa.localeCompare(ob);
      break;
    }
    case "platforms":
      cmp = a.platforms.join(",").localeCompare(b.platforms.join(","));
      break;
    case "status":
      cmp = statusRank(a).localeCompare(statusRank(b));
      break;
    case "updates":
      cmp = (a.pendingPackageUpdates ?? -1) - (b.pendingPackageUpdates ?? -1);
      break;
    case "lastCheck": {
      const ta = a.lastHealthCheck ? new Date(a.lastHealthCheck).getTime() : 0;
      const tb = b.lastHealthCheck ? new Date(b.lastHealthCheck).getTime() : 0;
      cmp = ta - tb;
      break;
    }
    default:
      cmp = 0;
  }
  return dir === "asc" ? cmp : -cmp;
}
