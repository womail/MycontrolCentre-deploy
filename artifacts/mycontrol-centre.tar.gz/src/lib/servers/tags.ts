export function parseTags(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((item): item is string => typeof item === "string");
}

export function tagsToJson(tags: string[]): string[] {
  return tags.map((t) => t.trim()).filter(Boolean);
}
