import type { ServerGroup } from "@prisma/client";
import { prisma } from "../db";
import { parseTags } from "./tags";

export function parseStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
}

export type ServerGroupTarget = Pick<
  ServerGroup,
  "kind" | "serverIds" | "matchTags" | "matchAnyTag"
>;

export function normalizeTag(tag: string): string {
  return tag.trim().toLowerCase();
}

export function serverMatchesTags(
  serverTags: string[],
  matchTags: string[],
  matchAnyTag: boolean,
): boolean {
  const normalized = matchTags.map(normalizeTag).filter(Boolean);
  if (normalized.length === 0) return false;
  const tags = serverTags.map(normalizeTag);
  if (matchAnyTag) {
    return normalized.some((tag) => tags.includes(tag));
  }
  return normalized.every((tag) => tags.includes(tag));
}

export async function resolveServerGroupMemberIds(
  groupId: string,
  options?: { activeOnly?: boolean },
): Promise<string[]> {
  const group = await prisma.serverGroup.findUnique({ where: { id: groupId } });
  if (!group) return [];
  return resolveServerGroupMembers(group, options);
}

export async function resolveServerGroupMembers(
  group: ServerGroupTarget,
  options?: { activeOnly?: boolean },
): Promise<string[]> {
  const activeOnly = options?.activeOnly !== false;

  if (group.kind === "STATIC") {
    const ids = parseStringArray(group.serverIds);
    if (!activeOnly) return ids;
    if (ids.length === 0) return [];
    const active = await prisma.server.findMany({
      where: { id: { in: ids }, isActive: true },
      select: { id: true },
    });
    const activeSet = new Set(active.map((entry) => entry.id));
    return ids.filter((id) => activeSet.has(id));
  }

  const matchTags = parseStringArray(group.matchTags);
  const servers = await prisma.server.findMany({
    where: activeOnly ? { isActive: true } : {},
    select: { id: true, tags: true },
  });

  return servers
    .filter((server) =>
      serverMatchesTags(parseTags(server.tags), matchTags, group.matchAnyTag),
    )
    .map((server) => server.id);
}

export async function resolveProfileServerIds(profile: {
  serverIds: unknown;
  serverGroupId: string | null;
}): Promise<string[]> {
  if (profile.serverGroupId) {
    return resolveServerGroupMemberIds(profile.serverGroupId, { activeOnly: true });
  }
  const ids = parseStringArray(profile.serverIds);
  if (ids.length === 0) return [];
  const active = await prisma.server.findMany({
    where: { id: { in: ids }, isActive: true },
    select: { id: true },
  });
  const activeSet = new Set(active.map((entry) => entry.id));
  return ids.filter((id) => activeSet.has(id));
}
