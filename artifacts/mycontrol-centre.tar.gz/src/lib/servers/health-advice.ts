export interface HealthAdviceCommand {
  label: string;
  command: string;
}

export interface HealthAdvice {
  id: string;
  title: string;
  summary: string;
  steps: string[];
  commands: HealthAdviceCommand[];
}

export interface ServerHealthContext {
  name: string;
  hostname: string;
  port: number;
  sshUser: string;
  authType: string;
  healthMessage?: string | null;
  inMaintenance?: boolean;
}

function msg(ctx: ServerHealthContext): string {
  return (ctx.healthMessage ?? "").toLowerCase();
}

export function getServerHealthAdvice(ctx: ServerHealthContext): HealthAdvice | null {
  if (ctx.inMaintenance) {
    return {
      id: "maintenance",
      title: "Server in maintenance",
      summary: "Health checks and operator runs may be suppressed while maintenance is enabled.",
      steps: [
        "Open server settings (gear icon on the Fleet row) and clear maintenance when work is finished.",
        "Run a health check from the Fleet tab.",
      ],
      commands: [],
    };
  }

  const m = msg(ctx);
  const host = `${ctx.sshUser}@${ctx.hostname}`;
  const portFlag = ctx.port === 22 ? "" : ` -p ${ctx.port}`;

  if (
    m.includes("all configured authentication methods failed") ||
    m.includes("authentication methods failed")
  ) {
    return {
      id: "auth-failed",
      title: "SSH authentication failed",
      summary:
        "The console could reach the host, but the stored private key or password was rejected. The key on the server often does not match the key in MyControl Centre.",
      commands: [
        {
          label: "On the host — list mcc-auto keys",
          command: `sudo grep -v '^#' /home/${ctx.sshUser}/.ssh/authorized_keys 2>/dev/null || echo '(no keys file)'`,
        },
        {
          label: "From your workstation — test SSH (replace key path)",
          command: `ssh -i /path/to/private_key${portFlag} -o BatchMode=yes -o ConnectTimeout=10 ${host} 'echo ok'`,
        },
      ],
      steps: [
        "Admin → Vault: unlock and confirm the private key matches the wizard key you used when adding this server.",
        "On the host as root: verify mcc-auto’s authorized_keys contains the same public key (or re-run the install command from Setup & add).",
        "If you rotated keys, open Fleet → gear icon → SSH connection, paste the current private key, then health-check again.",
        "Optional: remove old keys on the host with the remote cleanup command (Vault or Setup wizard).",
      ],
    };
  }

  if (m.includes("host key verification failed") || m.includes("host key mismatch")) {
    return {
      id: "host-key",
      title: "SSH host key mismatch",
      summary: "The server’s host key does not match the known host key stored for this entry.",
      steps: [
        "From a trusted network, run ssh-keyscan and compare with the server’s Known host key in settings.",
        "If the host was reinstalled, update the known host key or enable accept-on-first-connect once (admin only).",
      ],
      commands: [
        {
          label: "Fetch current host keys",
          command: `ssh-keyscan -t ed25519,rsa -p ${ctx.port} ${ctx.hostname} 2>/dev/null`,
        },
      ],
    };
  }

  if (
    m.includes("econnrefused") ||
    m.includes("connection refused") ||
    m.includes("etimedout") ||
    m.includes("timed out") ||
    m.includes("connect timeout")
  ) {
    return {
      id: "network",
      title: "Cannot reach SSH port",
      summary: "TCP connection to the host or port failed. This is usually firewall, wrong IP/port, or sshd not listening.",
      steps: [
        "Confirm hostname/IP and port on the Fleet row match the host.",
        "From the MyControl Centre host (or your PC), test port reachability.",
        "On the remote host: ensure sshd is running and the firewall allows port " + String(ctx.port) + ".",
      ],
      commands: [
        {
          label: "Test TCP from console host",
          command: `nc -zv ${ctx.hostname} ${ctx.port} 2>&1 || curl -v --connect-timeout 5 telnet://${ctx.hostname}:${ctx.port} 2>&1 | head -5`,
        },
        {
          label: "On the remote host — sshd status",
          command: "systemctl status ssh --no-pager || systemctl status sshd --no-pager",
        },
      ],
    };
  }

  if (m.includes("enotfound") || m.includes("getaddrinfo")) {
    return {
      id: "dns",
      title: "Hostname not resolved",
      summary: "DNS lookup for the configured hostname failed from the console container/host.",
      steps: [
        "Use an IP address instead of a short hostname, or fix DNS on the MyControl Centre host.",
      ],
      commands: [
        {
          label: "Test resolution from console host",
          command: `getent hosts ${ctx.hostname} || nslookup ${ctx.hostname}`,
        },
      ],
    };
  }

  if (m.includes("unsupported key format") || m.includes("cannot parse private key")) {
    return {
      id: "key-format",
      title: "Private key format not supported",
      summary: "The stored private key is not in a format ssh2 can use (OpenSSH PEM required).",
      steps: [
        "Regenerate a key in Servers → Setup & add, or convert with: ssh-keygen -p -m PEM -f keyfile",
        "Update the server record with the OpenSSH private key and run health check again.",
      ],
      commands: [
        {
          label: "Convert key to PEM (on a machine with ssh-keygen)",
          command: "ssh-keygen -p -m PEM -f ./mycontrol_private_key",
        },
      ],
    };
  }

  if (m.includes("permission denied") && !m.includes("authentication methods")) {
    return {
      id: "permission-denied",
      title: "Permission denied",
      summary: "SSH connected but the user cannot run the health check command (shell or authorized_keys restriction).",
      steps: [
        "Confirm the SSH user is correct and the account is not locked.",
        "Re-run the host setup script to refresh authorized_keys and sudoers.",
      ],
      commands: [
        {
          label: "On the host — test local login",
          command: `su - ${ctx.sshUser} -c 'echo mcc-ok'`,
        },
      ],
    };
  }

  if (ctx.healthMessage?.trim()) {
    return {
      id: "generic",
      title: "Health check failed",
      summary: ctx.healthMessage.trim(),
      steps: [
        "Review the error above and connection logs under Logs → Remote SSH.",
        "Run a manual health check after fixing the underlying issue.",
      ],
      commands: [],
    };
  }

  return {
    id: "offline-unknown",
    title: "Server offline",
    summary: "No recent error message stored. Run a health check to capture diagnostics.",
    steps: ["Click the health-check button on the Fleet tab."],
    commands: [],
  };
}
