import type { Prisma } from "@prisma/client";
import { serializeKnownHostKeys } from "@/lib/ssh/known-host-keys";

export function resolveEnrollmentKnownHostKey(input: {
  knownHostKey?: string | null;
  knownHostKeys?: string[] | null;
  metadata?: Prisma.JsonValue;
}): string | null {
  const keys: string[] = [];
  if (input.knownHostKeys?.length) {
    keys.push(...input.knownHostKeys);
  }
  if (input.knownHostKey?.trim()) {
    keys.push(input.knownHostKey.trim());
  }
  if (input.metadata && typeof input.metadata === "object" && !Array.isArray(input.metadata)) {
    const meta = input.metadata as Record<string, unknown>;
    const fromMeta = meta.hostKeys;
    if (Array.isArray(fromMeta)) {
      for (const entry of fromMeta) {
        if (typeof entry === "string" && entry.trim()) keys.push(entry.trim());
      }
    }
  }
  return serializeKnownHostKeys(keys);
}
