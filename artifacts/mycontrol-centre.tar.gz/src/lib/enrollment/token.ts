import { randomBytes } from "crypto";
import { getSetting, setSetting } from "../settings";

const SETTINGS_KEY = "enrollment_token";

export async function getEnrollmentToken(): Promise<string | null> {
  const raw = await getSetting(SETTINGS_KEY, "");
  return raw.trim() || null;
}

export async function ensureEnrollmentToken(): Promise<string> {
  const existing = await getEnrollmentToken();
  if (existing) return existing;

  const token = randomBytes(24).toString("base64url");
  await setSetting(SETTINGS_KEY, token);
  return token;
}

export async function rotateEnrollmentToken(): Promise<string> {
  const token = randomBytes(24).toString("base64url");
  await setSetting(SETTINGS_KEY, token);
  return token;
}

export function sanitizeEnrollmentTokenForClient(token: string | null): string | null {
  if (!token) return null;
  if (token.length <= 8) return "********";
  return `${token.slice(0, 4)}…${token.slice(-4)}`;
}
