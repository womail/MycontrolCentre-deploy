import { prisma } from "../db";
import { encrypt, decrypt } from "../crypto";
import { fingerprintPublicKey, fingerprintPublicKeyLookupKeys } from "./register";

const SETUP_KEY_TTL_MS = 30 * 24 * 60 * 60 * 1000;

export async function storeSetupSshKey(input: {
  createdById: string;
  publicKey: string;
  privateKey: string;
}): Promise<{ id: string; publicKeyFingerprint: string }> {
  const publicKey = input.publicKey.trim();
  const fingerprint = fingerprintPublicKey(publicKey);
  const expiresAt = new Date(Date.now() + SETUP_KEY_TTL_MS);

  const lookupKeys = fingerprintPublicKeyLookupKeys(publicKey);
  await prisma.setupSshKey.deleteMany({
    where: { publicKeyFingerprint: { in: lookupKeys } },
  });

  const row = await prisma.setupSshKey.create({
    data: {
      createdById: input.createdById,
      publicKey,
      publicKeyFingerprint: fingerprint,
      encryptedPrivateKey: encrypt(input.privateKey.trim()),
      expiresAt,
    },
  });

  return { id: row.id, publicKeyFingerprint: fingerprint };
}

export async function findStoredPrivateKeyForFingerprint(
  fingerprint: string | null | undefined,
): Promise<string | null> {
  if (!fingerprint?.trim()) return null;
  const needle = fingerprint.trim();

  const rows = await prisma.setupSshKey.findMany({
    where: { expiresAt: { gt: new Date() } },
    orderBy: { createdAt: "desc" },
  });

  for (const row of rows) {
    const keys = fingerprintPublicKeyLookupKeys(row.publicKey);
    if (keys.includes(needle)) {
      return decrypt(row.encryptedPrivateKey);
    }
  }
  return null;
}

export async function consumeSetupSshKey(fingerprint: string): Promise<void> {
  const needle = fingerprint.trim();
  const rows = await prisma.setupSshKey.findMany({
    select: { id: true, publicKey: true, publicKeyFingerprint: true },
  });
  const ids = rows
    .filter((row) => fingerprintPublicKeyLookupKeys(row.publicKey).includes(needle))
    .map((row) => row.id);
  if (ids.length > 0) {
    await prisma.setupSshKey.deleteMany({ where: { id: { in: ids } } });
  }
}

export async function hasStoredSetupKey(fingerprint: string | null | undefined): Promise<boolean> {
  if (!fingerprint?.trim()) return false;
  const key = await findStoredPrivateKeyForFingerprint(fingerprint);
  return key != null;
}

export async function deleteSetupSshKeyById(id: string): Promise<void> {
  await prisma.setupSshKey.delete({ where: { id } });
}

export async function deleteExpiredSetupSshKeys(): Promise<number> {
  const result = await prisma.setupSshKey.deleteMany({
    where: { expiresAt: { lte: new Date() } },
  });
  return result.count;
}

export async function deleteAllSetupSshKeys(): Promise<number> {
  const result = await prisma.setupSshKey.deleteMany({});
  return result.count;
}
