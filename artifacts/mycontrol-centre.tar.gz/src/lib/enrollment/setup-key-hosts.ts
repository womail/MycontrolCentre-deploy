import { utils } from "ssh2";
import { privateKeyForSsh2 } from "../ssh/private-key-for-ssh2";
import { fingerprintPublicKey } from "./register";
import {
  opensshSha256FingerprintLabel,
  publicKeysMatch,
} from "../ssh/openssh-fingerprint";

/** SHA-256 fingerprint (base64) of the public half of a stored private key PEM. */
export function fingerprintPrivateKeyPem(pem: string): string | null {
  try {
    const normalized = privateKeyForSsh2(pem.trim());
    const parsed = utils.parseKey(normalized);
    if (parsed instanceof Error) return null;
    const pub = parsed.getPublicSSH();
    if (!pub) return null;
    const line = `${parsed.type} ${pub.toString("base64")}`;
    return fingerprintPublicKey(line);
  } catch {
    return null;
  }
}

/** OpenSSH public key line (type + base64) derived from a private key PEM. */
export function opensshPublicLineFromPrivate(pem: string): string | null {
  try {
    const normalized = privateKeyForSsh2(pem.trim());
    const parsed = utils.parseKey(normalized);
    if (parsed instanceof Error) return null;
    const pub = parsed.getPublicSSH();
    if (!pub) return null;
    const comment = parsed.comment || "mycontrol-centre";
    return `${parsed.type} ${pub.toString("base64")} ${comment}`.trim();
  } catch {
    return null;
  }
}

export type SetupKeyHostLink = {
  kind: "fleet" | "enrollment_pending" | "enrollment_approved" | "enrollment_rejected";
  label: string;
  hostname: string;
  port: number;
  sshUser: string;
  serverId?: string;
  enrollmentId?: string;
  statusNote?: string;
};

export function opensshFingerprintLabelFromPrivate(pem: string): string | null {
  const line = opensshPublicLineFromPrivate(pem);
  if (!line) return null;
  return opensshSha256FingerprintLabel(line);
}

export function privateKeyMatchesPublicLine(privatePem: string, publicLine: string): boolean {
  const derived = opensshPublicLineFromPrivate(privatePem);
  if (!derived) return false;
  return publicKeysMatch(derived, publicLine);
}

export function mergeSetupKeyHostLinks(links: SetupKeyHostLink[]): SetupKeyHostLink[] {
  const seen = new Set<string>();
  const out: SetupKeyHostLink[] = [];
  for (const link of links) {
    const key =
      link.serverId ??
      link.enrollmentId ??
      `${link.kind}:${link.hostname}:${link.port}:${link.sshUser}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(link);
  }
  return out;
}
