import { createHash } from "crypto";
import {
  legacyMccPublicKeyFingerprint,
  opensshSha256Fingerprint,
  opensshPublicKeyBlobB64,
} from "../ssh/openssh-fingerprint";
import { z } from "zod";

export const enrollmentRegisterSchema = z.object({
  name: z.string().min(1).max(100),
  hostname: z.string().min(1).max(255),
  port: z.number().int().min(1).max(65535).default(22),
  sshUser: z.string().min(1).max(64),
  publicKey: z.string().min(20).max(8000),
  knownHostKey: z.string().max(2000).optional().nullable(),
  knownHostKeys: z.array(z.string().min(1).max(2000)).optional(),
  hostKeyType: z.string().max(32).optional().nullable(),
  metadata: z.record(z.unknown()).optional(),
});

/** OpenSSH-standard SHA256 fingerprint (base64, no prefix). */
export function fingerprintPublicKey(publicKey: string): string {
  const standard = opensshSha256Fingerprint(publicKey);
  if (standard) return standard;
  const normalized = publicKey.trim().split(/\s+/);
  const keyData = normalized.length >= 2 ? normalized[1] : publicKey;
  return createHash("sha256").update(keyData).digest("base64");
}

/** Lookup key for enrollment/setup rows (new + legacy fingerprints). */
export function fingerprintPublicKeyLookupKeys(publicKey: string): string[] {
  const keys = new Set<string>();
  const standard = fingerprintPublicKey(publicKey);
  keys.add(standard);
  const legacy = legacyMccPublicKeyFingerprint(publicKey);
  if (legacy) keys.add(legacy);
  const b64 = opensshPublicKeyBlobB64(publicKey);
  if (b64) keys.add(createHash("sha256").update(b64, "utf8").digest("base64"));
  return [...keys];
}

export function normalizeEnrollmentPublicKey(publicKey: string): string {
  const trimmed = publicKey.trim();
  if (!trimmed.startsWith("ssh-")) {
    throw new Error("publicKey must be an OpenSSH public key line");
  }
  return trimmed;
}
