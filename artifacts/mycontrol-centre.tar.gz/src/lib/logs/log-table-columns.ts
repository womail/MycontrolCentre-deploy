export type LogTabId = "audit" | "remote" | "api";

const STORAGE_PREFIX = "mcc_logs_col_";

export type AuditColWidths = {
  time: number;
  user: number;
  action: number;
  resource: number;
  ip: number;
  details: number;
};

export type RemoteColWidths = {
  time: number;
  server: number;
  target: number;
  purpose: number;
  user: number;
  outcome: number;
  duration: number;
  details: number;
};

export type ApiColWidths = {
  time: number;
  method: number;
  path: number;
  status: number;
  duration: number;
  user: number;
  ip: number;
};

export const DEFAULT_AUDIT_COL_WIDTHS: AuditColWidths = {
  time: 168,
  user: 100,
  action: 140,
  resource: 120,
  ip: 112,
  details: 280,
};

export const DEFAULT_REMOTE_COL_WIDTHS: RemoteColWidths = {
  time: 168,
  server: 120,
  target: 220,
  purpose: 120,
  user: 100,
  outcome: 96,
  duration: 96,
  details: 200,
};

export const DEFAULT_API_COL_WIDTHS: ApiColWidths = {
  time: 168,
  method: 88,
  path: 320,
  status: 88,
  duration: 96,
  user: 100,
  ip: 120,
};

function readJson<T extends Record<string, number>>(key: string, defaults: T): T {
  if (typeof window === "undefined") return defaults;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw) as Partial<T>;
    const next = { ...defaults };
    for (const k of Object.keys(defaults) as (keyof T)[]) {
      const v = parsed[k];
      if (typeof v === "number" && v >= 48) {
        next[k] = v as T[typeof k];
      }
    }
    return next;
  } catch {
    return defaults;
  }
}

function storeJson(key: string, value: Record<string, number>) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(value));
}

export function readAuditColWidths(): AuditColWidths {
  return readJson(`${STORAGE_PREFIX}audit`, DEFAULT_AUDIT_COL_WIDTHS);
}

export function storeAuditColWidths(widths: AuditColWidths) {
  storeJson(`${STORAGE_PREFIX}audit`, widths);
}

export function readRemoteColWidths(): RemoteColWidths {
  return readJson(`${STORAGE_PREFIX}remote`, DEFAULT_REMOTE_COL_WIDTHS);
}

export function storeRemoteColWidths(widths: RemoteColWidths) {
  storeJson(`${STORAGE_PREFIX}remote`, widths);
}

export function readApiColWidths(): ApiColWidths {
  return readJson(`${STORAGE_PREFIX}api`, DEFAULT_API_COL_WIDTHS);
}

export function storeApiColWidths(widths: ApiColWidths) {
  storeJson(`${STORAGE_PREFIX}api`, widths);
}
