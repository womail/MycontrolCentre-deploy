"use client";

import { useMemo, useState } from "react";

export type SortDir = "asc" | "desc";

export function useSortedRows<T>(
  rows: T[],
  initialKey: keyof T,
  compare: (a: T, b: T, key: keyof T) => number,
) {
  const [sortKey, setSortKey] = useState<keyof T>(initialKey);
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  const sorted = useMemo(() => {
    const mult = sortDir === "asc" ? 1 : -1;
    return [...rows].sort((a, b) => mult * compare(a, b, sortKey));
  }, [rows, sortKey, sortDir, compare]);

  function toggleSort(key: keyof T) {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  }

  return { sorted, sortKey, sortDir, toggleSort };
}

function compareStrings(a: string | null | undefined, b: string | null | undefined) {
  return (a ?? "").localeCompare(b ?? "", undefined, { sensitivity: "base" });
}

export function compareAuditLogs<T extends {
  createdAt: string;
  action: string;
  resourceType: string | null;
  ipAddress: string | null;
  user: { username: string } | null;
}>(a: T, b: T, key: keyof T): number {
  switch (key) {
    case "createdAt":
      return a.createdAt.localeCompare(b.createdAt);
    case "action":
      return compareStrings(a.action, b.action);
    case "resourceType":
      return compareStrings(a.resourceType, b.resourceType);
    case "ipAddress":
      return compareStrings(a.ipAddress, b.ipAddress);
    case "user":
      return compareStrings(a.user?.username, b.user?.username);
    default:
      return 0;
  }
}

export function compareRemoteLogs<T extends {
  createdAt: string;
  hostname: string;
  purpose: string;
  outcome: string;
  durationMs: number | null;
  user: { username: string } | null;
  server: { name: string } | null;
  serverName: string | null;
}>(a: T, b: T, key: keyof T): number {
  switch (key) {
    case "createdAt":
      return a.createdAt.localeCompare(b.createdAt);
    case "hostname":
      return compareStrings(a.hostname, b.hostname);
    case "purpose":
      return compareStrings(a.purpose, b.purpose);
    case "outcome":
      return compareStrings(a.outcome, b.outcome);
    case "durationMs":
      return (a.durationMs ?? -1) - (b.durationMs ?? -1);
    case "user":
      return compareStrings(a.user?.username, b.user?.username);
    case "server":
      return compareStrings(a.server?.name ?? a.serverName, b.server?.name ?? b.serverName);
    default:
      return 0;
  }
}

export function compareApiLogs<T extends {
  createdAt: string;
  method: string;
  path: string;
  statusCode: number;
  durationMs: number;
  ipAddress: string | null;
  user: { username: string } | null;
}>(a: T, b: T, key: keyof T): number {
  switch (key) {
    case "createdAt":
      return a.createdAt.localeCompare(b.createdAt);
    case "method":
      return compareStrings(a.method, b.method);
    case "path":
      return compareStrings(a.path, b.path);
    case "statusCode":
      return a.statusCode - b.statusCode;
    case "durationMs":
      return a.durationMs - b.durationMs;
    case "ipAddress":
      return compareStrings(a.ipAddress, b.ipAddress);
    case "user":
      return compareStrings(a.user?.username, b.user?.username);
    default:
      return 0;
  }
}
