import { getSetting, setSetting } from "../settings";

export const DEFAULT_BACKUP_MAX_AGE_HOURS = 168;

export async function getBackupMaxAgeHours(): Promise<number> {
  const raw = await getSetting("backup_max_age_hours", String(DEFAULT_BACKUP_MAX_AGE_HOURS));
  const parsed = parseInt(raw, 10);
  if (!Number.isFinite(parsed) || parsed < 1 || parsed > 8760) {
    return DEFAULT_BACKUP_MAX_AGE_HOURS;
  }
  return parsed;
}

export async function setBackupMaxAgeHours(hours: number): Promise<void> {
  const normalized = Math.min(8760, Math.max(1, Math.floor(hours)));
  await setSetting("backup_max_age_hours", String(normalized));
}
