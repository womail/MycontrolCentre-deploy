import { getBackupMaxAgeHours } from "./settings";

export interface BackupFreshnessInput {
  lastBackupAt: Date | null;
  lastBackupSource: string | null;
  requiresFreshBackup: boolean;
  isProxmoxHost: boolean;
}

export interface BackupFreshnessResult {
  stale: boolean;
  missing: boolean;
  maxAgeHours: number;
  ageHours: number | null;
  message?: string;
}

export async function evaluateBackupFreshness(
  input: BackupFreshnessInput,
): Promise<BackupFreshnessResult> {
  const maxAgeHours = await getBackupMaxAgeHours();

  if (!input.requiresFreshBackup || !input.isProxmoxHost) {
    return { stale: false, missing: false, maxAgeHours, ageHours: null };
  }

  if (!input.lastBackupAt) {
    return {
      stale: true,
      missing: true,
      maxAgeHours,
      ageHours: null,
      message: "No recent vzdump or ZFS snapshot found on this Proxmox host",
    };
  }

  const ageMs = Date.now() - input.lastBackupAt.getTime();
  const ageHours = ageMs / (60 * 60 * 1000);

  if (ageHours > maxAgeHours) {
    const source = input.lastBackupSource ?? "backup";
    return {
      stale: true,
      missing: false,
      maxAgeHours,
      ageHours,
      message: `Last ${source} was ${Math.round(ageHours)}h ago (max ${maxAgeHours}h)`,
    };
  }

  return { stale: false, missing: false, maxAgeHours, ageHours };
}

export function formatBackupAge(hours: number | null): string {
  if (hours == null) return "unknown";
  if (hours < 24) return `${Math.round(hours)}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}
