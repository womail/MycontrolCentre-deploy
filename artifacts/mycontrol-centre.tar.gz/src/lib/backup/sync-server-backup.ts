import type { Server } from "@prisma/client";
import { prisma } from "../db";
import { execOnServer } from "../ssh/client";
import { parseTemplatePlatforms } from "../servers/platforms";

const BACKUP_PROBE_COMMAND = `(
  grep -E 'INFO: (Finished backup|Backup finished successfully)' /var/log/vzdump.log 2>/dev/null | tail -1 | awk '{print "vzdump:" $1 " " $2}'
  zfs list -t snapshot -H -o creation -s creation 2>/dev/null | tail -1 | awk '{print "zfs:" $1}'
) | head -1`;

export interface BackupProbeResult {
  lastBackupAt: Date | null;
  lastBackupSource: string | null;
}

export function parseBackupProbeOutput(stdout: string): BackupProbeResult {
  const line = stdout.trim().split("\n").pop()?.trim() ?? "";
  if (!line) {
    return { lastBackupAt: null, lastBackupSource: null };
  }

  if (line.startsWith("zfs:")) {
    const epoch = Number(line.slice(4));
    if (!Number.isFinite(epoch) || epoch <= 0) {
      return { lastBackupAt: null, lastBackupSource: null };
    }
    return {
      lastBackupAt: new Date(epoch * 1000),
      lastBackupSource: "zfs",
    };
  }

  if (line.startsWith("vzdump:")) {
    const timestamp = line.slice("vzdump:".length).trim();
    const parsed = Date.parse(`${timestamp} UTC`);
    if (!Number.isFinite(parsed)) {
      return { lastBackupAt: null, lastBackupSource: null };
    }
    return {
      lastBackupAt: new Date(parsed),
      lastBackupSource: "vzdump",
    };
  }

  return { lastBackupAt: null, lastBackupSource: null };
}

export function serverNeedsBackupProbe(server: Server): boolean {
  const manual = parseTemplatePlatforms(server.manualPlatforms);
  const detected = parseTemplatePlatforms(server.detectedPlatforms);
  return manual.includes("proxmox") || detected.includes("proxmox");
}

export async function syncServerBackupStatus(server: Server): Promise<BackupProbeResult | null> {
  if (!serverNeedsBackupProbe(server)) return null;

  try {
    const result = await execOnServer(server, BACKUP_PROBE_COMMAND, {
      timeoutMs: 20_000,
      log: { purpose: "HEALTH_CHECK" },
    });
    const probe = parseBackupProbeOutput(result.stdout);
    await prisma.server.update({
      where: { id: server.id },
      data: {
        lastBackupAt: probe.lastBackupAt,
        lastBackupSource: probe.lastBackupSource,
      },
    });
    return probe;
  } catch (error) {
    console.error(`[backup] Failed to probe ${server.name}:`, error);
    return null;
  }
}
