import { prisma } from "./db";
import { redactSecrets } from "./crypto";
import type { AuditAction, Prisma } from "@prisma/client";

export async function logAudit(params: {
  userId?: string | null;
  action: AuditAction;
  resourceType?: string;
  resourceId?: string;
  details?: Record<string, unknown>;
  ipAddress?: string;
  userAgent?: string;
}) {
  const sanitizedDetails = params.details
    ? JSON.parse(
        redactSecrets(JSON.stringify(params.details)),
      ) as Prisma.InputJsonValue
    : undefined;

  return prisma.auditLog.create({
    data: {
      userId: params.userId ?? null,
      action: params.action,
      resourceType: params.resourceType,
      resourceId: params.resourceId,
      details: sanitizedDetails,
      ipAddress: params.ipAddress,
      userAgent: params.userAgent,
    },
  });
}

export async function purgeOldAuditLogs(): Promise<number> {
  const retentionDays = parseInt(
    process.env.AUDIT_LOG_RETENTION_DAYS ?? "365",
    10,
  );
  const cutoff = new Date(Date.now() - retentionDays * 24 * 60 * 60 * 1000);
  const result = await prisma.auditLog.deleteMany({
    where: { createdAt: { lt: cutoff } },
  });
  return result.count;
}
