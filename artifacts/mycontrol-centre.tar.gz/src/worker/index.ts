import { startCommandWorker } from "../lib/queue/command-queue";
import { startBackgroundServices } from "../lib/queue/background-services";

console.log("Starting MyControl Centre standalone command worker...");

const worker = startCommandWorker();
startBackgroundServices();

process.on("SIGTERM", async () => {
  console.log("Shutting down worker...");
  await worker.close();
  process.exit(0);
});

process.on("SIGINT", async () => {
  console.log("Shutting down worker...");
  await worker.close();
  process.exit(0);
});
