#!/bin/sh
# Runs as root, drops to nextjs for the app process.
set -e

APP_USER="${APP_USER:-nextjs}"
APP_GROUP="${APP_GROUP:-nodejs}"
DATA_DIR="/app/.data"

mkdir -p "$DATA_DIR"
chown -R "${APP_USER}:${APP_GROUP}" "$DATA_DIR"

if [ -z "${SESSION_SECRET:-}" ] || [ "${SESSION_SECRET#change-me}" != "${SESSION_SECRET}" ]; then
  echo "ERROR: Set SESSION_SECRET (32+ chars) in .env or compose environment." >&2
  exit 1
fi
if [ -z "${ENCRYPTION_KEY:-}" ] || [ "${ENCRYPTION_KEY#change-me}" != "${ENCRYPTION_KEY}" ]; then
  echo "ERROR: Set ENCRYPTION_KEY (openssl rand -base64 32) in .env or compose environment." >&2
  exit 1
fi

export DATABASE_URL="${DATABASE_URL:-file:${DATA_DIR}/mycontrol.db}"

run_as_app() {
  if command -v su-exec >/dev/null 2>&1; then
    su-exec "${APP_USER}:${APP_GROUP}" "$@"
  else
    exec "$@"
  fi
}

echo "Applying database schema (${DATABASE_URL})..."
run_as_app npx prisma db push --skip-generate

if [ "${RUN_SEED:-true}" = "true" ]; then
  echo "Seeding database (idempotent)..."
  if ! run_as_app npm run db:seed; then
    echo "WARNING: Seed failed — admin user or templates may be missing. Run: docker compose exec app npm run db:seed" >&2
  fi
fi

echo "Starting MyControl Centre..."
if [ -x /usr/bin/ssh-keygen ]; then
  echo "ssh-keygen: /usr/bin/ssh-keygen"
else
  echo "WARNING: /usr/bin/ssh-keygen missing — SSH wizard will use in-process key generation" >&2
fi
exec su-exec "${APP_USER}:${APP_GROUP}" node server.js
