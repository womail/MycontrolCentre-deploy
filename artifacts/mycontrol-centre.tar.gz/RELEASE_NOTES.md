# Release Notes

All notable changes to MyControl Centre are documented here.

Format based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

---

## [0.1.1] — 2026-07-19

Documentation, testing, and operational tooling.

### Added
- `FEATURES.md` — living feature tracker (implemented vs planned)
- `RELEASE_NOTES.md` — changelog (this file)
- `scripts/start.sh` — unified launcher for dev, prod, docker, test, db, stop, and status
- Vitest unit test suite (46 tests) covering crypto, auth, commands, SSH helpers, rate limiting, and utils
- `npm test`, `npm run test:watch`, and `npm run test:coverage` scripts

### Changed
- README and `MycontrolCentre.md` updated to reference feature list, release notes, and start script

---

## [0.1.0] — 2026-07-19

Initial release — secure SSH automation platform for Proxmox servers.

### Added

#### Platform
- Next.js 15 web application with dashboard, dark/light theme, and responsive layout
- Docker Compose stack: `app`, `worker`, `postgres`, `redis`
- `scripts/start.sh` — unified launcher for dev, prod, and Docker modes
- Vitest unit test suite for core library modules
- Project documentation: `README.md`, `MycontrolCentre.md`, `FEATURES.md`

#### Authentication
- Server-side session auth with httpOnly cookies
- Default admin user (`admin` / `admin`) with forced password change on first login
- Three roles: Admin, Operator, Viewer
- Password policy: minimum 12 characters, upper, lower, and numeric required
- Login rate limiting (5 attempts per 15 minutes per IP)

#### Server management
- Server CRUD with name, hostname, port, SSH user, tags
- SSH auth modes: key, password, key + passphrase
- AES-256-GCM encryption for stored credentials
- Host key verification (strict or accept-on-first-connect)
- Manual health check via SSH probe
- In-app SSH setup guide for Proxmox hosts

#### Command execution
- Built-in commands: `cd`, `ls`, `apt update`, `apt upgrade`
- Non-interactive apt flags: `DEBIAN_FRONTEND=noninteractive`, `NEEDRESTART_MODE=a`, dpkg force options
- Custom single-line commands (admin only)
- Single-server and batch multi-server execution
- BullMQ async worker with configurable concurrent SSH sessions
- Command run history with stdout, stderr, exit code, and duration

#### Audit & settings
- Full audit trail for login, user/server CRUD, health checks, and command execution
- Secret redaction in audit log details
- Configurable audit retention (default 365 days) with automatic purge
- Admin settings page for concurrent SSH limit and retention

### Security
- bcrypt password hashing (12 rounds)
- Encrypted SSH credentials at rest
- Session tokens stored as SHA-256 hashes
- No PTY allocation on SSH exec (prevents interactive prompts)
- Multi-line custom commands blocked

### Known limitations
- 2FA not yet implemented
- No scheduled command runs
- No Proxmox API integration
- Worker concurrency setting requires worker restart to take full effect
- Integration and E2E tests not yet included

---

## [Unreleased]

---

## [0.9.0] — 2026-07-28 (feature release)

Live SSH console, SFTP file manager, security hardening, and URL-based section navigation.

### Added
- **Server console** (`/servers/{id}/console`): xterm.js SSH (multi-server tabs, font size, resizable geometry), SFTP file browser (upload/download, archives, resizable columns)
- **URL sections** for Servers, Commands, and Logs (`/servers/setup`, `/commands/docker`, `/logs/remote`, etc.) — bookmarkable tabs
- **Logs UI**: resizable columns, font controls, audit row slide-over with full JSON
- **SECURITY.md**, security response headers, login rate limiting (IP + username), timing-safe enrollment token compare
- **SBOM** script (`npm run sbom`); CycloneDX/SPDX outputs gitignored
- Tests: shell geometry, remote delete path validation, privilege updates

### Changed
- SSH/sudo: non-interactive `-n`, stale RUNNING recovery, client timeouts; remote delete path guardrails
- Connection/audit log APIs restricted to ADMIN and OPERATOR
- Package-update deep link: `/commands?runUpdates=…`; `#pending-enrollment` → `/servers/approvals`

### Fixed
- Terminal API column cap (max 300 cols) for wide layouts
- ESLint/TypeScript cleanup across API routes and command UI

---

## [0.10.6] — 2026-07-26

Fix disk cleanup commands in Run picker and support custom command types.

### Fixed
- **Disk category templates** (e.g. APT Clean Cache) now appear under Commands → Run
- **Proxmox hosts** match Debian-tagged templates for platform filtering

### Changed
- Command template **type** is a free-form string; custom types run via command text
- Manage commands: edit **category** and **platforms**; defaults `general` / `all`
- Schema: `CommandTemplate.type` and `CommandRun.commandType` are strings (run `prisma db push` after deploy)

---

## [0.10.5] — 2026-07-26

Commands UI: editable template type and clearer run workflow.

### Added
- **Slide-over panels** for command template edit/create and Run tab server/command/failure pickers

### Changed
- **Manage commands** — command **Type** is editable (including built-ins); API PATCH persists type changes
- **Commands → Run** — step cards plus clearer on-failure remediation explanation

---

## [0.10.4] — 2026-07-26

Fix database seeding inside the Docker image.

### Fixed
- **Docker seed** — build `prisma/seed.bundle.cjs` at image build time; entrypoint and `npm run db:seed` use the bundle (no `@/` path aliases or `src/` in the runtime image)
- Removed stale `prisma/seed.js` that skipped new command templates

---

## [0.10.3] — 2026-07-26

Host setup UX, mcc-auto useradd fix, and disk cleanup command templates.

### Added
- **Dual install one-liners** — root and `sudo` variants; overwrite and remove `/tmp/mcc-proxmox-setup.sh`
- **Disk command templates** — df summary, apt clean/autoremove, journal vacuum, pacman cache clean, Docker system prune
- **journalctl** in mcc-auto passwordless sudo (host setup script)

### Fixed
- **proxmox-host-setup.sh** — create user with `-g mcc-auto` when group already exists

---

## [0.10.2] — 2026-07-26

Vault access history shows server node and admin workstation node.

### Added
- **Vault last-used nodes** — server credentials show target `name (hostname:port)`; all entries show **From node** (optional browser label, reverse DNS, or IP)
- Optional **This computer's node name** on Admin → Vault (localStorage + `X-MCC-Client-Node`)
- `VaultAccessLog.clientNode`; reverse DNS helper for client IP

---

## [0.10.1] — 2026-07-26

TOTP QR enrollment and vault secret access history.

### Added
- **TOTP setup QR code** — scan in Account → Security when enrolling authenticator app
- **Vault access log** — per server/setup key: last viewed or copied, user, time, client (IP/browser/platform)
- `VaultAccessLog` table; `POST /api/admin/vault/access` for copy events

---

## [0.10.0] — 2026-07-26

Per-admin TOTP and optional WebAuthn; vault unlock paths.

### Added
- **Account → Security** — enroll authenticator app (TOTP) and security keys (WebAuthn)
- **Login step-up** — password then TOTP or security key when MFA is enabled; password-only if not enrolled
- **Vault unlock** — `SECRETS_VAULT_PASSWORD` still works alone; optional **Account + MFA** (password + TOTP or key)
- Schema: `UserMfa`, `WebAuthnCredential`; dependencies `otplib`, `@simplewebauthn/server`, `@simplewebauthn/browser`

### Changed
- Login and vault MFA API routes; middleware allows MFA verify endpoints without session

---

## [0.9.1] — 2026-07-25

Vault cleanup, remote host teardown script, and offline server guidance.

### Added
- **Vault** — delete setup wizard keys (single, expired, or all); production cleanup copy commands
- **Remote cleanup script** — `/api/setup/proxmox-host-cleanup.sh` revokes keys, sudoers, optional user delete
- **Health advice** — Dashboard and Fleet show issue-specific steps and copyable fix commands
- **Copy command** — prominent primary button before install/cleanup one-liners in the wizard

---

## [0.9.0] — 2026-07-25

Admin vault, cleaner Servers layout, and maintenance under System.

### Added
- **Admin → Vault** — unlock with `SECRETS_VAULT_PASSWORD` to view decrypted server SSH credentials and setup keys (15‑minute session)
- **Admin → System → Maintenance** — clear failed command runs, SSH failure logs, and wipe audit / remote / API logs (moved off Dashboard and Logs)
- **Servers tabs** — Fleet, Setup & add, Groups, Approvals (enrollment badge on Servers nav)

### Changed
- Left navigation order: Dashboard → Servers → Commands → Cluster → Logs; admin section grouped (Settings, System, Vault, Database, Users)
- Fleet table simplified (fewer columns; user/auth under name)
- Proxmox install one-liner removes `/tmp/mcc-proxmox-setup.sh` after run

### Removed
- Dashboard and Logs “clear logs” panels (use System → Maintenance)

---

## [0.8.0] — 2026-07-24

Server groups for batch and scheduled targeting.

### Added
- **Server groups** — admin CRUD on **Servers** (`STATIC` server lists or **TAG** rules with any/all match)
- **Group picker** on **Commands** (replace or add to server selection) and **Saved run profiles** (optional linked group)
- **Dynamic resolution** at profile run time (including weekly schedules) via `GET /api/server-groups/[id]/members`
- REST API: `GET/POST /api/server-groups`, `GET/PATCH/DELETE /api/server-groups/[id]`
- Unit tests for tag matching and group helpers

### Changed
- `SavedRunProfile` may use `serverGroupId` instead of a fixed `serverIds` list
- `FEATURES.md` / `MycontrolCentre.md` document `ServerGroup` schema

---

## [0.7.1] — 2026-07-24

Polish for enrollment errors, package update checks, and database restore UX.

### Added
- **Arch pacman update counts** — `pendingPackageUpdates` on Arch-tagged hosts via `pacman -Qu`
- **Updates column tooltip** — last package check time on Servers list

### Changed
- Enrollment API returns clearer validation messages; host script surfaces JSON `error` on failed POST
- Database restore shows a prominent **restart required** banner after success

---

## [0.7.0] — 2026-07-24

Remote enrollment, Docker operations, database admin, and fleet UX.

### Added
- **Remote enrollment** — host script POSTs to `/api/enrollment/register`; admin **Pending enrollment** queue with sidebar badge and one-click approve (stored wizard key)
- **Docker Engine / Portainer CE** install templates; **compose stack deploy** (SFTP + `docker compose up`)
- **Database admin** (`/admin/database`) — CRUD on selected tables, AES-256-GCM **encrypted backup/restore** with admin-stored password
- **Dashboard cleanup** — clear failed command runs and/or SSH failure logs (admin)
- **Server Updates column** — periodic apt upgrade count (health check + 6h scheduler)
- **Sortable server table** columns; **full-width** app layout
- SSH **privilege adaptation** (`sudo -S` / temp scripts) for Docker and apt on automation users
- Multi **host key** verification (RSA + ed25519) for SSH strict mode

### Fixed
- Server delete blocked by command history (FK cascade on `CommandRun`)
- Enrollment POST rejected for long RSA host keys; curl HTTP code `400000` false failure in setup script

---

Scheduled profile runs, backup awareness, and CI/build fixes.

### Added
- **Scheduled profile runs** — weekly UTC cron per saved profile (Commands → Profiles → Schedule)
- **Backup awareness** — blocks destructive commands on Proxmox hosts when vzdump/ZFS snapshot is stale or missing
- **Backup freshness setting** — configurable max age (default 168h) in Settings → System
- **GitHub Actions CI** — lint, test, and build on push/PR

### Changed
- Health checks probe last backup timestamp on Proxmox servers (`lastBackupAt`, `lastBackupSource`)
- Built-in templates marked `requiresFreshBackup`: APT Upgrade, Pacman Upgrade, Restart LXC
- Preview and execute show backup warnings; admins can override with “Override stale backup guard”
- `withApiLog` route handlers aligned with Next.js 15 `RouteContext` typing

### Fixed
- Production build type errors (change-password route context, template JSON updates, guest picker, alerts merge, fleet-stats filter, proxmox sync JSON, ssh wizard error state)
- Duplicate `zod` import in command templates API route

---

## [0.5.0] — 2026-07-22

Proxmox depth, platform-aware commands, and guest picker.

### Added
- **Server platforms** — manual tags (Proxmox, Debian, Docker, Arch) plus auto-detection on health check
- **Platform-filtered commands** — command list narrows to templates compatible with selected servers
- **Categorized command library** — nested groups: Filesystem, APT, Arch, Proxmox, Docker
- **Guest picker** — select VMID from synced Proxmox inventory when running guest commands
- **Cluster page** — fleet view of Proxmox nodes, quorum, guest counts, and sync status
- **Docker commands** — `docker ps`, images, system df (shown when Docker platform detected)
- **Arch commands** — pacman sync and upgrade templates

### Changed
- Built-in templates now include `category` and `platforms` metadata
- Proxmox inventory sync auto-tags server as Proxmox platform

---

## [0.4.0] — 2026-07-22

Ops maturity: scheduled monitoring, alerts, fleet dashboard, and change accountability.

### Added
- **Scheduled health checks** — background worker probes active servers on a configurable interval
- **Alert notifications** — webhook, ntfy, and Gotify channels with cooldown and maintenance suppression
- **Settings → Alerts & health checks** — configure intervals, channels, and send test alerts
- **Richer dashboard** — offline servers, pending/failed runs, 24h SSH failure rate, Proxmox quorum warnings
- **Change reason field** — required for multi-server or multi-command runs; stored in audit and history

### Changed
- Manual health checks refactored through shared `runServerHealthCheck` service
- Embedded worker now runs log purge and health scheduler via `startBackgroundServices()`

---

## [0.3.1] — 2026-07-22

Live command output streaming.

### Added
- **SSE live output** — `GET /api/commands/runs/[id]/stream` streams stdout/stderr while runs execute
- Commands page **Live** badge and auto-scroll output panel during `PENDING`/`RUNNING` runs
- In-process run stream bus with replay for late subscribers
- Worker flushes partial output to SQLite every 2 seconds during execution

---

## [0.3.0] — 2026-07-22

Operations usability and Proxmox-specific fleet features.

### Added
- **Maintenance windows** — mark servers in maintenance; operators blocked from runs; admin override
- **Dry-run preview** — `POST /api/commands/preview` and UI button before queueing
- **Saved run profiles** — named server + command presets with one-click run
- **Batch comparison view** — per-server success/fail, duration, exit code, stderr snippets
- **Failure remediation** — optional follow-up templates auto-queued when a run fails
- **Template variables** — `{{vmid}}` substitution for guest-aware commands
- **Proxmox API integration** — read-only token storage, inventory sync, guest cache
- **Proxmox built-in templates** — pveversion, cluster resources, ZFS, Ceph, guest status/restart
- Dashboard cards for Proxmox guest count and maintenance status
- Servers → Operations panel for maintenance + Proxmox settings and guest inventory

### Changed
- Command execution uses shared `buildExecutionPlan` for preview and execute
- Seed includes Proxmox maintenance command templates

---

## [0.2.1] — 2026-07-20

Automated Proxmox host SSH onboarding.

### Added
- `scripts/proxmox-host-setup.sh` — run on each Proxmox host as root to create `mcc-auto`, install pubkey, configure apt sudo
- Public endpoint `GET /api/setup/proxmox-host.sh` for curl-based remote install
- `POST /api/setup/ssh-key` — admin API to generate ed25519 key pair + install one-liner
- **Servers** page wizard: generate key → copy install command → paste host output → pre-fill Add Server form
- Known host key field on Add Server form

### Changed
- Apt templates now use `sudo apt-get` (matches bootstrap sudoers rule)
- SSH setup documentation expanded in `MycontrolCentre.md`

---

## [0.2.0] — 2026-07-19

Zero-dependency local deployment — SQLite replaces PostgreSQL and Redis.

### Added
- **SQLite** single-file database (`.data/mycontrol.db`) — no PostgreSQL required
- **Embedded command worker** — queue runs inside the Next.js process (no Redis/BullMQ)
- `scripts/setup.sh` — first-time local setup (Node “virtualenv”: `node_modules/` + SQLite + `.env`)
- `npm run setup` and `npm run local` shortcuts
- `.nvmrc` for Node 22 via nvm
- Unit tests for server tags JSON helper

### Changed
- Default start command is now `./scripts/start.sh local` (was Docker-based dev)
- Docker Compose simplified to single app container with SQLite volume (optional)
- Server tags stored as JSON (SQLite compatibility)
- README and docs updated for native local-first workflow

### Removed
- PostgreSQL dependency
- Redis and BullMQ dependency
- Separate worker process required by default (still available with `RUN_EMBEDDED_WORKER=false`)

### Migration note
If you had a PostgreSQL database, export your data and re-add servers in the new SQLite install. No automatic migration path in v0.2.0.

---
- TOTP two-factor authentication
- Integration tests for API routes
- GitHub Actions CI (lint, test, build)
- Audit log export (CSV/JSON)
- Periodic automatic server health checks

### Planned (future)
- Proxmox API integration (VMs, containers, storage)
- Scheduled / cron command runs
- Server groups and tag-based batch targeting
- Live command output streaming (WebSocket)
- Jump host / bastion SSH support
