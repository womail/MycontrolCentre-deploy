import { prisma } from "../src/lib/db";
import { hashPassword } from "../src/lib/auth/password";
import {
  buildBashScriptCommand,
  DOCKER_ENGINE_INSTALL_UBUNTU,
  portainerCeInstallScript,
} from "../src/lib/docker/scripts";

type SeedTemplate = {
  name: string;
  type: "CD" | "LS" | "APT_UPDATE" | "APT_UPGRADE" | "CUSTOM";
  description: string;
  commandText?: string;
  category: string;
  platforms: string[];
  sortOrder: number;
  adminOnly?: boolean;
  requiresFreshBackup?: boolean;
};

async function upsertTemplate(template: SeedTemplate) {
  await prisma.commandTemplate.upsert({
    where: { name: template.name },
    update: {
      description: template.description,
      commandText: template.commandText ?? null,
      category: template.category,
      platforms: template.platforms,
      sortOrder: template.sortOrder,
      adminOnly: template.adminOnly ?? false,
      requiresFreshBackup: template.requiresFreshBackup ?? false,
      isBuiltIn: true,
      isActive: true,
    },
    create: {
      ...template,
      commandText: template.commandText ?? null,
      adminOnly: template.adminOnly ?? false,
      requiresFreshBackup: template.requiresFreshBackup ?? false,
      isBuiltIn: true,
      isActive: true,
    },
  });
}

async function main() {
  const admin = await prisma.user.upsert({
    where: { username: "admin" },
    update: {},
    create: {
      username: "admin",
      passwordHash: await hashPassword("admin"),
      role: "ADMIN",
      mustChangePassword: true,
    },
  });

  console.log(`Seeded admin user: ${admin.username} (must change password on first login)`);

  const templates: SeedTemplate[] = [
    {
      name: "Change Directory",
      type: "CD",
      description: "Verify access to a directory path",
      category: "filesystem",
      platforms: ["all"],
      sortOrder: 10,
    },
    {
      name: "List Directory",
      type: "LS",
      description: "List files in a directory (ls -la)",
      category: "filesystem",
      platforms: ["all"],
      sortOrder: 20,
    },
    {
      name: "Disk Usage Summary",
      type: "CUSTOM",
      description: "Show filesystem and inode usage (df -hT / df -i)",
      commandText: "df -hT && echo && df -i",
      category: "disk",
      platforms: ["all"],
      sortOrder: 25,
    },
    {
      name: "APT Update",
      type: "APT_UPDATE",
      description: "Refresh package lists (non-interactive)",
      category: "apt",
      platforms: ["debian"],
      sortOrder: 30,
    },
    {
      name: "APT Upgrade",
      type: "APT_UPGRADE",
      description: "Upgrade installed packages (non-interactive)",
      category: "apt",
      platforms: ["debian"],
      sortOrder: 40,
      requiresFreshBackup: true,
    },
    {
      name: "APT Clean Cache",
      type: "CUSTOM",
      description: "Remove downloaded .deb packages from /var/cache/apt/archives",
      commandText: "sudo apt-get clean && sudo apt-get autoclean -qq",
      category: "disk",
      platforms: ["debian"],
      sortOrder: 42,
    },
    {
      name: "APT Autoremove",
      type: "CUSTOM",
      description: "Remove unused dependency packages (safe after upgrades)",
      commandText:
        "export DEBIAN_FRONTEND=noninteractive; sudo apt-get autoremove -y -qq",
      category: "disk",
      platforms: ["debian"],
      sortOrder: 43,
    },
    {
      name: "Journal Vacuum (7 days)",
      type: "CUSTOM",
      description: "Shrink systemd journal — keep last 7 days of logs",
      commandText: "sudo journalctl --vacuum-time=7d",
      category: "disk",
      platforms: ["debian", "arch"],
      sortOrder: 44,
    },
    {
      name: "Journal Vacuum (500 MB)",
      type: "CUSTOM",
      description: "Cap systemd journal disk use at about 500 MB",
      commandText: "sudo journalctl --vacuum-size=500M",
      category: "disk",
      platforms: ["debian", "arch"],
      sortOrder: 46,
    },
    {
      name: "DPKG Configure (remediation)",
      type: "CUSTOM",
      description: "Fix interrupted apt/dpkg after failed upgrade",
      commandText: "DEBIAN_FRONTEND=noninteractive dpkg --configure -a",
      category: "apt",
      platforms: ["debian"],
      sortOrder: 45,
      adminOnly: true,
    },
    {
      name: "Pacman Sync",
      type: "CUSTOM",
      description: "Refresh Arch package databases",
      commandText: "sudo pacman -Sy --noconfirm",
      category: "arch",
      platforms: ["arch"],
      sortOrder: 50,
    },
    {
      name: "Pacman Upgrade",
      type: "CUSTOM",
      description: "Upgrade Arch packages (non-interactive)",
      commandText: "sudo pacman -Syu --noconfirm",
      category: "arch",
      platforms: ["arch"],
      sortOrder: 55,
      adminOnly: true,
      requiresFreshBackup: true,
    },
    {
      name: "Pacman Cache Clean",
      type: "CUSTOM",
      description: "Remove uninstalled package files from pacman cache",
      commandText: "sudo pacman -Sc --noconfirm",
      category: "disk",
      platforms: ["arch"],
      sortOrder: 56,
      adminOnly: true,
    },
    {
      name: "PVE Version",
      type: "CUSTOM",
      description: "Show Proxmox VE version details",
      commandText: "pveversion -v",
      category: "proxmox",
      platforms: ["proxmox"],
      sortOrder: 100,
    },
    {
      name: "Cluster Resources",
      type: "CUSTOM",
      description: "List cluster resources via pvesh",
      commandText: "pvesh get /cluster/resources --output-format json-pretty",
      category: "proxmox",
      platforms: ["proxmox"],
      sortOrder: 110,
    },
    {
      name: "ZFS Pool List",
      type: "CUSTOM",
      description: "List ZFS pools and usage",
      commandText: "zfs list",
      category: "proxmox",
      platforms: ["proxmox"],
      sortOrder: 120,
    },
    {
      name: "Ceph Status",
      type: "CUSTOM",
      description: "Show Ceph cluster health (if configured)",
      commandText: "ceph status 2>/dev/null || echo 'Ceph not configured on this node'",
      category: "proxmox",
      platforms: ["proxmox"],
      sortOrder: 130,
    },
    {
      name: "Cluster Status",
      type: "CUSTOM",
      description: "Corosync / cluster quorum via pvesh",
      commandText: "pvesh get /cluster/status --output-format json-pretty",
      category: "proxmox",
      platforms: ["proxmox"],
      sortOrder: 140,
    },
    {
      name: "Guest Status (QEMU)",
      type: "CUSTOM",
      description: "Show VM status — pick guest or set {{vmid}}",
      commandText: "qm status {{vmid}}",
      category: "proxmox",
      platforms: ["proxmox"],
      sortOrder: 150,
    },
    {
      name: "Guest Status (LXC)",
      type: "CUSTOM",
      description: "Show container status — pick guest or set {{vmid}}",
      commandText: "pct status {{vmid}}",
      category: "proxmox",
      platforms: ["proxmox"],
      sortOrder: 160,
    },
    {
      name: "Restart LXC",
      type: "CUSTOM",
      description: "Restart a container — pick guest or set {{vmid}}",
      commandText: "pct reboot {{vmid}}",
      category: "proxmox",
      platforms: ["proxmox"],
      sortOrder: 170,
      adminOnly: true,
      requiresFreshBackup: true,
    },
    {
      name: "Docker PS",
      type: "CUSTOM",
      description: "List running Docker containers",
      commandText: "docker ps --format 'table {{.Names}}\\t{{.Status}}\\t{{.Ports}}'",
      category: "docker",
      platforms: ["docker"],
      sortOrder: 200,
    },
    {
      name: "Docker Images",
      type: "CUSTOM",
      description: "List Docker images on the host",
      commandText: "docker images",
      category: "docker",
      platforms: ["docker"],
      sortOrder: 210,
    },
    {
      name: "Docker System DF",
      type: "CUSTOM",
      description: "Show Docker disk usage summary",
      commandText: "docker system df",
      category: "docker",
      platforms: ["docker"],
      sortOrder: 220,
    },
    {
      name: "Docker System Prune",
      type: "CUSTOM",
      description:
        "Remove unused Docker images, containers, and build cache (does not remove named volumes)",
      commandText: "docker system prune -af",
      category: "docker",
      platforms: ["docker"],
      sortOrder: 225,
      adminOnly: true,
    },
    {
      name: "Install Docker Engine (Ubuntu)",
      type: "CUSTOM",
      description:
        "Official Docker apt repository install for Ubuntu (docs.docker.com/engine/install/ubuntu)",
      commandText: buildBashScriptCommand(DOCKER_ENGINE_INSTALL_UBUNTU),
      category: "docker",
      platforms: ["debian"],
      sortOrder: 230,
      adminOnly: true,
    },
    {
      name: "Install Portainer CE",
      type: "CUSTOM",
      description:
        "Deploy Portainer CE LTS on ports 8000/9443 (docs.portainer.io Docker on Linux)",
      commandText: buildBashScriptCommand(portainerCeInstallScript()),
      category: "docker",
      platforms: ["docker"],
      sortOrder: 240,
      adminOnly: true,
    },
    {
      name: "Install Portainer CE (+ HTTP 9000)",
      type: "CUSTOM",
      description: "Portainer CE with legacy HTTP port 9000 exposed in addition to 9443",
      commandText: buildBashScriptCommand(portainerCeInstallScript({ httpLegacyPort: true })),
      category: "docker",
      platforms: ["docker"],
      sortOrder: 245,
      adminOnly: true,
    },
  ];

  for (const template of templates) {
    await upsertTemplate(template);
  }

  const settings = [
    { key: "max_concurrent_ssh", value: process.env.MAX_CONCURRENT_SSH ?? "5" },
  ];

  for (const s of settings) {
    await prisma.appSetting.upsert({
      where: { key: s.key },
      update: {},
      create: s,
    });
  }

  console.log("Seed completed.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
