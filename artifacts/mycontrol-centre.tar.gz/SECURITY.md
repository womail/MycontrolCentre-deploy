# Security — MyControl Centre

This document summarizes security controls, OWASP Top 10 (2021) alignment, SBOM generation, and deployment hardening recommendations.

## SBOM (Software Bill of Materials)

Generate dependency SBOMs locally (Node.js 20+):

```bash
npm run sbom
```

Outputs (gitignored; attach to releases or your asset inventory):

| File | Format |
|------|--------|
| `sbom.cyclonedx.json` | CycloneDX 1.5 |
| `sbom.spdx.json` | SPDX |

Review periodically with `npm audit` and your vulnerability scanner against these SBOMs.

## Architecture trust boundaries

| Zone | Exposure | Notes |
|------|----------|--------|
| Browser | Untrusted | Session cookie (`httpOnly`, `sameSite=lax`, `secure` when HTTPS) |
| Next.js API | Authenticated | `withAuth`, role checks, Zod validation on inputs |
| Managed servers | SSH/SFTP | Encrypted credentials, host key verification, audit logs |
| Public endpoints | Limited | Login, MFA, health, enrollment (token), Proxmox install scripts |

## OWASP Top 10 (2021) — mapping

| ID | Risk | Status in MCC | Notes |
|----|------|---------------|--------|
| **A01** | Broken access control | **Mostly mitigated** | `withAuth` + `{ roles: [...] }` on sensitive routes; VIEWER blocked from commands, console, logs APIs. Admin DB/vault/users ADMIN-only. **Recommendation:** periodic review of new API routes for role defaults. |
| **A02** | Cryptographic failures | **Mitigated** | AES-256-GCM for secrets at rest (`ENCRYPTION_KEY`); session tokens hashed (SHA-256) in DB; bcrypt passwords. **Recommendation:** TLS in front of app (`SESSION_COOKIE_SECURE=true`, strong ciphers on reverse proxy). |
| **A03** | Injection | **Partially mitigated** | Command templates: blocked patterns, length limits, no newlines on custom commands. Remote paths: absolute paths, no `..`. File delete: **protected paths** (`/`, `/etc`, `/usr`, …). SSH uses parameterized exec/SFTP, not shell string concat for user paths (except `rm -rf` with `shellEscape` on validated paths). **Risk:** operators can still run destructive *allowed* commands on servers — least privilege on `mcc-auto` sudoers. |
| **A04** | Insecure design | **Acceptable for LAN ops tool** | Embedded worker, SQLite single-node. **Recommendation:** do not expose to Internet without WAF, VPN, or Zero Trust. |
| **A05** | Security misconfiguration | **Hardened in app** | Security headers (CSP, `X-Frame-Options`, etc.) via middleware. **Recommendation:** set strong `SESSION_SECRET`, `ENCRYPTION_KEY`, rotate defaults; disable enrollment when unused; `APP_URL` must match how clients reach the app. |
| **A06** | Vulnerable components | **Process** | Run `npm audit`, `npm run sbom`, patch dependencies on cadence. |
| **A07** | Auth failures | **Mitigated** | Rate limit login (IP + username), MFA (TOTP/WebAuthn), session expiry, `mustChangePassword`, inactive users rejected. |
| **A08** | Software/data integrity | **Partial** | Host key pinning for SSH. Proxmox install scripts served over HTTP — **use TLS** on console URL in production. No CI artifact signing documented. |
| **A09** | Logging failures | **Mitigated** | Audit log, remote SSH log, API request log; retention env vars; secrets redacted in audit JSON. |
| **A10** | SSRF | **Low direct risk** | App initiates outbound SSH to configured hosts only, not arbitrary URLs from user input. Enrollment/register validates host fields, not open URL fetch. |

## Validation summary

| Area | Mechanism |
|------|-----------|
| API bodies | Zod schemas (commands, servers, enrollment, terminal geometry, file actions) |
| Remote paths | `validatePath`, `validateRemoteEntryName`, `validateSafeRemoteDeletePath` |
| Commands | `validateCustomCommand`, blocked destructive regexes, admin-only templates |
| Upload/download | Size caps (50 MB / 100 MB), authenticated SFTP |
| Terminal | Cols/rows clamped (40–300 / 8–120), session ownership checks |

## Controls implemented (code)

- Session-based auth with server-side session store
- Role-based access: ADMIN / OPERATOR / VIEWER
- Encryption at rest for SSH keys and passwords
- SSH host key verifier (TOFU or stored key)
- `sudo -n` / non-interactive patterns for automation users
- Audit events for file mutations, server changes, login failures
- Login + enrollment rate limiting (in-memory; see below)
- Timing-safe enrollment token compare
- HTTP security headers on responses via middleware

## Recommendations (operations)

1. **Network:** Place MCC on a management VLAN; require VPN or Tailscale; never port-forward `:3000` to the public Internet without TLS + WAF.
2. **TLS:** Terminate HTTPS at Caddy/nginx/Traefik; set `SESSION_COOKIE_SECURE=true` and trust `X-Forwarded-Proto`.
3. **Secrets:** Unique `SESSION_SECRET`, `ENCRYPTION_KEY`, `SECRETS_VAULT_PASSWORD` per environment; never commit `.env`.
4. **SSH on targets:** Dedicated `mcc-auto` user, key-only, minimal sudoers (`NOPASSWD` only for required commands).
5. **Enrollment:** Rotate enrollment token after onboarding; disable by clearing token when not needed.
6. **Backups:** Encrypted DB backups (admin UI); protect backup password separately.
7. **Updates:** Rebuild Docker image on security patches; run `npm audit fix` when safe.
8. **Rate limits:** Current login/enrollment limits are **per process** — fine for single container; for multi-instance use Redis-backed limiter.
9. **CSP:** Current policy allows `'unsafe-inline'` for Next.js — tighten if you move to nonce-based CSP.
10. **Monitoring:** Alert on repeated `LOGIN_FAILED`, failed SSH outcomes, spike in API 401/403.

## Public endpoints (review regularly)

- `POST /api/auth/login`, MFA routes
- `GET /api/health`
- `POST /api/enrollment/register` (Bearer enrollment token)
- `GET /api/setup/proxmox-host.sh`, cleanup script
- `GET /api/settings/appearance` (theme only)

All other `/api/*` routes expect a valid session cookie (middleware) plus handler-level authorization.

## Reporting issues

Report security concerns privately to the repository owner. Do not open public issues for unpatched vulnerabilities.
