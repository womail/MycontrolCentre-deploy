# MyControl Centre

Secure web-based automation and remote command management for Proxmox servers over SSH.

**Runs locally with only Node.js** — no Docker, PostgreSQL, or Redis required. Uses SQLite and an embedded command worker.

## Quick start (recommended)

Requirements: **Node.js 20+** (22 recommended). Optional: [nvm](https://github.com/nvm-sh/nvm) reads `.nvmrc`.

```bash
chmod +x scripts/setup.sh scripts/start.sh

# First-time setup (creates .env, node_modules, SQLite DB)
./scripts/setup.sh

# Start the app
./scripts/start.sh local
```

Open http://localhost:3000 → login **`admin` / `admin`** → change password on first login.

Or as npm scripts:

```bash
npm run setup
npm run local
```

## What “virtual environment” means here

This is a Node.js project, not Python. The isolated local environment is:

| Component | Location | Purpose |
|-----------|----------|---------|
| Dependencies | `node_modules/` | npm packages (like a Python venv) |
| Database | `.data/mycontrol.db` | SQLite — no external DB server |
| Secrets | `.env` | Generated on setup |
| Logs | `.logs/` | App output when backgrounded |
| PIDs | `.run/` | Process tracking |

## Other commands

```bash
./scripts/start.sh dev      # Same as local (dev server + hot reload)
./scripts/start.sh prod     # Production build + start
./scripts/start.sh status   # Check if running
./scripts/start.sh stop     # Stop the app
./scripts/start.sh test     # Unit tests
./scripts/start.sh db       # Re-apply schema + seed
./scripts/start.sh docker   # Optional Docker (SQLite volume)
```

## Testing

```bash
npm test
```

## Architecture

- **Next.js 15** — UI + REST API
- **SQLite** — single-file database, zero config
- **Embedded worker** — command queue runs inside the app (no Redis)
- **AES-256-GCM** — encrypted SSH credentials
- **Server-side sessions** — httpOnly cookies

## Default roles

| Role | Capabilities |
|------|----------------|
| Admin | Full CRUD, custom commands, settings |
| Operator | Run predefined commands, view logs |
| Viewer | Read-only dashboard, logs, run history |

## Documentation

| Document | Purpose |
|----------|---------|
| [MycontrolCentre.md](./MycontrolCentre.md) | Schema, env vars, SSH setup |
| [FEATURES.md](./FEATURES.md) | Implemented vs planned features |
| [RELEASE_NOTES.md](./RELEASE_NOTES.md) | Changelog |
