# MyControl Centre — Feature List

Track what is implemented, in progress, and planned. Update this file when shipping features.

**Legend:** ✅ Implemented · 🚧 In progress · 📋 Planned

---

## Core platform

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Next.js web UI + REST API | ✅ | 0.1.0 | App Router, TypeScript |
| SQLite database (zero external DB) | ✅ | 0.2.0 | `.data/mycontrol.db` |
| Embedded command worker (no Redis) | ✅ | 0.2.0 | `RUN_EMBEDDED_WORKER=true` |
| Local setup script (`scripts/setup.sh`) | ✅ | 0.2.0 | Node virtualenv equivalent |
| Docker Compose deployment | ✅ | 0.2.0 | Optional single-container SQLite |
| PostgreSQL data store | 📋 | — | Removed in 0.2.0; SQLite preferred for local |
| Redis job queue | 📋 | — | Removed in 0.2.0; embedded queue |
| Dark / light theme | ✅ | 0.1.0 | User toggle, persisted |
| Admin appearance settings | ✅ | 0.2.2 | Colors, buttons, fonts (Settings) |
| Mobile-friendly layout | ✅ | 0.1.0 | Responsive sidebar + tables |
| Full-width page layout | ✅ | 0.7.0 | Uses browser width; `PageContainer` |
| Database admin (CRUD + backup) | ✅ | 0.7.0 | `/admin/database`, encrypted `.mccdb` |
| Startup script (`scripts/start.sh`) | ✅ | 0.1.1 | dev, prod, docker, test, stop, status |
| Unit test suite (Vitest) | ✅ | 0.7.1 | 112+ tests, core lib coverage |
| Feature list (`FEATURES.md`) | ✅ | 0.1.1 | Implemented vs planned tracker |
| Release notes (`RELEASE_NOTES.md`) | ✅ | 0.1.1 | Keep a Changelog format |

---

## Authentication & users

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Username / password login | ✅ | 0.1.0 | bcrypt, 12 rounds |
| Server-side sessions | ✅ | 0.1.0 | httpOnly cookies, DB-backed |
| Default admin user (`admin` / `admin`) | ✅ | 0.1.0 | Seeded on first run |
| Force password change on first login | ✅ | 0.1.0 | `mustChangePassword` flag |
| Password strength policy | ✅ | 0.1.0 | 12+ chars, upper, lower, digit |
| Role: Admin | ✅ | 0.1.0 | Full access |
| Role: Operator | ✅ | 0.1.0 | Run commands, view data |
| Role: Viewer | ✅ | 0.1.0 | Read-only |
| User CRUD (admin) | ✅ | 0.1.0 | Create, list, update, delete |
| Login rate limiting | ✅ | 0.1.0 | 5 attempts / 15 min per IP |
| Session revocation on password change | ✅ | 0.1.0 | All sessions cleared |
| TOTP 2FA | ✅ | 0.10.0 | Per-user enrollment; optional WebAuthn; password-only login if MFA not set up |
| Password reset via email | 📋 | — | Planned |
| API tokens / service accounts | 📋 | — | Planned |

---

## Server management

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Server list with CRUD | ✅ | 0.1.0 | Admin only for write |
| SSH key authentication | ✅ | 0.1.0 | PEM private key |
| SSH password authentication | ✅ | 0.1.0 | Encrypted at rest |
| Key + passphrase auth | ✅ | 0.1.0 | KEY_AND_PASSWORD mode |
| Encrypted credential storage | ✅ | 0.1.0 | AES-256-GCM |
| Host key verification | ✅ | 0.1.0 | Strict or accept-on-first-connect |
| Server tags | ✅ | 0.1.0 | Stored, UI basic |
| Manual health check | ✅ | 0.1.0 | SSH probe + status |
| SSH setup guide (in-app) | ✅ | 0.1.0 | Servers page |
| Automated host bootstrap script | ✅ | 0.2.1 | `scripts/proxmox-host-setup.sh` |
| In-console SSH setup wizard | ✅ | 0.2.1 | Key gen + one-liner + form pre-fill |
| Remote enrollment queue | ✅ | 0.7.0 | Host script → API → admin approve |
| Pending enrollment sidebar badge | ✅ | 0.7.0 | Inbox + count on Servers nav |
| Sortable servers table | ✅ | 0.7.0 | Name, host, health, updates, etc. |
| Pending package update count | ✅ | 0.7.0 | apt (Debian/Proxmox); pacman (Arch) in 0.7.1 |
| Host setup API (public script) | ✅ | 0.2.1 | `GET /api/setup/proxmox-host.sh` |
| Periodic automatic health checks | ✅ | 0.4.0 | Embedded scheduler; configurable interval |
| Health check alerts | ✅ | 0.4.0 | Webhook, ntfy, Gotify; cooldown + maintenance suppress |
| Server groups for batch targeting | ✅ | 0.8.0 | Static lists + tag rules; Commands/Profiles picker; dynamic resolve for scheduled profiles |
| Servers page tabs (Fleet / Setup / Groups / Approvals) | ✅ | 0.9.0 | Separates fleet view from wizard, groups, enrollment |
| Admin secrets vault | ✅ | 0.9.0 | `SECRETS_VAULT_PASSWORD`; Admin → Vault; credentials encrypted at rest via `ENCRYPTION_KEY` |
| Server platform tags | ✅ | 0.5.0 | Proxmox, Debian, Docker, Arch — manual + auto-detect |
| Jump host / bastion support | 📋 | — | Planned |
| Maintenance windows | ✅ | 0.3.0 | Block operator runs; admin override |
| Proxmox API integration | ✅ | 0.3.0 | Read-only token, inventory sync, dashboard |
| Proxmox guest inventory | ✅ | 0.3.0 | Synced VM/CT list per server |

---

## Command execution

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Command: cd (verify path) | ✅ | 0.1.0 | Non-interactive |
| Command: ls (list directory) | ✅ | 0.1.0 | `ls -la` |
| Command: apt update | ✅ | 0.1.0 | `DEBIAN_FRONTEND=noninteractive` |
| Command: apt upgrade | ✅ | 0.1.0 | dpkg force-confdef/confold |
| Custom commands | ✅ | 0.1.0 | Admin only, single-line |
| Single-server execution | ✅ | 0.1.0 | |
| Batch multi-server execution | ✅ | 0.1.0 | Shared batch ID |
| Async job queue | ✅ | 0.1.0 | BullMQ worker |
| Configurable concurrent SSH limit | ✅ | 0.1.0 | Settings UI + env default |
| Command run history + output | ✅ | 0.1.0 | stdout/stderr retained |
| Admin command template CRUD | ✅ | 0.2.3 | Manage commands tab |
| Command test in editor | ✅ | 0.2.3 | Admin test against live server |
| Multi-command chains | ✅ | 0.2.3 | Select multiple commands in order |
| Selectable server/command lists | ✅ | 0.2.3 | Checkbox lists with run order |
| Command validation (paths, blocklist) | ✅ | 0.2.3 | Server-side validation |
| Dry-run / preview before execute | ✅ | 0.3.0 | Per-server command preview |
| Saved run profiles | ✅ | 0.3.0 | Named presets, one-click run |
| Batch run comparison view | ✅ | 0.3.0 | Side-by-side per-server results |
| Failure remediation templates | ✅ | 0.3.0 | Auto-queue on FAILED |
| Template variables (`{{vmid}}`) | ✅ | 0.3.0 | Guest-aware commands |
| Proxmox built-in command library | ✅ | 0.3.0 | pveversion, cluster, ZFS, Ceph, guest ops |
| Live streaming output (SSE) | ✅ | 0.3.1 | Live stdout/stderr on Commands page during runs |
| Change reason on batch runs | ✅ | 0.4.0 | Required for multi-server / multi-command runs |
| Fleet dashboard | ✅ | 0.4.0 | Offline list, failures, SSH error rate, quorum warnings |
| Admin maintenance (failed runs, clear logs) | ✅ | 0.9.0 | Admin → System; was on Dashboard/Logs in 0.7.0 |
| Command template categories | ✅ | 0.5.0 | Nested APT / Proxmox / Docker / Arch groups in UI |
| Platform-aware command filtering | ✅ | 0.5.0 | Commands filtered by server platform tags |
| Proxmox guest picker | ✅ | 0.5.0 | VMID dropdown from synced inventory |
| Cluster health page | ✅ | 0.5.0 | Quorum, node status, guest counts |
| Docker host commands | ✅ | 0.5.0 | Built-in docker ps/images/df when Docker detected |
| Docker Engine install (Ubuntu) | ✅ | 0.7.0 | Official apt repo install template |
| Portainer CE install | ✅ | 0.7.0 | Official LTS container template |
| Compose stack deploy | ✅ | 0.7.0 | Push docker-compose.yml + .env via SFTP, compose up |
| Arch host commands | ✅ | 0.5.0 | Built-in pacman sync/upgrade templates |
| Scheduled / cron commands | ✅ | 0.6.0 | Weekly UTC schedule per saved profile |
| Backup freshness guard | ✅ | 0.6.0 | vzdump/ZFS age check before destructive Proxmox commands |
| Command approval workflow | 📋 | — | Operator runs, admin approves |
| Ansible / playbook support | 📋 | — | Planned |

---

## Audit & logging

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Audit log for all actions | ✅ | 0.1.0 | Login, CRUD, commands |
| Remote SSH connection log | ✅ | 0.2.2 | Outbound SSH to managed servers |
| API request connection log | ✅ | 0.2.2 | Inbound `/api/*` requests |
| Secret redaction in logs | ✅ | 0.1.0 | Passwords, keys masked |
| Configurable retention period | ✅ | 0.1.0 | Default 365 days |
| Automatic log purge | ✅ | 0.1.0 | Worker maintenance task |
| Audit log export (CSV/JSON) | 📋 | — | Planned |
| SIEM / webhook integration | 📋 | — | Planned |

---

## Settings & security

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Max concurrent SSH setting | ✅ | 0.1.0 | Admin UI |
| Audit retention setting | ✅ | 0.1.0 | Admin UI |
| HTTPS reverse proxy docs | ✅ | 0.1.0 | MycontrolCentre.md |
| Secrets vault env (`SECRETS_VAULT_PASSWORD`) | ✅ | 0.9.0 | Documented in `.env.example` / compose |
| IP allowlist for UI | 📋 | — | Planned |
| Command allowlist per role | 📋 | — | Planned |
| Hardware security module (HSM) key storage | 📋 | — | Enterprise |

---

## Testing & DevOps

| Feature | Status | Version | Notes |
|---------|--------|---------|-------|
| Unit tests (Vitest) | ✅ | 0.1.1 | 46 tests — crypto, auth, commands, SSH helpers |
| Integration tests | 📋 | 0.2.0 | API routes with test DB |
| E2E tests (Playwright) | 📋 | 0.2.0 | Login, server CRUD flows |
| CI pipeline (GitHub Actions) | ✅ | 0.6.0 | lint, test, build on push/PR |
| Helm chart / K8s manifests | 📋 | — | Planned |

---

## How to update

When implementing a feature:

1. Move the row from **Planned** to **Implemented** with the release version.
2. Add an entry to [RELEASE_NOTES.md](./RELEASE_NOTES.md).
3. Update [MycontrolCentre.md](./MycontrolCentre.md) if schema or architecture changes.
4. If the feature originated in [suggestions.md](./suggestions.md), update status there too.
