#!/usr/bin/env tsx
/**
 * Offline memory / database report (no running server required).
 * Writes human-readable output to .logs/memory-report.txt
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { execSync } from "node:child_process";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const logDir = path.join(root, ".logs");
const dbPath = path.join(root, ".data", "mycontrol.db");

function mb(bytes: number) {
  return Math.round((bytes / (1024 * 1024)) * 10) / 10;
}

function sqlite(query: string): string {
  if (!fs.existsSync(dbPath)) return "";
  return execSync(`sqlite3 ${JSON.stringify(dbPath)} ${JSON.stringify(query)}`, {
    encoding: "utf8",
  }).trim();
}

function main() {
  fs.mkdirSync(logDir, { recursive: true });

  const lines: string[] = [
    "MyControl Centre — offline memory report",
    `Generated: ${new Date().toISOString()}`,
    "",
  ];

  if (!fs.existsSync(dbPath)) {
    lines.push("Database not found at .data/mycontrol.db — run setup first.");
  } else {
    const stat = fs.statSync(dbPath);
    lines.push("=== SQLite (.data/mycontrol.db) ===");
    lines.push(`File size: ${mb(stat.size)} MB`);
    lines.push("");

    const tables = [
      "ApiRequestLog",
      "AuditLog",
      "RemoteConnectionLog",
      "CommandRun",
      "Session",
    ];
    lines.push("=== Row counts ===");
    for (const table of tables) {
      try {
        const n = sqlite(`SELECT COUNT(*) FROM ${table};`);
        lines.push(`  ${table.padEnd(24)} ${n}`);
      } catch {
        lines.push(`  ${table.padEnd(24)} (missing)`);
      }
    }
    lines.push("");

    try {
      const out = sqlite(
        "SELECT COALESCE(SUM(LENGTH(stdout)+LENGTH(stderr)),0), COALESCE(MAX(LENGTH(stdout)+LENGTH(stderr)),0) FROM CommandRun;",
      );
      const [total, max] = out.split("|");
      lines.push("=== Command output stored ===");
      lines.push(`  Total bytes: ${total}`);
      lines.push(`  Largest run: ${max} bytes`);
      lines.push("");
    } catch {
      /* ignore */
    }

    try {
      const oldApi = sqlite(
        "SELECT COUNT(*) FROM ApiRequestLog WHERE createdAt < datetime('now', '-14 days');",
      );
      lines.push(`API logs older than 14 days (purge candidates): ${oldApi}`);
      lines.push("");
    } catch {
      /* ignore */
    }
  }

  lines.push("=== Live process (if app running on :3000) ===");
  lines.push(
    "As ADMIN, open: GET /api/admin/memory-diagnostics?format=text",
  );
  lines.push("Or JSON: GET /api/admin/memory-diagnostics");
  lines.push("");
  lines.push("=== Typical causes of 1–2 GB heap ===");
  lines.push("- next dev (default ./scripts/start.sh local) — compiler + HMR cache");
  lines.push("- Fix: ./scripts/start.sh prod  (production build, ~150–400 MB typical)");
  lines.push("- Long dev session without restart — restart stop && local");
  lines.push("- Many API log rows — wipe in Logs UI (see counts above)");
  lines.push("");

  lines.push("=== Unused / optional code paths ===");
  lines.push("- src/worker/index.ts — only when RUN_EMBEDDED_WORKER=false");
  lines.push("- stopBackgroundServices() — shutdown helper (not wired to HTTP)");
  lines.push("");

  const report = lines.join("\n");
  const outPath = path.join(logDir, "memory-report.txt");
  fs.writeFileSync(outPath, report, "utf8");
  console.log(report);
  console.log(`\nWrote ${outPath}`);
}

main();
