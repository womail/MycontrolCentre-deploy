#!/usr/bin/env bash
# Build the MyControl Centre image locally (same as compose build).
set -euo pipefail
cd "$(dirname "$0")/.."

if ! docker info >/dev/null 2>&1; then
  if command -v sudo >/dev/null 2>&1; then
    echo "Docker socket not available as $(whoami); re-running build with sudo -E …" >&2
    exec sudo -E "$0" "$@"
  fi
  echo "ERROR: Cannot access Docker (permission denied on docker.sock)." >&2
  echo "Run: sudo -E $0 $*" >&2
  exit 1
fi

export MCC_BUILD_REF="$(git rev-parse --short HEAD 2>/dev/null || echo unknown)"
export MCC_APP_VERSION="$(node -p "require('./package.json').version")"
export MCC_BUILD_TIME="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
docker compose build "$@"
