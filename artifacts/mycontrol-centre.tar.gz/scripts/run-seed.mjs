import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const bundle = path.join(root, "prisma/seed.bundle.cjs");

function runNode(scriptPath) {
  const result = spawnSync(process.execPath, [scriptPath], {
    stdio: "inherit",
    cwd: root,
    env: process.env,
  });
  process.exit(result.status ?? 1);
}

if (existsSync(bundle)) {
  runNode(bundle);
}

const tsx = path.join(root, "node_modules", ".bin", "tsx");
if (existsSync(tsx)) {
  const result = spawnSync(tsx, ["prisma/seed.ts"], {
    stdio: "inherit",
    cwd: root,
    env: process.env,
  });
  process.exit(result.status ?? 1);
}

console.error(
  "Seed bundle missing. Run: npm run build:seed  (or npm run db:seed from dev checkout with tsx installed)",
);
process.exit(1);
