#!/usr/bin/env bash
#
# MyControl Centre — Proxmox / Debian host bootstrap
#
# Run as root on each remote host you want to manage:
#
#   curl -fsSL http://YOUR_CONSOLE:3000/api/setup/proxmox-host.sh -o /tmp/mcc-proxmox-setup.sh
#   bash /tmp/mcc-proxmox-setup.sh --pubkey "ssh-ed25519 AAAA... your-key"
#
# Or copy scripts/proxmox-host-setup.sh to the host and run:
#
#   ./proxmox-host-setup.sh --pubkey "$(cat mycontrol.pub)"
#
set -euo pipefail

MCC_USER="${MCC_USER:-mcc-auto}"
MCC_PUBKEY=""
MCC_SSH_PORT="${MCC_SSH_PORT:-22}"
MCC_APT_SUDO="${MCC_APT_SUDO:-1}"
MCC_HOSTNAME=""
MCC_ENROLL_URL=""
MCC_ENROLL_TOKEN=""

usage() {
  cat <<'EOF'
Usage: proxmox-host-setup.sh [options]

Prepare a Proxmox (or Debian/Ubuntu) host for MyControl Centre SSH automation.

Options:
  --pubkey "KEY"     Required. OpenSSH public key line (ssh-ed25519 or ssh-rsa)
  --user NAME        Automation user (default: mcc-auto)
  --port PORT        SSH port this host listens on (default: 22, informational)
  --hostname NAME    Display name hint for the console (default: system hostname)
  --enroll-url URL   POST enrollment payload to this URL after setup (optional)
  --enroll-token T   Bearer token for enrollment API (required with --enroll-url)
  --no-apt-sudo      Do not grant passwordless sudo for apt-get
  -h, --help         Show this help

Example:
  ./proxmox-host-setup.sh --pubkey "ssh-ed25519 AAAA... comment"

After running, copy the "MyControl Centre values" section into the Add Server form.
EOF
}

log()  { echo "==> $*"; }
warn() { echo "==> WARNING: $*" >&2; }
die()  { echo "ERROR: $*" >&2; exit 1; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --pubkey)   MCC_PUBKEY="${2:?missing value for --pubkey}"; shift 2 ;;
    --user)     MCC_USER="${2:?missing value for --user}"; shift 2 ;;
    --port)     MCC_SSH_PORT="${2:?missing value for --port}"; shift 2 ;;
    --hostname) MCC_HOSTNAME="${2:?missing value for --hostname}"; shift 2 ;;
    --enroll-url) MCC_ENROLL_URL="${2:?missing value for --enroll-url}"; shift 2 ;;
    --enroll-token) MCC_ENROLL_TOKEN="${2:?missing value for --enroll-token}"; shift 2 ;;
    --no-apt-sudo) MCC_APT_SUDO=0; shift ;;
    -h|--help)  usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

[[ "$(id -u)" -eq 0 ]] || die "Run as root (e.g. sudo bash proxmox-host-setup.sh ...)"

[[ -n "${MCC_PUBKEY}" ]] || {
  echo ""
  echo "ERROR: --pubkey is required." >&2
  echo "" >&2
  echo "This script configures a Proxmox/Debian host for MyControl Centre." >&2
  echo "It must be run ON THE REMOTE HOST as root, not in your browser." >&2
  echo "" >&2
  echo "In MyControl Centre → Servers → Generate SSH key, then copy the full" >&2
  echo "install command (curl ... -o /tmp/mcc-proxmox-setup.sh && bash /tmp/mcc-proxmox-setup.sh --pubkey '...')." >&2
  echo "" >&2
  usage
  exit 1
}

# Basic pubkey validation
[[ "${MCC_PUBKEY}" == ssh-* ]] || die "Public key must start with ssh-ed25519 or ssh-rsa"

if [[ -n "${MCC_ENROLL_URL}" && -z "${MCC_ENROLL_TOKEN}" ]]; then
  die "--enroll-token is required when --enroll-url is set"
fi
if [[ -n "${MCC_ENROLL_TOKEN}" && -z "${MCC_ENROLL_URL}" ]]; then
  die "--enroll-url is required when --enroll-token is set"
fi

if [[ -z "${MCC_HOSTNAME}" ]]; then
  MCC_HOSTNAME="$(hostname -f 2>/dev/null || hostname)"
fi

# Resolve primary IP for console hostname field
MCC_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
if [[ -z "${MCC_IP}" ]]; then
  MCC_IP="$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}' | head -1)"
fi
[[ -n "${MCC_IP}" ]] || MCC_IP="${MCC_HOSTNAME}"

log "MyControl Centre — remote host setup"
log "User: ${MCC_USER}  Host: ${MCC_HOSTNAME}  IP: ${MCC_IP}"

# --- user -------------------------------------------------------------------
if id "${MCC_USER}" &>/dev/null; then
  log "User ${MCC_USER} already exists"
else
  log "Creating user ${MCC_USER}..."
  if getent group "${MCC_USER}" &>/dev/null; then
    useradd -m -s /bin/bash -g "${MCC_USER}" "${MCC_USER}"
  else
    useradd -m -s /bin/bash "${MCC_USER}"
  fi
fi

# --- authorized_keys --------------------------------------------------------
AUTH_DIR="/home/${MCC_USER}/.ssh"
AUTH_FILE="${AUTH_DIR}/authorized_keys"
mkdir -p "${AUTH_DIR}"
chmod 700 "${AUTH_DIR}"
touch "${AUTH_FILE}"
chmod 600 "${AUTH_FILE}"

if grep -qF "${MCC_PUBKEY}" "${AUTH_FILE}" 2>/dev/null; then
  log "Public key already in authorized_keys"
else
  log "Installing public key..."
  echo "${MCC_PUBKEY}" >> "${AUTH_FILE}"
fi
chown -R "${MCC_USER}:${MCC_USER}" "${AUTH_DIR}"

# --- sudo for apt (scoped) --------------------------------------------------
SUDOERS="/etc/sudoers.d/mycontrol-${MCC_USER}"
if [[ "${MCC_APT_SUDO}" -eq 1 ]]; then
  log "Configuring passwordless sudo for MyControl automation (apt, docker, systemctl, bash)..."
  cat > "${SUDOERS}" <<EOF
# MyControl Centre — automation sudo (managed by proxmox-host-setup.sh)
${MCC_USER} ALL=(ALL) NOPASSWD: /usr/bin/apt-get, /usr/bin/apt, /usr/bin/docker, /usr/bin/systemctl, /usr/bin/install, /usr/bin/curl, /usr/bin/tee, /usr/bin/chmod, /usr/bin/usermod, /usr/bin/bash, /bin/bash, /usr/bin/journalctl
EOF
  chmod 440 "${SUDOERS}"
  visudo -cf "${SUDOERS}" >/dev/null || die "sudoers validation failed"
else
  log "Skipping apt sudo (--no-apt-sudo)"
fi

# --- verify sshd allows pubkey auth -------------------------------------------
SSHD_CFG="/etc/ssh/sshd_config"
if [[ -f "${SSHD_CFG}" ]]; then
  if grep -qE '^[[:space:]]*PubkeyAuthentication[[:space:]]+no' "${SSHD_CFG}"; then
    warn "PubkeyAuthentication is disabled in sshd_config — enable it for key auth"
  fi
fi

# --- host key for console (ed25519 + rsa — SSH may negotiate either) ------------
MCC_HOST_KEYS=()
while IFS= read -r line; do
  [[ -z "${line}" || "${line}" == \#* ]] && continue
  key="$(echo "${line}" | awk '{print $3}')"
  [[ -n "${key}" ]] && MCC_HOST_KEYS+=("${key}")
done < <(ssh-keyscan -t ed25519,rsa -p "${MCC_SSH_PORT}" 127.0.0.1 "${MCC_IP}" 2>/dev/null | sort -u)

MCC_HOST_KEY=""
MCC_HOST_KEY_TYPE=""
for line in $(ssh-keyscan -t ed25519,rsa -p "${MCC_SSH_PORT}" 127.0.0.1 2>/dev/null | grep -v '^#'); do
  ktype="$(echo "${line}" | awk '{print $2}')"
  key="$(echo "${line}" | awk '{print $3}')"
  if [[ "${ktype}" == "ssh-ed25519" && -n "${key}" ]]; then
    MCC_HOST_KEY="${key}"
    MCC_HOST_KEY_TYPE="ed25519"
    break
  fi
done
if [[ -z "${MCC_HOST_KEY}" && ${#MCC_HOST_KEYS[@]} -gt 0 ]]; then
  MCC_HOST_KEY="${MCC_HOST_KEYS[0]}"
  MCC_HOST_KEY_TYPE="rsa"
fi

# --- local connectivity test ------------------------------------------------
log "Testing local SSH as ${MCC_USER}..."
if su - "${MCC_USER}" -c "echo mcc-ok" | grep -q mcc-ok; then
  log "Local shell OK"
else
  warn "Could not verify local login for ${MCC_USER}"
fi

# --- output for console -----------------------------------------------------
echo ""
echo "================================================================================"
echo "  MyControl Centre — copy these values into Add Server"
echo "================================================================================"
echo ""
echo "  Name:              ${MCC_HOSTNAME}"
echo "  Hostname / IP:     ${MCC_IP}"
echo "  Port:              ${MCC_SSH_PORT}"
echo "  SSH user:          ${MCC_USER}"
echo "  Auth type:         KEY"
echo "  Private key:       (paste the key you generated in MyControl Centre)"
if [[ -n "${MCC_HOST_KEY}" ]]; then
  echo "  Known host key:    ${MCC_HOST_KEY}"
  echo "  Host key type:     ${MCC_HOST_KEY_TYPE}"
else
  echo "  Known host key:    (leave empty and enable 'Accept on first connect')"
fi
echo ""
echo "  Privileged commands (Docker install, apt, etc.) need passwordless sudo."
echo "    • Re-run proxmox-host-setup.sh on the host to refresh /etc/sudoers.d/mycontrol-${MCC_USER}"
echo "    • Or store the SSH user's sudo password on the server (KEY_AND_PASSWORD auth)"
echo "    • Or use ssh user 'root' (not recommended)"
echo ""
echo "  Test from MyControl Centre host:"
echo "    ssh -i /path/to/private_key -p ${MCC_SSH_PORT} ${MCC_USER}@${MCC_IP} 'echo ok && uname -a'"
echo ""
echo "================================================================================"
echo "  JSON (optional — for automation)"
echo "================================================================================"
cat <<EOF
{
  "name": "${MCC_HOSTNAME}",
  "hostname": "${MCC_IP}",
  "port": ${MCC_SSH_PORT},
  "sshUser": "${MCC_USER}",
  "authType": "KEY",
  "knownHostKey": "${MCC_HOST_KEY}",
  "acceptNewHostKey": $([[ -n "${MCC_HOST_KEY}" ]] && echo false || echo true)
}
EOF
echo ""
if [[ -n "${MCC_ENROLL_URL}" ]]; then
  log "Submitting enrollment request to console..."
  export MCC_ENROLL_NAME="${MCC_HOSTNAME}"
  export MCC_ENROLL_HOST="${MCC_IP}"
  export MCC_ENROLL_PORT="${MCC_SSH_PORT}"
  export MCC_ENROLL_USER="${MCC_USER}"
  export MCC_ENROLL_PUBKEY="${MCC_PUBKEY}"
  export MCC_ENROLL_KNOWN="${MCC_HOST_KEY}"
  export MCC_ENROLL_KTYPE="${MCC_HOST_KEY_TYPE}"
  export MCC_ENROLL_HOST_KEYS="$(printf '%s\n' "${MCC_HOST_KEYS[@]}")"
  ENROLL_JSON="$(python3 - <<'PY'
import json, os, platform, subprocess
meta = {"kernel": platform.release(), "machine": platform.machine()}
try:
    with open("/etc/os-release") as f:
        for line in f:
            if line.startswith("PRETTY_NAME="):
                meta["os"] = line.split("=", 1)[1].strip().strip('"')
except OSError:
    pass
try:
    meta["uname"] = subprocess.check_output(["uname", "-a"], text=True, timeout=5).strip()
except Exception:
    pass
host_keys_raw = os.environ.get("MCC_ENROLL_HOST_KEYS", "").strip()
host_keys = [k.strip() for k in host_keys_raw.splitlines() if k.strip()]
if host_keys:
    meta["hostKeys"] = host_keys
payload = {
    "name": os.environ["MCC_ENROLL_NAME"],
    "hostname": os.environ["MCC_ENROLL_HOST"],
    "port": int(os.environ.get("MCC_ENROLL_PORT", "22")),
    "sshUser": os.environ["MCC_ENROLL_USER"],
    "publicKey": os.environ["MCC_ENROLL_PUBKEY"],
    "metadata": meta,
}
if host_keys:
    payload["knownHostKeys"] = host_keys
known = os.environ.get("MCC_ENROLL_KNOWN", "").strip()
ktype = os.environ.get("MCC_ENROLL_KTYPE", "").strip()
if known:
    payload["knownHostKey"] = known
if ktype:
    payload["hostKeyType"] = ktype
print(json.dumps(payload))
PY
  )" || die "python3 required for enrollment JSON"
  ENROLL_HTTP="$(curl -sS -o /tmp/mcc-enroll-response.json -w '%{http_code}' \
    -X POST "${MCC_ENROLL_URL}" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${MCC_ENROLL_TOKEN}" \
    -d "${ENROLL_JSON}")" || ENROLL_HTTP="000"
  ENROLL_OK=0
  if [[ "${ENROLL_HTTP}" =~ ^20[0-9]$ ]]; then
    ENROLL_OK=1
  elif command -v python3 >/dev/null 2>&1 && python3 - <<'PY' 2>/dev/null
import json, sys
try:
    with open("/tmp/mcc-enroll-response.json") as f:
        data = json.load(f)
    sys.exit(0 if data.get("ok") is True else 1)
except Exception:
    sys.exit(1)
PY
  then
    ENROLL_OK=1
  fi
  if [[ "${ENROLL_OK}" -eq 1 ]]; then
    log "Enrollment submitted (HTTP ${ENROLL_HTTP}; $(cat /tmp/mcc-enroll-response.json 2>/dev/null || echo ok))"
    echo "  → Approve this host in MyControl Centre → Servers → Pending enrollment"
  else
    warn "Enrollment POST failed (HTTP ${ENROLL_HTTP}). Response:"
    cat /tmp/mcc-enroll-response.json 2>/dev/null || true
    if command -v python3 >/dev/null 2>&1; then
      API_ERR="$(python3 - <<'PY' 2>/dev/null
import json
try:
    with open("/tmp/mcc-enroll-response.json") as f:
        data = json.load(f)
    print(data.get("error") or data.get("message") or "")
except Exception:
    pass
PY
)"
      [[ -n "${API_ERR}" ]] && warn "Console says: ${API_ERR}"
    fi
    echo ""
    echo "  Common fixes: regenerate SSH key in the console (refresh enroll token), check console URL/firewall,"
    echo "  and ensure MyControl Centre was restarted after upgrading."
    echo "  You can still add the server manually using the values above."
  fi
fi
log "Setup complete."
