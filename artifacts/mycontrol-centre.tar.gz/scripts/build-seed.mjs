import esbuild from "esbuild";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");

await esbuild.build({
  entryPoints: [path.join(root, "prisma/seed.ts")],
  bundle: true,
  platform: "node",
  format: "cjs",
  outfile: path.join(root, "prisma/seed.bundle.cjs"),
  external: ["@prisma/client"],
  logLevel: "info",
});
