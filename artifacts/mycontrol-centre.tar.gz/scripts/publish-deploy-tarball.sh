#!/usr/bin/env bash
#
# Build a source tarball for Proxmox LXC installs (public MycontrolCentre-deploy).
# Run from repo root: bash scripts/publish-deploy-tarball.sh [output-dir]
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
OUT_DIR="${1:-${ROOT}/dist/deploy-artifacts}"
TARBALL="${OUT_DIR}/mycontrol-centre.tar.gz"
VERSION_FILE="${OUT_DIR}/source-version.txt"

mkdir -p "${OUT_DIR}"

SHA="$(git -C "${ROOT}" rev-parse HEAD)"
SHORT_SHA="$(git -C "${ROOT}" rev-parse --short HEAD)"
REF="$(git -C "${ROOT}" rev-parse --abbrev-ref HEAD)"
BUILT_AT="$(date -u +"%Y-%m-%dT%H:%M:%SZ")"

STAGING="$(mktemp -d)"
trap 'rm -rf "${STAGING}"' EXIT

rsync -a \
  --exclude='.git' \
  --exclude='node_modules' \
  --exclude='.next' \
  --exclude='.data' \
  --exclude='dist' \
  --exclude='coverage' \
  --exclude='.env' \
  --exclude='.env.*' \
  --exclude='*.log' \
  "${ROOT}/" "${STAGING}/"

cat >"${STAGING}/.mcc-source-sha" <<EOF
${SHA}
EOF
cat >"${STAGING}/.mcc-source-version" <<EOF
ref=${REF}
sha=${SHA}
short_sha=${SHORT_SHA}
built_at=${BUILT_AT}
EOF

tar -czf "${TARBALL}" -C "${STAGING}" .

cat >"${VERSION_FILE}" <<EOF
ref=${REF}
sha=${SHA}
short_sha=${SHORT_SHA}
built_at=${BUILT_AT}
tarball=mycontrol-centre.tar.gz
EOF

echo "Wrote ${TARBALL} (${SHORT_SHA})"
echo "Wrote ${VERSION_FILE}"
