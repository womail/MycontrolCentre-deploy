#!/usr/bin/env bash
#
# MyControl Centre — one-time / repeat local setup
# Creates an isolated local environment (Node deps + SQLite database).
# Node.js equivalent of a Python virtualenv: dependencies live in node_modules/.
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log()  { echo -e "${GREEN}==>${NC} $*"; }
warn() { echo -e "${YELLOW}==>${NC} $*"; }
err()  { echo -e "${RED}==>${NC} $*" >&2; }

cd "${PROJECT_ROOT}"

require_node() {
  if ! command -v node >/dev/null 2>&1; then
    err "Node.js is required. Install Node 22+ from https://nodejs.org"
    err "Or use nvm: curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash"
    exit 1
  fi

  local major
  major="$(node -p "process.versions.node.split('.')[0]")"
  if [[ "${major}" -lt 20 ]]; then
    err "Node.js 20+ required (22 recommended). Current: $(node -v)"
    exit 1
  fi
  log "Node $(node -v)"
}

use_nvm_if_available() {
  if [[ -f "${HOME}/.nvm/nvm.sh" && -f "${PROJECT_ROOT}/.nvmrc" ]]; then
    # shellcheck disable=SC1091
    source "${HOME}/.nvm/nvm.sh"
    nvm install >/dev/null 2>&1 || true
    nvm use >/dev/null 2>&1 || true
    log "Using nvm Node $(node -v)"
  fi
}

ensure_data_dir() {
  mkdir -p "${PROJECT_ROOT}/.data"
  log "Data directory: ${PROJECT_ROOT}/.data"
}

fix_sqlite_url() {
  local url="${DATABASE_URL:-}"
  if [[ -z "${url}" || "${url}" != file:* ]]; then
    warn "DATABASE_URL is not SQLite — updating to file:../.data/mycontrol.db"
    bash "${SCRIPT_DIR}/set-env.sh" "${PROJECT_ROOT}/.env" DATABASE_URL "file:../.data/mycontrol.db"
    DATABASE_URL="file:../.data/mycontrol.db"
  fi
}

ensure_env() {
  if [[ ! -f "${PROJECT_ROOT}/.env" ]]; then
    cp "${PROJECT_ROOT}/.env.example" "${PROJECT_ROOT}/.env"
    log "Created .env from .env.example"
  fi

  # shellcheck disable=SC1091
  set -a
  source "${PROJECT_ROOT}/.env"
  set +a

  fix_sqlite_url

  if [[ -z "${SESSION_SECRET:-}" || "${SESSION_SECRET}" == change-me* ]]; then
    SESSION_SECRET="$(openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64)"
    bash "${SCRIPT_DIR}/set-env.sh" "${PROJECT_ROOT}/.env" SESSION_SECRET "${SESSION_SECRET}"
    log "Generated SESSION_SECRET"
  fi

  if [[ -z "${ENCRYPTION_KEY:-}" || "${ENCRYPTION_KEY}" == change-me* ]]; then
    ENCRYPTION_KEY="$(openssl rand -base64 32 2>/dev/null || head -c 32 /dev/urandom | base64)"
    bash "${SCRIPT_DIR}/set-env.sh" "${PROJECT_ROOT}/.env" ENCRYPTION_KEY "${ENCRYPTION_KEY}"
    log "Generated ENCRYPTION_KEY"
  fi

  if ! grep -q '^RUN_EMBEDDED_WORKER=' "${PROJECT_ROOT}/.env"; then
    echo 'RUN_EMBEDDED_WORKER="true"' >> "${PROJECT_ROOT}/.env"
  fi
}

install_deps() {
  log "Installing npm dependencies into node_modules/ (local virtualenv)..."
  npm install
}

setup_database() {
  log "Creating SQLite database..."
  npx prisma db push
  log "Repairing invalid JSON columns (if any)..."
  npm run db:repair
  log "Seeding default admin user and templates..."
  npm run db:seed
}

log "MyControl Centre — local setup"
log "=============================="
use_nvm_if_available
require_node
ensure_data_dir
ensure_env
install_deps
setup_database

echo ""
log "Setup complete. No Docker, PostgreSQL, or Redis required."
log "Start the app with:  ./scripts/start.sh local"
log "Or dev mode:         ./scripts/start.sh dev"
