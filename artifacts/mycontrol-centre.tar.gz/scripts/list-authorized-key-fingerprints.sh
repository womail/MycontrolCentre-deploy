#!/bin/sh
# List OpenSSH fingerprints for each line in authorized_keys (same format as ssh-keygen -lf).
# Usage on a fleet host:
#   sudo sh list-authorized-key-fingerprints.sh /home/mcc-auto/.ssh/authorized_keys
set -eu
file="${1:-/home/mcc-auto/.ssh/authorized_keys}"
if [ ! -f "$file" ]; then
  echo "No such file: $file" >&2
  exit 1
fi
n=0
while IFS= read -r line || [ -n "$line" ]; do
  case "$line" in
    '' | \#*) continue ;;
  esac
  n=$((n + 1))
  printf '%s) ' "$n"
  echo "$line" | ssh-keygen -lf -
done <"$file"
if [ "$n" -eq 0 ]; then
  echo "(no key lines in $file)" >&2
  exit 1
fi
