#!/usr/bin/env bash
# Simpler secret writer for setup.sh
set -euo pipefail
ENV_FILE="${1:?env file required}"
KEY="${2:?key required}"
VALUE="${3:?value required}"

if grep -q "^${KEY}=" "${ENV_FILE}"; then
  sed -i "s|^${KEY}=.*|${KEY}=\"${VALUE}\"|" "${ENV_FILE}"
else
  echo "${KEY}=\"${VALUE}\"" >> "${ENV_FILE}"
fi
