/**
 * Fix SQLite rows where Json columns were stored as empty strings instead of [].
 * Prisma throws P2023 on read and /api/servers returns 500 until repaired.
 */
import { prisma } from "../src/lib/db";

const REPAIRS: Array<{ table: string; column: string }> = [
  { table: "Server", column: "tags" },
  { table: "Server", column: "manualPlatforms" },
  { table: "Server", column: "detectedPlatforms" },
  { table: "SavedRunProfile", column: "serverIds" },
  { table: "SavedRunProfile", column: "templateIds" },
  { table: "SavedRunProfile", column: "failureTemplateIds" },
  { table: "ServerGroup", column: "serverIds" },
  { table: "ServerGroup", column: "matchTags" },
  { table: "CommandTemplate", column: "platforms" },
  { table: "CommandRun", column: "failureTemplateIds" },
];

async function main() {
  let repaired = 0;

  for (const { table, column } of REPAIRS) {
    const result = await prisma.$executeRawUnsafe(
      `UPDATE "${table}" SET "${column}" = '[]' WHERE "${column}" IS NULL OR trim("${column}") = ''`,
    );
    if (typeof result === "number" && result > 0) {
      console.log(`[repair-db] ${table}.${column}: fixed ${result} row(s)`);
      repaired += result;
    }
  }

  if (repaired === 0) {
    console.log("[repair-db] No invalid JSON columns found.");
  } else {
    console.log(`[repair-db] Repaired ${repaired} column value(s) total.`);
  }
}

main()
  .catch((error) => {
    console.error("[repair-db] Failed:", error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
