#!/usr/bin/env bash
#
# MyControl Centre — remove automation user / keys / sudo from a managed host
#
# Run as root on the remote host when decommissioning MCC or before production cutover.
#
set -euo pipefail

MCC_USER="${MCC_USER:-mcc-auto}"
MCC_PUBKEY=""
MCC_REMOVE_USER=0
MCC_REMOVE_SUDO=1

usage() {
  cat <<'EOF'
Usage: proxmox-host-cleanup.sh [options]

Remove MyControl Centre SSH automation from this host.

Options:
  --pubkey "KEY"     Remove this public key line from authorized_keys (recommended)
  --user NAME        Automation user (default: mcc-auto)
  --remove-user      Delete the automation user and home directory (destructive)
  --keep-sudo        Leave /etc/sudoers.d/mycontrol-* in place
  -h, --help         Show this help

Example (remove one wizard key, keep user):
  ./proxmox-host-cleanup.sh --pubkey "ssh-ed25519 AAAA... mycontrol-centre"

Example (full removal):
  ./proxmox-host-cleanup.sh --pubkey "ssh-ed25519 AAAA..." --remove-user
EOF
}

log()  { echo "==> $*"; }
warn() { echo "==> WARNING: $*" >&2; }
die()  { echo "ERROR: $*" >&2; exit 1; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --pubkey)       MCC_PUBKEY="${2:?missing value for --pubkey}"; shift 2 ;;
    --user)         MCC_USER="${2:?missing value for --user}"; shift 2 ;;
    --remove-user)  MCC_REMOVE_USER=1; shift ;;
    --keep-sudo)    MCC_REMOVE_SUDO=0; shift ;;
    -h|--help)      usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

[[ "$(id -u)" -eq 0 ]] || die "Run as root (e.g. sudo bash proxmox-host-cleanup.sh ...)"

log "MyControl Centre — remote host cleanup (user: ${MCC_USER})"

AUTH_FILE="/home/${MCC_USER}/.ssh/authorized_keys"
if [[ -n "${MCC_PUBKEY}" && -f "${AUTH_FILE}" ]]; then
  log "Removing public key from ${AUTH_FILE}..."
  tmp="$(mktemp)"
  grep -vF "${MCC_PUBKEY}" "${AUTH_FILE}" > "${tmp}" || true
  if [[ ! -s "${tmp}" ]]; then
    rm -f "${tmp}"
    log "No keys left in authorized_keys — removing file"
    rm -f "${AUTH_FILE}"
  else
    install -m 600 -o "${MCC_USER}" -g "${MCC_USER}" "${tmp}" "${AUTH_FILE}"
    rm -f "${tmp}"
  fi
elif [[ -n "${MCC_PUBKEY}" ]]; then
  warn "authorized_keys not found — key may already be removed"
fi

SUDOERS="/etc/sudoers.d/mycontrol-${MCC_USER}"
if [[ "${MCC_REMOVE_SUDO}" -eq 1 && -f "${SUDOERS}" ]]; then
  log "Removing ${SUDOERS}..."
  rm -f "${SUDOERS}"
fi

rm -f /tmp/mcc-proxmox-setup.sh /tmp/mcc-enroll-response.json 2>/dev/null || true

if [[ "${MCC_REMOVE_USER}" -eq 1 ]]; then
  if id "${MCC_USER}" &>/dev/null; then
    log "Deleting user ${MCC_USER}..."
    userdel -r "${MCC_USER}" 2>/dev/null || userdel "${MCC_USER}" || warn "Could not delete user ${MCC_USER}"
  else
    log "User ${MCC_USER} does not exist"
  fi
fi

log "Cleanup complete. Remove the server from MyControl Centre → Servers if you have not already."
