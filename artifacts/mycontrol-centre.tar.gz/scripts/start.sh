#!/usr/bin/env bash
#
# MyControl Centre — start / stop / status helper
#
# Usage:
#   ./scripts/start.sh local        Recommended: SQLite, no Docker (default)
#   ./scripts/start.sh dev          Local dev with file watching
#   ./scripts/start.sh prod         Build and run production locally
#   ./scripts/start.sh setup        Run first-time setup only
#   ./scripts/start.sh docker       Optional Docker deployment
#   ./scripts/start.sh stop         Stop local processes
#   ./scripts/start.sh status       Show running services
#   ./scripts/start.sh test         Run unit tests
#   ./scripts/start.sh db           Push schema and seed database
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
RUN_DIR="${PROJECT_ROOT}/.run"
LOG_DIR="${PROJECT_ROOT}/.logs"

APP_PID_FILE="${RUN_DIR}/app.pid"
WORKER_PID_FILE="${RUN_DIR}/worker.pid"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log()  { echo -e "${GREEN}==>${NC} $*"; }
warn() { echo -e "${YELLOW}==>${NC} $*"; }
err()  { echo -e "${RED}==>${NC} $*" >&2; }

lan_ip() {
  ip -4 route get 1.1.1.1 2>/dev/null | awk '/src/ { for (i=1;i<=NF;i++) if ($i=="src") { print $(i+1); exit } }' \
    || hostname -I 2>/dev/null | awk '{print $1}'
}

print_access_hints() {
  local lan
  lan="$(lan_ip)"
  echo ""
  log "MyControl Centre is listening on all interfaces (0.0.0.0:3000)"
  log "  Local:  http://127.0.0.1:3000"
  if [[ -n "${lan}" ]]; then
    log "  LAN:    http://${lan}:3000"
    log "  Health: curl -fsSL http://${lan}:3000/api/health"
    warn "Proxmox hosts must reach the LAN URL above (not localhost)."
    warn "If ping works but curl hangs, open TCP 3000 on this machine, e.g.:"
    warn "  sudo ufw allow 3000/tcp"
    warn "Test from Proxmox with: curl -v --connect-timeout 10 --noproxy '*' http://${lan}:3000/api/health"
  fi
}

cd "${PROJECT_ROOT}"

ensure_env() {
  if [[ ! -f "${PROJECT_ROOT}/.env" ]]; then
    warn ".env not found — running setup first"
    "${SCRIPT_DIR}/setup.sh"
    return
  fi

  # shellcheck disable=SC1091
  set -a
  source "${PROJECT_ROOT}/.env"
  set +a

  if [[ -z "${DATABASE_URL:-}" || "${DATABASE_URL}" != file:* ]]; then
    warn "Fixing DATABASE_URL for SQLite..."
    bash "${SCRIPT_DIR}/set-env.sh" "${PROJECT_ROOT}/.env" DATABASE_URL "file:../.data/mycontrol.db"
    DATABASE_URL="file:../.data/mycontrol.db"
  elif [[ "${DATABASE_URL}" == *"/app/.data"* ]]; then
    warn "DATABASE_URL is set for Docker (file:/app/.data/...). Fixing for local native dev..."
    bash "${SCRIPT_DIR}/set-env.sh" "${PROJECT_ROOT}/.env" DATABASE_URL "file:../.data/mycontrol.db"
    DATABASE_URL="file:../.data/mycontrol.db"
  fi
}

ensure_dirs() {
  mkdir -p "${RUN_DIR}" "${LOG_DIR}" "${PROJECT_ROOT}/.data"
}

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    err "Required command not found: $1"
    exit 1
  fi
}

is_running() {
  local pid_file="$1"
  if [[ -f "${pid_file}" ]]; then
    local pid
    pid="$(cat "${pid_file}")"
    if kill -0 "${pid}" 2>/dev/null; then
      return 0
    fi
    rm -f "${pid_file}"
  fi
  return 1
}

stop_pid_file() {
  local name="$1"
  local pid_file="$2"
  if is_running "${pid_file}"; then
    local pid
    pid="$(cat "${pid_file}")"
    log "Stopping ${name} (PID ${pid})..."
    kill "${pid}" 2>/dev/null || true
    sleep 1
    kill -0 "${pid}" 2>/dev/null && kill -9 "${pid}" 2>/dev/null || true
    rm -f "${pid_file}"
  fi
}

setup_db() {
  require_cmd npx
  log "Applying database schema..."
  npx prisma db push
  log "Repairing invalid JSON columns (if any)..."
  npm run db:repair
  log "Seeding database..."
  npm run db:seed
}

start_app_dev() {
  export RUN_EMBEDDED_WORKER="${RUN_EMBEDDED_WORKER:-true}"
  if is_running "${APP_PID_FILE}"; then
    warn "App already running (PID $(cat "${APP_PID_FILE}"))"
  else
    log "Starting Next.js dev server (embedded command worker)..."
    nohup npm run dev > "${LOG_DIR}/app.log" 2>&1 &
    echo $! > "${APP_PID_FILE}"
    log "App started — PID $(cat "${APP_PID_FILE}") — log: ${LOG_DIR}/app.log"
  fi
}

start_app_prod() {
  export RUN_EMBEDDED_WORKER="${RUN_EMBEDDED_WORKER:-true}"
  stop_pid_file "app" "${APP_PID_FILE}"
  log "Starting production server (embedded command worker)..."
  nohup npm run start > "${LOG_DIR}/app.log" 2>&1 &
  echo $! > "${APP_PID_FILE}"
  log "App started — PID $(cat "${APP_PID_FILE}")"
}

start_standalone_worker() {
  if [[ "${RUN_EMBEDDED_WORKER:-true}" == "true" ]]; then
    log "Embedded worker enabled — skipping separate worker process"
    return
  fi
  if is_running "${WORKER_PID_FILE}"; then
    warn "Worker already running (PID $(cat "${WORKER_PID_FILE}"))"
  else
    log "Starting standalone command worker..."
    nohup npm run worker > "${LOG_DIR}/worker.log" 2>&1 &
    echo $! > "${WORKER_PID_FILE}"
    log "Worker started — PID $(cat "${WORKER_PID_FILE}")"
  fi
}

cmd_setup() {
  "${SCRIPT_DIR}/setup.sh"
}

cmd_local() {
  require_cmd node
  require_cmd npm
  if [[ ! -d "${PROJECT_ROOT}/node_modules" ]]; then
    cmd_setup
  else
    ensure_env
    ensure_dirs
    setup_db
  fi
  ensure_env
  ensure_dirs
  export RUN_EMBEDDED_WORKER=true
  start_app_dev
  print_access_hints
  echo ""
  log "MyControl Centre running locally (SQLite, no Docker)"
  warn "Dev mode (next dev) often uses 1–2 GB RAM — for lower memory use: ./scripts/start.sh prod"
  log "  UI:     ${APP_URL:-http://localhost:3000}"
  log "  Login:  admin / admin (change password on first login)"
  log "  DB:     ${PROJECT_ROOT}/.data/mycontrol.db"
  log "  Logs:   ${LOG_DIR}/"
  log "  Stop:   ./scripts/start.sh stop"
}

cmd_dev() {
  cmd_local
}

cmd_prod() {
  require_cmd node
  require_cmd npm
  ensure_env
  ensure_dirs
  setup_db
  log "Building application..."
  # Next must see production during build (never NODE_ENV=development from .env)
  NODE_ENV=production npm run build
  export RUN_EMBEDDED_WORKER=true
  start_app_prod
  print_access_hints
  echo ""
  log "MyControl Centre running in production mode"
  log "  UI:   ${APP_URL:-http://localhost:3000}"
  log "  Stop: ./scripts/start.sh stop"
}

cmd_docker() {
  require_cmd docker
  ensure_env

  if [[ ! -f "${PROJECT_ROOT}/.env" ]]; then
    if [[ -f "${PROJECT_ROOT}/.env.docker.example" ]]; then
      cp "${PROJECT_ROOT}/.env.docker.example" "${PROJECT_ROOT}/.env"
      warn "Created .env from .env.docker.example — set SESSION_SECRET and ENCRYPTION_KEY before production use."
    fi
  fi

  ensure_env
  warn "Docker mode is optional. Prefer ./scripts/start.sh local for zero-dependency runs."

  if [[ -z "${SESSION_SECRET:-}" || "${SESSION_SECRET}" == change-me* ]]; then
    export SESSION_SECRET="$(openssl rand -base64 32)"
    bash "${SCRIPT_DIR}/set-env.sh" "${PROJECT_ROOT}/.env" SESSION_SECRET "${SESSION_SECRET}"
    warn "Generated SESSION_SECRET and saved to .env"
  fi
  if [[ -z "${ENCRYPTION_KEY:-}" || "${ENCRYPTION_KEY}" == change-me* ]]; then
    export ENCRYPTION_KEY="$(openssl rand -base64 32)"
    bash "${SCRIPT_DIR}/set-env.sh" "${PROJECT_ROOT}/.env" ENCRYPTION_KEY "${ENCRYPTION_KEY}"
    warn "Generated ENCRYPTION_KEY and saved to .env"
  fi

  docker compose up -d --build
  log "Docker stack started at ${APP_URL:-http://localhost:3000}"
  log "  Logs:   docker compose logs -f app"
  log "  Stop:   ./scripts/start.sh stop docker"
}

cmd_stop() {
  ensure_dirs
  stop_pid_file "app" "${APP_PID_FILE}"
  stop_pid_file "worker" "${WORKER_PID_FILE}"

  if [[ "${1:-}" == "docker" ]]; then
    require_cmd docker
    docker compose down
  fi

  log "Stopped"
}

cmd_status() {
  ensure_dirs
  echo "MyControl Centre status"
  echo "-----------------------"

  if [[ -f "${PROJECT_ROOT}/.data/mycontrol.db" ]]; then
    echo -e "SQLite: ${GREEN}present${NC} (.data/mycontrol.db)"
  else
    echo -e "SQLite: ${YELLOW}not initialized${NC} — run ./scripts/setup.sh"
  fi

  if is_running "${APP_PID_FILE}"; then
    echo -e "App:    ${GREEN}running${NC} (PID $(cat "${APP_PID_FILE}"))"
  else
    echo -e "App:    ${RED}stopped${NC}"
  fi

  if [[ "${RUN_EMBEDDED_WORKER:-true}" == "true" ]]; then
    echo -e "Worker: ${GREEN}embedded${NC} (runs inside app process)"
  elif is_running "${WORKER_PID_FILE}"; then
    echo -e "Worker: ${GREEN}running${NC} (PID $(cat "${WORKER_PID_FILE}"))"
  else
    echo -e "Worker: ${RED}stopped${NC}"
  fi
}

cmd_test() {
  require_cmd npm
  npm test
}

cmd_db() {
  require_cmd npx
  ensure_env
  ensure_dirs
  setup_db
  log "Database ready at .data/mycontrol.db"
}

usage() {
  sed -n '3,15p' "$0" | sed 's/^# \?//'
  exit 1
}

ACTION="${1:-local}"

case "${ACTION}" in
  local|dev) cmd_local ;;
  prod)      cmd_prod ;;
  setup)     cmd_setup ;;
  docker)    cmd_docker ;;
  stop)      cmd_stop "${2:-}" ;;
  status)    cmd_status ;;
  test)      cmd_test ;;
  db)        cmd_db ;;
  -h|--help|help) usage ;;
  *)
    err "Unknown command: ${ACTION}"
    usage
    ;;
esac
